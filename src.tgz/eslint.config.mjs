import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
  {
    // Booking paths handle customer names and phone numbers; a stray
    // console.* would make Vercel logs a PII sink (build/08 veto 16 — use
    // lib/redact.ts if something MUST be logged).
    files: [
      "app/api/booking/**",
      "app/api/cron/**",
      "app/api/inquiry/**",
      "lib/booking.ts",
      "lib/http/**",
      "lib/notify.ts",
      "lib/pii.ts",
      "lib/rate-limit.ts",
      "lib/redact.ts",
      "lib/sanitize.ts",
    ],
    rules: {
      "no-console": "error",
    },
  },
]);

export default eslintConfig;
