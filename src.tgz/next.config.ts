import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactCompiler: true,
  // Nothing gains from advertising the framework version to scanners.
  poweredByHeader: false,
  // No CSP here on purpose: the site ships inline JSON-LD (restaurant schema in
  // the layout, FAQPage on /find-us) and a nonce-based policy needs middleware,
  // which costs the static export nothing but complexity. Revisit if the site
  // ever takes user input beyond the env-gated inquiry form.
  // INTERIM, file-upload deployments only: the MCP deploy path cannot carry
  // binaries, so /photos/* proxies the public assets repo via jsDelivr. The
  // same files exist in public/photos, and rewrites lose to real files on any
  // git-connected build - so this is harmless there and this block plus the
  // assets repo (pllxrgn-ui/speedtrap-site-photos) can be deleted the day the
  // project deploys from git.
  async rewrites() {
    return [
      {
        source: '/photos/:path*',
        destination: 'https://cdn.jsdelivr.net/gh/pllxrgn-ui/speedtrap-site-photos@main/:path*',
      },
    ]
  },
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'DENY' },
        ],
      },
    ];
  },
};

export default nextConfig;
