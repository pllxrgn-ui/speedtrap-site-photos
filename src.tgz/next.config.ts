import type { NextConfig } from "next";
import { RETIRED_ROUTES } from "./lib/links";

const nextConfig: NextConfig = {
  reactCompiler: true,
  // `next dev` otherwise writes apps/web/AGENTS.md AND apps/web/CLAUDE.md
  // whenever it detects an agent (config-shared.d.ts:1574, default true;
  // next/dist/docs/01-app/02-guides/ai-agents.md documents the opt-out).
  // A generated apps/web/CLAUDE.md would be read as this package's project
  // instructions and would quietly compete with the real one at the repo
  // root - the version-matched Next docs it points at are already on disk
  // at node_modules/next/dist/docs/ for anyone who wants them.
  agentRules: false,
  // 'use cache' + cacheTag('overlay') for the menu overlay (build/08 fork
  // C). useCache, NOT cacheComponents - cacheComponents flips the app
  // dynamic-by-default and costs the 1.02s LCP (verified against this
  // Next's config-shared.d.ts during planning).
  experimental: { useCache: true },
  // Owner-uploaded dish photos live in the project's public Blob store
  // (contract §Back of House amendment 2026-09-22).
  images: {
    remotePatterns: [{ protocol: 'https', hostname: '*.public.blob.vercel-storage.com' }],
  },
  // Nothing gains from advertising the framework version to scanners.
  poweredByHeader: false,
  // No CSP here on purpose: the site ships inline JSON-LD (Restaurant, Menu
  // and FAQPage, all three emitted from app/(site)/page.tsx since build/13
  // moved Restaurant out of the layout) and a nonce-based policy needs middleware,
  // which costs the static export nothing but complexity. Revisit if the site
  // ever takes user input beyond the env-gated inquiry form.
  // INTERIM, file-upload deployments only: the MCP deploy path cannot carry
  // binaries, so /photos/* proxies the public assets repo via jsDelivr,
  // PINNED TO A COMMIT SHA - @main sat behind jsDelivr's 12h edge cache and
  // production served a stale hero photo for hours after a swap (audit
  // build/05 M7). When a photo changes: push the assets repo, paste the new
  // SHA here, redeploy. Delete this block plus the assets repo the day the
  // project deploys from git.
  // ONE PAGE (build/07): every retired route sends its visitors to its
  // fragment. permanent:true emits 308 (Next never emits 301) - equivalent
  // for consolidation, cached hard; safe ONLY because robots.ts proves the
  // preview host is not indexed. If a real domain is live before a change
  // like this, run permanent:false for a fortnight first. Incoming fragments
  // (/menu#burgers) are lost by the browser - visitors land on the category
  // index, and /#burgers typed directly still works.
  async redirects() {
    return RETIRED_ROUTES.map((route) => ({
      source: route.source,
      destination: route.destination,
      permanent: true,
    }))
  },
  async rewrites() {
    return [
      {
        source: '/photos/:path*',
        destination:
          'https://cdn.jsdelivr.net/gh/pllxrgn-ui/speedtrap-site-photos@e846fd01db9c144964c0a05c68bcf42b09471baa/:path*',
      },
    ]
  },
  async headers() {
    const noindex = { key: 'X-Robots-Tag', value: 'noindex, nofollow' }
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'DENY' },
        ],
      },
      // Back office: header-level noindex, layer two of three (build/08
      // §2 row 10). robots.ts and the admin layout metadata are the others.
      { source: '/admin', headers: [noindex] },
      { source: '/admin/:path*', headers: [noindex] },
      { source: '/api/admin/:path*', headers: [noindex] },
    ];
  },
};

export default nextConfig;
