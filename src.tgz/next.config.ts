import type { NextConfig } from "next";
import { RETIRED_ROUTES } from "./lib/links";

const nextConfig: NextConfig = {
  reactCompiler: true,
  // Nothing gains from advertising the framework version to scanners.
  poweredByHeader: false,
  // No CSP here on purpose: the site ships inline JSON-LD (restaurant schema in
  // the layout, FAQPage on /find-us) and a nonce-based policy needs middleware,
  // which costs the static export nothing but complexity. Revisit if the site
  // ever takes user input beyond the env-gated inquiry form.
  // INTERIM, file-upload deployments only: the MCP deploy path cannot carry
  // binaries, so /photos/* proxies the public assets repo via jsDelivr,
  // PINNED TO A COMMIT SHA - @main sat behind jsDelivr's 12h edge cache and
  // production served a stale hero photo for hours after a swap (audit
  // build/05 M7). When a photo changes: push the assets repo, paste the new
  // SHA here, redeploy. Delete this block plus the assets repo the day the
  // project deploys from git.
  // ONE PAGE (build/07): every retired route sends its visitors to its
  // fragment. permanent:true emits 308 (Next never emits 301) - equivalent
  // for consolidation, cached hard; safe ONLY because robots.ts proves the
  // preview host is not indexed. If a real domain is live before a change
  // like this, run permanent:false for a fortnight first. Incoming fragments
  // (/menu#burgers) are lost by the browser - visitors land on the category
  // index, and /#burgers typed directly still works.
  async redirects() {
    return RETIRED_ROUTES.map((route) => ({
      source: route.source,
      destination: route.destination,
      permanent: true,
    }))
  },
  async rewrites() {
    return [
      {
        source: '/photos/:path*',
        destination:
          'https://cdn.jsdelivr.net/gh/pllxrgn-ui/speedtrap-site-photos@e846fd01db9c144964c0a05c68bcf42b09471baa/:path*',
      },
    ]
  },
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'DENY' },
        ],
      },
    ];
  },
};

export default nextConfig;
