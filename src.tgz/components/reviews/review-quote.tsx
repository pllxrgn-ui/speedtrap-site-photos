import type { Quote } from '@/lib/quotes'

// Plain blockquote, attribution required, no avatars and no star graphics per
// quote: we have no rights to reviewer photos and no per-review rating data.
export function ReviewQuote({ quote }: { quote: Quote }) {
  return (
    <figure className="border-t-2 border-ink pt-5">
      <blockquote className="max-w-[42ch] text-2xl font-bold leading-snug">
        {quote.text}
      </blockquote>
      <figcaption className="mt-3 text-ink-muted">
        {quote.author}
        <span className="block font-mono text-sm tabular-nums">
          {quote.source}, {quote.year}
        </span>
      </figcaption>
    </figure>
  )
}
