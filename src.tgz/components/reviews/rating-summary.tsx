import { Star } from '@phosphor-icons/react/dist/ssr'
import { Odometer } from '@/components/ui/odometer'
import { SITE } from '@/lib/site'

// Numerals in mono, tabular, like sign data (build/03 §1.2). The as-of date is
// rendered because a rating is a snapshot, not a standing claim.
//
// The figure rolls up when its <Reveal> comes into view (build/03 §1.5). Mono
// tabular digits were already the right material for it: the columns are
// identical widths, so nothing reflows as it counts. The sr-only sentence
// below is the accessible copy and is untouched by any of this.
export function RatingSummary() {
  const { value, count, source, asOf } = SITE.rating

  return (
    <div className="mt-8 border-t-2 border-ink pt-5">
      <p className="sr-only">
        Rated {value} out of 5 from {count} {source} reviews, as of {asOf}.
      </p>
      <p aria-hidden className="flex items-center gap-3">
        <Star size={28} weight="fill" />
        <Odometer
          value={String(value)}
          trigger="view"
          className="font-mono text-h2 font-bold tabular-nums"
        />
        <span className="text-lg">of 5</span>
      </p>
      <p aria-hidden className="mt-2 font-mono tabular-nums text-ink-muted">
        {count} reviews on {source}
      </p>
      <p aria-hidden className="mt-1 font-mono text-sm tabular-nums text-ink-muted">
        as of {asOf}
      </p>
    </div>
  )
}
