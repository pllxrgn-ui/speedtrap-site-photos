'use client'

import * as Accordion from '@radix-ui/react-accordion'
import { Minus, Plus } from '@phosphor-icons/react/dist/ssr'
import type { Faq } from '@/lib/faq'

// The only accordion on the site (build/03 §3). Height transition is 200ms
// ease-out, motion register item #4.
//
// Keyframes rather than a CSS transition on purpose: Radix removes the content
// node immediately when it detects no running animation, so a transition alone
// would never play on close. The whole block sits behind
// prefers-reduced-motion: no-preference, where it collapses to an instant
// open and close. The styles live here rather than in globals.css because
// nothing else on the site uses them.
const ACCORDION_CSS = `
.stt-acc-content { overflow: hidden; }
@media (prefers-reduced-motion: no-preference) {
  .stt-acc-content[data-state='open'] { animation: stt-acc-open 200ms ease-out; }
  .stt-acc-content[data-state='closed'] { animation: stt-acc-close 200ms ease-out; }
}
@keyframes stt-acc-open {
  from { height: 0; }
  to { height: var(--radix-accordion-content-height); }
}
@keyframes stt-acc-close {
  from { height: var(--radix-accordion-content-height); }
  to { height: 0; }
}
.stt-acc-trigger[data-state='open'] .stt-acc-plus { display: none; }
.stt-acc-trigger[data-state='closed'] .stt-acc-minus { display: none; }
`

export function FaqAccordion({ items }: { items: readonly Faq[] }) {
  return (
    <>
      <style>{ACCORDION_CSS}</style>
      <Accordion.Root
        type="single"
        collapsible
        className="border-t border-hairline"
      >
        {items.map((item, index) => (
          <Accordion.Item
            key={item.q}
            value={`faq-${index}`}
            className="border-b border-hairline"
          >
            {/* The size lives on the Header, which is the real h3, so the
                question renders at the h3 token (1.25rem, build/03 §1.2)
                instead of leaving a 16px/400 heading behind a styled button. */}
            <Accordion.Header className="text-xl font-bold">
              {/* tick: the amber edge line, same as every other row on the
                  site. Closed, it lands on the item's own hairline; open, it
                  underlines the question above its answer. */}
              <Accordion.Trigger className="stt-acc-trigger tick tap-feedback flex w-full min-h-14 items-center justify-between gap-4 py-4 text-left">
                <span>{item.q}</span>
                <Plus size={22} weight="bold" aria-hidden className="stt-acc-plus shrink-0" />
                <Minus size={22} weight="bold" aria-hidden className="stt-acc-minus shrink-0" />
              </Accordion.Trigger>
            </Accordion.Header>
            <Accordion.Content className="stt-acc-content">
              <p className="max-w-[62ch] pb-5 leading-relaxed text-ink-muted">{item.a}</p>
            </Accordion.Content>
          </Accordion.Item>
        ))}
      </Accordion.Root>
    </>
  )
}
