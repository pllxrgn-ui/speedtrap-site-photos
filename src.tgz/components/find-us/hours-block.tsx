import { Clock } from '@phosphor-icons/react/dist/ssr'
import { dayName, formatRange } from '@/lib/hours'
import type { ExceptionLine, HoursView } from '@/lib/hours-data'
import { TEL_HREF } from '@/lib/links'
import { hoursProvenance } from '@/lib/provenance'
import { SITE } from '@/lib/site'

// THE HOURS (build/13). Owner-entered HoursDay / HoursException rows, read
// through lib/hours-data.ts. TWO RULES, both load-bearing:
//
// 1. THE ABSENCE BRANCH BELOW IS THE FALLBACK FOR EVERYTHING - no database,
//    a thrown query, a partial week. There is no SEED_HOURS and there never
//    will be; a cached wrong table on THIS site is the product's founding
//    failure ("six different sets of hours ... ours is the one at the other
//    end of this number").
// 2. ALL SEVEN DAYS OR NONE. A gap reads as "closed", which is a guess.
//
// Pure and synchronous on purpose (build/13 §2.8): the page reads getHours()
// once and passes the view down, so this unit-tests against fixed data with
// no mocks and no async server component lands inside Reveal's client
// boundary. Dated notices render whether or not the week does (§2.6).
//
// NOT HERE, deliberately: any open-now / closed-now claim (§2.7, cut - it
// needs client time or a dynamic render, and veto 7 bans the second), and
// row emphasis for today, which is Optional Rider 1 and out of scope.
export function HoursBlock({ view }: { view: HoursView }) {
  const stamp = view.week ? hoursProvenance(view.week.updatedAt).blockLabel : null
  return (
    <div className="flex min-h-[18rem] flex-col justify-between rounded border border-hairline bg-paper p-6 md:min-h-[22rem] md:p-8">
      <div>
        <Clock size={40} weight="fill" aria-hidden />
        {view.week ? (
          <>
            <h2 className="mt-4 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
              Our hours
            </h2>
            {/* Day labels in the chrome register, and EVERY numeral in
                Martian Mono (design-system rule 4, no exceptions). The
                separator inside formatRange is an ASCII hyphen - an en dash
                would fail check-no-placeholder.mjs on the rendered page. */}
            <dl className="mt-5 border-t border-hairline">
              {view.week.days.map(({ day, state }) => (
                <div
                  key={day}
                  className="flex items-baseline justify-between gap-4 border-b border-hairline py-2.5"
                >
                  <dt className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                    {dayName(day)}
                  </dt>
                  <dd className="font-mono font-bold tabular-nums">
                    {state.state === 'open' ? formatRange(state.open, state.close) : 'Closed'}
                  </dd>
                </div>
              ))}
            </dl>
          </>
        ) : (
          <>
            <h2 className="mt-4 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
              Call for today&rsquo;s hours
            </h2>
            <p className="mt-4 max-w-[44ch] leading-relaxed text-ink-muted">
              There are six different sets of hours for this place floating around the
              internet. Ours is the one at the other end of this number, and it is the
              only one worth driving on.
            </p>
          </>
        )}

        {view.exceptions.map((line) => (
          <ExceptionNote key={line.key} line={line} />
        ))}

        {stamp && <p className="mt-4 font-mono text-xs text-ink-muted">{stamp}</p>}
      </div>
      {/* The primary action on this block, so it is a 48px target, not a
          24px line of type (build/03 §1.4 touch targets). Printing hours is
          not a reason to demote the number (veto 11). */}
      <p className="mt-8">
        <a
          href={TEL_HREF}
          className="tap-feedback inline-flex min-h-12 items-center font-mono text-2xl font-bold tabular-nums underline underline-offset-4"
        >
          {SITE.phoneDisplay}
        </a>
      </p>
    </div>
  )
}

/** The same material the owner already recognises from the menu head
 *  (components/menu/today-note.tsx): ink edge, surface plate, mono eyebrow,
 *  bold body. One line per winning dated row - never two claims about the
 *  same day (§1.9). */
function ExceptionNote({ line }: { line: ExceptionLine }) {
  return (
    <p className="mt-4 max-w-[52ch] border-l-2 border-ink bg-surface py-3 pl-5 pr-4">
      <span className="mr-3 font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
        {line.eyebrow}
      </span>
      <span className="font-bold">{line.body}</span>
    </p>
  )
}
