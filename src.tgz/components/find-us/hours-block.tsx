import { Clock } from '@phosphor-icons/react/dist/ssr'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Hours are unverified: SITE.hours.verified is false and SITE.hours.weekly is
// null. Six public listings give six different answers (research/01 §3), so no
// times are rendered anywhere on this site, in the page or in the JSON-LD.
//
// WHEN THE OWNER CONFIRMS: flip site.ts, then build the labeled hours table
// here against the real shape (Zingerman's pattern, two labeled blocks, mono
// times, today emphasized, per build/03 ref index). Do not build it against the
// null shape first, it would ship untested and unverifiable.

export function HoursBlock() {
  return (
    <div className="flex min-h-[18rem] flex-col justify-between rounded border border-hairline bg-paper p-6 md:min-h-[22rem] md:p-8">
      <div>
        <Clock size={40} weight="fill" aria-hidden />
        <h2 className="mt-4 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
          Call for today&rsquo;s hours
        </h2>
        <p className="mt-4 max-w-[44ch] leading-relaxed text-ink-muted">
          There are six different sets of hours for this place floating around the
          internet. Ours is the one at the other end of this number, and it is the
          only one worth driving on.
        </p>
      </div>
      {/* The primary action on this block, so it is a 48px target, not a
          24px line of type (build/03 §1.4 touch targets). */}
      <p className="mt-8">
        <a
          href={TEL_HREF}
          className="tap-feedback inline-flex min-h-12 items-center font-mono text-2xl font-bold tabular-nums underline underline-offset-4"
        >
          {SITE.phoneDisplay}
        </a>
      </p>
    </div>
  )
}
