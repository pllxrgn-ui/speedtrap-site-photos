'use client'

import { useState } from 'react'
import { ArrowSquareOut, MapPin } from '@phosphor-icons/react/dist/ssr'
import { SignPlate } from '@/components/site/sign-plate'
import { DIRECTIONS_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Google Maps as a click-to-load facade (added 2026-09-14 on client request).
//
// The full embed costs roughly a megabyte of script and tiles before it
// paints, and this site's whole budget is a megabyte on throttled 4G
// (build/00-spec.md) - so nothing loads until the visitor asks for it. The
// tap swaps this flat block for the real interactive map. That is also the
// privacy-correct shape: Google sets nothing until the visitor opts in,
// which keeps the no-trackers promise (research/04) honest.
//
// The embed iframe is Google's keyless one: no API key, no billing, no env.
// It is pinned to the verified coordinates, not a street address - the E/W
// Broadway conflict is unresolved (CLIENT-QUESTIONS #3) and this component
// must not take a side.
const EMBED_SRC = `https://www.google.com/maps?q=${SITE.geo.lat},${SITE.geo.lng}&z=15&output=embed`

export function MapBlock() {
  const [loaded, setLoaded] = useState(false)

  if (loaded) {
    return (
      <div className="flex min-h-[18rem] flex-col md:min-h-[22rem]">
        <div className="img-frame relative flex-1 overflow-hidden rounded">
          <iframe
            src={EMBED_SRC}
            title={`Map showing ${SITE.name} on Highway 2 in Reardan, Washington`}
            className="absolute inset-0 h-full w-full border-0"
            loading="eager"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
          />
        </div>
        <p className="mt-2">
          <a
            href={DIRECTIONS_HREF}
            target="_blank"
            rel="noopener"
            className="inline-flex min-h-11 items-center gap-2 font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            Open in the Google Maps app for turn by turn
            <ArrowSquareOut size={18} weight="bold" aria-hidden />
          </a>
        </p>
      </div>
    )
  }

  return (
    <button
      type="button"
      onClick={() => setLoaded(true)}
      className="lift tap-feedback flex min-h-[18rem] w-full flex-col justify-between rounded border border-hairline bg-paper p-6 text-left md:min-h-[22rem] md:p-8"
    >
      <SignPlate className="self-start text-sm">Highway 2, Reardan</SignPlate>

      <span className="mt-8 block">
        <MapPin size={40} weight="fill" aria-hidden />
        <span className="mt-4 flex items-center gap-2 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight">
          Tap to load the map
        </span>
        <span className="mt-2 block max-w-[40ch] text-ink-muted">
          Loads Google Maps right here. Pan, zoom, and get directions from
          wherever you are right now.
        </span>
      </span>
    </button>
  )
}
