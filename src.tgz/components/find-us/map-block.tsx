import { ArrowSquareOut, MapPin } from '@phosphor-icons/react/dist/ssr'
import { SignPlate } from '@/components/site/sign-plate'
import { DIRECTIONS_HREF } from '@/lib/links'

// Deliberately not a map iframe. A Google Maps embed costs roughly a megabyte
// of script and tiles before it paints, and this site's whole budget is a
// megabyte on throttled 4G (build/00-spec.md). This is a flat block that opens
// the real map in one tap, which is what a driver actually wants anyway.
//
// STATIC MAP SLOT: when we have a licensed static map capture, drop a WebP in
// here as a next/image with explicit width and height and keep this link as its
// wrapper. Do not swap it for an iframe.

export function MapBlock() {
  return (
    <a
      href={DIRECTIONS_HREF}
      target="_blank"
      rel="noopener"
      className="tap-feedback flex min-h-[18rem] flex-col justify-between rounded border border-hairline bg-paper p-6 md:min-h-[22rem] md:p-8"
    >
      <SignPlate className="self-start text-sm">Highway 2, Reardan</SignPlate>

      <div className="mt-8">
        <MapPin size={40} weight="fill" aria-hidden />
        <p className="mt-4 flex items-center gap-2 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight">
          Open in Google Maps
          <ArrowSquareOut size={22} weight="bold" aria-hidden />
        </p>
        <p className="mt-2 max-w-[40ch] text-ink-muted">
          Tap for turn by turn directions from wherever you are right now.
        </p>
      </div>
    </a>
  )
}
