'use client'

import { useState } from 'react'
import Image from 'next/image'
import { ArrowSquareOut } from '@phosphor-icons/react/dist/ssr'
import { DIRECTIONS_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Google Maps as a click-to-load facade (client request 2026-09-14), with a
// real map IMAGE as the resting state so the pin is visible before any tap.
//
// The preview is a one-time OpenStreetMap render (assets/web-ready, ODbL,
// attribution below is required and stays) with the brand locator dot baked
// in at the verified coordinates. Google imagery cannot be used this way -
// their terms allow embeds, not extracted stills - which is why the still is
// OSM and the live map is Google.
//
// Until the tap: one 66KB image, zero third-party requests, zero cookies.
// The tap swaps in Google's keyless embed iframe (no API key, no billing).
// Coordinates, never a street address: E/W Broadway is unresolved
// (CLIENT-QUESTIONS #3) and this component must not take a side.
const EMBED_SRC = `https://www.google.com/maps?q=${SITE.geo.lat},${SITE.geo.lng}&z=15&output=embed`

export function MapBlock() {
  const [loaded, setLoaded] = useState(false)

  if (loaded) {
    return (
      <div className="flex min-h-[18rem] flex-col md:min-h-[22rem]">
        <div className="img-frame relative flex-1 overflow-hidden rounded">
          <iframe
            src={EMBED_SRC}
            title={`Map showing ${SITE.name} on Highway 2 in Reardan, Washington`}
            className="absolute inset-0 h-full w-full border-0"
            loading="eager"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
          />
        </div>
        <p className="mt-2">
          <a
            href={DIRECTIONS_HREF}
            target="_blank"
            rel="noopener"
            className="inline-flex min-h-11 items-center gap-2 font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            Open in the Google Maps app for turn by turn
            <ArrowSquareOut size={18} weight="bold" aria-hidden />
          </a>
        </p>
      </div>
    )
  }

  return (
    <button
      type="button"
      onClick={() => setLoaded(true)}
      className="lift tap-feedback img-frame relative block min-h-[18rem] w-full overflow-hidden rounded text-left md:min-h-[22rem]"
    >
      <Image
        src="/photos/map-reardan.webp"
        alt={`Map of Reardan, Washington with a pin marking ${SITE.name} on Highway 2. Tap to load the interactive map.`}
        fill
        sizes="(min-width: 1024px) 574px, 100vw"
        className="object-cover"
      />
      {/* Text sits on solid plates, never on the map itself (build/03 §1.6.1). */}
      <span className="absolute inset-x-3 bottom-3 flex flex-wrap items-end justify-between gap-2">
        <span className="rounded bg-ink px-4 py-2.5 font-bold uppercase tracking-tight text-paper">
          Tap for the live map
        </span>
        {/* ODbL attribution for the preview render. Required, do not remove. */}
        <span className="rounded bg-surface/95 px-2 py-1 text-xs text-ink-muted">
          &copy; OpenStreetMap contributors
        </span>
      </span>
    </button>
  )
}
