import Image from 'next/image'
import type { OverlaySpecial } from '@/lib/overlay'
import { specialProvenance } from '@/lib/provenance'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Published specials take over the head plate that used to apologise for
// them (build/08 §5 Phase 5) — the apology sentence dies, the tel link
// STAYS, and every special carries its freshness stamp so staleness is
// shown, never hidden. priceLabel is printed as text: it is a label, not
// a number, and it never enters the Menu JSON-LD (veto 4).
export function SpecialsList({ specials }: { specials: OverlaySpecial[] }) {
  return (
    <div className="mt-3">
      <p className="font-display text-h2 uppercase leading-none">Today&apos;s specials</p>
      <ul className="mt-3 flex flex-col gap-3">
        {specials.map((special) => (
          <li key={special.slot} className="flex items-start gap-3">
            {/* Owner-uploaded shot (addendum 2) — same inherent-permission
                media as dish photos, thumb-scale so the words stay the menu. */}
            {special.photo ? (
              <span className="img-frame relative block size-16 shrink-0 overflow-hidden rounded md:size-20">
                <Image
                  src={special.photo.src}
                  alt={special.photo.alt}
                  fill
                  sizes="(min-width: 768px) 80px, 64px"
                  className="object-cover"
                />
              </span>
            ) : null}
            <span className="flex min-w-0 flex-col gap-1">
              <p className="flex flex-wrap items-baseline gap-x-3">
                <span className="font-bold uppercase tracking-tight">{special.title}</span>
                {special.priceLabel ? (
                  <span className="font-mono font-bold tabular-nums">{special.priceLabel}</span>
                ) : null}
              </p>
              {special.body ? (
                <p className="text-sm leading-relaxed text-ink-muted">{special.body}</p>
              ) : null}
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-sm italic text-ink-muted">
        {specialProvenance(new Date(specials[0].publishedAt))}
      </p>
      <a
        href={TEL_HREF}
        className="tick mt-3 inline-flex min-h-11 flex-wrap items-baseline gap-x-3 font-extrabold uppercase tracking-tight hover:text-amber-ink"
      >
        Call to claim one
        <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
      </a>
    </div>
  )
}
