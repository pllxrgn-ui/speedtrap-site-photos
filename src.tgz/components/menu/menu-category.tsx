import Image from 'next/image'
import type { ReactNode } from 'react'
import type { MenuCategory, MenuItem } from '@/lib/menu'
import type { Photo } from '@/lib/photos'

const TAG_LABELS: Record<NonNullable<MenuItem['tags']>[number], string> = {
  gf: 'gluten free',
  v: 'vegetarian',
}

function Tag({ children }: { children: ReactNode }) {
  return (
    <span className="rounded border border-hairline bg-surface-warm px-2 py-0.5 text-sm font-bold uppercase tracking-tight text-amber-ink">
      {children}
    </span>
  )
}

function Row({ item }: { item: MenuItem }) {
  return (
    // A menu row is a scan target, not a control: it gets the amber edge line
    // and nothing else. No lift and no nudge, because a row that rises is
    // claiming to be clickable and this one is not, and because text that
    // shifts under the eye is worse to read down than text that does not.
    // The tick lands on the hairline that is already there.
    <li className="tick flex items-baseline justify-between gap-4 border-b border-hairline py-4">
      <div className="min-w-0">
        <p className="font-bold">
          {item.name}
          {item.houseMade ? (
            <>
              {' '}
              <Tag>house-made</Tag>
            </>
          ) : null}
          {item.tags?.map((tag) => (
            <span key={tag}>
              {' '}
              <Tag>{TAG_LABELS[tag]}</Tag>
            </span>
          ))}
        </p>
        {item.description ? <p className="text-ink-muted">{item.description}</p> : null}
      </div>
      {/* price is null for every item until the owner confirms: render nothing,
          not a dash and not a placeholder. Ships correct the day prices land. */}
      {item.price !== null ? (
        <p className="shrink-0 font-mono text-[1.125rem] font-bold tabular-nums">
          ${item.price.toFixed(2)}
        </p>
      ) : null}
    </li>
  )
}

export function MenuCategorySection({
  category,
  emptyNote,
  photo,
}: {
  category: MenuCategory
  emptyNote?: string
  /** A real photo of this category's food or setting, business-posted only
   *  (client direction 2026-09-14). Never a stock stand-in. */
  photo?: Photo
}) {
  const titleId = `${category.id}-title`

  return (
    // Anchor offset = sticky header (--header-h) + the sticky category nav
    // (min-h-11 plus py-3 = 4.25rem, rounded to 5rem for breathing room).
    <section
      id={category.id}
      aria-labelledby={titleId}
      className="scroll-mt-[calc(var(--header-h)+5rem)]"
    >
      <h2 id={titleId} className="text-h2 font-extrabold uppercase tracking-tight">
        {category.title}
      </h2>
      {category.note ? <p className="mt-2 max-w-[62ch] text-ink-muted">{category.note}</p> : null}

      {photo ? (
        <div className="img-frame relative mt-6 aspect-square max-w-[240px] overflow-hidden rounded md:float-right md:ml-6 md:mt-0">
          <Image
            src={photo.src}
            alt={photo.alt}
            fill
            sizes="240px"
            loading="lazy"
            className="object-cover"
          />
        </div>
      ) : null}

      {category.items.length > 0 ? (
        <ul className="mt-6 border-t border-hairline">
          {category.items.map((item) => (
            <Row key={item.name} item={item} />
          ))}
        </ul>
      ) : emptyNote ? (
        <p className="mt-6 border-y border-hairline py-4 font-bold">{emptyNote}</p>
      ) : null}
      {photo ? <div className="clear-both" /> : null}
    </section>
  )
}
