import Image from 'next/image'
import type { ReactNode } from 'react'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { Odometer } from '@/components/ui/odometer'
import { MENU_PHOTO_COASTERS, type MenuCategory, type MenuItem } from '@/lib/menu'

// THE PASS (menu redesign, 2026-09-14; amendment logged in build/03).
// Two section modes on one 12-col substrate:
//   rail  - lg gets a sticky 4-col head rail beside an 8-col list in two
//           equal tracks. The 32px category name parks under the nav and
//           holds while its rows travel past: position sticky, cannot jank.
//   board - inside the surface band; full-width head band, list in up to
//           three tracks.
// Lists are CSS grid with grid-flow-col + an explicit row count, never
// multicol: column order = DOM order, row heights equalise so hairlines
// align across tracks, and break-inside fragility does not exist.

// Tailwind v4 scans source text: an interpolated `lg:grid-rows-${n}`
// compiles to nothing and the tracks silently collapse. Literal lookups only.
const ROWS_LG = {
  2: 'lg:grid-rows-2',
  3: 'lg:grid-rows-3',
  4: 'lg:grid-rows-4',
  5: 'lg:grid-rows-5',
} as const
const ROWS_MD = {
  2: 'md:grid-rows-2',
  3: 'md:grid-rows-3',
  4: 'md:grid-rows-4',
  5: 'md:grid-rows-5',
} as const

export type TrackRows = keyof typeof ROWS_LG

const TAG_LABELS: Record<NonNullable<MenuItem['tags']>[number], string> = {
  gf: 'gluten free',
  v: 'vegetarian',
}

function Tag({ children }: { children: ReactNode }) {
  // Amber border + amber-ink text: --surface-warm belongs to the home today
  // strip only (build/03 §1.3); the old bg-surface-warm here was a latent
  // reserved-token violation, fixed in this pass.
  return (
    <span className="rounded border border-amber bg-surface px-2 py-0.5 text-sm font-bold uppercase tracking-tight text-amber-ink">
      {children}
    </span>
  )
}

// Stacked row, not name-left/price-right: stacking is what survives a 336px
// track. Contrast is weight (800/400), colour (ink/muted) and leading, which
// is signage contrast. `lead` sets the top line of a prose category one step
// up (the existing h3 step), the way the top line of a printed board is set
// larger; purely positional, asserts nothing editorial.
function Row({
  item,
  lead,
  mdDivided,
  lgDivided,
}: {
  item: MenuItem
  lead: boolean
  /** True when this row is not in track 1 at that breakpoint: it carries the
   *  broadsheet column rule on its left edge. */
  mdDivided: boolean
  lgDivided: boolean
}) {
  const text = (
    <div className="min-w-0">
      <p
        className={
          lead
            ? 'text-[1.25rem] font-extrabold leading-tight tracking-[-0.01em]'
            : 'text-[1.0625rem] font-extrabold leading-tight tracking-[-0.01em]'
        }
      >
        {item.name}
        {item.houseMade ? (
          <>
            {' '}
            <Tag>house-made</Tag>
          </>
        ) : null}
        {item.tags?.map((tag) => (
          <span key={tag}>
            {' '}
            <Tag>{TAG_LABELS[tag]}</Tag>
          </span>
        ))}
      </p>
      {item.description ? (
        <p className="mt-1 max-w-[44ch] text-[0.9375rem] leading-snug text-ink-muted">
          {item.description}
        </p>
      ) : null}
      {item.price !== null ? (
        <p className="mt-1 font-mono text-[1.125rem] font-bold tabular-nums">
          ${item.price.toFixed(2)}
        </p>
      ) : null}
    </div>
  )

  return (
    <li
      className={`tick border-b border-hairline py-3.5 md:px-6 lg:px-8 lg:py-4 ${
        mdDivided ? 'md:border-l' : lgDivided ? 'lg:border-l' : ''
      }`}
    >
      {/* A dish with a real photo gets a 56px plate beside its text. Without
          one: during the client-preview phase (MENU_PHOTO_COASTERS) the slot
          holds a laurel coaster - their own mark on a flat field, never a
          gray broken frame - so the owner sees exactly where each shot
          lands. Coasters off = the row as it already is (§1.6 rule 6). */}
      {item.photo ? (
        <div className="flex items-start gap-4">
          {/* 80px: big enough that the dish actually reads as food on a
              phone; the text column keeps ~240px inside a track. */}
          <div className="img-frame relative size-20 shrink-0 overflow-hidden rounded">
            <Image
              src={item.photo.src}
              alt={item.photo.alt}
              fill
              loading="lazy"
              sizes="80px"
              className="object-cover"
            />
          </div>
          {text}
        </div>
      ) : MENU_PHOTO_COASTERS ? (
        <div className="flex items-start gap-4">
          <div
            aria-hidden
            className="img-frame flex size-20 shrink-0 items-center justify-center overflow-hidden rounded bg-surface"
          >
            <Image
              src="/photos/logo-laurel.webp"
              alt=""
              width={400}
              height={345}
              loading="lazy"
              className="invert-on-dark w-12 opacity-25"
            />
          </div>
          {text}
        </div>
      ) : (
        text
      )}
    </li>
  )
}

// The tracked list, exported for the drinks spread which composes its own
// section around it. -mx pulls the ul to the container edges so px on the
// rows restores the gutter, which is what makes the column rules land in the
// middle of real 32px air (broadsheet rule, not a crowded border).
export function MenuList({
  items,
  rows,
  rowsMd,
  lead = false,
  className = '',
}: {
  items: MenuItem[]
  rows: TrackRows
  rowsMd: TrackRows
  lead?: boolean
  className?: string
}) {
  return (
    <ul
      className={`stt-stagger border-t border-hairline md:-mx-6 md:grid md:auto-cols-fr md:grid-flow-col md:gap-x-0 ${ROWS_MD[rowsMd]} lg:-mx-8 ${ROWS_LG[rows]} ${className}`}
    >
      {items.map((item, index) => (
        <Row
          key={item.name}
          item={item}
          lead={lead && index === 0}
          mdDivided={index >= rowsMd}
          lgDivided={index >= rows}
        />
      ))}
    </ul>
  )
}

// Head: h2 + item count on one baseline below lg (and always, in board mode);
// stacked in the sticky rail at lg. The count is an item count, never an
// index: not zero-padded, suppressed at 0 (build/03 bans section numbering).
// Odometer is aria-hidden internally, so the sr-only sentence is mandatory.
function Head({ category, rail }: { category: MenuCategory; rail: boolean }) {
  const count = category.items.length
  return (
    <div
      className={
        rail
          ? 'lg:sticky lg:col-span-4 lg:self-start lg:top-[calc(var(--header-h)+5.25rem)]'
          : ''
      }
    >
      <div className={`flex items-baseline justify-between gap-4 ${rail ? 'lg:block' : 'md:gap-6'}`}>
        <h2
          id={`${category.id}-title`}
          className="text-h2 font-extrabold uppercase leading-[0.95] tracking-[-0.03em]"
        >
          {category.title}
        </h2>
        {count > 0 ? (
          <p
            className={`shrink-0 font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted ${rail ? 'lg:mt-5' : ''}`}
          >
            <Odometer value={String(count)} trigger="view" baseDelay={120} />
            <span aria-hidden> items</span>
            <span className="sr-only">{count} items</span>
          </p>
        ) : null}
      </div>
      {category.note ? (
        <p className={`mt-3 max-w-[62ch] text-ink-muted ${rail ? 'lg:mt-4 lg:max-w-[34ch]' : ''}`}>
          {category.note}
        </p>
      ) : null}
    </div>
  )
}

// The 2px section rule doubles as the :target landing cue: a pill tap lands
// here and the rule answers in amber. Pure CSS.
const SECTION_RULE =
  'border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber'

export function RailSection({
  category,
  rows,
  rowsMd,
  lead = false,
}: {
  category: MenuCategory
  rows: TrackRows
  rowsMd: TrackRows
  lead?: boolean
}) {
  return (
    <section
      id={category.id}
      aria-labelledby={`${category.id}-title`}
      className="group scroll-mt-[calc(var(--header-h)+5rem)]"
    >
      <Container className="py-14 lg:py-20">
        <div className={SECTION_RULE} />
        {/* Reveal group IS the grid container: a plain Reveal's translateY on
            a grid child fights the column layout during entrance. */}
        <Reveal group className="pt-6 lg:grid lg:grid-cols-12 lg:gap-x-8 lg:pt-10">
          <Head category={category} rail />
          <MenuList
            items={category.items}
            rows={rows}
            rowsMd={rowsMd}
            lead={lead}
            className="mt-6 md:mt-8 lg:col-span-8 lg:mt-0 lg:self-start"
          />
        </Reveal>
      </Container>
    </section>
  )
}

// Board mode: rendered inside the surface band (the band owns Container and
// section rhythm), head band on top, tracks below.
export function BoardSection({
  category,
  rows,
  rowsMd,
}: {
  category: MenuCategory
  rows: TrackRows
  rowsMd: TrackRows
}) {
  return (
    <section
      id={category.id}
      aria-labelledby={`${category.id}-title`}
      className="group scroll-mt-[calc(var(--header-h)+5rem)]"
    >
      <div className={SECTION_RULE} />
      <Reveal group className="pt-5">
        <Head category={category} rail={false} />
        <MenuList items={category.items} rows={rows} rowsMd={rowsMd} className="mt-6 md:mt-8" />
      </Reveal>
    </section>
  )
}
