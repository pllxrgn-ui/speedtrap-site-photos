import Image from 'next/image'
import type { ReactNode } from 'react'
import { Reveal } from '@/components/site/reveal'
import { MENU_PHOTO_COASTERS, type MenuCategory, type MenuItem } from '@/lib/menu'

// ONE-PAGE MENU (build/07 §2, superseding THE PASS's rail mode). Every
// category is a BoardSection: RailSection is RETIRED - its sticky 4-col head
// would stack a third sticky layer under the site header and the pill rail,
// and board mode gives the list all 12 columns, which is where the density
// comes from. Lists are CSS grid with grid-flow-col + literal row counts
// (an interpolated `lg:grid-rows-${'{n}'}` compiles to nothing).
const ROWS_LG = {
  2: 'lg:grid-rows-2',
  3: 'lg:grid-rows-3',
  4: 'lg:grid-rows-4',
  5: 'lg:grid-rows-5',
} as const
const ROWS_MD = {
  2: 'md:grid-rows-2',
  3: 'md:grid-rows-3',
  4: 'md:grid-rows-4',
  5: 'md:grid-rows-5',
} as const

export type TrackRows = keyof typeof ROWS_LG

const TAG_LABELS: Record<NonNullable<MenuItem['tags']>[number], string> = {
  gf: 'gluten free',
  v: 'vegetarian',
}

function Tag({ children }: { children: ReactNode }) {
  return (
    <span className="rounded border border-amber bg-surface px-2 py-0.5 text-sm font-bold uppercase tracking-tight text-amber-ink">
      {children}
    </span>
  )
}

// Row anatomy (build/03 amendment via build/07 §6.3): name and price share
// ONE BASELINE - flex items-baseline, min-w-0 name, shrink-0 mono price.
// Measured across all 50 rows at 375: 5,664px stacked -> 3,992px on the
// baseline. A handful of long names wrap; that is how a printed board sets
// a long item. Do NOT revert to stacked "because tracks are narrow" - that
// comment described a collision this anatomy already survives.
function Row({
  item,
  mdDivided,
  lgDivided,
}: {
  item: MenuItem
  /** True when this row is not in track 1 at that breakpoint: it carries the
   *  broadsheet column rule on its left edge. */
  mdDivided: boolean
  lgDivided: boolean
}) {
  return (
    <li
      className={`tick border-b border-hairline py-3 md:px-6 lg:px-8 ${
        mdDivided ? 'md:border-l' : lgDivided ? 'lg:border-l' : ''
      }`}
    >
      {/* 56px plate (build/07 §2): at size-14 the row's min height equals a
          plateless row's 84px, so the plate costs ZERO height forever. The
          old comment claiming 56px over an 80px implementation is gone with
          the 80px. When real item.photo entries land they render at 56px
          too - mixed sizes inflate grid rows across tracks (grid-flow-col
          equalises); if Pol wants bigger plates it must be all-at-once. */}
      {item.photo ? (
        <div className="flex items-start gap-3">
          <div className="img-frame relative size-14 shrink-0 overflow-hidden rounded">
            <Image
              src={item.photo.src}
              alt={item.photo.alt}
              fill
              loading="lazy"
              sizes="56px"
              className="object-cover"
            />
          </div>
          <RowText item={item} />
        </div>
      ) : MENU_PHOTO_COASTERS ? (
        <div className="flex items-start gap-3">
          <div
            aria-hidden
            className="img-frame flex size-14 shrink-0 items-center justify-center overflow-hidden rounded bg-surface"
          >
            <Image
              src="/photos/logo-laurel.webp"
              alt=""
              width={400}
              height={345}
              sizes="32px"
              loading="lazy"
              className="invert-on-dark w-8 opacity-25"
            />
          </div>
          <RowText item={item} />
        </div>
      ) : (
        <RowText item={item} />
      )}
    </li>
  )
}

function RowText({ item }: { item: MenuItem }) {
  return (
    <div className="min-w-0 flex-1">
      <p className="flex items-baseline justify-between gap-3">
        <span className="min-w-0 text-[1.0625rem] font-extrabold leading-tight tracking-[-0.01em]">
          {item.name}
        </span>
        {item.price !== null ? (
          <span className="shrink-0 font-mono text-[1.0625rem] font-bold tabular-nums">
            ${item.price.toFixed(2)}
          </span>
        ) : null}
      </p>
      {item.houseMade || item.tags?.length ? (
        <p className="mt-1">
          {item.houseMade ? <Tag>house-made</Tag> : null}
          {item.tags?.map((tag) => (
            <span key={tag}>
              {' '}
              <Tag>{TAG_LABELS[tag]}</Tag>
            </span>
          ))}
        </p>
      ) : null}
      {item.description ? (
        <p className="mt-1 max-w-[44ch] text-[0.9375rem] leading-snug text-ink-muted">
          {item.description}
        </p>
      ) : null}
    </div>
  )
}

export function MenuList({
  items,
  rows,
  rowsMd,
  className = '',
}: {
  items: MenuItem[]
  rows: TrackRows
  rowsMd: TrackRows
  className?: string
}) {
  return (
    <ul
      className={`stt-stagger border-t border-hairline md:-mx-6 md:grid md:auto-cols-fr md:grid-flow-col md:gap-x-0 ${ROWS_MD[rowsMd]} lg:-mx-8 ${ROWS_LG[rows]} ${className}`}
    >
      {items.map((item, index) => (
        <Row
          key={item.name}
          item={item}
          mdDivided={index >= rowsMd}
          lgDivided={index >= rows}
        />
      ))}
    </ul>
  )
}

// Head: h3 (the one-pager's outline puts category titles one rank under the
// #menu section's h2). The count is STATIC mono text - the per-category
// Odometers were cut (7 client islands on the longest page on the site;
// Odometer keeps its justified homes: the Numbers stats and the 55).
function Head({ category }: { category: MenuCategory }) {
  const count = category.items.length
  return (
    <div>
      <div className="flex items-baseline justify-between gap-4 md:gap-6">
        <h3
          id={`${category.id}-title`}
          className="font-display text-h2 uppercase leading-[0.95] text-ink"
        >
          {category.title}
        </h3>
        {count > 0 ? (
          <p className="shrink-0 font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
            {count} items
          </p>
        ) : null}
      </div>
      {category.note ? (
        <p className="mt-3 max-w-[62ch] text-ink-muted">{category.note}</p>
      ) : null}
    </div>
  )
}

// The 2px section rule doubles as the :target landing cue.
const SECTION_RULE =
  'border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber'

export function BoardSection({
  category,
  rows,
  rowsMd,
}: {
  category: MenuCategory
  rows: TrackRows
  rowsMd: TrackRows
}) {
  return (
    <section
      id={category.id}
      aria-labelledby={`${category.id}-title`}
      className="group scroll-mt-[calc(var(--header-h)+5rem)]"
    >
      <div className={SECTION_RULE} />
      {/* Reveal wraps the category BODY only - never the sticky pill rail or
          the #menu section itself: Reveal writes a transform and a transform
          on a sticky ancestor kills the pin silently (build/07 §2). */}
      <Reveal group className="pt-5">
        <Head category={category} />
        <MenuList items={category.items} rows={rows} rowsMd={rowsMd} className="mt-5 md:mt-6" />
      </Reveal>
    </section>
  )
}
