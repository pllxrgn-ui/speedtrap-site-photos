// "Today's note" — the one line the owner can chalk onto the menu head
// (build/08 §4). It expires overnight on its own, so a Tuesday note can
// never greet a Thursday customer.
export function TodayNote({ note }: { note: string | null }) {
  if (!note) return null
  return (
    <p className="mt-4 max-w-[52ch] border-l-2 border-ink bg-surface py-3 pl-5 pr-4">
      <span className="mr-3 font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
        Today
      </span>
      <span className="font-bold">{note}</span>
    </p>
  )
}
