import { ArrowUp } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import type { MenuCategory } from '@/lib/menu'

// The sticky pill rail (build/07 §2): a DIRECT CHILD of #menu, so
// position:sticky pins it under the site header for exactly the length of
// the menu section and unpins after - no JS, no scroll listener.
// HARD CONSTRAINT: #menu and every ancestor must stay free of overflow-*
// and transform, and this nav must never sit inside a Reveal (Reveal writes
// a transform). The pin fails silently otherwise.
//
// Scrolling rail, not wrapping: the 7 pills measure a ~920px track in a
// 343px container; wrapping to keep all seven visible costs ~216px of
// PERMANENT sticky chrome at 375. Rejected - the static category index at
// the section head is the all-seven-visible affordance. From lg the track
// fits one row with no scrolling.
//
// DEFERRED, still: no active/current pill state. Scroll-spy means an
// IntersectionObserver per category and a client component for a cosmetic
// cue. The sticky section head is the location cue.
export function CategoryNav({ categories }: { categories: MenuCategory[] }) {
  return (
    <nav
      aria-label="Menu categories"
      className="sticky top-[var(--header-h)] z-20 border-y border-hairline bg-paper"
    >
      <Container className="flex items-center gap-2">
        <ul className="flex min-w-0 flex-1 snap-x snap-mandatory gap-2 overflow-x-auto py-3">
          {categories.map((category) => (
            <li key={category.id} className="snap-start">
              <a
                href={`#${category.id}`}
                className="lift tap-feedback inline-flex min-h-11 items-center whitespace-nowrap rounded border border-hairline px-4 font-bold uppercase tracking-tight text-ink hover:border-ink"
              >
                {category.title}
              </a>
            </li>
          ))}
        </ul>
        {/* Jump-back, as a SIBLING of the scroller so it can never scroll out
            of reach, at zero height cost. */}
        <a
          href="#menu"
          className="tap-feedback flex size-11 shrink-0 items-center justify-center rounded border border-hairline hover:border-ink"
        >
          <ArrowUp size={20} weight="bold" aria-hidden />
          <span className="sr-only">Back to the menu index</span>
        </a>
      </Container>
    </nav>
  )
}
