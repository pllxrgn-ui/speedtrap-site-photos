import { Container } from '@/components/site/container'
import type { MenuCategory } from '@/lib/menu'

// Sticky jump-nav (build/03 §3, Menu row). Plain anchors on purpose: no state,
// no hydration, no JS. Sits directly under the sticky header, whose height is
// --header-h in globals.css — the same token menu-category.tsx derives its
// scroll-mt from, so the two offsets cannot drift apart.
//
// DEFERRED: no active/current pill state. Marking one needs scroll-spy, which
// means an IntersectionObserver per category and turning this into a client
// component for a cosmetic cue. Revisit when the page has real prices and the
// categories are worth tracking.
export function CategoryNav({ categories }: { categories: MenuCategory[] }) {
  return (
    <nav
      aria-label="Menu categories"
      className="sticky top-[var(--header-h)] z-20 border-y border-hairline bg-paper"
    >
      <Container>
        <ul className="flex snap-x snap-mandatory gap-2 overflow-x-auto py-3">
          {categories.map((category) => (
            <li key={category.id} className="snap-start">
              <a
                href={`#${category.id}`}
                className="lift tap-feedback inline-flex min-h-11 items-center whitespace-nowrap rounded border border-hairline px-4 font-bold uppercase tracking-tight text-ink hover:bg-surface"
              >
                {category.title}
              </a>
            </li>
          ))}
        </ul>
      </Container>
    </nav>
  )
}
