import Link from 'next/link'
import type { ComponentProps, ReactNode } from 'react'

type Variant = 'ink' | 'amber' | 'ghost' | 'inverse'
/** 'lg' is the 48px call/directions target (build/03 §1.4). */
type Size = 'md' | 'lg'

const styles: Record<Variant, string> = {
  ink: 'bg-ink text-paper hover:opacity-90',
  amber: 'bg-amber text-on-amber hover:brightness-95',
  ghost: 'border border-hairline text-ink hover:bg-surface',
  // For use on the inverted ink band only.
  inverse: 'border border-paper text-paper hover:bg-paper/10',
}

const sizes: Record<Size, string> = {
  md: 'min-h-11',
  lg: 'min-h-12',
}

// Hover language, build/03 §1.5. A control is the one thing on the site that
// LIFTS: 1px up on hover, then flat and 0.98 on press, released on a spring.
// Link-shaped things grow an amber tick instead, and rows nudge. One
// personality, three materials, and nothing here is a second accent colour.
//
// .lift is fine-pointer-gated in globals.css, so a phone never inherits a
// stuck hover; .tap-feedback is the touch half and fires on :active.
const base =
  'lift tap-feedback inline-flex items-center justify-center gap-2 rounded px-5 font-bold uppercase tracking-tight'

const recipe = (variant: Variant, size: Size, className: string) =>
  `${base} ${sizes[size]} ${styles[variant]} ${className}`

type Common = { variant?: Variant; size?: Size; children: ReactNode }

export function ButtonLink({
  variant = 'ink',
  size = 'md',
  className = '',
  children,
  ...props
}: ComponentProps<typeof Link> & Common) {
  return (
    <Link {...props} className={recipe(variant, size, className)}>
      {children}
    </Link>
  )
}

export function ButtonA({
  variant = 'ink',
  size = 'md',
  className = '',
  children,
  ...props
}: ComponentProps<'a'> & Common) {
  return (
    <a {...props} className={recipe(variant, size, className)}>
      {children}
    </a>
  )
}

/** Real <button>. Same recipe as the link forms so the three cannot drift. */
export function Button({
  variant = 'ink',
  size = 'md',
  className = '',
  children,
  ...props
}: ComponentProps<'button'> & Common) {
  return (
    <button {...props} className={recipe(variant, size, className)}>
      {children}
    </button>
  )
}
