import type { CSSProperties } from 'react'

const DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

/**
 * A number that rolls up to its value, odometer style (build/03 §1.5).
 *
 * Server component, zero JavaScript. Each digit is a one-line window over a
 * 0-to-9 strip that is parked on the real digit by a static transform; the
 * animation only re-runs the strip from 0 up to that parked position. Strip
 * every animation out, disable JS, or set prefers-reduced-motion and the
 * correct number is still what renders, because the correct number is the
 * resting state rather than the end of a timeline.
 *
 * The site already sets everything numeric in Overpass Mono with tabular
 * figures, so the columns are the same width and nothing shifts as it rolls.
 *
 * DECORATIVE. The root is aria-hidden, so the caller has to carry the value in
 * real accessible text. Both call sites (the hero rating plate and the reviews
 * summary) already render a full sr-only sentence, which says more than the
 * bare figure would.
 */
export function Odometer({
  value,
  trigger,
  baseDelay = 0,
  className = '',
}: {
  /** Already formatted for display, for example "4.4". Digits roll, the rest
   *  (a decimal point, a slash) renders as static type. */
  value: string
  /**
   * 'load' rolls as soon as the page paints. Use it above the fold.
   * 'view' waits for the surrounding <Reveal> to become visible, and does
   * nothing at all if there is no Reveal around it.
   */
  trigger: 'load' | 'view'
  /** ms before the first column starts, to sit behind an entrance. */
  baseDelay?: number
  className?: string
}) {
  let digitIndex = 0

  return (
    <span
      aria-hidden="true"
      className={`stt-odo ${trigger === 'load' ? 'stt-odo--auto' : ''} ${className}`}
    >
      {[...value].map((char, index) => {
        const digit = DIGITS.indexOf(char)
        if (digit === -1) {
          return <span key={`${char}-${index}`}>{char}</span>
        }
        // Each column starts 90ms after the one before it, so the figure
        // settles left to right the way a mechanical counter does.
        const delay = baseDelay + digitIndex * 90
        digitIndex += 1
        return (
          <span key={`${char}-${index}`} className="stt-odo-win">
            <span
              className="stt-odo-col"
              style={
                {
                  '--stt-digit': digit,
                  '--stt-d': `${delay}ms`,
                } as CSSProperties
              }
            >
              {DIGITS.map((candidate) => (
                <span key={candidate}>{candidate}</span>
              ))}
            </span>
          </span>
        )
      })}
    </span>
  )
}
