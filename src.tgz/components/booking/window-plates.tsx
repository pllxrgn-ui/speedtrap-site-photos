'use client'

import { TIME_WINDOWS, TIME_WINDOW_LABELS, type TimeWindowValue } from '@/lib/booking'

// Four tappable plates in a 2×2 — no clock input, no slot list, no "next
// available" (build/08 veto 1). Until then the data type IS the honesty rule.
//
// READ THIS BEFORE WIRING HOURS IN HERE (build/13 §0.3). Clock times arrive
// when #B3 confirms BOOKING CAPACITY — whether a table is free at a given
// time. They do NOT arrive when the bar's published hours do. Owner-entered
// HoursDay rows (build/13) say when the DOOR is open, which is a different
// question, so they are explicitly not #B3's answer and they unlock nothing
// here: no clock picker, no greying out closed days on the date field, no
// is-it-open-now. lib/booking.test.ts pins that on both channels — the
// import AND the prop surface — with veto 1 quoted in it.
export function WindowPlates({
  value,
  onChange,
  describedBy,
}: {
  value: TimeWindowValue | undefined
  onChange: (window: TimeWindowValue) => void
  describedBy?: string
}) {
  return (
    <div className="grid grid-cols-2 gap-2" aria-describedby={describedBy}>
      {TIME_WINDOWS.map((window) => {
        const selected = value === window
        return (
          <button
            key={window}
            type="button"
            aria-pressed={selected}
            onClick={() => onChange(window)}
            className={`tap-feedback min-h-14 rounded border font-bold uppercase tracking-tight ${
              selected ? 'border-ink bg-ink text-paper' : 'border-hairline bg-surface text-ink'
            }`}
          >
            {TIME_WINDOW_LABELS[window]}
          </button>
        )
      })}
    </div>
  )
}
