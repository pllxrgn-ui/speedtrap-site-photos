'use client'

import { TIME_WINDOWS, TIME_WINDOW_LABELS, type TimeWindowValue } from '@/lib/booking'

// Four tappable plates in a 2×2 — no clock input, no slot list, no "next
// available" (build/08 veto 1). Clock times arrive only when #B3 confirms
// the hours; until then the data type IS the honesty rule.
export function WindowPlates({
  value,
  onChange,
  describedBy,
}: {
  value: TimeWindowValue | undefined
  onChange: (window: TimeWindowValue) => void
  describedBy?: string
}) {
  return (
    <div className="grid grid-cols-2 gap-2" aria-describedby={describedBy}>
      {TIME_WINDOWS.map((window) => {
        const selected = value === window
        return (
          <button
            key={window}
            type="button"
            aria-pressed={selected}
            onClick={() => onChange(window)}
            className={`tap-feedback min-h-14 rounded border font-bold uppercase tracking-tight ${
              selected ? 'border-ink bg-ink text-paper' : 'border-hairline bg-surface text-ink'
            }`}
          >
            {TIME_WINDOW_LABELS[window]}
          </button>
        )
      })}
    </div>
  )
}
