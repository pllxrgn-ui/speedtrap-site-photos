import { Phone } from '@phosphor-icons/react/dist/ssr'
import { ButtonA } from '@/components/ui/button'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Rendered while NEXT_PUBLIC_BOOKING_ENABLED is off (build/08 §2 row 11):
// a form that collects a name and number with nowhere to send them is
// worse than no form, so until #B1 gives requests somewhere to land, the
// section is a call panel — never a form into a void.
export function BookingFallback() {
  return (
    <div className="rounded border border-hairline bg-surface p-6 md:p-8">
      <p className="max-w-[52ch] text-lg leading-relaxed">
        The online book isn&apos;t taking requests quite yet. The phone already
        does. Call and we&apos;ll take it down the old way, which is also the
        fast way.
      </p>
      <p className="mt-6">
        <ButtonA href={TEL_HREF} variant="ink" size="lg">
          <Phone size={20} weight="bold" aria-hidden />
          Call {SITE.phoneDisplay}
        </ButtonA>
      </p>
    </div>
  )
}
