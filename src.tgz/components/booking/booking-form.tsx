'use client'

import { useMemo, useState } from 'react'
import { useForm, type Resolver } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { WarningCircle } from '@phosphor-icons/react/dist/ssr'
import { BookedPanel } from '@/components/booking/booked-panel'
import { PartyChips } from '@/components/booking/party-chips'
import { WindowPlates } from '@/components/booking/window-plates'
import { FieldError } from '@/components/forms/field-error'
import {
  MAX_ADVANCE_DAYS,
  bookingSchema,
  presanitizeBooking,
  type BookingInput,
} from '@/lib/booking'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Nine states, one honest voice (build/08 §3): no state may claim more
// than the server confirmed, and every failure hands over the phone
// number. No spinner — the label and disabled state carry "submitting"
// (build/03 §1.5). Success is only ever the server's 2xx with a reference.

type Status =
  | { kind: 'idle' }
  | { kind: 'sent'; reference: string; echo: BookingInput }
  | { kind: 'failed'; message: string }

const CALL_INSTEAD = `We could not send that from here. Call ${SITE.phoneDisplay} and we will take it down the old way.`
const OFFLINE = `You look offline. When you are back on signal this will work — or just call ${SITE.phoneDisplay}.`

const FIELD_NAMES: Record<string, true> = {
  name: true,
  phone: true,
  date: true,
  partySize: true,
  timeWindow: true,
  note: true,
}

// THE SAME transform the server runs before ITS parse (lib/booking.ts):
// client and route validate identical bytes, so nothing passes here and
// 400s there.
const resolver: Resolver<BookingInput> = (values, context, options) =>
  zodResolver(bookingSchema)(presanitizeBooking(values) as BookingInput, context, options)

const fieldLabel = 'block font-bold uppercase tracking-tight'
const fieldHint = 'mt-1 text-sm text-ink-muted'
const inputBase =
  'mt-2 block w-full min-h-12 rounded bg-surface px-3 py-2 text-ink placeholder:text-ink-muted'
const inputRest = `${inputBase} border border-hairline`
const inputInvalid = `${inputBase} border-2 border-ink`

function localIso(date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${date.getFullYear()}-${month}-${day}`
}

// `hoursPublished` is the ONLY hours-derived value in this subtree, and it
// rides down from BookSection as a boolean (build/13 §0.3). It swaps one
// sentence of hint copy. It does not gate a day, grey out a date or pick a
// time: veto 1 stands until #B3 answers the capacity question.
export function BookingForm({ hoursPublished }: { hoursPublished: boolean }) {
  const [status, setStatus] = useState<Status>({ kind: 'idle' })

  const { min, max } = useMemo(() => {
    const today = new Date()
    const horizon = new Date(today.getTime() + MAX_ADVANCE_DAYS * 86_400_000)
    return { min: localIso(today), max: localIso(horizon) }
  }, [])

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<BookingInput>({
    resolver,
    defaultValues: {
      name: '',
      phone: '',
      date: '',
      note: '',
      hp_referrer: '',
    } as Partial<BookingInput> as BookingInput,
  })

  const partySize = watch('partySize')
  const timeWindow = watch('timeWindow')

  const onSubmit = handleSubmit(async (values) => {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      setStatus({ kind: 'failed', message: OFFLINE })
      return
    }
    setStatus({ kind: 'idle' })
    try {
      const response = await fetch('/api/booking', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(values),
      })
      const body = (await response.json().catch(() => null)) as
        | {
            ok?: boolean
            reference?: string
            message?: string
            issues?: { field: string; message: string }[]
          }
        | null

      if (!response.ok || body?.ok !== true || typeof body.reference !== 'string') {
        for (const issue of body?.issues ?? []) {
          if (issue.field in FIELD_NAMES) {
            setError(issue.field as keyof BookingInput, { message: issue.message })
          }
        }
        setStatus({ kind: 'failed', message: body?.message ?? CALL_INSTEAD })
        return
      }

      // 201 new or 200 duplicate/amended: either way it is in the book
      // under this reference — the customer experience is identical.
      setStatus({ kind: 'sent', reference: body.reference, echo: values })
    } catch {
      setStatus({ kind: 'failed', message: CALL_INSTEAD })
    }
  })

  if (status.kind === 'sent') {
    return (
      <BookedPanel
        reference={status.reference}
        partySize={status.echo.partySize}
        date={status.echo.date}
        timeWindow={status.echo.timeWindow}
      />
    )
  }

  return (
    <form noValidate onSubmit={onSubmit} className="relative">
      {/* Honeypot — same hard-won field name as the inquiry form (a field
          named "company" gets address-autofilled by Chrome, flagging real
          customers as bots). Off screen, unfocusable, hidden from AT. */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-[-9999px] top-0 h-0 w-0 overflow-hidden"
      >
        <label htmlFor="book-hp">Leave this field empty</label>
        <input id="book-hp" type="text" tabIndex={-1} autoComplete="off" {...register('hp_referrer')} />
      </div>

      <div className="flex flex-col gap-6">
        {/* Fields in the order a person says it out loud (build/08 §3). */}
        <div>
          <span className={fieldLabel}>How many of you</span>
          <div className="mt-2">
            <PartyChips
              value={partySize}
              onChange={(size) =>
                setValue('partySize', size, { shouldValidate: true, shouldDirty: true })
              }
              describedBy={errors.partySize ? 'book-party-error' : undefined}
            />
          </div>
          <FieldError id="book-party-error">{errors.partySize?.message}</FieldError>
        </div>

        <div>
          <label htmlFor="book-date" className={fieldLabel}>
            What day
          </label>
          {/* Native picker; min is the visitor's today, the server keeps its
              own 48h slack so timezones never eat a same-day request. No
              greyed-out days: we do not know which days we are closed. */}
          <input
            id="book-date"
            type="date"
            min={min}
            max={max}
            aria-invalid={errors.date ? true : undefined}
            aria-describedby={errors.date ? 'book-date-error' : undefined}
            className={`${errors.date ? inputInvalid : inputRest} font-mono`}
            {...register('date')}
          />
          <FieldError id="book-date-error">{errors.date?.message}</FieldError>
        </div>

        <div>
          <span className={fieldLabel}>When, roughly</span>
          <div className="mt-2">
            <WindowPlates
              value={timeWindow}
              onChange={(window) =>
                setValue('timeWindow', window, { shouldValidate: true, shouldDirty: true })
              }
              describedBy="book-window-hint"
            />
          </div>
          <FieldError id="book-window-error">{errors.timeWindow?.message}</FieldError>
          <p id="book-window-hint" className={fieldHint}>
            {hoursPublished
              ? 'Our hours are on this page under Find us. Pick roughly when, and we will tell you exactly.'
              : 'We have not printed our hours here yet, and we are not going to guess at them. Pick roughly when, and we will tell you exactly.'}
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          <div>
            <label htmlFor="book-name" className={fieldLabel}>
              Your name
            </label>
            <input
              id="book-name"
              type="text"
              autoComplete="name"
              aria-invalid={errors.name ? true : undefined}
              aria-describedby={errors.name ? 'book-name-error' : undefined}
              className={errors.name ? inputInvalid : inputRest}
              {...register('name')}
            />
            <FieldError id="book-name-error">{errors.name?.message}</FieldError>
          </div>

          <div>
            <label htmlFor="book-phone" className={fieldLabel}>
              Number to call back
            </label>
            <input
              id="book-phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              placeholder="509 555 0123"
              aria-invalid={errors.phone ? true : undefined}
              aria-describedby={errors.phone ? 'book-phone-error' : undefined}
              className={`${errors.phone ? inputInvalid : inputRest} font-mono`}
              {...register('phone')}
            />
            <FieldError id="book-phone-error">{errors.phone?.message}</FieldError>
          </div>
        </div>

        <div>
          <label htmlFor="book-note" className={fieldLabel}>
            Anything else
          </label>
          <textarea
            id="book-note"
            rows={3}
            aria-invalid={errors.note ? true : undefined}
            aria-describedby={errors.note ? 'book-note-error' : 'book-note-hint'}
            className={errors.note ? inputInvalid : inputRest}
            {...register('note')}
          />
          {errors.note ? (
            <FieldError id="book-note-error">{errors.note.message}</FieldError>
          ) : (
            <p id="book-note-hint" className={fieldHint}>
              High chair, wheelchair space, someone&apos;s birthday. Optional.
            </p>
          )}
        </div>
      </div>

      {status.kind === 'failed' && (
        <div
          role="alert"
          className="mt-8 flex items-start gap-3 rounded border-2 border-ink bg-surface p-4"
        >
          <WarningCircle size={24} weight="fill" aria-hidden className="mt-1 shrink-0" />
          <div>
            <p className="font-bold">{status.message}</p>
            <p className="mt-2">
              <a
                href={TEL_HREF}
                className="font-mono text-lg font-bold underline underline-offset-4"
              >
                {SITE.phoneDisplay}
              </a>
            </p>
          </div>
        </div>
      )}

      <div className="mt-8 flex flex-wrap items-center gap-4">
        {/* THE page's amber fill (cap 5, spent here - build/08 §0: the
            corridor Directions and the inquiry submit demoted in the same
            commit). No spinner; the label carries the state. */}
        <button
          type="submit"
          disabled={isSubmitting}
          aria-busy={isSubmitting}
          className="lift tap-feedback inline-flex min-h-12 items-center justify-center gap-2 rounded bg-amber px-6 font-bold uppercase tracking-tight text-[#17181A] disabled:opacity-70"
        >
          {isSubmitting ? 'Sending' : 'Hold a table'}
        </button>
        <p className="text-ink-muted">
          In a hurry?{' '}
          <a
            href={TEL_HREF}
            className="font-mono font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            {SITE.phoneDisplay}
          </a>
        </p>
      </div>

      <p className="mt-6 max-w-[60ch] text-sm text-ink-muted">
        We keep your name, your number and this request so we can call you
        back, and we delete it 90 days after your date.
      </p>
    </form>
  )
}
