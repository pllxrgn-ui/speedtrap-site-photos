'use client'

import { useEffect, useRef } from 'react'
import { CheckCircle } from '@phosphor-icons/react/dist/ssr'
import { TIME_WINDOW_LABELS, type TimeWindowValue } from '@/lib/booking'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The sent state may not say Booked, Confirmed, or See you then (build/08
// veto 10): nothing is held until a human calls back, and this panel says
// exactly that. The reference is printed big so both sides can quote one
// code on the phone. Focus lands here so screen readers announce it — the
// form it replaced took the old focus point with it.
export function BookedPanel({
  reference,
  partySize,
  date,
  timeWindow,
}: {
  reference: string
  partySize: number
  date: string
  timeWindow: TimeWindowValue
}) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => ref.current?.focus(), [])

  const dateLabel = new Date(`${date}T00:00:00`).toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  })

  return (
    <div
      ref={ref}
      role="status"
      tabIndex={-1}
      className="rounded border border-hairline bg-surface p-6 md:p-8"
    >
      <p className="flex items-center gap-3 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight">
        <CheckCircle size={32} weight="fill" aria-hidden />
        That&apos;s in the book to call back
      </p>
      <p className="mt-4 max-w-[62ch] leading-relaxed">
        Party of <span className="font-mono font-bold tabular-nums">{partySize}</span>,{' '}
        {dateLabel}, {TIME_WINDOW_LABELS[timeWindow].toLowerCase()}. Nothing is held yet —
        we call you back and settle it in one short call.
      </p>
      <p className="mt-6 text-sm font-bold uppercase tracking-tight text-ink-muted">
        Say this code when we call
      </p>
      <p className="mt-1 font-mono text-3xl font-bold tracking-wide">{reference}</p>
      <p className="mt-6">
        Rather not wait?{' '}
        <a
          href={TEL_HREF}
          className="font-mono text-lg font-bold underline underline-offset-4 hover:text-amber-ink"
        >
          {SITE.phoneDisplay}
        </a>
      </p>
    </div>
  )
}
