'use client'

import { useState } from 'react'
import { MAX_PARTY_SIZE } from '@/lib/booking'

// Cheap taps before keyboard (build/08 §3): a chip row covers the parties
// this room actually sees; 9+ reveals a numeric input. Selection is an ink
// fill — amber is spent on the submit. Past twelve the form ROUTES, never
// errors: a non-blocking nudge toward the private room, still submittable.
const CHIPS = [1, 2, 3, 4, 5, 6, 7, 8] as const

export function PartyChips({
  value,
  onChange,
  describedBy,
}: {
  value: number | undefined
  onChange: (size: number) => void
  describedBy?: string
}) {
  const [custom, setCustom] = useState(false)
  const showCustom = custom || (value !== undefined && value > 8)

  return (
    <div aria-describedby={describedBy}>
      <div className="flex flex-wrap gap-2">
        {CHIPS.map((size) => {
          const selected = !showCustom && value === size
          return (
            <button
              key={size}
              type="button"
              aria-pressed={selected}
              onClick={() => {
                setCustom(false)
                onChange(size)
              }}
              className={`tap-feedback min-h-12 min-w-12 rounded border font-mono text-lg font-bold tabular-nums ${
                selected
                  ? 'border-ink bg-ink text-paper'
                  : 'border-hairline bg-surface text-ink'
              }`}
            >
              {size}
            </button>
          )
        })}
        <button
          type="button"
          aria-pressed={showCustom}
          onClick={() => {
            setCustom(true)
            if (value === undefined || value <= 8) onChange(9)
          }}
          className={`tap-feedback min-h-12 min-w-12 rounded border px-3 font-mono text-lg font-bold ${
            showCustom ? 'border-ink bg-ink text-paper' : 'border-hairline bg-surface text-ink'
          }`}
        >
          9+
        </button>
      </div>

      {showCustom ? (
        <label className="mt-3 block text-sm">
          <span className="font-bold uppercase tracking-tight">How many exactly</span>
          <input
            type="number"
            inputMode="numeric"
            min={9}
            max={MAX_PARTY_SIZE}
            value={value !== undefined && value > 0 ? value : ''}
            onChange={(event) => {
              const next = Number(event.target.value)
              if (Number.isInteger(next)) onChange(next)
            }}
            className="mt-2 block w-28 min-h-12 rounded border border-hairline bg-surface px-3 font-mono text-lg tabular-nums"
          />
        </label>
      ) : null}

      {value !== undefined && value > 12 ? (
        <p className="mt-3 max-w-[48ch] text-sm text-ink-muted">
          {value} of you? The private room might fit better —{' '}
          <a href="#ask" className="font-bold underline underline-offset-4">
            ask about it below
          </a>
          . This request still works either way.
        </p>
      ) : null}
    </div>
  )
}
