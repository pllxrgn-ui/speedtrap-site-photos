import { CategoryNav } from '@/components/menu/category-nav'
import { BoardSection, type TrackRows } from '@/components/menu/menu-category'
import { FeatureCards } from '@/components/home/dishes'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { TEL_HREF } from '@/lib/links'
import { SpecialsList } from '@/components/menu/special-plate'
import { TodayNote } from '@/components/menu/today-note'
import { getFeatures, type MenuData } from '@/lib/menu-data'
import { readOverlay } from '@/lib/overlay'
import { menuProvenance } from '@/lib/provenance'
import { SITE } from '@/lib/site'

// THE MENU (build/07 §2): the whole priced menu on the one page. Head plate
// + a static all-seven category index FIRST (a #menu tap lands with every
// category one tap away - the client's requirement, literally), then the
// four feature cards, then the sticky pill rail, then all 50 rows in board
// tracks. NO overflow-* or transform may ever land on this section or an
// ancestor, and the pill rail never goes inside a Reveal - the sticky pin
// dies silently (see category-nav.tsx).
// Track plan (build/07 §2, generalised by the boards addendum): the seven
// seed boards keep their hand-tuned row counts; a board the owner adds
// gets the safe default — 2 rows, 3 on md — because 3+ tracks only work
// where items carry no descriptions, and we can't know that in advance.
const TUNED_ROWS: Record<string, { rows: TrackRows; rowsMd: TrackRows }> = {
  burgers: { rows: 5, rowsMd: 5 },
  dinners: { rows: 2, rowsMd: 2 },
  sandwiches: { rows: 4, rowsMd: 4 },
  appetizers: { rows: 3, rowsMd: 5 },
  baskets: { rows: 2, rowsMd: 3 },
  'salads-sides': { rows: 3, rowsMd: 5 },
  drinks: { rows: 2, rowsMd: 3 },
}
const DEFAULT_ROWS: { rows: TrackRows; rowsMd: TrackRows } = { rows: 2, rowsMd: 3 }
const rowsFor = (id: string) => TUNED_ROWS[id] ?? DEFAULT_ROWS

export async function MenuSection({ menu }: { menu: MenuData }) {
  // The overlay: specials, 86 marks, today's note - cached under
  // cacheTag('overlay') so an admin publish shows on the VERY NEXT
  // request while the page itself stays cached (veto 7).
  const overlay = await readOverlay()
  const features = await getFeatures()
  const categories = menu.categories
  return (
    <section
      id="menu"
      tabIndex={-1}
      className="group scroll-mt-[var(--header-h)]"
      aria-label="Menu"
    >
      <div className="border-y border-hairline bg-surface">
        <Container className="py-12 md:py-16 lg:py-20">
          <Reveal>
            <h2 className="font-display text-slab uppercase text-ink">
              <span className="stt-line block">
                <span className="stt-masked">Order this</span>
              </span>
            </h2>

            {/* Price provenance plate: the label is non-negotiable while
                MENU_PRICES_AS_OF is set; the second sentence is the retired
                /menu ink band's copy, verbatim. */}
            <TodayNote note={overlay.note} />
            <div className="mt-6 max-w-[52ch] border-l-2 border-amber bg-paper py-4 pl-5 pr-4">
              <p className="text-sm font-bold uppercase tracking-wide text-ink-muted">
                {menuProvenance(menu.updatedAt).plateLabel}
              </p>
              {overlay.specials.length > 0 ? (
                // A published special takes this plate over; the apology
                // sentence dies and the tel link lives on inside the list
                // (build/08 §5 Phase 5).
                <SpecialsList specials={overlay.specials} />
              ) : (
                <>
                  <p className="mt-1 text-ink-muted">
                    The kitchen runs specials that never make it onto a page this
                    tidy. One call gets you the real answer.
                  </p>
                  <a
                    href={TEL_HREF}
                    className="tick mt-2 inline-flex min-h-11 flex-wrap items-baseline gap-x-3 font-extrabold uppercase tracking-tight hover:text-amber-ink"
                  >
                    Call for today&apos;s specials
                    <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
                  </a>
                </>
              )}
            </div>
          </Reveal>

          {/* The category index: every board, always visible, one tap each.
              Same device as the About dateline (LedgerIndex). This is the
              "customers dont scroll too much" affordance - do not delete it
              as a "duplicate" of the pill rail: the rail scrolls and shows
              ~3 pills at 375; this shows all seven. */}
          <Reveal group className="mt-10 border-t-2 border-ink pt-5">
            <ul className="stt-stagger grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-x-6 lg:gap-x-8">
              {categories.map((category) => (
                <li key={category.id} className="border-t border-hairline pt-3 md:border-0 md:pt-0">
                  <a href={`#${category.id}`} className="tick flex min-h-11 flex-col gap-1 pb-2">
                    <span className="text-[1.0625rem] font-extrabold uppercase tracking-tight">
                      {category.title}
                    </span>
                    <span className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
                      {category.items.length} items
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>

          {/* THE FAVORITES (addendum 6): owner-picked, and the section says
              WHAT IT IS now — four cards with no label read as a random
              menu excerpt (client feedback 2026-09-23). */}
          {features.length > 0 ? (
            <Reveal group className="mt-10">
              <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-t-2 border-ink pt-5">
                <h3 className="font-display text-h3 uppercase">House favorites</h3>
                <p className="text-sm font-bold text-ink-muted">
                  Four picks from our boards. The whole menu runs below.
                </p>
              </div>
              <div className="mt-5">
                <FeatureCards cards={features} />
              </div>
            </Reveal>
          ) : null}
        </Container>
      </div>

      <CategoryNav categories={categories} />

      {/* The paper/surface rhythm generalised by POSITION over whatever
          boards render: first 3 on paper, next 2 on the surface band, the
          rest on paper — the same alternation the seven seed boards shipped
          with, indifferent to renames, reorders and additions. */}
      <Container className="space-y-12 py-12">
        {categories.slice(0, 3).map((category) => (
          <BoardSection soldOut={overlay.soldOut} photos={overlay.photos}
            key={category.id}
            category={category}
            rows={rowsFor(category.id).rows}
            rowsMd={rowsFor(category.id).rowsMd}
          />
        ))}
      </Container>

      {categories.length > 3 ? (
        <div className="border-y border-hairline bg-surface">
          <Container className="space-y-12 py-12">
            {categories.slice(3, 5).map((category) => (
              <BoardSection soldOut={overlay.soldOut} photos={overlay.photos}
                key={category.id}
                category={category}
                rows={rowsFor(category.id).rows}
                rowsMd={rowsFor(category.id).rowsMd}
              />
            ))}
          </Container>
        </div>
      ) : null}

      <Container className="space-y-12 py-12">
        {categories.slice(5).map((category) => (
          <BoardSection soldOut={overlay.soldOut} photos={overlay.photos}
            key={category.id}
            category={category}
            rows={rowsFor(category.id).rows}
            rowsMd={rowsFor(category.id).rowsMd}
          />
        ))}

        {/* Jump-back row: one 44px line, the section's foot. */}
        <div className="flex flex-wrap gap-x-8 border-t border-hairline pt-4">
          <a
            href="#menu"
            className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            Back to the menu index
          </a>
          <a
            href={TEL_HREF}
            className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            Call for today&apos;s specials
          </a>
        </div>
      </Container>
    </section>
  )
}
