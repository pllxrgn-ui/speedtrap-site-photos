import { CategoryNav } from '@/components/menu/category-nav'
import { BoardSection, type TrackRows } from '@/components/menu/menu-category'
import { FeatureCards } from '@/components/home/dishes'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { TEL_HREF } from '@/lib/links'
import { MENU, MENU_PRICES_AS_OF, type MenuCategory } from '@/lib/menu'
import { SITE } from '@/lib/site'

// THE MENU (build/07 §2): the whole priced menu on the one page. Head plate
// + a static all-seven category index FIRST (a #menu tap lands with every
// category one tap away - the client's requirement, literally), then the
// four feature cards, then the sticky pill rail, then all 50 rows in board
// tracks. NO overflow-* or transform may ever land on this section or an
// ancestor, and the pill rail never goes inside a Reveal - the sticky pin
// dies silently (see category-nav.tsx).
const pickCategory = (id: string): MenuCategory => {
  const category = MENU.find((candidate) => candidate.id === id)
  if (!category) throw new Error(`Menu category missing: ${id}`)
  return category
}

// Track plan (build/07 §2): 3 tracks only where items carry no descriptions;
// prose categories stay 2 or one tall row inflates its whole grid row.
const BOARDS: { id: string; rows: TrackRows; rowsMd: TrackRows }[] = [
  { id: 'burgers', rows: 5, rowsMd: 5 },
  { id: 'dinners', rows: 2, rowsMd: 2 },
  { id: 'sandwiches', rows: 4, rowsMd: 4 },
  { id: 'appetizers', rows: 3, rowsMd: 5 },
  { id: 'baskets', rows: 2, rowsMd: 3 },
  { id: 'salads-sides', rows: 3, rowsMd: 5 },
  { id: 'drinks', rows: 2, rowsMd: 3 },
]
const GROUP_PAPER_A = BOARDS.slice(0, 3)
const GROUP_SURFACE = BOARDS.slice(3, 5)
const GROUP_PAPER_B = BOARDS.slice(5)

export function MenuSection() {
  return (
    <section
      id="menu"
      tabIndex={-1}
      className="group scroll-mt-[var(--header-h)]"
      aria-label="Menu"
    >
      <div className="border-y border-hairline bg-surface">
        <Container className="py-12 md:py-16 lg:py-20">
          <Reveal>
            <h2 className="font-display text-slab uppercase text-ink">
              <span className="stt-line block">
                <span className="stt-masked">Order this</span>
              </span>
            </h2>

            {/* Price provenance plate: the label is non-negotiable while
                MENU_PRICES_AS_OF is set; the second sentence is the retired
                /menu ink band's copy, verbatim. */}
            <div className="mt-6 max-w-[52ch] border-l-2 border-amber bg-paper py-4 pl-5 pr-4">
              <p className="text-sm font-bold uppercase tracking-wide text-ink-muted">
                {MENU_PRICES_AS_OF
                  ? `Prices from the ${MENU_PRICES_AS_OF} menu.`
                  : 'Prices at the bar while we finish this page.'}
              </p>
              <p className="mt-1 text-ink-muted">
                The kitchen runs specials that never make it onto a page this
                tidy. One call gets you the real answer.
              </p>
              <a
                href={TEL_HREF}
                className="tick mt-2 inline-flex min-h-11 flex-wrap items-baseline gap-x-3 font-extrabold uppercase tracking-tight hover:text-amber-ink"
              >
                Call for today&apos;s specials
                <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
              </a>
            </div>
          </Reveal>

          {/* The category index: all seven, always visible, one tap each.
              Same device as the About dateline (LedgerIndex). This is the
              "customers dont scroll too much" affordance - do not delete it
              as a "duplicate" of the pill rail: the rail scrolls and shows
              ~3 pills at 375; this shows all seven. */}
          <Reveal group className="mt-10 border-t-2 border-ink pt-5">
            <ul className="stt-stagger grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-x-6 lg:gap-x-8">
              {MENU.map((category) => (
                <li key={category.id} className="border-t border-hairline pt-3 md:border-0 md:pt-0">
                  <a href={`#${category.id}`} className="tick flex min-h-11 flex-col gap-1 pb-2">
                    <span className="text-[1.0625rem] font-extrabold uppercase tracking-tight">
                      {category.title}
                    </span>
                    <span className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
                      {category.items.length} items
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal group className="mt-10">
            <FeatureCards />
          </Reveal>
        </Container>
      </div>

      <CategoryNav categories={MENU} />

      <Container className="space-y-12 py-12">
        {GROUP_PAPER_A.map((board) => (
          <BoardSection
            key={board.id}
            category={pickCategory(board.id)}
            rows={board.rows}
            rowsMd={board.rowsMd}
          />
        ))}
      </Container>

      <div className="border-y border-hairline bg-surface">
        <Container className="space-y-12 py-12">
          {GROUP_SURFACE.map((board) => (
            <BoardSection
              key={board.id}
              category={pickCategory(board.id)}
              rows={board.rows}
              rowsMd={board.rowsMd}
            />
          ))}
        </Container>
      </div>

      <Container className="space-y-12 py-12">
        {GROUP_PAPER_B.map((board) => (
          <BoardSection
            key={board.id}
            category={pickCategory(board.id)}
            rows={board.rows}
            rowsMd={board.rowsMd}
          />
        ))}

        {/* Jump-back row: one 44px line, the section's foot. */}
        <div className="flex flex-wrap gap-x-8 border-t border-hairline pt-4">
          <a
            href="#menu"
            className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            Back to the menu index
          </a>
          <a
            href={TEL_HREF}
            className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            Call for today&apos;s specials
          </a>
        </div>
      </Container>
    </section>
  )
}
