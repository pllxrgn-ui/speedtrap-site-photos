import { BookingFallback } from '@/components/booking/booking-fallback'
import { BookingForm } from '@/components/booking/booking-form'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// BLOCK 13 — the cap is SPENT (build/07 block cap; build/08 §3). The
// film's third light: the hero opens lit, the page runs dark through the
// argument, and it comes back up lit for the two closing asks — hold a
// table, or call. Material, not ground: the glow pool and the amber-edged
// plate sit ON the night scene the way the menu's paper insert does.
//
// The asks escalate on purpose: the private room fits your party (#12
// above) → hold a table (here) → or just call (#call below). The tel link
// is never demoted (veto 11): lede, beside submit, every failure state,
// and the giant number one block down.
const bookingEnabled = process.env.NEXT_PUBLIC_BOOKING_ENABLED === '1'

export function BookSection() {
  return (
    <section
      id="book"
      tabIndex={-1}
      className="anchor-section group relative overflow-hidden pb-12 lg:pb-0"
    >
      <div
        aria-hidden
        className="glow-pool pointer-events-none absolute inset-x-0 top-0 h-[70%]"
      />
      <Container className="relative py-12 md:py-16 lg:py-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <div className="grid gap-10 pt-5 lg:grid-cols-12 lg:gap-12">
          <Reveal className="lg:col-span-5">
            <p className="font-mono text-sm font-bold uppercase tracking-widest text-ink-muted">
              The book
            </p>
            <h2 className="mt-3 font-display text-slab uppercase text-ink">
              Hold a table
            </h2>
            <p className="mt-6 max-w-[46ch] text-lg leading-relaxed">
              <strong className="font-bold">
                This is a request, not a table held. We call you back.
              </strong>{' '}
              One short call, usually the same day, and it is settled.
            </p>
            <p className="mt-6 text-ink-muted">
              The fast lane is still the phone:{' '}
              <a
                href={TEL_HREF}
                className="font-mono font-bold text-ink underline underline-offset-4 hover:text-amber-ink"
              >
                {SITE.phoneDisplay}
              </a>
            </p>
          </Reveal>

          <Reveal className="lg:col-span-7">
            {/* The amber-edged plate: the section's one edge of light,
                same register as the odometer (build/03). */}
            <div className="rounded-lg border border-hairline border-t-2 border-t-amber bg-surface/60 p-6 md:p-8">
              {bookingEnabled ? <BookingForm /> : <BookingFallback />}
            </div>
          </Reveal>
        </div>
      </Container>
    </section>
  )
}
