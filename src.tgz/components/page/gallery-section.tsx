import { PhotoTile } from '@/components/gallery/photo-tile'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { CATEGORY_LABEL, CATEGORY_ORDER, PHOTOS } from '@/lib/photos'

// GALLERY (build/07 §1.8): /gallery entire in ONE section - every photo,
// clustered in CATEGORY_ORDER under mono labels instead of four separate
// heading sections, 2-up at 375. Lede uses the audit-corrected line (three
// of seven frames are exteriors, so "shot in the building" was wrong).
export function GallerySection() {
  const clusters = CATEGORY_ORDER.map((category) => ({
    category,
    photos: PHOTOS.filter((photo) => photo.category === category),
  })).filter((cluster) => cluster.photos.length > 0)

  return (
    <section
      id="gallery"
      tabIndex={-1}
      className="anchor-section group border-y border-hairline bg-surface"
    >
      <Container className="py-12 md:py-16 lg:py-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <Reveal className="pt-5">
          <h2 className="font-display text-slab uppercase text-ink">
            Inside the Speed Trap
          </h2>
          <p className="mt-3 max-w-[62ch] text-ink-muted">
            Real pictures of this place, not stock photography. Tap any picture
            to see it bigger.
          </p>
        </Reveal>

        {clusters.map((cluster) => (
          <Reveal group key={cluster.category} className="mt-8">
            <p className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
              {CATEGORY_LABEL[cluster.category]}
            </p>
            <div className="stt-stagger mt-3 grid grid-cols-2 gap-4 lg:grid-cols-3">
              {cluster.photos.map((photo) => (
                <PhotoTile key={photo.src} photo={photo} />
              ))}
            </div>
          </Reveal>
        ))}
      </Container>
    </section>
  )
}
