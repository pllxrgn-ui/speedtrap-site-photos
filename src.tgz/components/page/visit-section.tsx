import { HoursBlock } from '@/components/find-us/hours-block'
import { MapBlock } from '@/components/find-us/map-block'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { VISIT_FACTS } from '@/lib/facts'
import { FAQS } from '@/lib/faq'

// FIND US (build/07 §1.7): /find-us entire. The map facade, the hours block,
// the four visit facts at their strongest (body) length - no icons, the
// mono-ledger device instead - and the six FAQs as a PLAIN VISIBLE <dl>.
// The accordion is retired site-wide with this file: ~112px bought zero-JS,
// full crawlability, Radix Accordion out of the bundle, and audit M3's
// dark-mode plate bug dead by deletion. FAQPage JSON-LD is emitted from
// app/page.tsx via lib/jsonld.ts, same source, cannot drift.
// No street address anywhere here: E/W Broadway is unresolved
// (CLIENT-QUESTIONS #3); location is corridor, landmark and coordinates.
export function VisitSection() {
  return (
    <section id="find-us" tabIndex={-1} className="anchor-section group bg-paper">
      <Container className="py-12 md:py-16 lg:py-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <Reveal className="pt-5">
          <h2 className="font-display text-slab uppercase text-ink">Find us</h2>
          <p className="mt-6 max-w-[62ch] text-lg leading-relaxed">
            On Highway 2 in Reardan, 22 miles west of Spokane. If you are headed
            for Davenport, Grand Coulee Dam or Lake Roosevelt, you drive right
            past the front door. We are on the highway itself, so you will see
            the sign before you are looking for it.
          </p>
        </Reveal>

        <Reveal className="mt-10">
          <div className="grid gap-6 lg:grid-cols-2">
            <MapBlock />
            <HoursBlock />
          </div>
        </Reveal>

        <Reveal group className="mt-12">
          <h3 className="text-h3 font-extrabold uppercase tracking-tight">
            Good to know
          </h3>
          <dl className="stt-stagger mt-5 border-t border-hairline">
            {VISIT_FACTS.map((fact) => (
              <div
                key={fact.id}
                className="grid gap-2 border-b border-hairline py-5 md:grid-cols-[10rem_16rem_1fr] md:gap-6"
              >
                <dt className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                  {fact.label}
                </dt>
                <dd className="font-bold">{fact.title}</dd>
                <dd className="max-w-[62ch] text-ink-muted">{fact.body}</dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal className="mt-12 lg:grid lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-4">
            <h3 className="text-h3 font-extrabold uppercase tracking-tight">
              Questions we get
            </h3>
            <p className="mt-3 max-w-[40ch] leading-relaxed text-ink-muted">
              If yours is not here, call and ask. Nobody here minds the phone.
            </p>
          </div>
          <dl className="mt-6 lg:col-span-8 lg:mt-0">
            {FAQS.map((faq) => (
              <div key={faq.q} className="border-t border-hairline py-5 last:border-b">
                <dt className="font-bold">{faq.q}</dt>
                <dd className="mt-1 max-w-[62ch] text-ink-muted">{faq.a}</dd>
              </div>
            ))}
          </dl>
        </Reveal>
      </Container>
    </section>
  )
}
