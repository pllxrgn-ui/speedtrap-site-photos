import Image from 'next/image'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { Odometer } from '@/components/ui/odometer'
import { HISTORY } from '@/lib/history'

// THE ROOM (v3, client direction 2026-09-15: "come up another way"). The
// six-row ledger and its switchback are retired. The section is now one
// cinematic rhyme with the hero: the c.1904 crowd outside this building,
// full-bleed and darkened, answering the packed bar up top - SAME ROOM,
// SAME CROWD, a century apart. Under it, the whole history as four big
// stops on one line. Caption honesty unchanged: circa stays circa, the
// archive is credited, text sits on the solid-overlay ground (the
// corridor-band device), never on raw photo.
const STOPS = HISTORY.filter((row) => row.kind === 'entry')

export function RoomSection() {
  return (
    <section id="about" tabIndex={-1} className="anchor-section group bg-paper">
      <Container className="pt-12 md:pt-16 lg:pt-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <Reveal className="pt-5">
          <p className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
            The Stevenson Building &middot; Reardan, Washington &middot;{' '}
            <span className="tabular-nums">22</span> miles west of Spokane
          </p>
          <h2 className="mt-4 font-display text-slab uppercase text-ink">
            Same building since the early{' '}
            <span className="font-mono tabular-nums">1900</span>s
          </h2>
        </Reveal>
      </Container>

      {/* The scene: the crowd out front, more than a century ago. */}
      <Reveal className="mt-10">
        <div className="relative min-h-[60vh] overflow-hidden md:min-h-[70vh]">
          <Image
            src="/photos/stevenson-building-c1904.webp"
            alt="A crowd gathered in front of the Stevenson Building around 1904, signs for J.C. Driscoll General Merchandise on the facade."
            fill
            loading="lazy"
            sizes="100vw"
            className="object-cover object-center"
          />
          <span aria-hidden className="absolute inset-0 bg-paper/60" />
          <div className="absolute inset-x-0 bottom-0">
            <Container className="pb-10 md:pb-14">
              <p className="font-display text-slab uppercase leading-[0.95] text-ink">
                Same room.
                <br />
                <span className="text-amber-ink">Same crowd.</span>
              </p>
              <p className="mt-4 max-w-[46ch] text-lg leading-relaxed text-ink">
                Local histories say Reardan&apos;s first bank opened in this
                room. It has carried a few different names since, and it is
                still the same room.
              </p>
              <p className="mt-5 inline-block rounded bg-paper/85 px-3 py-1.5 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
                Circa 1904 &middot; Reardan Memorial Library, via Washington
                Rural Heritage
              </p>
            </Container>
          </div>
        </div>
      </Reveal>

      {/* The century, four stops on one line. */}
      <Container className="py-12 md:py-16 lg:py-20">
        <Reveal group>
          <ol className="stt-stagger grid grid-cols-2 gap-x-6 gap-y-10 lg:grid-cols-4 lg:gap-x-8">
            {STOPS.map((row) => (
              <li key={row.id} id={row.id ?? undefined} className="border-t-2 border-ink pt-5">
                <p
                  className={`font-mono text-sm font-bold uppercase tracking-wide tabular-nums ${
                    row.era === 'Today' ? 'text-amber-ink' : 'text-ink-muted'
                  }`}
                >
                  {row.era}
                </p>
                <p className="mt-2 font-display text-h1 uppercase leading-[0.95] text-ink">
                  {row.name}
                </p>
                <p className="mt-3 max-w-[36ch] text-ink-muted">{row.body}</p>
              </li>
            ))}
          </ol>
        </Reveal>
      </Container>

      {/* Why the name: unchanged - these statements earn their keep. */}
      <div className="border-y border-hairline bg-surface">
        <Container className="py-12 md:py-16 lg:py-20">
          <div className="border-t-2 border-ink" />
          <Reveal className="pt-8 lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="lg:col-span-6">
              <p className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                Why the name
              </p>
              <p className="mt-4 text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
                Highway <span className="font-mono tabular-nums">2</span> runs
                straight and open until it hits Reardan.
              </p>
              <div className="mt-6 border-t-2 border-ink pt-6">
                <p className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
                  Then the limit drops.
                </p>
              </div>
            </div>
            <div className="mt-8 lg:col-span-5 lg:col-start-8 lg:mt-0 lg:self-end">
              <p className="max-w-[46ch] text-lg leading-relaxed">
                The town gets a reputation with drivers who notice that late.
                The name was sitting right there, so we took it.
              </p>
            </div>
          </Reveal>
        </Container>
      </div>

      {/* The Memorial Day fact. Odometer stays; the source keeps the amber
          edge. */}
      <Container className="py-12 md:py-16 lg:py-20">
        <Reveal className="lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
          <p aria-hidden className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em] lg:col-span-7">
            In May <span className="font-mono tabular-nums">2026</span> the town
            held its Memorial Day observance in here, and{' '}
            <Odometer value="55" trigger="view" baseDelay={200} className="font-mono tabular-nums" />{' '}
            people packed in.
          </p>
          <p className="sr-only">
            In May 2026 the town held its Memorial Day observance in here, and
            55 people packed in.
          </p>
          <div className="mt-8 border-l-2 border-amber pl-4 lg:col-span-4 lg:col-start-9 lg:mt-0 lg:pl-6">
            <p className="font-mono text-sm uppercase tracking-wide text-ink-muted">Source</p>
            <p className="mt-1 font-bold">Odessa Record</p>
            <p className="font-mono text-sm tabular-nums text-ink-muted">May 2026</p>
          </div>
        </Reveal>
      </Container>
    </section>
  )
}
