import Image from 'next/image'
import { Ledger, LedgerIndex } from '@/components/about/ledger'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { Odometer } from '@/components/ui/odometer'

// THE ROOM (build/07 §1.5): /about entire - masthead with the c.1904 scan
// and its honest caption, the dateline index, the full ledger with all four
// attributed archival frames, the why-the-name pull, and the Memorial Day
// fact. The About ink band becomes a PAPER statement (the corridor band
// keeps the page's one inversion); the Odessa source keeps the amber-edge
// device. Cut: only the Stop-in CTA block, a duplicate of VISIT_FACTS.
export function RoomSection() {
  return (
    <section id="about" tabIndex={-1} className="anchor-section group bg-paper">
      <Container className="pt-12 md:pt-16 lg:pt-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <Reveal className="pt-5 lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
          <div className="lg:col-span-7">
            <p className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
              The Stevenson Building &middot; Reardan, Washington &middot;{' '}
              <span className="tabular-nums">22</span> miles west of Spokane
            </p>
            <h2 className="mt-4 font-display text-slab uppercase text-ink">
              Same building since the early{' '}
              <span className="font-mono tabular-nums">1900</span>s
            </h2>
            <p className="mt-6 max-w-[46ch] text-lg leading-relaxed text-ink-muted">
              Local histories say Reardan&apos;s first bank opened in this room.
              It has carried a few different names since, and it is still the
              same room.
            </p>
          </div>
          <div className="mt-8 lg:col-span-5 lg:mt-0">
            <div className="img-frame relative aspect-[3/2] overflow-hidden rounded grayscale md:max-w-[34rem]">
              <Image
                src="/photos/stevenson-building-c1904.webp"
                alt="A crowd gathered in front of the Stevenson Building around 1904, signs for J.C. Driscoll General Merchandise on the facade."
                fill
                loading="lazy"
                sizes="(min-width: 1024px) 455px, (min-width: 768px) 544px, 100vw"
                className="object-cover"
              />
            </div>
            <p className="mt-3 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
              The same building &middot; Circa 1904 &middot; Reardan Memorial
              Library, via Washington Rural Heritage
            </p>
          </div>
        </Reveal>
        <LedgerIndex />
      </Container>

      <Ledger />

      <div className="border-y border-hairline bg-surface">
        <Container className="py-12 md:py-16 lg:py-20">
          <div className="border-t-2 border-ink" />
          <Reveal className="pt-8 lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="lg:col-span-6">
              <p className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                Why the name
              </p>
              <p className="mt-4 text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
                Highway <span className="font-mono tabular-nums">2</span> runs
                straight and open until it hits Reardan.
              </p>
              <div className="mt-6 border-t-2 border-ink pt-6">
                <p className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
                  Then the limit drops.
                </p>
              </div>
            </div>
            <div className="mt-8 lg:col-span-5 lg:col-start-8 lg:mt-0 lg:self-end">
              <p className="max-w-[46ch] text-lg leading-relaxed">
                The town gets a reputation with drivers who notice that late.
                The name was sitting right there, so we took it.
              </p>
            </div>
          </Reveal>
        </Container>
      </div>

      {/* The Memorial Day fact, on paper (the corridor band keeps the page's
          one inversion). Odometer stays; the source keeps the amber edge. */}
      <Container className="py-12 md:py-16 lg:py-20">
        <Reveal className="lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
          <p aria-hidden className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em] lg:col-span-7">
            In May <span className="font-mono tabular-nums">2026</span> the town
            held its Memorial Day observance in here, and{' '}
            <Odometer value="55" trigger="view" baseDelay={200} className="font-mono tabular-nums" />{' '}
            people packed in.
          </p>
          <p className="sr-only">
            In May 2026 the town held its Memorial Day observance in here, and
            55 people packed in.
          </p>
          <div className="mt-8 border-l-2 border-amber pl-4 lg:col-span-4 lg:col-start-9 lg:mt-0 lg:pl-6">
            <p className="font-mono text-sm uppercase tracking-wide text-ink-muted">Source</p>
            <p className="mt-1 font-bold">Odessa Record</p>
            <p className="font-mono text-sm tabular-nums text-ink-muted">May 2026</p>
          </div>
        </Reveal>
      </Container>
    </section>
  )
}
