import { RhythmList } from '@/components/events/rhythm-list'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { MULE_DAYS_NOTE, RECURRING } from '@/lib/events'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// THE WEEK (build/07 §1.4): /events entire. All five recurring rows with
// their posted prices, the Mule Days plate (DEMOTED amber -> ink: the
// one-pager's amber-fill cap is five and the hero/dishes/corridor/sticky
// slots hold them), and the announcements line, which also absorbs
// /find-us's "land here first" sentence - one Facebook pointer, not two.
export function WeekSection() {
  return (
    <section
      id="events"
      tabIndex={-1}
      className="anchor-section group border-y border-hairline bg-surface"
    >
      <Container className="py-12 md:py-16 lg:py-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <Reveal className="pt-5">
          <h2 className="font-display text-slab uppercase text-ink">
            The week, roughly
          </h2>
          <p className="mt-3 max-w-[62ch] text-lg">
            The rhythm below is what regulars know.{' '}
            <a href={TEL_HREF} className="font-bold underline underline-offset-4 hover:text-amber-ink">
              Call to confirm what is on tonight:{' '}
              <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
            </a>
          </p>
        </Reveal>

        <Reveal className="mt-8">
          <div className="max-w-3xl">
            <RhythmList events={RECURRING} />
          </div>
        </Reveal>

        <Reveal className="mt-10">
          <div className="grid gap-6 lg:grid-cols-12 lg:items-center lg:gap-12">
            <h3 className="lg:col-span-4">
              <span className="inline-block rounded bg-ink px-5 py-3 text-h2 font-extrabold uppercase leading-[1.15] tracking-[-0.02em] text-paper">
                Mule Days
              </span>
            </h3>
            <p className="max-w-[46ch] text-lg leading-relaxed lg:col-span-8">
              {MULE_DAYS_NOTE}
            </p>
          </div>
        </Reveal>

        <Reveal className="mt-10">
          <h3 className="text-h3 font-extrabold uppercase tracking-tight">
            Nights get announced before they get printed
          </h3>
          <p className="mt-3 max-w-[62ch] text-ink-muted">
            Specials, live music and whatever is coming out of the kitchen this
            week land here first. Follow along on Facebook, or call and someone
            will tell you straight.
          </p>
          <p className="mt-2">
            <a
              href={SITE.social.facebook}
              target="_blank"
              rel="noopener"
              className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Facebook
            </a>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
