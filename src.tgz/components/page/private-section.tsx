import { Phone } from '@phosphor-icons/react/dist/ssr'
import { InquiryFallback } from '@/components/private-room/inquiry-fallback'
import { InquiryForm } from '@/components/private-room/inquiry-form'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// PRIVATE ROOM & CATERING (build/07 §1.11): /private-room entire. The three
// no-guessing facts (icons dropped, list device instead), the Menupix quote
// as a paper statement on the amber-edge device (the corridor band keeps the
// page's one inversion), and the env-gated inquiry form under its #ask
// anchor. The Call button is INK here (amber-fill cap = 5, spent elsewhere);
// the ghost "Ask about a date" button died - #ask is one scroll below.
const FACTS = [
  {
    title: 'There is a private room',
    body: 'A private dining room, part of the restaurant, and bookable. What it seats is the one thing we are not going to guess at in print.',
  },
  {
    title: 'A full bar comes with it',
    body: 'The full spirits license is current in state records. Beer, wine and cocktails, not just what is on tap.',
  },
  {
    title: 'Licensed to cater',
    body: 'Our license carries a catering endorsement, active in Washington State records through May 2027. Ask what we can bring and how far it travels.',
  },
] as const

const inquiryEnabled = process.env.NEXT_PUBLIC_INQUIRY_ENABLED === '1'

export function PrivateSection() {
  return (
    // GROUND = SURFACE, not paper (amendment 2026-09-23, build/07
    // "VISITOR-ORDER REORDER"). THE ROOM (#about) now sits directly above
    // this block and its tail band is paper, so bg-paper here would butt two
    // paper grounds with no seam. This is the ONE ground flipped to restore
    // the alternation. Downstream: #call is also surface, seamed by its own
    // full-bleed `border-t border-hairline` - the same device build/07 §1
    // uses at the footer. Do not flip this back without re-deriving the
    // whole chain in the amendment.
    <section id="private-room" tabIndex={-1} className="anchor-section group bg-surface">
      <Container className="py-12 md:py-16 lg:py-20">
        <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
        <Reveal className="pt-5">
          <h2 className="font-display text-slab uppercase text-ink">
            The private room
          </h2>
          <p className="mt-6 max-w-[62ch] text-lg leading-relaxed">
            Yes, there is one, and yes you can have it. What we will not do is
            print a seating number we have not measured, because you would plan
            around it and we would both regret it. So here is the deal instead.{' '}
            <strong className="font-bold">
              Tell us your date and headcount and we will tell you if the room
              fits.
            </strong>
          </p>
          <p className="mt-6">
            <ButtonA href={TEL_HREF} variant="ink" size="lg">
              <Phone size={20} weight="bold" aria-hidden />
              Call {SITE.phoneDisplay}
            </ButtonA>
          </p>
        </Reveal>

        <Reveal group className="mt-10">
          <dl className="stt-stagger border-t border-hairline">
            {FACTS.map((fact) => (
              <div
                key={fact.title}
                className="grid gap-2 border-b border-hairline py-5 md:grid-cols-[18rem_1fr] md:gap-6"
              >
                <dt className="font-bold">{fact.title}</dt>
                <dd className="max-w-[62ch] leading-relaxed text-ink-muted">{fact.body}</dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal className="mt-12">
          <figure className="max-w-[40rem] border-l-2 border-amber pl-5">
            <blockquote>
              <p className="text-h2 font-extrabold uppercase leading-[1.15] tracking-[-0.02em]">
                &ldquo;The food was excellent.&rdquo;
              </p>
            </blockquote>
            <figcaption className="mt-3 font-mono text-sm text-ink-muted">
              Menupix review of a catered event, September 2023
            </figcaption>
          </figure>
        </Reveal>

        <Reveal className="mt-12">
          <div id="ask" className="scroll-mt-[calc(var(--header-h)+1rem)] grid gap-10 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <h3 className="text-h3 font-extrabold uppercase tracking-tight">
                Ask about a date
              </h3>
              <p className="mt-3 max-w-[48ch] leading-relaxed text-ink-muted">
                Capacity, deposits and what a booking includes are not published
                here yet, because we have not pinned them down in writing. Ask
                and you get the real numbers, not a range somebody typed into a
                website.
              </p>
            </div>
            <div className="lg:col-span-8">
              {inquiryEnabled ? <InquiryForm /> : <InquiryFallback />}
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  )
}
