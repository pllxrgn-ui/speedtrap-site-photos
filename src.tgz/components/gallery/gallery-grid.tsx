import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { PhotoTile } from './photo-tile'
import { CATEGORY_LABEL, CATEGORY_ORDER, PHOTOS } from '@/lib/photos'

// Server component. Renders one section per category in a fixed order with
// seating first, and nothing at all for a category with no photos in it yet,
// so the page fills in shot by shot instead of waiting on a complete set.
export function GalleryGrid() {
  return (
    <>
      {CATEGORY_ORDER.map((category) => {
        const photos = PHOTOS.filter((photo) => photo.category === category)
        if (photos.length === 0) return null

        return (
          <section key={category} className="border-b border-hairline last:border-b-0">
            <Container className="py-12 md:py-20">
              <Reveal>
                <h2 className="text-h2 font-extrabold uppercase tracking-tight">
                  {CATEGORY_LABEL[category]}
                </h2>
              </Reveal>
              {/* Tiles enter in sequence behind the heading (build/03 §1.5).
                  The stagger is capped at six steps in globals.css, so a
                  category with a dozen photos still finishes in 300ms. */}
              <Reveal group>
                <div className="stt-stagger mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {photos.map((photo) => (
                    <PhotoTile key={photo.src} photo={photo} />
                  ))}
                </div>
              </Reveal>
            </Container>
          </section>
        )
      })}
    </>
  )
}
