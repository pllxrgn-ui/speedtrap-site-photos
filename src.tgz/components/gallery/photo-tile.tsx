'use client'

import * as Dialog from '@radix-ui/react-dialog'
import Image from 'next/image'
import { X } from '@phosphor-icons/react/dist/ssr'
import { RATIO_CLASS, type Photo } from '@/lib/photos'

// The only client component on this page. Motion register #5: opacity fade
// 150ms, no scale, no backdrop blur. No carousel: one photo, Escape or a tap
// outside closes it (build/03 §3, the embla rejection is recorded there).
export function PhotoTile({ photo }: { photo: Photo }) {
  const ratio = RATIO_CLASS[photo.ratio]

  return (
    <Dialog.Root>
      {/* stt-fade keyframe lives in globals.css, gated by reduced-motion.
          photo-zoom scales the picture to 1.03 inside a frame that holds
          still, so the crop stays inside the fixed aspect ratio and the grid
          never reflows. lift and tap-feedback are the same control physics
          every button on the site uses. */}
      <Dialog.Trigger
        className={`photo-zoom lift tap-feedback img-frame relative block w-full overflow-hidden rounded ${ratio}`}
      >
        <Image
          src={photo.src}
          alt={photo.alt}
          fill
          // No rendered photo exceeds 720px (build/03 §1.6 rule 3); at the
          // 1200px container a three-up tile tops out around 380px.
          sizes="(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw"
          loading="lazy"
          className="object-cover"
          style={photo.objectPosition ? { objectPosition: photo.objectPosition } : undefined}
        />
      </Dialog.Trigger>

      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/80 animate-[stt-fade_150ms_ease-out]" />
        <Dialog.Content
          aria-describedby={undefined}
          className="fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-[720px] -translate-x-1/2 -translate-y-1/2 animate-[stt-fade_150ms_ease-out]"
        >
          <Dialog.Title className="sr-only">{photo.alt}</Dialog.Title>
          <div className={`img-frame relative overflow-hidden rounded ${ratio}`}>
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              sizes="(min-width: 768px) 720px, 100vw"
              className="object-cover"
              style={photo.objectPosition ? { objectPosition: photo.objectPosition } : undefined}
            />
          </div>
          {/* A control on a solid plate, never type floating on the photo. */}
          <Dialog.Close
            className="tap-feedback absolute right-2 top-2 flex size-11 items-center justify-center rounded bg-paper text-ink"
            aria-label="Close photo"
          >
            <X size={22} weight="bold" aria-hidden />
          </Dialog.Close>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
