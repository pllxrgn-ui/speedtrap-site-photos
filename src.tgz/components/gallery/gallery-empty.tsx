import { Phone } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { CATEGORY_LABEL, CATEGORY_ORDER } from '@/lib/photos'

// What actually renders today. A flat color field with type, which is the
// documented treatment for a slot with no real photo in it (build/03 §1.6
// rule 6). It has to read as a finished page, not as a broken one.
export function GalleryEmpty() {
  return (
    <section className="border-b border-hairline bg-surface">
      <Container className="py-12 md:py-20">
        <div className="grid gap-10 lg:grid-cols-2">
          <div className="max-w-[62ch]">
            <h2 className="text-h2 font-extrabold uppercase tracking-tight">
              Photos are coming. The room is better in person anyway.
            </h2>
            <p className="mt-6 text-ink-muted">
              Every picture that goes on this page will be taken inside this
              building. We do not buy stock photos of somebody else&apos;s bar,
              so the page stays honest and empty until the real ones exist.
            </p>
            <p className="mt-4 text-ink-muted">
              Booths go up first, because that is the one people ask about.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonA href={TEL_HREF} variant="amber" size="lg">
                <Phone size={18} weight="bold" aria-hidden />
                Call us
              </ButtonA>
              <ButtonA
                href={DIRECTIONS_HREF}
                target="_blank"
                rel="noopener"
                variant="ghost"
                size="lg"
              >
                Directions
              </ButtonA>
            </div>
          </div>

          {/* The category list, built as a roadside guide sign (build/03 §1.7).
              The plate is real markup with real text so nothing sits on an
              illustration (§1.6.1); the illustration is only the posts holding
              it up. This is why the honest-empty page reads as designed. */}
          <div className="lg:w-full lg:max-w-[380px] lg:justify-self-end">
            <div className="rounded border-2 border-ink bg-paper px-5 py-4">
              <h3 className="text-xl font-bold uppercase tracking-tight">
                What you will see here
              </h3>
              <ul className="mt-3">
                {CATEGORY_ORDER.map((category) => (
                  <li
                    key={category}
                    className="border-t border-hairline py-3 font-mono text-sm font-bold uppercase tracking-tight"
                  >
                    {CATEGORY_LABEL[category]}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </Container>
    </section>
  )
}
