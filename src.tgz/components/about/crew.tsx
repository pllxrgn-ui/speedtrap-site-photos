// STUB, RENDERS NOTHING ON PURPOSE. Do not fill this in without permission.
//
// build/03-design-direction.md §3, About / The crew: "Only ships with named
// permission. Otherwise the section does not render."
// build/02-content-plan.md §About flags the crew as pending permission and
// photos. That permission is blocker #5 in CLAUDE.md and has not come back.
//
// Naming staff or publishing their faces without written consent is the client's
// liability, not a copy decision, so the component returns null instead of
// rendering a section with empty slots in it.
//
// To ship it later: get written permission per person, add the names and photos
// to a typed data file next to this one, build the section here, and only then
// does app/about/page.tsx start rendering anything.
export function Crew() {
  return null
}
