import Image from 'next/image'
import { HISTORY } from '@/lib/history'

// Grayscale is the one photo treatment on the site, and it exists so archival
// scans of the 1905 building and modern phone shots can sit in the same row
// (build/03 §1.6 rule 5).
//
// Until a scan exists the slot is a flat color field WITH TYPE IN IT, which is
// rule 6 and the same pattern the empty gallery uses. The previous version put
// one small mono label inside an otherwise empty 3:2 box with a 1px hairline
// around it, which at 1.27:1 is invisible: four blank white rectangles that
// read as failed images, not as a designed empty state. Now the field carries
// the era as sign data and the room's name as the headline, and it is topped
// by a 2px ink rule so it reads as a plate in both themes.
export function HistoryStrip() {
  return (
    <ol className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {HISTORY.map((entry) => (
        <li key={entry.era}>
          {entry.photo ? (
            <>
              <div className="img-frame relative aspect-[3/2] overflow-hidden rounded grayscale">
                <Image
                  src={entry.photo.src}
                  alt={entry.photo.alt}
                  fill
                  sizes="(min-width: 1024px) 280px, (min-width: 768px) 50vw, 100vw"
                  loading="lazy"
                  className="object-cover"
                  style={
                    entry.photo.objectPosition
                      ? { objectPosition: entry.photo.objectPosition }
                      : undefined
                  }
                />
              </div>
              <p className="mt-3 font-mono text-sm font-bold uppercase tracking-wide tabular-nums">
                {entry.era}
              </p>
            </>
          ) : (
            <div className="flex aspect-[3/2] flex-col justify-between rounded border-t-2 border-ink bg-surface p-5">
              <p className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
                {entry.era}
              </p>
              <p className="text-h2 font-extrabold uppercase leading-[1.05] tracking-[-0.02em]">
                {entry.name}
              </p>
            </div>
          )}
          <p className="mt-3 max-w-[62ch]">{entry.body}</p>
        </li>
      ))}
    </ol>
  )
}
