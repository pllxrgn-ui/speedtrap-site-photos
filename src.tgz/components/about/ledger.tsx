import Image from 'next/image'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { HISTORY, LEDGER_INDEX, type HistoryRow } from '@/lib/history'
import { RATIO_CLASS } from '@/lib/photos'

// THE LEDGER (About redesign, 2026-09-14; amendment logged in build/03).
// The room opened as a bank, so the page is that bank's ledger: a date
// column, one strong vertical rule, entries posted down it in sequence.
// The spine is the entry cell's LEFT BORDER - a stretched grid item, so the
// border is exactly row height and consecutive rows with zero gap fuse it
// into one unbroken rule. No pseudo-elements, no absolute positioning.

// One caption recipe for every frame: designation, date, source, middots
// between, mono sign data. Never a dash. `source` is copied verbatim from a
// manifest, never composed; null renders nothing (the honest state while a
// permission gate is open).
function Caption({
  designation,
  date,
  source,
  plate = false,
}: {
  designation: string
  date: string
  source: string | null
  plate?: boolean
}) {
  return (
    <p
      className={`mt-3 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted ${
        plate ? 'border-l-2 border-amber bg-surface py-3 pl-5' : ''
      }`}
    >
      {designation} &middot; {date}
      {source ? <> &middot; {source}</> : null}
    </p>
  )
}

function Evidence({ evidence }: { evidence: NonNullable<HistoryRow['evidence']> }) {
  // Full literal class strings: Tailwind's scanner cannot see an interpolated
  // `lg:${...}` and the width would silently compile to nothing.
  const width =
    evidence.frame === '4:5'
      ? 'lg:max-w-[26rem]'
      : evidence.frame === '1:1'
        ? 'lg:max-w-[28rem]'
        : 'lg:max-w-[40rem]'
  return (
    <figure className={`mt-6 w-full md:max-w-[34rem] ${width}`}>
      <div className={`img-frame relative overflow-hidden rounded grayscale ${RATIO_CLASS[evidence.frame]}`}>
        <Image
          src={evidence.src}
          alt={evidence.alt}
          fill
          loading="lazy"
          sizes="(min-width: 1024px) 640px, (min-width: 768px) 544px, 100vw"
          className="object-cover"
        />
      </div>
      <figcaption>
        <Caption
          designation={evidence.designation}
          date={evidence.date}
          source={evidence.source}
          plate={evidence.plate}
        />
      </figcaption>
    </figure>
  )
}

// The four anchorable eras, under the masthead: mono era over the room's
// name, .tick because these are the page's only row-shaped controls.
export function LedgerIndex() {
  return (
    <div className="mt-16 border-t-2 border-ink pt-6">
      <Reveal group>
        <ul className="stt-stagger grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-x-6 lg:gap-x-8">
          {LEDGER_INDEX.map((row) => (
            <li key={row.id} className="border-t border-hairline pt-3 md:border-0 md:pt-0">
              <a href={`#${row.id}`} className="tick flex min-h-11 flex-col gap-1 pb-2">
                <span className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
                  {row.era}
                </span>
                <span className="text-[1.0625rem] font-extrabold uppercase tracking-tight">
                  {row.name}
                </span>
              </a>
            </li>
          ))}
        </ul>
      </Reveal>
    </div>
  )
}

export function Ledger() {
  return (
    <section className="py-16 md:py-20 lg:py-24">
      <Container>
        <div className="flex items-baseline justify-between gap-8 border-t-2 border-ink pt-6">
          {/* h3: on the one page the ledger sits inside the #about section's
              h2 (build/07 heading ranks). */}
          <h3 className="text-h2 font-extrabold uppercase tracking-[-0.03em]">The building</h3>
          <p className="shrink-0 font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
            <span aria-hidden>1905 to today</span>
            <span className="sr-only">1905 to today</span>
          </p>
        </div>

        {/* NEVER add gap-y here: row gaps cut the spine into dashes. And never
            wrap a whole <li> in <Reveal>: the spine segment would slide and
            visibly break the vertical rule. Content cells only.

            THE SWITCHBACK (client directive 2026-09-14, amendment e): at lg
            the six rows fold into a two-column serpentine - chronology reads
            left to right, drops a row, comes back right to left, like the
            highway's own switchbacks. The lg:order literals below place the
            second visual row in reverse; each cell keeps its own spine
            segment. Below lg the single-rule ledger survives untouched. */}
        <ol className="mt-10 lg:grid lg:grid-cols-2 lg:gap-x-10">
          {HISTORY.map((row, index) => (
            <li
              key={`${row.era}-${row.name}`}
              id={row.id ?? undefined}
              className={`${
                // Snake order, literal so the scanner sees it: row two of the
                // switchback (indexes 2 and 3) swaps cells, so chronology
                // runs L-to-R, down, then R-to-L.
                ['lg:order-1', 'lg:order-2', 'lg:order-4', 'lg:order-3', 'lg:order-5', 'lg:order-6'][index]
              } ${
                row.kind === 'entry'
                  ? 'border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] target:border-t-amber'
                  : 'border-t border-hairline'
              } border-l-2 border-l-ink pl-4 scroll-mt-[calc(var(--header-h)+2rem)] md:border-l-0 md:pl-0 ${
                // Row rhythm lives on the CHILDREN at md+, never on the li:
                // padding on the li acts as a row gap and chops the spine
                // (the inner cell's border) into dashes (audit build/05 M1).
                // Mobile keeps li padding because there the spine IS the li.
                row.evidence ? 'py-12 md:py-0' : 'py-8 md:py-0'
              } md:grid md:grid-cols-[7rem_minmax(0,1fr)]`}
            >
              <p
                className={`font-mono text-sm font-bold uppercase tracking-wide tabular-nums md:pr-6 md:text-right ${
                  row.evidence ? 'md:py-12' : 'md:py-8'
                } ${row.kind === 'entry' ? 'text-ink' : 'text-ink-muted'}`}
              >
                {row.era}
              </p>
              {/* In the switchback each cell carries its own spine segment;
                  the inner name/content split stays stacked at lg because a
                  half-track cell has no room for a 16rem name column. */}
              <div
                className={`mt-2 md:mt-0 md:border-l-2 md:border-ink md:pl-8 ${
                  row.evidence ? 'md:py-12' : 'md:py-8'
                }`}
              >
                <h4
                  className={
                    row.kind === 'entry'
                      ? 'text-h2 font-extrabold uppercase leading-[0.95] tracking-[-0.03em]'
                      : 'font-bold uppercase tracking-tight text-ink-muted'
                  }
                >
                  {row.name}
                </h4>
                <Reveal className="mt-3">
                  <p className="max-w-[46ch] text-lg leading-relaxed">{row.body}</p>
                  {row.evidence ? <Evidence evidence={row.evidence} /> : null}
                </Reveal>
              </div>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  )
}
