import type { RecurringEvent } from '@/lib/events'

// Flat rows, hairline separators, mono day label. No dates and no times beyond
// what the data strings carry: every entry is confirmed:false, so nothing here
// may read as a schedule. No Event JSON-LD for the same reason.
export function RhythmList({ events }: { events: RecurringEvent[] }) {
  return (
    <ul className="border-t border-hairline">
      {events.map((event) => (
        <li
          key={event.id}
          id={event.id}
          className="scroll-mt-[calc(var(--header-h)+2rem)] border-b border-hairline py-6 md:grid md:grid-cols-[10rem_1fr] md:gap-6"
        >
          {/* tracking-wide, matching the day/label column on the home teasers:
              the two had opposite tracking for the same mono device. */}
          <p className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
            {event.day}
          </p>
          <div className="mt-1 md:mt-0">
            <h3 className="text-xl font-extrabold uppercase tracking-tight">{event.title}</h3>
            <p className="mt-1 max-w-[62ch] text-ink-muted">{event.blurb}</p>
          </div>
        </li>
      ))}
    </ul>
  )
}
