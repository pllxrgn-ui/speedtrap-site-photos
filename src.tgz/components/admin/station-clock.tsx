'use client'

import { useEffect, useState } from 'react'

// The station clock (Pol's ask, 2026-09-23): the DEVICE's own time, live,
// in the header chrome — Martian Mono like every number back here. It
// reads the computer it runs on (no bar-timezone conversion, on purpose:
// the person behind the bar wants THEIR clock). Renders empty until the
// first client tick so the server render never guesses a time.
export function StationClock() {
  const [now, setNow] = useState<string | null>(null)

  useEffect(() => {
    const tick = () =>
      setNow(
        new Date().toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
          second: '2-digit',
        }),
      )
    // Deferred first tick (compiler rule: no sync setState in an effect).
    const first = window.setTimeout(tick, 0)
    const timer = window.setInterval(tick, 1000)
    return () => {
      window.clearTimeout(first)
      window.clearInterval(timer)
    }
  }, [])

  if (!now) return null
  return (
    <span
      aria-label="Current time on this device"
      className="font-mono text-xs font-bold uppercase tracking-widest tabular-nums text-ink-muted"
    >
      {now}
    </span>
  )
}
