'use client'

import { useState } from 'react'
import { noteClass, type StationNote } from '@/components/admin/station-message'
import { adminMutate } from '@/lib/admin/mutate'
import { dayName, weekSchema, type DayId, type DayState } from '@/lib/hours'

// THE WEEK (build/13 section 4.2). Seven rows in DAY_ORDER and ONE deliberate
// PUBLISH for the whole week.
//
// WHY THERE IS NO TRAY HERE (section 0.5). The menu's tray exists because a
// menu edit sits thousands of pixels from its APPLY. A seven-row card cannot
// have that distance: PUBLISH lives in this card, 44px, always visible. So
// the week's edits live in this component's state and nowhere else - no
// second localStorage key, no "saved on this device only" (build/12 item 10).
//
// THE REGIME IS A CHIP, NOT A PARAGRAPH. build/11 found ~165 words of
// instruction prose across three panels; WAITING FOR PUBLISH says it in three.
//
// AMBER MEANS "NEEDS YOU" (contract rule 3, Wave S-A amendment 4): a day that
// is not set yet carries the amber border and keeps its surface. A saved,
// finished week is INK - success is not amber, so the PUBLISHED status line
// renders in ink and only the unfinished parts pull the eye.

/** A weekday as this card holds it. `open`/`close` stay as strings through
 *  'closed' and 'unset' so switching a day back and forth does not silently
 *  lose the times the owner already typed. */
export interface WeekRow {
  day: DayId
  state: DayState['state']
  open: string
  close: string
}

/** A day counts as SET when it is closed, or open with BOTH times - exactly
 *  what the HoursDay_shape_check allows into the table. */
function isSet(row: WeekRow): boolean {
  return row.state === 'closed' || (row.state === 'open' && row.open !== '' && row.close !== '')
}

function toDayState(row: WeekRow): DayState & { day: DayId } {
  if (row.state === 'unset') return { day: row.day, state: 'unset' }
  if (row.state === 'closed') return { day: row.day, state: 'closed' }
  return { day: row.day, state: 'open', open: row.open, close: row.close }
}

const CONTROL =
  'min-h-11 rounded border border-hairline bg-paper px-2 text-sm font-bold text-ink'

export function HoursWeek({ initial }: { initial: WeekRow[] }) {
  const [rows, setRows] = useState<WeekRow[]>(initial)
  const [message, setMessage] = useState<StationNote>(null)
  const [busy, setBusy] = useState(false)

  const setCount = rows.filter(isSet).length
  const complete = setCount === 7

  function patch(day: DayId, next: Partial<WeekRow>) {
    setRows((current) => current.map((row) => (row.day === day ? { ...row, ...next } : row)))
  }

  async function publish() {
    // The owner reads a sentence about HIS day, not a schema error. The
    // schema still runs underneath - same rules the route enforces
    // (section 5.1) - but this refusal names the day that is missing.
    const incomplete = rows.find((row) => row.state === 'open' && !isSet(row))
    if (incomplete) {
      setMessage({
        text: `${dayName(incomplete.day)} needs both times, or mark it closed.`,
        tone: 'amber',
      })
      return
    }

    const days = rows.map(toDayState)
    const parsed = weekSchema.safeParse({ days })
    if (!parsed.success) {
      setMessage({
        text: parsed.error.issues[0]?.message ?? 'That week did not make sense.',
        tone: 'amber',
      })
      return
    }

    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/hours', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ days }),
      })
      const data = (await res.json().catch(() => null)) as {
        ok?: boolean
        message?: string
        published?: boolean
        days?: { day: string; closed: boolean; open: string | null; close: string | null }[]
      } | null

      if (!res.ok || data?.ok !== true) {
        setMessage({
          text: data?.message ?? 'That did not stick. Refresh and retry.',
          tone: 'amber',
        })
        return
      }

      // The list comes back from the RESPONSE, never from a guess: the saved
      // rows are what the site is about to render.
      const saved = new Map((data.days ?? []).map((row) => [row.day, row]))
      setRows((current) =>
        current.map((row) => {
          const found = saved.get(row.day)
          if (!found) return { ...row, state: 'unset' }
          if (found.closed) return { ...row, state: 'closed' }
          return {
            day: row.day,
            state: 'open',
            open: found.open ?? row.open,
            close: found.close ?? row.close,
          }
        }),
      )
      setMessage(
        data.published === true
          ? { text: 'Week published - live on the site.', tone: 'ok' }
          : { text: 'Saved. The site still says call.', tone: 'ok' },
      )
    } catch {
      setMessage({ text: 'That did not stick. Refresh and retry.', tone: 'amber' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <section
      aria-label="The week"
      className="rounded-lg border border-hairline bg-surface p-4 lg:min-w-0"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <h2 className="font-display text-xl uppercase">The week</h2>
        <p className="font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
          Waiting for publish
        </p>
      </div>

      <ul className="mt-3 flex flex-col gap-2">
        {rows.map((row) => {
          const filled = isSet(row)
          return (
            <li
              key={row.day}
              className={`rounded border bg-surface p-3 ${filled ? 'border-hairline' : 'border-2 border-amber'}`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-mono text-xs font-bold uppercase tracking-widest">
                  {dayName(row.day)}
                </span>
                <select
                  value={row.state}
                  aria-label={`${dayName(row.day)}: open, closed or not set`}
                  disabled={busy}
                  onChange={(event) =>
                    patch(row.day, { state: event.target.value as WeekRow['state'] })
                  }
                  className={CONTROL}
                >
                  <option value="open">Open</option>
                  <option value="closed">Closed</option>
                  <option value="unset">Not set</option>
                </select>
              </div>

              {row.state === 'open' ? (
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  {/* flex-wrap + a real min width: at 320px the pair cannot
                      sit side by side without squeezing the AM/PM segment out
                      of the native picker, and a closing time missing its
                      meridiem is a guessed hour on the screen built to end
                      those. */}
                  <input
                    type="time"
                    value={row.open}
                    aria-label={`${dayName(row.day)} opens`}
                    disabled={busy}
                    onChange={(event) => patch(row.day, { open: event.target.value })}
                    className={`${CONTROL} min-w-[8.5rem] flex-1 font-mono tabular-nums`}
                  />
                  <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">
                    to
                  </span>
                  <input
                    type="time"
                    value={row.close}
                    aria-label={`${dayName(row.day)} closes`}
                    disabled={busy}
                    onChange={(event) => patch(row.day, { close: event.target.value })}
                    className={`${CONTROL} min-w-[8.5rem] flex-1 font-mono tabular-nums`}
                  />
                </div>
              ) : null}
            </li>
          )
        })}
      </ul>

      {/* The card states its own progress. "3 of 7" is amber because it needs
          the owner; a finished week settles to ink. */}
      <p
        className={`mt-3 text-sm font-bold ${complete ? 'text-ink-muted' : 'text-amber-ink'}`}
      >
        {complete ? (
          <>All seven days are set.</>
        ) : (
          <>
            <span className="font-mono tabular-nums">{setCount}</span> of{' '}
            <span className="font-mono tabular-nums">7</span> days set - the site still says call.
          </>
        )}
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-3">
        <button
          type="button"
          disabled={busy}
          onClick={publish}
          className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
        >
          Publish the week
        </button>
        {/* MOUNTED at all times: a live region that appears already holding
            its text is never announced (Wave S-A amendment 4). */}
        <p role="status" aria-live="polite" className={noteClass(message)}>
          {message?.text}
        </p>
      </div>
    </section>
  )
}
