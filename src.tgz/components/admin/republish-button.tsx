'use client'

import { useState } from 'react'
import { adminMutate } from '@/lib/admin/mutate'

// "Still true": re-stamps every live special to now, so the page's
// freshness line goes back to "From the kitchen, today." Staleness is
// shown, never hidden — this is the owner's answer to it.
export function RepublishButton() {
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function republish() {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/republish')
      if (!res.ok) throw new Error(String(res.status))
      setMessage('Live on the site')
    } catch {
      setMessage('That did not stick.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <span className="flex items-center gap-2">
      <button
        type="button"
        disabled={busy}
        onClick={republish}
        className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
      >
        Still true — republish
      </button>
      <span role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
        {message}
      </span>
    </span>
  )
}
