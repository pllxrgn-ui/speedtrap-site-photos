'use client'

import { useState } from 'react'
import { noteClass, type StationNote } from '@/components/admin/station-message'
import { adminMutate } from '@/lib/admin/mutate'

// "Still true": re-stamps every live special to now, so the page's
// freshness line goes back to "From the kitchen, today." Staleness is
// shown, never hidden — this is the owner's answer to it.
export function RepublishButton() {
  const [message, setMessage] = useState<StationNote>(null)
  const [busy, setBusy] = useState(false)

  async function republish() {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/republish')
      if (!res.ok) throw new Error(String(res.status))
      // D6 (build/11): success is ink; only the failure keeps the amber.
      setMessage({ text: 'Live on the site', tone: 'ok' })
    } catch {
      setMessage({ text: 'That did not stick.', tone: 'amber' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <span className="flex items-center gap-2">
      <button
        type="button"
        disabled={busy}
        onClick={republish}
        className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
      >
        Still true — republish
      </button>
      <span role="status" aria-live="polite" className={noteClass(message)}>
        {message?.text}
      </span>
    </span>
  )
}
