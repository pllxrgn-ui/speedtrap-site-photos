'use client'

import { useState } from 'react'

// One editable span: renders as the site does, edits on tap, commits on
// Enter or blur, Escape restores. Kept dumb — the parent owns saving.
// Extracted from menu-preview (addendum 6) so THE FAVORITES edits with
// the same fingers as THE MENU. Phone taps get 44px (max-lg).
export function InlineEdit({
  value,
  placeholder,
  ariaLabel,
  display,
  className,
  inputClassName,
  disabled,
  onCommit,
}: {
  value: string
  placeholder: string
  ariaLabel: string
  display: React.ReactNode
  className: string
  inputClassName: string
  disabled?: boolean
  onCommit: (next: string) => void
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value)

  if (!editing) {
    return (
      <button
        type="button"
        aria-label={`Edit ${ariaLabel}`}
        title={`Tap to edit ${ariaLabel}`}
        disabled={disabled}
        onClick={() => {
          setDraft(value)
          setEditing(true)
        }}
        className={`${className} rounded text-left decoration-dotted underline-offset-4 hover:underline disabled:opacity-60 max-lg:min-h-11`}
      >
        {display}
      </button>
    )
  }
  return (
    <input
      autoFocus
      aria-label={ariaLabel}
      value={draft}
      placeholder={placeholder}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={() => {
        setEditing(false)
        if (draft !== value) onCommit(draft)
      }}
      onKeyDown={(event) => {
        if (event.key === 'Enter') (event.target as HTMLInputElement).blur()
        if (event.key === 'Escape') {
          setDraft(value)
          setEditing(false)
        }
      }}
      className={inputClassName}
    />
  )
}
