'use client'

import { adminMutate } from '@/lib/admin/mutate'

export function LogoutButton() {
  async function signOut() {
    // adminMutate attaches the CSRF header — the one wrapper every admin
    // mutation must go through (build/08 §2 row 7).
    await adminMutate('/api/admin/logout').catch(() => null)
    // HARD navigation on purpose: the dead cookie must reach the server
    // layout's requireSession, not a client-router cache.
    // eslint-disable-next-line @next/next/no-location-assign-relative-destination
    window.location.assign('/admin/login')
  }

  return (
    <button
      type="button"
      onClick={signOut}
      className="min-h-11 self-start rounded border border-hairline px-4 text-sm font-bold uppercase tracking-tight"
    >
      Sign out
    </button>
  )
}
