'use client'

import * as Dialog from '@radix-ui/react-dialog'

// Built on the @radix-ui/react-dialog dependency the site already carries
// — no shadcn install, per the contract's consumption rules. Destructive
// actions only; everything else on this screen is one tap.
export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  body,
  confirmLabel,
  onConfirm,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  body: string
  confirmLabel: string
  onConfirm: () => void
}) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/60" />
        <Dialog.Content className="scene-station fixed left-1/2 top-1/2 z-50 w-[calc(100vw-2rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-lg border border-hairline p-6">
          <Dialog.Title className="font-display text-2xl uppercase">{title}</Dialog.Title>
          <Dialog.Description className="mt-3 text-sm leading-relaxed text-ink-muted">
            {body}
          </Dialog.Description>
          <div className="mt-6 flex justify-end gap-2">
            <Dialog.Close asChild>
              <button
                type="button"
                className="tap-feedback min-h-11 rounded border border-hairline px-4 text-sm font-bold uppercase tracking-tight"
              >
                Keep it
              </button>
            </Dialog.Close>
            <button
              type="button"
              onClick={onConfirm}
              className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper"
            >
              {confirmLabel}
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
