'use client'

import { useState } from 'react'
import type { BookingStatus } from '@prisma/client'
import { ConfirmDialog } from '@/components/admin/confirm-dialog'
import { StatusPill } from '@/components/admin/status-pill'
import { ALLOWED_TRANSITIONS } from '@/lib/booking-status'
import { TIME_WINDOW_LABELS, type TimeWindowValue } from '@/lib/booking'

// A TICKET, not a table row (build/08 §4: at 375px a grid is a lie).
// The phone is the largest interactive element on the card because the
// owner's job is to call back — every other layout buries the verb.
// Type re-weighting per the contract: Martian Mono carries the chrome
// (party, date, window, reference, age), Schibsted carries what a human
// wrote (name, note), Big Shoulders only the status word.

export interface TicketBooking {
  id: string
  reference: string
  name: string
  phone: string
  phoneDigits: string
  partySize: number
  date: string // YYYY-MM-DD
  timeWindow: TimeWindowValue
  note: string | null
  status: BookingStatus
  createdAt: string // ISO
}

// What the owner can tap from each state, in the order they reach for it.
const ACTION_LABELS: Partial<Record<BookingStatus, string>> = {
  confirmed: 'Confirm',
  declined: "Can't do it",
  completed: 'Done',
  no_show: 'No-show',
  cancelled: 'Cancel it',
}

function ageInWords(iso: string): string {
  const minutes = Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 60_000))
  if (minutes < 2) return 'just now'
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.round(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  return `${Math.round(hours / 24)}d ago`
}

export function BookingTicket({
  booking,
  onStatus,
  onDelete,
}: {
  booking: TicketBooking
  onStatus: (id: string, next: BookingStatus) => Promise<boolean>
  onDelete: (id: string) => Promise<boolean>
}) {
  const [busy, setBusy] = useState(false)
  const [failed, setFailed] = useState(false)
  const [confirmingDelete, setConfirmingDelete] = useState(false)

  const dateLabel = new Date(`${booking.date}T00:00:00`).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  })

  async function act(next: BookingStatus) {
    // Synchronous re-entry guard: a double-tap inside one frame must not
    // fire the same transition twice and then "fail" its own second try.
    if (busy) return
    setBusy(true)
    setFailed(false)
    const ok = await onStatus(booking.id, next)
    if (!ok) setFailed(true)
    setBusy(false)
  }

  const [primary, secondary, ...rest] = ALLOWED_TRANSITIONS[booking.status]

  return (
    <li className="rounded-lg border border-hairline bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-baseline gap-3">
          <span className="font-mono text-3xl font-bold tabular-nums">{booking.partySize}</span>
          <span className="rounded border border-hairline px-2 py-1 font-mono text-sm font-bold uppercase">
            {dateLabel} · {TIME_WINDOW_LABELS[booking.timeWindow]}
          </span>
        </div>
        <StatusPill status={booking.status} />
      </div>

      <p className="mt-3 text-lg font-bold">{booking.name}</p>

      {/* The verb. Full width, the tallest thing on the card. */}
      <a
        href={`tel:+1${booking.phoneDigits.slice(-10)}`}
        className="tap-feedback mt-2 flex min-h-14 items-center justify-center rounded border border-hairline bg-paper font-mono text-xl font-bold tracking-wide"
      >
        {booking.phone}
      </a>

      {booking.note ? (
        <p className="mt-3 border-l-2 border-hairline pl-3 text-sm leading-relaxed text-ink-muted">
          {booking.note}
        </p>
      ) : null}

      <p className="mt-3 font-mono text-xs uppercase tracking-widest text-ink-muted">
        {booking.reference} · {ageInWords(booking.createdAt)}
      </p>

      {failed ? (
        <p role="alert" className="mt-2 text-sm font-bold">
          That did not stick. It is back the way it was — try again.
        </p>
      ) : null}

      {primary ? (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={() => act(primary)}
            className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
          >
            {ACTION_LABELS[primary]}
          </button>
          {secondary ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => act(secondary)}
              className="tap-feedback min-h-11 rounded border border-hairline px-4 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
            >
              {ACTION_LABELS[secondary]}
            </button>
          ) : null}
          <details className="relative ml-auto">
            <summary className="tap-feedback flex min-h-11 cursor-pointer list-none items-center rounded border border-hairline px-3 text-sm font-bold">
              &#8943;
            </summary>
            <div className="absolute right-0 z-10 mt-1 flex w-44 flex-col rounded border border-hairline bg-surface p-1">
              {rest.map((extra) => (
                <button
                  key={extra}
                  type="button"
                  disabled={busy}
                  onClick={() => act(extra)}
                  className="min-h-11 rounded px-3 text-left text-sm font-bold uppercase tracking-tight hover:bg-paper"
                >
                  {ACTION_LABELS[extra]}
                </button>
              ))}
              <button
                type="button"
                disabled={busy}
                onClick={() => setConfirmingDelete(true)}
                className="min-h-11 rounded px-3 text-left text-sm font-bold uppercase tracking-tight hover:bg-paper"
              >
                Delete
              </button>
            </div>
          </details>
        </div>
      ) : (
        <div className="mt-3 flex justify-end">
          <button
            type="button"
            disabled={busy}
            onClick={() => setConfirmingDelete(true)}
            className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted disabled:opacity-60"
          >
            Delete
          </button>
        </div>
      )}

      <ConfirmDialog
        open={confirmingDelete}
        onOpenChange={setConfirmingDelete}
        title="Delete this request?"
        body={`${booking.name}, party of ${booking.partySize}, ${dateLabel}. This removes the name and number for good — only a dated deletion record survives. It cannot be undone.`}
        confirmLabel="Delete it"
        onConfirm={async () => {
          setConfirmingDelete(false)
          setBusy(true)
          const ok = await onDelete(booking.id)
          if (!ok) setFailed(true)
          setBusy(false)
        }}
      />
    </li>
  )
}
