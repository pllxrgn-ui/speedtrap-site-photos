'use client'

import { useEffect, useRef, useState } from 'react'
import {
  isNewArrival,
  notificationBody,
  titleWithBadge,
  type BookingPulse,
} from '@/lib/admin/booking-pulse'

// THE WATCHER (build/09 addendum 5): the admin left open on the bar's
// laptop checks the book once a minute and CLINGS — a two-note chime +
// a desktop notification + a count in the tab title — when a new table
// request lands. Honest limits, stated in the chrome: it works while
// this page is open in a running browser and the sound is ON; a closed
// laptop stays silent (the pocket ping is still client question #B1).
// Alerts are OFF until the owner turns them on: both the chime and the
// notification permission NEED that tap (browser autoplay rules), and
// an alert nobody chose is noise.

const POLL_MS = 60_000
const ALERTS_KEY = 'stt-alerts-v1'

// Two rising sine blips, built in code — no audio asset to load or lose.
function cling(context: AudioContext) {
  const note = (freq: number, at: number, length: number) => {
    const osc = context.createOscillator()
    const gain = context.createGain()
    osc.type = 'sine'
    osc.frequency.value = freq
    gain.gain.setValueAtTime(0.0001, context.currentTime + at)
    gain.gain.exponentialRampToValueAtTime(0.28, context.currentTime + at + 0.02)
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + at + length)
    osc.connect(gain)
    gain.connect(context.destination)
    osc.start(context.currentTime + at)
    osc.stop(context.currentTime + at + length + 0.05)
  }
  note(880, 0, 0.18)
  note(1320, 0.14, 0.24)
}

export function BookingWatcher() {
  const [alertsOn, setAlertsOn] = useState(false)
  const [newCount, setNewCount] = useState(0)
  const lastPulse = useRef<BookingPulse | null>(null)
  const audio = useRef<AudioContext | null>(null)
  const stopped = useRef(false)

  // The saved preference only says the owner WANTS alerts; the chime
  // still needs one tap per browser session to unlock audio, so the
  // toggle renders armed-but-quiet until they click it again.
  useEffect(() => {
    // Deferred a tick (compiler rule: no sync setState in an effect).
    const timer = window.setTimeout(() => {
      try {
        setAlertsOn(window.localStorage.getItem(ALERTS_KEY) === 'on')
      } catch {
        /* storage unavailable — toggle starts off */
      }
    }, 0)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    const look = async () => {
      if (stopped.current) return
      try {
        const res = await fetch('/api/admin/bookings/pulse', { cache: 'no-store' })
        if (res.status === 401) {
          // Session over — stop watching rather than knocking forever.
          stopped.current = true
          return
        }
        const data = (await res.json().catch(() => null)) as
          | { ok?: boolean; newCount?: number; latestAt?: string | null }
          | null
        if (data?.ok !== true || typeof data.newCount !== 'number') return
        const pulse: BookingPulse = { newCount: data.newCount, latestAt: data.latestAt ?? null }
        setNewCount(pulse.newCount)
        document.title = titleWithBadge(document.title, pulse.newCount)
        if (isNewArrival(lastPulse.current, pulse)) {
          if (audio.current) cling(audio.current)
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification('New table request', {
              body: notificationBody(pulse.newCount),
              tag: 'stt-booking', // repeats replace, never stack
            })
          }
        }
        lastPulse.current = pulse
      } catch {
        /* one missed look is fine — the next minute looks again */
      }
    }
    look()
    const timer = window.setInterval(look, POLL_MS)
    return () => window.clearInterval(timer)
  }, [])

  function toggleAlerts() {
    if (alertsOn) {
      setAlertsOn(false)
      try {
        window.localStorage.setItem(ALERTS_KEY, 'off')
      } catch {
        /* preference just won't stick */
      }
      return
    }
    // This click is the user gesture the browser requires: unlock audio,
    // ask for notification permission, and prove the chime works ONCE so
    // the owner knows what to listen for.
    try {
      audio.current = audio.current ?? new AudioContext()
      void audio.current.resume()
      cling(audio.current)
    } catch {
      /* no audio on this device — notifications may still work */
    }
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      void Notification.requestPermission()
    }
    setAlertsOn(true)
    try {
      window.localStorage.setItem(ALERTS_KEY, 'on')
    } catch {
      /* preference just won't stick */
    }
  }

  return (
    <span className="flex items-center gap-2">
      {newCount > 0 ? (
        <a
          href="/admin"
          className="tap-feedback inline-flex min-h-11 items-center gap-1.5 rounded-full border border-amber px-3 font-mono text-xs font-bold uppercase tracking-wide text-amber-ink"
        >
          <span aria-hidden className="size-1.5 rounded-full bg-amber" />
          {newCount} waiting
        </a>
      ) : null}
      <button
        type="button"
        aria-pressed={alertsOn}
        title={
          alertsOn
            ? 'Chime + desktop alert when a request lands (while this page is open)'
            : 'Turn on a chime + desktop alert for new requests'
        }
        onClick={toggleAlerts}
        className={`tap-feedback inline-flex min-h-11 items-center rounded-full border px-3 font-mono text-xs font-bold uppercase tracking-wide ${
          alertsOn ? 'border-ink bg-ink text-paper' : 'border-hairline bg-surface text-ink-muted'
        }`}
      >
        {alertsOn ? 'Alerts on' : 'Alerts off'}
      </button>
    </span>
  )
}
