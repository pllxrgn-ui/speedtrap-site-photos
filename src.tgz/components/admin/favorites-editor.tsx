'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { InlineEdit } from '@/components/admin/inline-edit'
import { noteClass, type StationNote } from '@/components/admin/station-message'
import { adminMutate } from '@/lib/admin/mutate'

// THE FAVORITES (build/09 addendum 6): the four cards under the menu head,
// rendered here EXACTLY as the site frames them — slot 1 the amber poster,
// three paper cards — with the controls on the material itself, same
// device as THE MENU PREVIEW. Favorites are the storefront, not the menu:
// a pick goes live the moment it changes (no tray), and every change
// writes its ledger row, so THE LOG carries it.

export interface SpotState {
  slot: number
  dishId: string | null
  blurb: string | null
}

export interface PickerDish {
  id: string
  name: string
  boardTitle: string
  price: string // display form, "" for none
  description: string | null
  /** The dish's DishPhoto - the SAME row the menu editor's photo slot
   *  manages: one dish, one picture, everywhere. */
  photo: { src: string; alt: string } | null
}

export function FavoritesEditor({ spots, dishes }: { spots: SpotState[]; dishes: PickerDish[] }) {
  const [state, setState] = useState<SpotState[]>(
    [1, 2, 3, 4].map(
      (slot) => spots.find((spot) => spot.slot === slot) ?? { slot, dishId: null, blurb: null },
    ),
  )
  const [message, setMessage] = useState<StationNote>(null)
  const [busy, setBusy] = useState(false)
  // Photo overrides layered over the prop (uploads/clears since page load).
  const [photoState, setPhotoState] = useState<Record<string, { src: string; alt: string } | null>>({})

  const dishById = new Map(dishes.map((dish) => [dish.id, dish]))
  const photoOf = (dishId: string) =>
    photoState[dishId] === undefined ? (dishById.get(dishId)?.photo ?? null) : photoState[dishId]

  // Pictures are LINKED, not managed here (client, 2026-09-23): a
  // favorite is a menu dish, so its picture is set in THE MENU editor
  // below. This listener keeps the preview honest the moment the menu
  // editor changes a photo on the same screen.
  useEffect(() => {
    const onPhoto = (event: Event) => {
      const { dishId, photo } = (event as CustomEvent<{ dishId: string; photo: { src: string; alt: string } | null }>).detail
      setPhotoState((current) => ({ ...current, [dishId]: photo }))
    }
    window.addEventListener('stt-dish-photo', onPhoto)
    return () => window.removeEventListener('stt-dish-photo', onPhoto)
  }, [])

  const boards = [...new Set(dishes.map((dish) => dish.boardTitle))]

  async function save(slot: number, body: { dishId?: string | null; blurb?: string }) {
    const before = state
    setState((current) =>
      current.map((spot) =>
        spot.slot === slot
          ? {
              ...spot,
              ...(body.dishId !== undefined ? { dishId: body.dishId } : {}),
              ...(body.blurb !== undefined ? { blurb: body.blurb.trim() || null } : {}),
            }
          : spot,
      ),
    )
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/features/${slot}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; spot?: { dishId: string | null; blurb: string | null } }
        | null
      if (!res.ok || data?.ok !== true || !data.spot) {
        setState(before)
        setMessage({ text: data?.message ?? 'That did not stick. Refresh and retry.', tone: 'amber' })
        return
      }
      const applied = data.spot
      setState((current) =>
        current.map((spot) =>
          spot.slot === slot ? { ...spot, dishId: applied.dishId, blurb: applied.blurb } : spot,
        ),
      )
      // D6 (build/11): the pick went live — that is not a "needs you".
      setMessage({ text: 'Live on the site', tone: 'ok' })
    } catch {
      setState(before)
      setMessage({ text: 'That did not stick. Refresh and retry.', tone: 'amber' })
    } finally {
      setBusy(false)
    }
  }

  function card(spot: SpotState) {
    const dish = spot.dishId ? dishById.get(spot.dishId) : undefined
    const blurb = spot.blurb ?? dish?.description ?? null
    const poster = spot.slot === 1

    // The card, EXACTLY as the site frames it (dishes.tsx anatomy, photo
    // included) - the same mirror promise the menu preview makes. A dark
    // spot renders as the dashed absence it is; the site drops the card.
    return (
      <div key={spot.slot} className="flex min-w-0 flex-col gap-2">
        {dish ? (
          poster ? (
            <div className="relative flex min-h-[16rem] flex-1 flex-col overflow-hidden rounded bg-amber p-6 text-on-amber md:min-h-[22rem] md:p-8">
              <Image
                src={photoOf(dish.id)?.src ?? '/photos/cheeseburgers-pass.webp'}
                alt=""
                aria-hidden
                fill
                loading="lazy"
                sizes="(min-width: 768px) 680px, 100vw"
                className="object-cover object-right opacity-30 grayscale mix-blend-multiply"
              />
              <span className="relative flex h-full flex-col">
                <span className="block font-display text-h2 uppercase leading-none">{dish.name}</span>
                <InlineEdit
                  value={spot.blurb ?? ''}
                  placeholder="Line under the name (empty = the menu line)"
                  ariaLabel={`line on favorite spot ${spot.slot}`}
                  disabled={busy}
                  display={
                    blurb ? (
                      <span className="block max-w-[24ch] text-h2 font-extrabold leading-[1.15] tracking-[-0.02em]">
                        {blurb}
                        {!spot.blurb ? (
                          <span className="block font-mono text-xs font-normal uppercase tracking-wide opacity-70">menu line</span>
                        ) : null}
                      </span>
                    ) : (
                      <span className="block text-sm italic opacity-70">add a line…</span>
                    )
                  }
                  className="relative mt-3 block text-left"
                  inputClassName="mt-3 block w-full min-h-10 rounded border border-hairline bg-paper px-2 text-ink"
                  onCommit={(next) => save(spot.slot, { blurb: next })}
                />
                {dish.price !== '' ? (
                  <span className="mt-auto block pt-6 font-mono text-2xl font-bold tabular-nums">${dish.price}</span>
                ) : null}
              </span>
            </div>
          ) : (
            <div className="halftone relative flex min-h-[10rem] flex-1 flex-col overflow-hidden rounded border border-hairline bg-paper p-6 md:p-8">
              {/* Site parity: the dish photo fades in from the RIGHT; no
                  photo = the laurel logo default, exactly as the page. */}
              <span
                aria-hidden
                className="absolute inset-y-0 right-0 w-2/5 [mask-image:linear-gradient(to_left,black_45%,transparent)]"
              >
                <Image
                  src={photoOf(dish.id)?.src ?? '/photos/logo-laurel.webp'}
                  alt=""
                  fill
                  sizes="260px"
                  className={photoOf(dish.id) ? 'object-cover' : 'object-contain object-right p-5 opacity-20'}
                />
              </span>
              <span className="relative block font-display text-h3 uppercase leading-tight text-ink">{dish.name}</span>
              <InlineEdit
                value={spot.blurb ?? ''}
                placeholder="Line under the name (empty = the menu line)"
                ariaLabel={`line on favorite spot ${spot.slot}`}
                disabled={busy}
                display={
                  blurb ? (
                    <span className="mt-2 block text-ink-muted">
                      {blurb}
                      {!spot.blurb ? <span className="font-mono text-xs uppercase tracking-wide opacity-70"> · menu line</span> : null}
                    </span>
                  ) : (
                    <span className="mt-2 block text-sm italic text-ink-muted">add a line…</span>
                  )
                }
                className="block text-left"
                inputClassName="mt-2 block w-full min-h-9 rounded border border-hairline bg-paper px-2 text-sm text-ink"
                onCommit={(next) => save(spot.slot, { blurb: next })}
              />
              <span className="relative mt-auto flex items-baseline justify-between gap-4 pt-4">
                <span className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">{dish.boardTitle}</span>
                {dish.price !== '' ? (
                  <span className="rounded bg-paper/85 px-1.5 py-0.5 font-mono text-lg font-bold tabular-nums">${dish.price}</span>
                ) : null}
              </span>
            </div>
          )
        ) : (
          <div className={`flex flex-1 items-center justify-center rounded border border-dashed border-hairline p-4 text-sm italic text-ink-muted ${poster ? 'min-h-[16rem] md:min-h-[22rem]' : 'min-h-[10rem]'}`}>
            Dark spot — the site shows no card here.
          </div>
        )}

        <label className="flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-wide text-ink-muted">
          Spot {spot.slot}
          {spot.slot === 1 ? ' · poster' : ''}
          <select
            aria-label={`Dish on favorite spot ${spot.slot}`}
            value={spot.dishId ?? ''}
            disabled={busy}
            onChange={(event) => save(spot.slot, { dishId: event.target.value || null })}
            className="min-h-11 min-w-0 flex-1 rounded border border-hairline bg-paper px-2 font-sans text-sm font-bold normal-case text-ink"
          >
            <option value="">— empty —</option>
            {boards.map((board) => (
              <optgroup key={board} label={board}>
                {dishes
                  .filter((dish) => dish.boardTitle === board)
                  .map((dish) => (
                    <option key={dish.id} value={dish.id}>
                      {dish.name}
                    </option>
                  ))}
              </optgroup>
            ))}
          </select>
        </label>
      </div>
    )
  }

  return (
    <section aria-label="House favorites" className="flex flex-col gap-3">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">House favorites</h2>
        <p role="status" aria-live="polite" className={noteClass(message)}>
          {message?.text}
        </p>
      </div>
      <p className="max-w-[70ch] text-sm text-ink-muted">
        The four cards at the top of the site&apos;s menu — spot 1 is the big
        poster. These change the moment you pick: no tray here. Tap the line
        under a name to write your own; empty falls back to the dish&apos;s
        menu line. Pictures ride along from the menu: set a dish&apos;s
        photo in THE MENU below and it shows here and on the card; no
        photo means the default. Every change is logged.
      </p>
      {/* The site's own composition (dishes.tsx): poster left, three
          paper cards stacked right - ON THE SITE'S OWN PAPER, the same
          scene-paper device as the menu preview, so amber stays bright
          and ink stays ink instead of the station's dark tokens. */}
      <div className="scene-paper rounded-lg border border-hairline p-4 md:p-5">
        <div className="grid gap-4 md:grid-cols-2 lg:gap-6">
          {card(state[0])}
          <div className="grid auto-rows-fr gap-4 lg:gap-6">{state.slice(1).map(card)}</div>
        </div>
      </div>
    </section>
  )
}
