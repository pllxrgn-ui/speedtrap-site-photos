'use client'

import { useState } from 'react'
import { InlineEdit } from '@/components/admin/inline-edit'
import { adminMutate } from '@/lib/admin/mutate'

// THE FAVORITES (build/09 addendum 6): the four cards under the menu head,
// rendered here EXACTLY as the site frames them — slot 1 the amber poster,
// three paper cards — with the controls on the material itself, same
// device as THE MENU PREVIEW. Favorites are the storefront, not the menu:
// a pick goes live the moment it changes (no tray), and every change
// writes its ledger row, so THE LOG carries it.

export interface SpotState {
  slot: number
  dishId: string | null
  blurb: string | null
}

export interface PickerDish {
  id: string
  name: string
  boardTitle: string
  price: string // display form, "" for none
  description: string | null
}

export function FavoritesEditor({ spots, dishes }: { spots: SpotState[]; dishes: PickerDish[] }) {
  const [state, setState] = useState<SpotState[]>(
    [1, 2, 3, 4].map(
      (slot) => spots.find((spot) => spot.slot === slot) ?? { slot, dishId: null, blurb: null },
    ),
  )
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const dishById = new Map(dishes.map((dish) => [dish.id, dish]))
  const boards = [...new Set(dishes.map((dish) => dish.boardTitle))]

  async function save(slot: number, body: { dishId?: string | null; blurb?: string }) {
    const before = state
    setState((current) =>
      current.map((spot) =>
        spot.slot === slot
          ? {
              ...spot,
              ...(body.dishId !== undefined ? { dishId: body.dishId } : {}),
              ...(body.blurb !== undefined ? { blurb: body.blurb.trim() || null } : {}),
            }
          : spot,
      ),
    )
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/features/${slot}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; spot?: { dishId: string | null; blurb: string | null } }
        | null
      if (!res.ok || data?.ok !== true || !data.spot) {
        setState(before)
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      const applied = data.spot
      setState((current) =>
        current.map((spot) =>
          spot.slot === slot ? { ...spot, dishId: applied.dishId, blurb: applied.blurb } : spot,
        ),
      )
      setMessage('Live on the site')
    } catch {
      setState(before)
      setMessage('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  function card(spot: SpotState) {
    const dish = spot.dishId ? dishById.get(spot.dishId) : undefined
    const blurb = spot.blurb ?? dish?.description ?? null
    const poster = spot.slot === 1

    return (
      <div key={spot.slot} className="flex flex-col gap-2">
        {/* The card, as the site frames it (mini). A dark spot renders as
            the dashed absence it is — the site simply drops the card. */}
        {dish ? (
          <div
            className={
              poster
                ? 'relative flex min-h-28 flex-col overflow-hidden rounded bg-amber p-4 text-on-amber'
                : 'halftone flex min-h-24 flex-col justify-end rounded border border-hairline bg-paper p-4'
            }
          >
            <span className={`block font-display uppercase leading-tight ${poster ? 'text-h3' : 'text-lg'}`}>
              {dish.name}
            </span>
            <InlineEdit
              value={spot.blurb ?? ''}
              placeholder="Line under the name (empty = the menu line)"
              ariaLabel={`line on favorite spot ${spot.slot}`}
              disabled={busy}
              display={
                blurb ? (
                  <span className={poster ? 'mt-1 block max-w-[28ch] font-extrabold leading-snug' : 'mt-1 block text-sm text-ink-muted'}>
                    {blurb}
                    {!spot.blurb ? <span className="opacity-60"> · menu line</span> : null}
                  </span>
                ) : (
                  <span className="mt-1 block text-sm italic opacity-70">add a line…</span>
                )
              }
              className="block text-left"
              inputClassName="mt-1 block w-full min-h-9 rounded border border-hairline bg-paper px-2 text-sm text-ink"
              onCommit={(next) => save(spot.slot, { blurb: next })}
            />
            <span className="mt-2 flex items-baseline justify-between gap-3">
              {!poster ? (
                <span className="font-mono text-[0.6875rem] font-bold uppercase tracking-wide text-ink-muted">
                  {dish.boardTitle}
                </span>
              ) : null}
              {dish.price !== '' ? (
                <span className="ml-auto font-mono font-bold tabular-nums">${dish.price}</span>
              ) : null}
            </span>
          </div>
        ) : (
          <div className="flex min-h-24 items-center justify-center rounded border border-dashed border-hairline p-4 text-sm italic text-ink-muted">
            Dark spot — the site shows no card here.
          </div>
        )}

        <label className="flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-wide text-ink-muted">
          Spot {spot.slot}
          {spot.slot === 1 ? ' · poster' : ''}
          <select
            aria-label={`Dish on favorite spot ${spot.slot}`}
            value={spot.dishId ?? ''}
            disabled={busy}
            onChange={(event) => save(spot.slot, { dishId: event.target.value || null })}
            className="min-h-11 min-w-0 flex-1 rounded border border-hairline bg-paper px-2 font-sans text-sm font-bold normal-case text-ink"
          >
            <option value="">— empty —</option>
            {boards.map((board) => (
              <optgroup key={board} label={board}>
                {dishes
                  .filter((dish) => dish.boardTitle === board)
                  .map((dish) => (
                    <option key={dish.id} value={dish.id}>
                      {dish.name}
                    </option>
                  ))}
              </optgroup>
            ))}
          </select>
        </label>
      </div>
    )
  }

  return (
    <section aria-label="House favorites" className="flex flex-col gap-3">
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">House favorites</h2>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>
      <p className="max-w-[70ch] text-sm text-ink-muted">
        The four cards at the top of the site&apos;s menu — spot 1 is the big
        poster. These change the moment you pick: no tray here. Tap the line
        under a name to write your own; empty falls back to the dish&apos;s
        menu line. Every change is logged.
      </p>
      {state.map(card)}
    </section>
  )
}
