// THE HOURS, found from THE BOARD (build/13 section 4.1).
//
// A LINK ON THE PAPER, NOT A CHIP IN THE HEADER. All three other homes were
// already fenced: a fourth thumb-bar tab is on build/11's killed list, an
// eighth header chip spends the width D3's wrap fix just bought, and a BOARD
// panel collides with Wave S-C, which owns that file.
//
// IT SITS AT THE TOP OF THE RAIL, not the foot (review finding 7). The rail
// measured 1,285px in a 950px window and scrolls inside its own max-h, so a
// foot link would sit below the fold behind three specials editors; on a
// phone it would land thousands of pixels down the stack. Amber on a control
// nobody scrolls to is amber nobody sees.
//
// A component rather than an inline block because of the amber computation:
// amber while ANY day is unset, or while a past dated row is still listed -
// rule 3 exactly ("needs you"), and it self-clears the moment the owner
// finishes.
export function HoursRailLink({
  unsetDays,
  pastRows,
}: {
  unsetDays: number
  pastRows: number
}) {
  const needsYou = unsetDays > 0 || pastRows > 0
  const trailing =
    unsetDays > 0
      ? 'not set yet'
      : pastRows > 0
        ? 'a past date is still listed'
        : 'on the site'

  return (
    <a
      href="/admin/hours"
      className={`tap-feedback flex min-h-14 flex-wrap items-center justify-between gap-x-3 gap-y-1 rounded-lg bg-surface px-4 py-3 ${
        needsYou ? 'border-2 border-amber' : 'border border-hairline'
      }`}
    >
      <span className="font-display text-xl uppercase">The hours</span>
      <span
        className={`font-mono text-xs font-bold uppercase tracking-widest ${
          needsYou ? 'text-amber-ink' : 'text-ink-muted'
        }`}
      >
        {trailing} &rarr;
      </span>
    </a>
  )
}
