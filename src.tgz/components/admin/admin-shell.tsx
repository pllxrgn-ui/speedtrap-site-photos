import { BookingWatcher } from '@/components/admin/booking-watcher'
import { LogoutButton } from '@/components/admin/logout-button'
import { StationClock } from '@/components/admin/station-clock'

// The station's rail (contract §Back of House): density inverts here —
// 8px rhythm, no hero spacing, Big Shoulders only for the screen title,
// Martian Mono for chrome. No sidebar, no dashboard (veto 12). Three
// screens now exist (THE LOG joined 2026-09-23, addendum 4), so
// navigation is a top tab rail ≥lg and a fixed 56px thumb bar below it
// (§4 IA).
const SCREENS = [
  { key: 'book', href: '/admin', label: 'The book' },
  { key: 'board', href: '/admin/board', label: 'The board' },
  { key: 'log', href: '/admin/log', label: 'The log' },
] as const

export type AdminScreen = (typeof SCREENS)[number]['key']

function Tabs({ active, thumb = false }: { active: AdminScreen | 'none'; thumb?: boolean }) {
  return (
    <nav
      aria-label="Back of house"
      className={
        thumb
          ? 'scene-station fixed inset-x-0 bottom-0 z-30 grid grid-cols-3 border-t border-hairline lg:hidden'
          : 'hidden gap-2 lg:flex'
      }
    >
      {SCREENS.map((screen) => (
        <a
          key={screen.key}
          href={screen.href}
          aria-current={active === screen.key ? 'page' : undefined}
          className={
            thumb
              ? `flex min-h-14 items-center justify-center text-sm font-bold uppercase tracking-tight ${
                  active === screen.key ? 'bg-ink text-paper' : 'text-ink'
                }`
              : `tap-feedback inline-flex min-h-11 items-center rounded-full border px-4 text-sm font-bold uppercase tracking-tight ${
                  active === screen.key
                    ? 'border-ink bg-ink text-paper'
                    : 'border-hairline bg-surface text-ink'
                }`
          }
        >
          {screen.label}
        </a>
      ))}
    </nav>
  )
}

export function AdminShell({
  title,
  active,
  children,
}: {
  title: string
  /** 'none' for pages that live off the tab rail (THE KEY). */
  active: AdminScreen | 'none'
  children: React.ReactNode
}) {
  // The WHOLE station runs wide (client override 2026-09-23 — the old
  // narrow queue floated like a phone in a desktop void). Screens keep
  // their reading measure with their own grids, not with the shell.
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-screen-2xl flex-col px-4 pb-20 lg:px-6 lg:pb-16">
      {/* D3 (build/11): seven items in a non-wrapping row measured 402-416px
          of scroll width from a 390px viewport — SIGN OUT clipped mid-button
          and the overflow strip rendered paper-WHITE. The row WRAPS below lg
          now, both halves carry min-w-0 so a long screen title cannot push
          the utilities off-screen, and THE CLOCK is desktop-only (the phone's
          own status bar already shows the time). */}
      <header className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3 border-b border-hairline py-4">
        <div className="min-w-0">
          <p className="whitespace-nowrap font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
            Back of house
          </p>
          <h1 className="mt-1 font-display text-3xl uppercase leading-none">{title}</h1>
        </div>
        <div className="flex min-w-0 flex-wrap items-center gap-3">
          {/* The clock hides ITSELF below lg (station-clock.tsx) — a wrapper
              here would keep an empty gap-3 slot in the row. */}
          <StationClock />
          <Tabs active={active} />
          <BookingWatcher />
          <a
            href="/admin/passphrase"
            aria-current={active === 'none' ? 'page' : undefined}
            className="tap-feedback inline-flex min-h-11 items-center rounded-full border border-hairline bg-surface px-4 font-mono text-xs font-bold uppercase tracking-wide text-ink-muted"
          >
            Key
          </a>
          <LogoutButton />
        </div>
      </header>
      <div className="flex-1 py-4">{children}</div>
      <Tabs active={active} thumb />
    </div>
  )
}
