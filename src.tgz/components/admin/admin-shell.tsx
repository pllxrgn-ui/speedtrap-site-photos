import { LogoutButton } from '@/components/admin/logout-button'

// The station's rail (contract §Back of House): density inverts here —
// 8px rhythm, no hero spacing, Big Shoulders only for the screen title,
// Martian Mono for chrome. No sidebar, no dashboard (veto 12); the bottom
// segmented bar arrives when a second screen exists (Phase 5's BOARD).
export function AdminShell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-4 pb-16">
      <header className="flex items-center justify-between gap-4 border-b border-hairline py-4">
        <div>
          <p className="font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
            Back of house
          </p>
          <h1 className="mt-1 font-display text-3xl uppercase leading-none">{title}</h1>
        </div>
        <LogoutButton />
      </header>
      <div className="flex-1 py-4">{children}</div>
    </div>
  )
}
