import { BookingWatcher } from '@/components/admin/booking-watcher'
import { LogoutButton } from '@/components/admin/logout-button'

// The station's rail (contract §Back of House): density inverts here —
// 8px rhythm, no hero spacing, Big Shoulders only for the screen title,
// Martian Mono for chrome. No sidebar, no dashboard (veto 12). Three
// screens now exist (THE LOG joined 2026-09-23, addendum 4), so
// navigation is a top tab rail ≥lg and a fixed 56px thumb bar below it
// (§4 IA).
const SCREENS = [
  { key: 'book', href: '/admin', label: 'The book' },
  { key: 'board', href: '/admin/board', label: 'The board' },
  { key: 'log', href: '/admin/log', label: 'The log' },
] as const

export type AdminScreen = (typeof SCREENS)[number]['key']

function Tabs({ active, thumb = false }: { active: AdminScreen; thumb?: boolean }) {
  return (
    <nav
      aria-label="Back of house"
      className={
        thumb
          ? 'scene-station fixed inset-x-0 bottom-0 z-30 grid grid-cols-3 border-t border-hairline lg:hidden'
          : 'hidden gap-2 lg:flex'
      }
    >
      {SCREENS.map((screen) => (
        <a
          key={screen.key}
          href={screen.href}
          aria-current={active === screen.key ? 'page' : undefined}
          className={
            thumb
              ? `flex min-h-14 items-center justify-center text-sm font-bold uppercase tracking-tight ${
                  active === screen.key ? 'bg-ink text-paper' : 'text-ink'
                }`
              : `tap-feedback inline-flex min-h-11 items-center rounded-full border px-4 text-sm font-bold uppercase tracking-tight ${
                  active === screen.key
                    ? 'border-ink bg-ink text-paper'
                    : 'border-hairline bg-surface text-ink'
                }`
          }
        >
          {screen.label}
        </a>
      ))}
    </nav>
  )
}

export function AdminShell({
  title,
  active,
  wide = false,
  children,
}: {
  title: string
  active: AdminScreen
  /** THE BOARD runs wide (contract amendment 2026-09-22); the queue stays
   *  a narrow rail on purpose - tickets read best one under the other. */
  wide?: boolean
  children: React.ReactNode
}) {
  return (
    <div
      className={`mx-auto flex min-h-screen w-full flex-col px-4 pb-20 lg:px-6 lg:pb-16 ${
        wide ? 'max-w-screen-2xl' : 'max-w-3xl'
      }`}
    >
      <header className="flex items-center justify-between gap-4 border-b border-hairline py-4">
        <div>
          <p className="font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
            Back of house
          </p>
          <h1 className="mt-1 font-display text-3xl uppercase leading-none">{title}</h1>
        </div>
        <div className="flex items-center gap-3">
          <Tabs active={active} />
          <BookingWatcher />
          <LogoutButton />
        </div>
      </header>
      <div className="flex-1 py-4">{children}</div>
      <Tabs active={active} thumb />
    </div>
  )
}
