'use client'

import { useRef, useState } from 'react'
import Image from 'next/image'
import { noteClass, type StationNote } from '@/components/admin/station-message'
import { adminMutate } from '@/lib/admin/mutate'
import { barToday, BAR_TIME_ZONE } from '@/lib/provenance'

// One of the three slots (the DB CHECK is the real cap). Publishing shows
// the owner the provenance line the page will print — the honesty
// machinery made visible — the toast says "Live on the site", never
// "Saved", and staleness is shown via the published-at stamp + a manual
// republish (build/08 §4).
export interface SlotState {
  slot: number
  title: string
  body: string
  priceLabel: string
  published: boolean
  publishedAt: string | null
  photo: { src: string; alt: string } | null
}

export function SpecialEditor({ initial }: { initial: SlotState }) {
  const [state, setState] = useState(initial)
  const [message, setMessage] = useState<StationNote>(null)
  const [busy, setBusy] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)

  // D6 (build/11): a status carries a tone. It worked → ink; it needs you
  // (a failure, a file too big) → amber.
  const say = (text: string) => setMessage({ text, tone: 'ok' })
  const warn = (text: string) => setMessage({ text, tone: 'amber' })

  const empty = !state.title && !state.published && !state.photo

  async function put(published: boolean) {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/specials/${state.slot}`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          title: state.title,
          body: state.body,
          priceLabel: state.priceLabel,
          published,
        }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; special?: { publishedAt: string | null } }
        | null
      if (!res.ok || data?.ok !== true) {
        warn(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      setState((current) => ({
        ...current,
        published,
        publishedAt: data.special?.publishedAt ?? current.publishedAt,
      }))
      say(published ? 'Live on the site' : 'Taken down')
    } catch {
      warn('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  async function clearSlot() {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/specials/${state.slot}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      // The photo survives a clear ON PURPOSE (addendum 2) — it goes via
      // its own Remove photo button.
      setState({
        slot: state.slot,
        title: '',
        body: '',
        priceLabel: '',
        published: false,
        publishedAt: null,
        photo: state.photo,
      })
      say(state.photo ? 'Slot cleared - the photo stays until you remove it' : 'Slot cleared')
    } catch {
      warn('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  async function onFileChosen(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return
    if (file.size > 4 * 1024 * 1024) {
      warn('That photo is over 4MB. Send a smaller one.')
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      const form = new FormData()
      form.set('slot', String(state.slot))
      form.set('file', file)
      const res = await adminMutate('/api/admin/special-photo', { body: form })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; photo?: { src: string; alt: string } }
        | null
      if (!res.ok || data?.ok !== true || !data.photo) {
        warn(data?.message ?? 'That upload did not stick. Try it again.')
        return
      }
      setState((current) => ({ ...current, photo: data.photo ?? null }))
      say(state.published ? 'Photo is live on the site' : 'Photo saved - it shows when this special is published')
    } catch {
      warn('That upload did not stick. Try it again.')
    } finally {
      setBusy(false)
    }
  }

  async function removePhoto() {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/special-photo', {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ slot: state.slot }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setState((current) => ({ ...current, photo: null }))
      say('Photo removed')
    } catch {
      warn('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  const field = 'mt-1 block w-full rounded border border-hairline bg-paper px-3 py-2'

  // The LIVE stamp AGES (review finding 7). Published today it is a settled
  // state: ink-muted, time only. Still up tomorrow it becomes a thing that
  // needs the owner — amber, and it names the day, because "published 4:15 PM"
  // on a three-day-old special reads as quietly current. Same bar-clock
  // compare specialProvenance() makes for the public stamp.
  // (A deliberate clock read at render: "is this still today" can only be
  // judged against now. It re-reads on every render and both sides convert
  // through the BAR's timezone, so server and client agree.)
  const publishedAt = state.publishedAt ? new Date(state.publishedAt) : null
  const staleStamp = publishedAt !== null && barToday(publishedAt) !== barToday()

  return (
    <div
      className={`rounded-lg border p-4 ${
        empty ? 'border-dashed border-hairline' : 'border-hairline bg-surface'
      }`}
    >
      <div className="flex items-baseline justify-between gap-3">
        <p className="font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
          Slot {state.slot}
        </p>
        {/* D6 (build/11): published TODAY is a settled state, not a signal —
            ink-muted. A stale one is a genuine "needs you" and keeps amber. */}
        {state.published && publishedAt ? (
          <p
            className={`font-mono text-xs uppercase tracking-widest ${
              staleStamp ? 'text-amber-ink' : 'text-ink-muted'
            }`}
          >
            live · published{' '}
            {staleStamp
              ? `${publishedAt.toLocaleDateString('en-US', {
                  weekday: 'short',
                  timeZone: BAR_TIME_ZONE,
                })} `
              : ''}
            {publishedAt.toLocaleTimeString('en-US', {
              hour: 'numeric',
              minute: '2-digit',
              timeZone: BAR_TIME_ZONE,
            })}
          </p>
        ) : null}
      </div>

      <label className="mt-3 block text-sm font-bold uppercase tracking-tight">
        Name
        <input
          type="text"
          maxLength={60}
          value={state.title}
          onChange={(event) => setState({ ...state, title: event.target.value })}
          className={field}
        />
      </label>
      <div className="mt-3 grid gap-3 sm:grid-cols-[1fr,8rem]">
        <label className="block text-sm font-bold uppercase tracking-tight">
          One line about it
          <input
            type="text"
            maxLength={200}
            value={state.body}
            onChange={(event) => setState({ ...state, body: event.target.value })}
            className={field}
          />
        </label>
        <label className="block text-sm font-bold uppercase tracking-tight">
          Price label
          <input
            type="text"
            maxLength={16}
            placeholder="$14"
            value={state.priceLabel}
            onChange={(event) => setState({ ...state, priceLabel: event.target.value })}
            className={`${field} font-mono`}
          />
        </label>
      </div>

      {state.title.trim() || state.photo ? (
        <div className="scene-paper mt-3 flex items-start gap-3 rounded border border-hairline p-3">
          {state.photo ? (
            <span className="relative size-16 shrink-0">
              <span className="img-frame relative block size-16 overflow-hidden rounded">
                <Image
                  src={state.photo.src}
                  alt={state.photo.alt}
                  fill
                  sizes="64px"
                  className="object-cover"
                />
              </span>
              {/* The ✕ ON the picture, same device as the dish tickets. */}
              <button
                type="button"
                aria-label={`Clear the picture on slot ${state.slot}`}
                title="Clear picture"
                disabled={busy}
                onClick={removePhoto}
                className="absolute -right-1.5 -top-1.5 flex size-6 items-center justify-center rounded-full border border-paper bg-ink font-mono text-[0.6875rem] font-bold leading-none text-paper disabled:opacity-40"
              >
                ✕
              </button>
            </span>
          ) : null}
          <span className="min-w-0">
            <p className="flex flex-wrap items-baseline gap-x-3">
              <span className="font-bold uppercase tracking-tight">
                {state.title || 'No name yet'}
              </span>
              {state.priceLabel ? (
                <span className="font-mono font-bold tabular-nums">{state.priceLabel}</span>
              ) : null}
            </p>
            {state.body ? <p className="mt-1 text-sm text-ink-muted">{state.body}</p> : null}
            <p className="mt-2 text-sm italic text-ink-muted">From the kitchen, today.</p>
          </span>
        </div>
      ) : null}

      <input
        ref={fileInput}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={onFileChosen}
      />

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button
          type="button"
          disabled={busy}
          onClick={() => fileInput.current?.click()}
          className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
        >
          {state.photo ? 'Swap photo' : '+ Photo'}
        </button>
        {state.photo ? (
          <button
            type="button"
            disabled={busy}
            onClick={removePhoto}
            className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted disabled:opacity-60"
          >
            Clear picture
          </button>
        ) : null}
        <button
          type="button"
          disabled={busy || state.title.trim().length === 0}
          onClick={() => put(true)}
          className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
        >
          {state.published ? 'Update' : 'Publish'}
        </button>
        {state.published ? (
          <button
            type="button"
            disabled={busy}
            onClick={() => put(false)}
            className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
          >
            Take down
          </button>
        ) : null}
        {!empty ? (
          <button
            type="button"
            disabled={busy}
            onClick={clearSlot}
            className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted disabled:opacity-60"
          >
            Clear slot
          </button>
        ) : null}
        <p role="status" aria-live="polite" className={noteClass(message)}>
          {message?.text}
        </p>
      </div>
    </div>
  )
}
