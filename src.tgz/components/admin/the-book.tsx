'use client'

import { useState } from 'react'
import type { BookingStatus } from '@prisma/client'
import { BookingTicket, type TicketBooking } from '@/components/admin/booking-ticket'
import { noteClass, type StationNote } from '@/components/admin/station-message'
import { adminMutate } from '@/lib/admin/mutate'
import { TIME_WINDOWS, TIME_WINDOW_LABELS, type TimeWindowValue } from '@/lib/booking'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The ticket rail. Status changes are optimistic with rollback: the pill
// flips instantly, and if the server disagrees the ticket snaps back and
// says so — never a silent divergence between the screen and the row.

// The bar's own clock, not the device's (same rule as the page's filters):
// "today" behind this bar is the Pacific date. Called on every OPEN, never
// once at mount — D5 (build/11): an always-open bar laptop crosses midnight
// and would otherwise offer yesterday as the default day.
const reardanToday = () =>
  new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' })

/** Which filter pill will actually be holding this booking after a refresh
 *  (review finding 3 — "under Today" was hardcoded, and the day field takes
 *  ANY date). Mirrors whereFor() in app/admin/(authed)/page.tsx exactly: new
 *  = status, today = that bar date, week = [today, today+7), all = the rest.
 *  A staff entry is born CONFIRMED, so NEW never holds it; the labels are
 *  the pills' own words (BOOK_FILTERS in filter-pills.tsx). */
const holdingFilter = (iso: string, today: string): 'Today' | 'This week' | 'All' => {
  if (iso === today) return 'Today'
  const days = (Date.parse(`${iso}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86_400_000
  return days > 0 && days < 7 ? 'This week' : 'All'
}

const dayLabel = (iso: string) =>
  new Date(`${iso}T00:00:00`).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  })

// STAFF ENTRY (Smoky Mug integration, 2026-09-23): the phone booking goes
// straight into THE BOOK - one book of record. Born CONFIRMED because the
// call already happened; the audit event says 'entered at the bar'.
function AddBooking({ onAdded }: { onAdded: (booking: TicketBooking) => void }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [party, setParty] = useState('2')
  const [date, setDate] = useState(reardanToday)
  const [timeWindow, setTimeWindow] = useState<TimeWindowValue>('evening')
  const [note, setNote] = useState('')
  const [message, setMessage] = useState<StationNote>(null)
  const [busy, setBusy] = useState(false)

  const say = (text: string) => setMessage({ text, tone: 'ok' })
  const warn = (text: string) => setMessage({ text, tone: 'amber' })

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/bookings', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name, phone, partySize: Number(party), date, timeWindow, note: note || undefined }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; duplicate?: boolean; booking?: Record<string, unknown> }
        | null
      if (!res.ok || data?.ok !== true || !data.booking) {
        warn(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      const row = data.booking as {
        id: string; reference: string; name: string; phone: string; phoneDigits: string
        partySize: number; requestedOn: string; timeWindow: TimeWindowValue
        note: string | null; status: TicketBooking['status']; createdAt: string
      }
      if (data.duplicate) {
        warn(`Already in the book: ${row.reference}`)
        return
      }
      onAdded({
        id: row.id,
        reference: row.reference,
        name: row.name,
        phone: row.phone,
        phoneDigits: row.phoneDigits,
        partySize: row.partySize,
        date: row.requestedOn.slice(0, 10),
        timeWindow: row.timeWindow,
        note: row.note,
        status: row.status,
        createdAt: row.createdAt,
      })
      setOpen(false)
      setName(''); setPhone(''); setParty('2'); setNote('')
      // D5 (build/11): the ticket is prepended to whatever is on screen, but
      // a staff entry is born CONFIRMED and the default filter is NEW — so a
      // refresh hides it and the owner thinks the booking was lost. Say
      // where it went, naming the pill that will actually hold it.
      const booked = row.requestedOn.slice(0, 10)
      say(
        `In the book for ${dayLabel(booked)} — it shows under ` +
          `${holdingFilter(booked, reardanToday())}, not New.`,
      )
    } catch {
      warn('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  const field = 'mt-1 block w-full min-h-11 rounded border border-hairline bg-paper px-3'

  // ONE live region for both states (review finding 8). The form and the
  // collapsed button swap places, and a role="status" that MOUNTS already
  // holding its text is not announced — the success line landed silently on
  // a screen reader, which is exactly the trust defect D5 is about. This
  // element never unmounts, so every message is a mutation it can announce.
  const status = (
    <p
      role="status"
      aria-live="polite"
      className={`${noteClass(message)}${message ? ' mt-2' : ''}`}
    >
      {message?.text}
    </p>
  )

  if (!open) {
    return (
      <div>
        <button
          type="button"
          onClick={() => {
            // The day defaults to TODAY as of this tap (D5).
            setDate(reardanToday())
            setOpen(true)
          }}
          className="tap-feedback min-h-11 rounded border border-hairline bg-surface px-4 text-sm font-bold uppercase tracking-tight"
        >
          + Add booking
        </button>
        {status}
      </div>
    )
  }

  return (
    <div>
      <form onSubmit={submit} className="rounded-lg border border-hairline bg-surface p-4">
        <p className="text-sm font-bold uppercase tracking-tight">
          Phone booking - goes in CONFIRMED (the call already happened)
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="block text-sm font-bold uppercase tracking-tight">
            Name
            <input required maxLength={80} value={name} onChange={(e) => setName(e.target.value)} className={field} />
          </label>
          <label className="block text-sm font-bold uppercase tracking-tight">
            Phone
            <input required type="tel" maxLength={30} value={phone} onChange={(e) => setPhone(e.target.value)} className={`${field} font-mono`} />
          </label>
          <label className="block text-sm font-bold uppercase tracking-tight">
            Party size
            <input required type="number" min={1} max={40} value={party} onChange={(e) => setParty(e.target.value)} className={`${field} font-mono`} />
          </label>
          <label className="block text-sm font-bold uppercase tracking-tight">
            What day
            <input required type="date" value={date} onChange={(e) => setDate(e.target.value)} className={`${field} font-mono`} />
          </label>
        </div>
        <fieldset className="mt-3">
          <legend className="text-sm font-bold uppercase tracking-tight">When, roughly</legend>
          <div className="mt-1 flex flex-wrap gap-2">
            {TIME_WINDOWS.map((value) => (
              <button
                key={value}
                type="button"
                aria-pressed={timeWindow === value}
                onClick={() => setTimeWindow(value)}
                className={`min-h-11 rounded border px-3 text-sm font-bold uppercase ${
                  timeWindow === value ? 'border-ink bg-ink text-paper' : 'border-hairline text-ink-muted'
                }`}
              >
                {TIME_WINDOW_LABELS[value]}
              </button>
            ))}
          </div>
        </fieldset>
        <label className="mt-3 block text-sm font-bold uppercase tracking-tight">
          Note (optional)
          <input maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} className={field} />
        </label>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            type="submit"
            disabled={busy}
            aria-busy={busy}
            className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
          >
            {busy ? 'Adding' : 'Into the book'}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => { setOpen(false); setMessage(null) }}
            className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted"
          >
            Never mind
          </button>
        </div>
      </form>
    {status}
    </div>
  )
}

export function TheBook({ initial }: { initial: TicketBooking[] }) {
  const [bookings, setBookings] = useState(initial)

  async function changeStatus(id: string, next: BookingStatus): Promise<boolean> {
    const before = bookings
    setBookings((rows) => rows.map((row) => (row.id === id ? { ...row, status: next } : row)))
    try {
      const res = await adminMutate(`/api/admin/bookings/${id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ status: next }),
      })
      if (!res.ok) throw new Error(String(res.status))
      return true
    } catch {
      setBookings(before)
      return false
    }
  }

  async function remove(id: string): Promise<boolean> {
    const before = bookings
    setBookings((rows) => rows.filter((row) => row.id !== id))
    try {
      const res = await adminMutate(`/api/admin/bookings/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      return true
    } catch {
      setBookings(before)
      return false
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <AddBooking onAdded={(booking) => setBookings((rows) => [booking, ...rows])} />
      {bookings.length === 0 ? (
        // An empty queue at 3pm on a Tuesday is the NORMAL state of this
        // business and must not read as broken (build/08 §4).
        <div className="max-w-xl rounded-lg border border-hairline bg-surface p-6">
          <p className="text-lg font-bold">Nothing waiting. The phone still works.</p>
          <p className="mt-2">
            <a href={TEL_HREF} className="font-mono font-bold underline underline-offset-4">
              {SITE.phoneDisplay}
            </a>
          </p>
        </div>
      ) : (
        // Width amendment 2026-09-23: the queue uses the room — tickets grid
        // 2-up at lg, 3-up at 2xl, still one-under-the-other inside a column.
        <ul className="grid items-start gap-3 lg:grid-cols-2 2xl:grid-cols-3">
          {bookings.map((booking) => (
            <BookingTicket
              key={booking.id}
              booking={booking}
              onStatus={changeStatus}
              onDelete={remove}
            />
          ))}
        </ul>
      )}
    </div>
  )
}
