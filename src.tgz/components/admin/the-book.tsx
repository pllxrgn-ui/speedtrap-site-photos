'use client'

import { useState } from 'react'
import type { BookingStatus } from '@prisma/client'
import { BookingTicket, type TicketBooking } from '@/components/admin/booking-ticket'
import { adminMutate } from '@/lib/admin/mutate'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The ticket rail. Status changes are optimistic with rollback: the pill
// flips instantly, and if the server disagrees the ticket snaps back and
// says so — never a silent divergence between the screen and the row.
export function TheBook({ initial }: { initial: TicketBooking[] }) {
  const [bookings, setBookings] = useState(initial)

  async function changeStatus(id: string, next: BookingStatus): Promise<boolean> {
    const before = bookings
    setBookings((rows) => rows.map((row) => (row.id === id ? { ...row, status: next } : row)))
    try {
      const res = await adminMutate(`/api/admin/bookings/${id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ status: next }),
      })
      if (!res.ok) throw new Error(String(res.status))
      return true
    } catch {
      setBookings(before)
      return false
    }
  }

  async function remove(id: string): Promise<boolean> {
    const before = bookings
    setBookings((rows) => rows.filter((row) => row.id !== id))
    try {
      const res = await adminMutate(`/api/admin/bookings/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      return true
    } catch {
      setBookings(before)
      return false
    }
  }

  if (bookings.length === 0) {
    // An empty queue at 3pm on a Tuesday is the NORMAL state of this
    // business and must not read as broken (build/08 §4).
    return (
      <div className="rounded-lg border border-hairline bg-surface p-6">
        <p className="text-lg font-bold">Nothing waiting. The phone still works.</p>
        <p className="mt-2">
          <a href={TEL_HREF} className="font-mono font-bold underline underline-offset-4">
            {SITE.phoneDisplay}
          </a>
        </p>
      </div>
    )
  }

  return (
    <ul className="flex flex-col gap-3">
      {bookings.map((booking) => (
        <BookingTicket
          key={booking.id}
          booking={booking}
          onStatus={changeStatus}
          onDelete={remove}
        />
      ))}
    </ul>
  )
}
