'use client'

import { useState } from 'react'
import type { BookingStatus } from '@prisma/client'
import { BookingTicket, type TicketBooking } from '@/components/admin/booking-ticket'
import { adminMutate } from '@/lib/admin/mutate'
import { TIME_WINDOWS, TIME_WINDOW_LABELS, type TimeWindowValue } from '@/lib/booking'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The ticket rail. Status changes are optimistic with rollback: the pill
// flips instantly, and if the server disagrees the ticket snaps back and
// says so — never a silent divergence between the screen and the row.

// STAFF ENTRY (Smoky Mug integration, 2026-09-23): the phone booking goes
// straight into THE BOOK - one book of record. Born CONFIRMED because the
// call already happened; the audit event says 'entered at the bar'.
function AddBooking({ onAdded }: { onAdded: (booking: TicketBooking) => void }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [party, setParty] = useState('2')
  const [date, setDate] = useState(() => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }))
  const [timeWindow, setTimeWindow] = useState<TimeWindowValue>('evening')
  const [note, setNote] = useState('')
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/bookings', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name, phone, partySize: Number(party), date, timeWindow, note: note || undefined }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; duplicate?: boolean; booking?: Record<string, unknown> }
        | null
      if (!res.ok || data?.ok !== true || !data.booking) {
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      const row = data.booking as {
        id: string; reference: string; name: string; phone: string; phoneDigits: string
        partySize: number; requestedOn: string; timeWindow: TimeWindowValue
        note: string | null; status: TicketBooking['status']; createdAt: string
      }
      if (data.duplicate) {
        setMessage(`Already in the book: ${row.reference}`)
        return
      }
      onAdded({
        id: row.id,
        reference: row.reference,
        name: row.name,
        phone: row.phone,
        phoneDigits: row.phoneDigits,
        partySize: row.partySize,
        date: row.requestedOn.slice(0, 10),
        timeWindow: row.timeWindow,
        note: row.note,
        status: row.status,
        createdAt: row.createdAt,
      })
      setOpen(false)
      setName(''); setPhone(''); setParty('2'); setNote('')
      setMessage(null)
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  const field = 'mt-1 block w-full min-h-11 rounded border border-hairline bg-paper px-3'

  if (!open) {
    return (
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="tap-feedback min-h-11 rounded border border-hairline bg-surface px-4 text-sm font-bold uppercase tracking-tight"
        >
          + Add booking
        </button>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">{message}</p>
      </div>
    )
  }

  return (
    <form onSubmit={submit} className="rounded-lg border border-hairline bg-surface p-4">
      <p className="text-sm font-bold uppercase tracking-tight">
        Phone booking - goes in CONFIRMED (the call already happened)
      </p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <label className="block text-sm font-bold uppercase tracking-tight">
          Name
          <input required maxLength={80} value={name} onChange={(e) => setName(e.target.value)} className={field} />
        </label>
        <label className="block text-sm font-bold uppercase tracking-tight">
          Phone
          <input required type="tel" maxLength={30} value={phone} onChange={(e) => setPhone(e.target.value)} className={`${field} font-mono`} />
        </label>
        <label className="block text-sm font-bold uppercase tracking-tight">
          Party size
          <input required type="number" min={1} max={40} value={party} onChange={(e) => setParty(e.target.value)} className={`${field} font-mono`} />
        </label>
        <label className="block text-sm font-bold uppercase tracking-tight">
          What day
          <input required type="date" value={date} onChange={(e) => setDate(e.target.value)} className={`${field} font-mono`} />
        </label>
      </div>
      <fieldset className="mt-3">
        <legend className="text-sm font-bold uppercase tracking-tight">When, roughly</legend>
        <div className="mt-1 flex flex-wrap gap-2">
          {TIME_WINDOWS.map((value) => (
            <button
              key={value}
              type="button"
              aria-pressed={timeWindow === value}
              onClick={() => setTimeWindow(value)}
              className={`min-h-11 rounded border px-3 text-sm font-bold uppercase ${
                timeWindow === value ? 'border-ink bg-ink text-paper' : 'border-hairline text-ink-muted'
              }`}
            >
              {TIME_WINDOW_LABELS[value]}
            </button>
          ))}
        </div>
      </fieldset>
      <label className="mt-3 block text-sm font-bold uppercase tracking-tight">
        Note (optional)
        <input maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} className={field} />
      </label>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="submit"
          disabled={busy}
          aria-busy={busy}
          className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
        >
          {busy ? 'Adding' : 'Into the book'}
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => { setOpen(false); setMessage(null) }}
          className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted"
        >
          Never mind
        </button>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">{message}</p>
      </div>
    </form>
  )
}

export function TheBook({ initial }: { initial: TicketBooking[] }) {
  const [bookings, setBookings] = useState(initial)

  async function changeStatus(id: string, next: BookingStatus): Promise<boolean> {
    const before = bookings
    setBookings((rows) => rows.map((row) => (row.id === id ? { ...row, status: next } : row)))
    try {
      const res = await adminMutate(`/api/admin/bookings/${id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ status: next }),
      })
      if (!res.ok) throw new Error(String(res.status))
      return true
    } catch {
      setBookings(before)
      return false
    }
  }

  async function remove(id: string): Promise<boolean> {
    const before = bookings
    setBookings((rows) => rows.filter((row) => row.id !== id))
    try {
      const res = await adminMutate(`/api/admin/bookings/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      return true
    } catch {
      setBookings(before)
      return false
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <AddBooking onAdded={(booking) => setBookings((rows) => [booking, ...rows])} />
      {bookings.length === 0 ? (
        // An empty queue at 3pm on a Tuesday is the NORMAL state of this
        // business and must not read as broken (build/08 §4).
        <div className="max-w-xl rounded-lg border border-hairline bg-surface p-6">
          <p className="text-lg font-bold">Nothing waiting. The phone still works.</p>
          <p className="mt-2">
            <a href={TEL_HREF} className="font-mono font-bold underline underline-offset-4">
              {SITE.phoneDisplay}
            </a>
          </p>
        </div>
      ) : (
        // Width amendment 2026-09-23: the queue uses the room — tickets grid
        // 2-up at lg, 3-up at 2xl, still one-under-the-other inside a column.
        <ul className="grid items-start gap-3 lg:grid-cols-2 2xl:grid-cols-3">
          {bookings.map((booking) => (
            <BookingTicket
              key={booking.id}
              booking={booking}
              onStatus={changeStatus}
              onDelete={remove}
            />
          ))}
        </ul>
      )}
    </div>
  )
}
