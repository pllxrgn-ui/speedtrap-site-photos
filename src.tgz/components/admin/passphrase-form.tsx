'use client'

import { useState } from 'react'
import { adminMutate } from '@/lib/admin/mutate'

// Change the passphrase (addendum 7). The current one must be typed again
// — an open session alone is not enough — and success signs out every
// other device on the spot. The passphrase itself never leaves this form
// except to the change endpoint; nothing here stores or echoes it.
export function PassphraseForm() {
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [message, setMessage] = useState<string | null>(null)
  const [done, setDone] = useState(false)
  const [busy, setBusy] = useState(false)

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    if (busy) return
    if (next !== confirm) {
      setMessage('The two new ones do not match.')
      return
    }
    if (next.length < 12) {
      setMessage('Twelve characters at least. Longer beats clever.')
      return
    }
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/passphrase', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ current, next }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string }
        | null
      if (!res.ok || data?.ok !== true) {
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      setDone(true)
      setCurrent('')
      setNext('')
      setConfirm('')
      setMessage(null)
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  const field = 'mt-1 block w-full min-h-12 rounded border border-hairline bg-paper px-3 py-2'

  if (done) {
    return (
      <div className="max-w-xl rounded-lg border border-hairline bg-surface p-6">
        <p className="text-lg font-bold">Changed. This device stays signed in.</p>
        <p className="mt-2 text-sm text-ink-muted">
          Every other signed-in device was signed out the moment it changed.
          Write the new passphrase down somewhere that is not this screen —
          there is no reset by email, on purpose.
        </p>
      </div>
    )
  }

  return (
    <form onSubmit={submit} className="max-w-xl">
      <label className="block text-sm font-bold uppercase tracking-tight">
        Current passphrase
        <input
          type="password"
          autoComplete="current-password"
          required
          value={current}
          onChange={(event) => setCurrent(event.target.value)}
          className={field}
        />
      </label>
      <label className="mt-4 block text-sm font-bold uppercase tracking-tight">
        New passphrase
        <input
          type="password"
          autoComplete="new-password"
          required
          minLength={12}
          value={next}
          onChange={(event) => setNext(event.target.value)}
          className={field}
        />
      </label>
      <p className="mt-1 text-sm text-ink-muted">
        Twelve characters at least. A few random words beat a clever code.
      </p>
      <label className="mt-4 block text-sm font-bold uppercase tracking-tight">
        New passphrase, again
        <input
          type="password"
          autoComplete="new-password"
          required
          minLength={12}
          value={confirm}
          onChange={(event) => setConfirm(event.target.value)}
          className={field}
        />
      </label>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={busy}
          aria-busy={busy}
          className="tap-feedback min-h-12 rounded bg-ink px-5 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
        >
          {busy ? 'Changing' : 'Change it'}
        </button>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>
      <p className="mt-4 max-w-[52ch] text-sm text-ink-muted">
        Changing it signs out every other device. There is no email reset:
        if the passphrase is lost, recovery goes through the site&apos;s
        hosting, not this screen.
      </p>
    </form>
  )
}
