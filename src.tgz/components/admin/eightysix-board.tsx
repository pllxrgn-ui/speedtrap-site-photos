'use client'

import { useState } from 'react'
import type { HoldUntil } from '@prisma/client'
import { adminMutate } from '@/lib/admin/mutate'
import { HOLD_CHOICES } from '@/lib/overlay-shared'

// The 86 board: all 50 dishes, one switch each, grouped by the printed
// menu's own categories. Flipping one ON applies the DEFAULT hold
// (Tonight — expiry automatic, veto 13); the hold chips adjust it. The
// switch is a real role="switch" per the a11y contract extracted into
// the procurement store.

export interface EightySixItem {
  itemKey: string
  name: string
  soldOut: boolean
  hold: HoldUntil
}

export interface EightySixGroup {
  categoryId: string
  title: string
  items: EightySixItem[]
}

export function EightySixBoard({
  groups,
  orphans,
}: {
  groups: EightySixGroup[]
  orphans: string[]
}) {
  const [state, setState] = useState(() => {
    const map: Record<string, { soldOut: boolean; hold: HoldUntil }> = {}
    for (const group of groups) {
      for (const item of group.items) map[item.itemKey] = { soldOut: item.soldOut, hold: item.hold }
    }
    return map
  })
  const [orphanKeys, setOrphanKeys] = useState(orphans)
  const [message, setMessage] = useState<string | null>(null)

  async function post(itemKey: string, soldOut: boolean, hold: HoldUntil) {
    const before = state[itemKey]
    setState((current) => ({ ...current, [itemKey]: { soldOut, hold } }))
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey, soldOut, hold }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage(soldOut ? 'Live on the site' : 'Back on')
      return true
    } catch {
      setState((current) => ({ ...current, [itemKey]: before }))
      setMessage('That did not stick. Refresh and retry.')
      return false
    }
  }

  async function clearOrphan(itemKey: string) {
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey, soldOut: false }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setOrphanKeys((keys) => keys.filter((key) => key !== itemKey))
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  return (
    <section aria-label="86 board" className="rounded-lg border border-hairline bg-surface p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">The 86 board</h2>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>

      {orphanKeys.length > 0 ? (
        <div className="mt-3 rounded border-2 border-ink p-3">
          <p className="text-sm font-bold">
            These marks point at dishes that are no longer on the printed menu. The page
            already ignores them — clear them here.
          </p>
          <ul className="mt-2 flex flex-col gap-1">
            {orphanKeys.map((key) => (
              <li key={key} className="flex items-center justify-between gap-3">
                <span className="font-mono text-sm">{key}</span>
                <button
                  type="button"
                  onClick={() => clearOrphan(key)}
                  className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase"
                >
                  Clear
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className="mt-3 flex flex-col gap-4">
        {groups.map((group) => (
          <div key={group.categoryId}>
            <h3 className="font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
              {group.title}
            </h3>
            <ul className="mt-1 flex flex-col">
              {group.items.map((item) => {
                const current = state[item.itemKey]
                return (
                  <li
                    key={item.itemKey}
                    className="flex min-h-12 flex-wrap items-center justify-between gap-x-4 gap-y-1 border-b border-hairline py-1 last:border-b-0"
                  >
                    <span className={current.soldOut ? 'font-bold' : ''}>{item.name}</span>
                    <span className="flex items-center gap-2">
                      {current.soldOut ? (
                        <span className="flex gap-1" role="group" aria-label={`How long is ${item.name} off`}>
                          {HOLD_CHOICES.map((choice) => (
                            <button
                              key={choice.value}
                              type="button"
                              aria-pressed={current.hold === choice.value}
                              onClick={() => post(item.itemKey, true, choice.value)}
                              className={`min-h-8 rounded border px-2 text-xs font-bold uppercase ${
                                current.hold === choice.value
                                  ? 'border-ink bg-ink text-paper'
                                  : 'border-hairline text-ink-muted'
                              }`}
                            >
                              {choice.label}
                            </button>
                          ))}
                        </span>
                      ) : null}
                      <button
                        type="button"
                        role="switch"
                        aria-checked={current.soldOut}
                        aria-label={`86 ${item.name}`}
                        onClick={() =>
                          // Turning ON always starts at the DEFAULT hold
                          // (Tonight, automatic expiry) — never inherits a
                          // stale 'cleared' from an old row (veto 13).
                          post(item.itemKey, !current.soldOut, current.soldOut ? current.hold : 'tonight')
                        }
                        className={`relative h-7 w-12 rounded-full border transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                          current.soldOut ? 'border-amber bg-amber' : 'border-hairline bg-paper'
                        }`}
                      >
                        <span
                          aria-hidden
                          className={`absolute top-0.5 size-5 rounded-full bg-ink transition-[left] duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                            current.soldOut ? 'left-6' : 'left-0.5'
                          }`}
                        />
                      </button>
                    </span>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </div>
    </section>
  )
}
