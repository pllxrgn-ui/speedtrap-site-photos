// Filter state lives in the URL on purpose (build/08 §4): a refresh
// behind the bar must not lose the view. Plain links, server-rendered.
export const BOOK_FILTERS = [
  ['new', 'New'],
  ['today', 'Today'],
  ['week', 'This week'],
  ['all', 'All'],
] as const

export type BookFilter = (typeof BOOK_FILTERS)[number][0]

export function FilterPills({ active }: { active: BookFilter }) {
  return (
    <nav aria-label="Filter bookings" className="flex flex-wrap gap-2">
      {BOOK_FILTERS.map(([key, label]) => (
        <a
          key={key}
          href={`/admin?f=${key}`}
          aria-current={active === key ? 'page' : undefined}
          className={`tap-feedback inline-flex min-h-11 items-center rounded-full border px-4 text-sm font-bold uppercase tracking-tight ${
            active === key
              ? 'border-ink bg-ink text-paper'
              : 'border-hairline bg-surface text-ink'
          }`}
        >
          {label}
        </a>
      ))}
    </nav>
  )
}
