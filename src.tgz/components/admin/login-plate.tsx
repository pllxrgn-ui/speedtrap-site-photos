'use client'

import { useState } from 'react'

// Plain Phase 3 form. Talks to /api/admin/login directly (no CSRF header
// needed to SIGN IN — the login response is what issues the token).
export function LoginPlate() {
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function submit(event: React.FormEvent) {
    event.preventDefault()
    setBusy(true)
    setError(null)
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      if (res.ok) {
        // HARD navigation on purpose: the admin layout's requireSession
        // must re-run against the just-set cookie, and a client-router
        // transition can reuse a prerendered payload from the logged-out
        // state. A full document load cannot.
        // eslint-disable-next-line @next/next/no-location-assign-relative-destination
        window.location.assign('/admin')
        return
      }
      const data = (await res.json().catch(() => null)) as { message?: string } | null
      setError(data?.message ?? 'Sign-in failed. Try again.')
    } catch {
      setError('Sign-in failed. Try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-4">
      <h1 className="font-display text-3xl uppercase">Back of house</h1>
      <label className="flex flex-col gap-2 text-sm">
        Password
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          autoComplete="current-password"
          className="min-h-12 rounded border border-hairline bg-surface px-3"
        />
      </label>
      {error ? (
        <p role="alert" className="text-sm font-bold">
          {error}
        </p>
      ) : null}
      <button
        type="submit"
        disabled={busy || password.length === 0}
        aria-busy={busy}
        className="min-h-12 rounded bg-ink font-bold uppercase tracking-tight text-paper disabled:opacity-60"
      >
        {busy ? 'Checking' : 'Sign in'}
      </button>
    </form>
  )
}
