// D6 (build/11, Wave S-A): AMBER IS NOT A SUCCESS COLOUR. Contract rule 3
// says amber back here means "needs you" — a new request, an 86 expiring, an
// unpublished draft. Every status line in the station printed in amber
// regardless, success included, so the one colour that is supposed to pull
// the eye pulled it for "Live on the site" too.
//
// Statuses carry a TONE now: success and settled information render in ink,
// failures and anything still wanting the owner's attention stay amber. The
// rule lives here so it is one edit, not seven.
//
// The favorites poster's amber is NOT a status and is out of scope — the
// PARITY amendment carved it out as a quoted site composition inside a
// .scene-paper island.

export type StationNote = { text: string; tone: 'ok' | 'amber' } | null

/** The class for a status line. Keep the `role="status" aria-live="polite"`
 *  element mounted at all times (even with no note) or nothing announces —
 *  a live region that appears already holding its text is silent. */
export function noteClass(note: StationNote): string {
  return `text-sm font-bold ${note?.tone === 'amber' ? 'text-amber-ink' : 'text-ink'}`
}
