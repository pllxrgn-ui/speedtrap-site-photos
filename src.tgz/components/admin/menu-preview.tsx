'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import type { HoldUntil } from '@prisma/client'
import { ConfirmDialog } from '@/components/admin/confirm-dialog'
import { InlineEdit } from '@/components/admin/inline-edit'
import { adminMutate } from '@/lib/admin/mutate'
import {
  applyRequestFor,
  describeDraft,
  dropDraft,
  isDraftId,
  normalizePriceInput,
  parseTray,
  queueDraft,
  replayDrafts,
  serializeTray,
  TRAY_STORAGE_KEY,
  validateDraftValue,
  type DraftChange,
  type PreviewDish,
  type PreviewGroup,
} from '@/lib/admin/menu-drafts'
import { HOLD_CHOICES, HOLD_LABELS } from '@/lib/overlay-shared'

// THE MENU EDITOR, tray regime (build/09 addendum 3). The paper shows the
// FUTURE site: every text edit, add, remove and reorder queues in THE TRAY
// and nothing reaches customers until "Apply to the site" replays the
// queue through the same per-change APIs (one MenuEvent ledger row per
// applied change, as ever). Two deliberate exceptions stay IMMEDIATE:
// the SOLD OUT switch (an 86 during service cannot wait in a tray) and
// photos (uploads are immediate by nature, and both are reversible).
// Drafts survive a dead tab via localStorage and replay onto the fresh
// baseline on return.

export type { PreviewDish, PreviewGroup } from '@/lib/admin/menu-drafts'

const TRAY_TOAST = 'In the tray — nothing is live until you apply'

function priceLabel(price: string): string {
  return price === '' ? 'no price' : `$${price}`
}

export function MenuPreview({ groups, orphans }: { groups: PreviewGroup[]; orphans: string[] }) {
  // baseline = what the SERVER has (groups at load, advanced by every
  // successful apply). The rendered view is always replayDrafts(baseline,
  // pending) — replaying against the page-load prop after an apply would
  // silently forget everything just applied (finish-gate catch,
  // 2026-09-23: the server was right and the screen lied).
  const [baseline, setBaseline] = useState(groups)
  const [pending, setPending] = useState<DraftChange[]>([])
  const [view, setView] = useState(groups)
  const [message, setMessage] = useState<string | null>(null)
  const [applying, setApplying] = useState(false)
  const [discarding, setDiscarding] = useState(false)
  const [orphanKeys, setOrphanKeys] = useState(orphans)
  const [addingBoard, setAddingBoard] = useState(false)
  const [newBoardName, setNewBoardName] = useState('')
  // SOLD OUT and photos apply immediately (they are the overlay, not the
  // menu) — they live OUTSIDE the tray so a view rebuild never loses them.
  const [liveState, setLiveState] = useState<
    Record<string, { soldOut?: boolean; hold?: HoldUntil; photo?: PreviewDish['photo'] }>
  >({})
  const fileInput = useRef<HTMLInputElement>(null)
  const uploadTarget = useRef<string | null>(null)

  function persist(next: DraftChange[]) {
    try {
      if (next.length === 0) window.localStorage.removeItem(TRAY_STORAGE_KEY)
      else window.localStorage.setItem(TRAY_STORAGE_KEY, serializeTray(next))
    } catch {
      /* storage unavailable — the tray still works for this tab */
    }
  }

  // A tray saved by a dead tab replays onto the fresh baseline. Deferred a
  // tick so the first paint is the plain baseline (and the compiler's
  // no-sync-setState-in-effect rule holds).
  useEffect(() => {
    const timer = window.setTimeout(() => {
      let raw: string | null = null
      try {
        raw = window.localStorage.getItem(TRAY_STORAGE_KEY)
      } catch {
        return
      }
      const saved = parseTray(raw)
      if (saved.length === 0) return
      const result = replayDrafts(groups, saved)
      setPending(result.kept)
      setView(result.groups)
      persist(result.kept)
      setMessage(
        result.dropped > 0
          ? `Brought back ${result.kept.length} unapplied changes; ${result.dropped} no longer fit and were dropped`
          : `Brought back ${result.kept.length} unapplied changes from last time`,
      )
    }, 0)
    return () => window.clearTimeout(timer)
  }, [groups])

  function queue(change: DraftChange) {
    const nextPending = queueDraft(pending, change)
    const result = replayDrafts(baseline, nextPending)
    setPending(result.kept)
    setView(result.groups)
    persist(result.kept)
    setMessage(result.kept.length === 0 ? 'Back to how the site has it' : TRAY_TOAST)
  }

  function findDish(id: string): PreviewDish | undefined {
    for (const group of view) {
      const dish = group.dishes.find((candidate) => candidate.id === id)
      if (dish) return dish
    }
    return undefined
  }

  function decorate(dish: PreviewDish): PreviewDish {
    const live = liveState[dish.id]
    if (!live) return dish
    return {
      ...dish,
      soldOut: live.soldOut ?? dish.soldOut,
      hold: live.hold ?? dish.hold,
      photo: live.photo === undefined ? dish.photo : live.photo,
    }
  }

  // ------------------------------------------------------------------ tray
  function saveField(id: string, field: 'name' | 'description' | 'price', next: string) {
    const dish = findDish(id)
    if (!dish) return
    if (field === 'price') {
      const parsed = normalizePriceInput(next)
      if (!parsed.ok) {
        setMessage(parsed.message)
        return
      }
      queue({ kind: 'dish-edit', id, dishName: dish.name, field, from: dish.price, to: parsed.value })
      return
    }
    const trimmed = next.trim()
    const error = validateDraftValue(field === 'name' ? 'dish-name' : 'dish-description', trimmed)
    if (error) {
      setMessage(error)
      return
    }
    queue({ kind: 'dish-edit', id, dishName: dish.name, field, from: dish[field], to: trimmed })
  }

  function addDish(group: PreviewGroup) {
    queue({
      kind: 'dish-add',
      id: `draft-dish-${crypto.randomUUID()}`,
      categoryId: group.categoryId,
      boardTitle: group.title,
    })
  }

  function removeDish(dish: PreviewDish) {
    queue({ kind: 'dish-remove', id: dish.id, dishName: dish.name })
  }

  function moveDish(dish: PreviewDish, direction: 'up' | 'down') {
    queue({ kind: 'dish-move', id: dish.id, dishName: dish.name, direction })
  }

  function saveBoardField(group: PreviewGroup, field: 'title' | 'note', next: string) {
    const trimmed = next.trim()
    const error = validateDraftValue(field === 'title' ? 'board-title' : 'board-note', trimmed)
    if (error) {
      setMessage(error)
      return
    }
    queue({
      kind: 'board-edit',
      id: group.categoryId,
      boardTitle: group.title,
      field,
      from: field === 'title' ? group.title : group.note,
      to: trimmed,
    })
  }

  function addBoard() {
    const title = newBoardName.trim()
    if (!title) {
      setAddingBoard(false)
      return
    }
    const error = validateDraftValue('board-title', title)
    if (error) {
      setMessage(error)
      return
    }
    queue({ kind: 'board-add', id: `draft-board-${crypto.randomUUID()}`, title })
    setAddingBoard(false)
    setNewBoardName('')
  }

  function removeBoard(group: PreviewGroup) {
    queue({ kind: 'board-remove', id: group.categoryId, boardTitle: group.title })
  }

  function moveBoard(group: PreviewGroup, direction: 'up' | 'down') {
    queue({ kind: 'board-move', id: group.categoryId, boardTitle: group.title, direction })
  }

  function dropAt(index: number) {
    const nextPending = dropDraft(pending, index)
    const result = replayDrafts(baseline, nextPending)
    setPending(result.kept)
    setView(result.groups)
    persist(result.kept)
    setMessage(result.kept.length === 0 ? 'Tray emptied — the site stays as it is' : 'Dropped from the tray')
  }

  function discardAll() {
    setPending([])
    setView(baseline)
    persist([])
    setMessage('Tray emptied — the site stays as it is')
  }

  // ---------------------------------------------------------------- apply
  async function apply() {
    if (pending.length === 0 || applying) return
    setApplying(true)
    const idMap: Record<string, string> = {}
    const resolve = (id: string) => idMap[id] ?? id
    const remap = (entry: DraftChange): DraftChange =>
      entry.kind === 'dish-add'
        ? { ...entry, id: resolve(entry.id), categoryId: resolve(entry.categoryId) }
        : { ...entry, id: resolve(entry.id) }

    for (let step = 0; step < pending.length; step += 1) {
      const change = pending[step]
      setMessage(`Applying ${step + 1} of ${pending.length}…`)
      const request = applyRequestFor(change, resolve)
      let failure: string | null = null
      try {
        const res = await adminMutate(request.url, {
          method: request.method,
          ...(request.body
            ? { headers: { 'content-type': 'application/json' }, body: JSON.stringify(request.body) }
            : {}),
        })
        const data = (await res.json().catch(() => null)) as
          | { ok?: boolean; message?: string; dish?: { id: string }; board?: { id: string } }
          | null
        if (!res.ok || data?.ok !== true) {
          failure = data?.message ?? 'That did not stick.'
        } else if (request.createsId) {
          const realId = change.kind === 'dish-add' ? data.dish?.id : data.board?.id
          if (!realId) failure = 'That did not stick.'
          else idMap[request.createsId] = realId
        }
      } catch {
        failure = 'That did not stick.'
      }
      if (failure) {
        // Everything before this step is LIVE (each wrote its ledger row);
        // this step and the rest stay in the tray, remapped so they fit
        // the fresh baseline after the reload.
        persist(pending.slice(step).map(remap))
        setMessage(
          `Stopped at "${describeDraft(change)}": ${failure} ` +
            `${step} of ${pending.length} went live; the rest are still in the tray. Reloading…`,
        )
        // Hard reload on purpose: the page must re-read what actually
        // applied — anything softer would show a view the server may not
        // match anymore.
        window.setTimeout(() => window.location.reload(), 2500)
        return
      }
    }

    const applied = pending.length
    setPending([])
    persist([])
    // The view already shows the applied future; swap draft ids for the
    // real ones the server minted so photos and SOLD OUT unlock — and
    // this becomes the NEW BASELINE, because the server now has it.
    const appliedView = view.map((group) => ({
      ...group,
      categoryId: resolve(group.categoryId),
      draft: false,
      dishes: group.dishes.map((dish) => ({ ...dish, id: resolve(dish.id), draft: false })),
    }))
    setView(appliedView)
    setBaseline(appliedView)
    setMessage(`${applied} change${applied === 1 ? '' : 's'} live on the site`)
    setApplying(false)
  }

  // ------------------------------------------- immediate: sold out, photos
  async function setSoldOut(id: string, soldOut: boolean, hold: HoldUntil) {
    const before = decorate(findDish(id) ?? ({} as PreviewDish))
    setLiveState((current) => ({ ...current, [id]: { ...current[id], soldOut, hold } }))
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey: id, soldOut, hold }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage(soldOut ? 'Live on the site' : 'Back on')
    } catch {
      setLiveState((current) => ({
        ...current,
        [id]: { ...current[id], soldOut: before.soldOut, hold: before.hold },
      }))
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  function pickPhoto(id: string) {
    uploadTarget.current = id
    fileInput.current?.click()
  }

  async function onFileChosen(event: React.ChangeEvent<HTMLInputElement>) {
    const id = uploadTarget.current
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!id || !file) return
    if (file.size > 4 * 1024 * 1024) {
      setMessage('That photo is over 4MB. Send a smaller one.')
      return
    }
    setMessage(null)
    try {
      const form = new FormData()
      form.set('itemKey', id)
      form.set('file', file)
      const res = await adminMutate('/api/admin/dish-photo', { body: form })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; photo?: { src: string; alt: string } }
        | null
      if (!res.ok || data?.ok !== true || !data.photo) {
        setMessage(data?.message ?? 'That upload did not stick. Try it again.')
        return
      }
      const photo = data.photo
      setLiveState((current) => ({ ...current, [id]: { ...current[id], photo } }))
      setMessage('Photo is live on the site')
    } catch {
      setMessage('That upload did not stick. Try it again.')
    }
  }

  async function removePhoto(id: string) {
    const before = decorate(findDish(id) ?? ({} as PreviewDish))
    setLiveState((current) => ({ ...current, [id]: { ...current[id], photo: null } }))
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/dish-photo', {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey: id }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage('Photo removed')
    } catch {
      setLiveState((current) => ({ ...current, [id]: { ...current[id], photo: before.photo } }))
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function clearOrphan(itemKey: string) {
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey, soldOut: false }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setOrphanKeys((keys) => keys.filter((key) => key !== itemKey))
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  // ------------------------------------------------------------------ UI
  return (
    <section aria-label="The menu, as the site will show it">
      <input
        ref={fileInput}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={onFileChosen}
      />

      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">The menu</h2>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>
      <p className="mt-1 max-w-[70ch] text-sm text-ink-muted">
        Edits wait in the tray — tap any word, use the arrows, add or remove
        things, then hit APPLY when it all looks right. Nothing touches the
        site before that. Two exceptions go live immediately: the SOLD OUT
        switch (an 86 can&apos;t wait) and photos. Every applied change is
        logged.
      </p>

      {/* THE TRAY — the second look. Amber means "needs you". */}
      {pending.length > 0 ? (
        <div className="mt-3 rounded-lg border-2 border-amber bg-surface p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-display text-lg uppercase">
              {pending.length} change{pending.length === 1 ? '' : 's'} waiting
            </p>
            <span className="flex items-center gap-2">
              <button
                type="button"
                disabled={applying}
                onClick={apply}
                className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
              >
                {applying ? 'Applying…' : 'Apply to the site'}
              </button>
              <button
                type="button"
                disabled={applying}
                onClick={() => setDiscarding(true)}
                className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted disabled:opacity-60"
              >
                Discard all
              </button>
            </span>
          </div>
          <ul className="mt-3 flex flex-col gap-1">
            {pending.map((change, index) => (
              <li
                key={`${change.kind}-${change.id}-${index}`}
                className="flex items-center justify-between gap-3 border-t border-hairline pt-1"
              >
                <span className="text-sm font-bold">{describeDraft(change)}</span>
                <button
                  type="button"
                  aria-label={`Drop: ${describeDraft(change)}`}
                  disabled={applying}
                  onClick={() => dropAt(index)}
                  className="min-h-8 max-lg:min-h-11 min-w-8 rounded border border-hairline font-mono text-xs font-bold text-ink-muted disabled:opacity-30"
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {orphanKeys.length > 0 ? (
        <div className="mt-3 rounded border-2 border-ink p-3">
          <p className="text-sm font-bold">
            Leftover marks from removed dishes. The page already ignores them —
            clear them here.
          </p>
          <ul className="mt-2 flex flex-col gap-1">
            {orphanKeys.map((key) => (
              <li key={key} className="flex items-center justify-between gap-3">
                <span className="font-mono text-sm">{key}</span>
                <button
                  type="button"
                  onClick={() => clearOrphan(key)}
                  className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase"
                >
                  Clear
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {/* The paper: the site as it WILL look once the tray applies. */}
      <div className="scene-paper mt-3 rounded-lg border border-hairline p-4 md:p-5">
        <div className="flex flex-col gap-6">
          {view.map((group, groupIndex) => (
            <div key={group.categoryId} className={group.draft ? 'rounded border border-dashed border-amber p-2' : undefined}>
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                {/* The InlineEdit button lives INSIDE the h3 so the board
                    keeps its heading for screen-reader navigation. */}
                <h3 className="min-w-0">
                  <InlineEdit
                    value={group.title}
                    placeholder="Board name"
                    ariaLabel={`name of the ${group.title} board`}
                    disabled={applying}
                    display={
                      <span className="font-display text-h2 uppercase leading-[0.95]">
                        {group.title}
                      </span>
                    }
                    className="min-w-0"
                    inputClassName="w-full min-h-10 rounded border border-hairline bg-paper px-2 font-display text-h2 uppercase"
                    onCommit={(next) => saveBoardField(group, 'title', next)}
                  />
                </h3>
                <span className="flex shrink-0 items-center gap-1">
                  <button
                    type="button"
                    aria-label={`Move ${group.title} up`}
                    disabled={applying || groupIndex === 0}
                    onClick={() => moveBoard(group, 'up')}
                    className="tap-feedback min-h-11 min-w-11 rounded border border-hairline font-mono text-sm font-bold disabled:opacity-30"
                  >
                    ↑
                  </button>
                  <button
                    type="button"
                    aria-label={`Move ${group.title} down`}
                    disabled={applying || groupIndex === view.length - 1}
                    onClick={() => moveBoard(group, 'down')}
                    className="tap-feedback min-h-11 min-w-11 rounded border border-hairline font-mono text-sm font-bold disabled:opacity-30"
                  >
                    ↓
                  </button>
                  {group.dishes.length === 0 ? (
                    <button
                      type="button"
                      disabled={applying}
                      onClick={() => removeBoard(group)}
                      className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted disabled:opacity-60"
                    >
                      Remove board
                    </button>
                  ) : null}
                  <button
                    type="button"
                    disabled={applying}
                    onClick={() => addDish(group)}
                    className="tap-feedback min-h-11 shrink-0 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
                  >
                    + Add dish
                  </button>
                </span>
              </div>
              <InlineEdit
                value={group.note}
                placeholder="A line under the board name (optional)"
                ariaLabel={`note under ${group.title}`}
                disabled={applying}
                display={
                  group.note ? (
                    <span className="text-sm text-ink-muted">{group.note}</span>
                  ) : (
                    <span className="text-sm italic text-ink-muted">add a line under the name…</span>
                  )
                }
                className="mt-1 block max-w-[60ch]"
                inputClassName="mt-1 block w-full min-h-9 rounded border border-hairline bg-paper px-2 text-sm"
                onCommit={(next) => saveBoardField(group, 'note', next)}
              />
              {group.dishes.length === 0 ? (
                <p className="mt-2 text-sm italic text-ink-muted">
                  Empty — the site hides this board until it has a dish.
                </p>
              ) : null}
              <ul className="mt-3 grid gap-2 md:grid-cols-2 2xl:grid-cols-3">
                {group.dishes.map(decorate).map((dish, dishIndex) => (
                  <li
                    key={dish.id}
                    className={`overflow-hidden rounded-lg border bg-surface px-4 py-3 ${
                      dish.draft ? 'border-dashed border-amber' : 'border-hairline'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {dish.photo ? (
                        <span className="relative size-16 shrink-0">
                          <button
                            type="button"
                            onClick={() => pickPhoto(dish.id)}
                            disabled={applying}
                            title="Swap photo"
                            className="img-frame relative block size-16 overflow-hidden rounded disabled:opacity-60"
                          >
                            <Image
                              src={dish.photo.src}
                              alt={dish.photo.alt}
                              fill
                              sizes="64px"
                              className="object-cover"
                            />
                          </button>
                          {/* The ✕ ON the picture — clearing it must not
                              require hunting for a button elsewhere, and it
                              works even while the dish is sold out. */}
                          <button
                            type="button"
                            aria-label={`Clear the picture of ${dish.name}`}
                            title="Clear picture"
                            disabled={applying}
                            onClick={() => removePhoto(dish.id)}
                            className="absolute -right-1.5 -top-1.5 flex size-6 items-center justify-center rounded-full border border-paper bg-ink font-mono text-[0.6875rem] font-bold leading-none text-paper disabled:opacity-40"
                          >
                            ✕
                          </button>
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => pickPhoto(dish.id)}
                          disabled={applying || isDraftId(dish.id)}
                          title={isDraftId(dish.id) ? 'Apply the tray first, then add a photo' : undefined}
                          className="flex size-16 shrink-0 flex-col items-center justify-center rounded border border-dashed border-hairline text-[0.625rem] font-bold uppercase tracking-wide text-ink-muted disabled:opacity-40"
                        >
                          + Photo
                        </button>
                      )}

                      <div className={dish.soldOut ? 'min-w-0 flex-1 opacity-60' : 'min-w-0 flex-1'}>
                        <div className="flex items-baseline justify-between gap-3">
                          <InlineEdit
                            value={dish.name}
                            placeholder="Dish name"
                            ariaLabel={`name of ${dish.name}`}
                            disabled={applying}
                            display={dish.name}
                            className="min-w-0 text-[1.0625rem] font-extrabold leading-tight tracking-[-0.01em]"
                            inputClassName="w-full min-h-9 rounded border border-hairline bg-paper px-2 text-[1.0625rem] font-extrabold"
                            onCommit={(next) => saveField(dish.id, 'name', next)}
                          />
                          <span className="flex shrink-0 items-center gap-2">
                            {dish.soldOut ? (
                              <span className="rounded border border-hairline px-1.5 py-0.5 font-mono text-[0.6875rem] font-bold uppercase tracking-wide text-ink-muted">
                                {HOLD_LABELS[dish.hold]}
                              </span>
                            ) : null}
                            <InlineEdit
                              value={dish.price}
                              placeholder="17.50"
                              ariaLabel={`price of ${dish.name}`}
                              disabled={applying}
                              display={
                                <span
                                  className={`font-mono text-[1.0625rem] font-bold tabular-nums ${
                                    dish.price === '' ? 'text-ink-muted' : ''
                                  }`}
                                >
                                  {priceLabel(dish.price)}
                                </span>
                              }
                              className=""
                              inputClassName="w-24 min-h-9 rounded border border-hairline bg-paper px-2 text-right font-mono text-[1.0625rem] font-bold tabular-nums"
                              onCommit={(next) => saveField(dish.id, 'price', next)}
                            />
                          </span>
                        </div>
                        <InlineEdit
                          value={dish.description}
                          placeholder="One line about it (optional)"
                          ariaLabel={`description of ${dish.name}`}
                          disabled={applying}
                          display={
                            dish.description ? (
                              <span className="text-[0.9375rem] leading-snug text-ink-muted">
                                {dish.description}
                              </span>
                            ) : (
                              <span className="text-sm italic text-ink-muted">add a line…</span>
                            )
                          }
                          className="mt-1 block max-w-[44ch]"
                          inputClassName="mt-1 block w-full min-h-9 rounded border border-hairline bg-paper px-2 text-[0.9375rem]"
                          onCommit={(next) => saveField(dish.id, 'description', next)}
                        />
                      </div>
                    </div>

                    <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-hairline pt-2">
                      <span className="flex items-center gap-1">
                        <button
                          type="button"
                          aria-label={`Move ${dish.name} up`}
                          disabled={applying || dishIndex === 0}
                          onClick={() => moveDish(dish, 'up')}
                          className="min-h-8 max-lg:min-h-11 min-w-8 rounded border border-hairline font-mono text-xs font-bold text-ink-muted disabled:opacity-30"
                        >
                          ↑
                        </button>
                        <button
                          type="button"
                          aria-label={`Move ${dish.name} down`}
                          disabled={applying || dishIndex === group.dishes.length - 1}
                          onClick={() => moveDish(dish, 'down')}
                          className="min-h-8 max-lg:min-h-11 min-w-8 rounded border border-hairline font-mono text-xs font-bold text-ink-muted disabled:opacity-30"
                        >
                          ↓
                        </button>
                        {dish.soldOut ? (
                          HOLD_CHOICES.map((choice) => (
                            <button
                              key={choice.value}
                              type="button"
                              aria-pressed={dish.hold === choice.value}
                              onClick={() => setSoldOut(dish.id, true, choice.value)}
                              className={`min-h-8 max-lg:min-h-11 rounded border px-2 text-xs font-bold uppercase ${
                                dish.hold === choice.value
                                  ? 'border-ink bg-ink text-paper'
                                  : 'border-hairline text-ink-muted'
                              }`}
                            >
                              {choice.label}
                            </button>
                          ))
                        ) : (
                          <>
                            {dish.photo ? (
                              <button
                                type="button"
                                disabled={applying}
                                onClick={() => removePhoto(dish.id)}
                                className="min-h-8 max-lg:min-h-11 rounded border border-hairline px-2 text-xs font-bold uppercase text-ink-muted disabled:opacity-60"
                              >
                                Clear picture
                              </button>
                            ) : null}
                            <button
                              type="button"
                              disabled={applying}
                              onClick={() => removeDish(dish)}
                              className="min-h-8 max-lg:min-h-11 rounded border border-hairline px-2 text-xs font-bold uppercase text-ink-muted disabled:opacity-60"
                            >
                              Remove dish
                            </button>
                          </>
                        )}
                      </span>
                      <label className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-ink-muted">
                        Sold out
                        <button
                          type="button"
                          role="switch"
                          aria-checked={dish.soldOut}
                          aria-label={`Mark ${dish.name} sold out`}
                          disabled={applying || isDraftId(dish.id)}
                          title={isDraftId(dish.id) ? 'Apply the tray first' : undefined}
                          onClick={() =>
                            setSoldOut(dish.id, !dish.soldOut, dish.soldOut ? dish.hold : 'tonight')
                          }
                          className={`relative h-7 w-12 rounded-full border transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] disabled:opacity-40 max-lg:before:absolute max-lg:before:-inset-x-1 max-lg:before:-inset-y-2.5 max-lg:before:content-[''] ${
                            dish.soldOut ? 'border-amber bg-amber' : 'border-hairline bg-paper'
                          }`}
                        >
                          <span
                            aria-hidden
                            className={`absolute top-0.5 size-5 rounded-full bg-ink transition-[left] duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                              dish.soldOut ? 'left-6' : 'left-0.5'
                            }`}
                          />
                        </button>
                      </label>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* A new board. Its link-name is minted from this first title
              when the tray applies, and never changes after. */}
          {addingBoard ? (
            <div className="flex flex-wrap items-center gap-2 border-t border-hairline pt-4">
              <input
                autoFocus
                aria-label="New board name"
                placeholder="Desserts"
                maxLength={40}
                value={newBoardName}
                onChange={(event) => setNewBoardName(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter') addBoard()
                  if (event.key === 'Escape') {
                    setAddingBoard(false)
                    setNewBoardName('')
                  }
                }}
                className="min-h-11 w-56 rounded border border-hairline bg-paper px-3 font-bold"
              />
              <button
                type="button"
                onClick={addBoard}
                className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper"
              >
                Add it
              </button>
              <button
                type="button"
                onClick={() => {
                  setAddingBoard(false)
                  setNewBoardName('')
                }}
                className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted"
              >
                Never mind
              </button>
            </div>
          ) : (
            <div className="border-t border-hairline pt-4">
              <button
                type="button"
                disabled={applying}
                onClick={() => setAddingBoard(true)}
                className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
              >
                + Add board
              </button>
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={discarding}
        onOpenChange={setDiscarding}
        title="Throw away these changes?"
        body={`${pending.length} unapplied change${pending.length === 1 ? '' : 's'} in the tray. The site never saw them; the paper goes back to how the site has it.`}
        confirmLabel="Throw them away"
        onConfirm={() => {
          discardAll()
          setDiscarding(false)
        }}
      />
    </section>
  )
}
