'use client'

import { useRef, useState } from 'react'
import Image from 'next/image'
import type { HoldUntil } from '@prisma/client'
import { RowText } from '@/components/menu/menu-category'
import { adminMutate } from '@/lib/admin/mutate'
import type { MenuItem } from '@/lib/menu'
import { HOLD_CHOICES, HOLD_LABELS } from '@/lib/overlay-shared'

// THE MENU PREVIEW (contract §Back of House amendment, client feedback
// 2026-09-22): the site's own menu, rendered in .scene-paper INSIDE the
// station — the owner edits the material the customer sees, the same
// device as the note and specials previews. Each ticket carries its own
// 86 switch, hold chips, and photo slot. Names and prices render through
// the SAME RowText the public page uses and are not editable here — the
// overlay boundary (veto 4/5) is visible, not just documented.

export interface PreviewDish {
  itemKey: string
  item: MenuItem
  soldOut: boolean
  hold: HoldUntil
  photo: { src: string; alt: string } | null
  hasCodePhoto: boolean
}

export interface PreviewGroup {
  categoryId: string
  title: string
  dishes: PreviewDish[]
}

type DishState = Record<
  string,
  { soldOut: boolean; hold: HoldUntil; photo: { src: string; alt: string } | null; busy: boolean }
>

export function MenuPreview({ groups, orphans }: { groups: PreviewGroup[]; orphans: string[] }) {
  const [state, setState] = useState<DishState>(() => {
    const map: DishState = {}
    for (const group of groups) {
      for (const dish of group.dishes) {
        map[dish.itemKey] = {
          soldOut: dish.soldOut,
          hold: dish.hold,
          photo: dish.photo,
          busy: false,
        }
      }
    }
    return map
  })
  const [orphanKeys, setOrphanKeys] = useState(orphans)
  const [message, setMessage] = useState<string | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const uploadTarget = useRef<string | null>(null)

  function patch(itemKey: string, partial: Partial<DishState[string]>) {
    setState((current) => ({ ...current, [itemKey]: { ...current[itemKey], ...partial } }))
  }

  async function setEightySix(itemKey: string, soldOut: boolean, hold: HoldUntil) {
    const before = state[itemKey]
    patch(itemKey, { soldOut, hold, busy: true })
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey, soldOut, hold }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage(soldOut ? 'Live on the site' : 'Back on')
    } catch {
      patch(itemKey, { soldOut: before.soldOut, hold: before.hold })
      setMessage('That did not stick. Refresh and retry.')
    } finally {
      patch(itemKey, { busy: false })
    }
  }

  function pickPhoto(itemKey: string) {
    uploadTarget.current = itemKey
    fileInput.current?.click()
  }

  async function onFileChosen(event: React.ChangeEvent<HTMLInputElement>) {
    const itemKey = uploadTarget.current
    const file = event.target.files?.[0]
    event.target.value = '' // same file can be picked twice in a row
    if (!itemKey || !file) return
    if (file.size > 4 * 1024 * 1024) {
      setMessage('That photo is over 4MB. Send a smaller one.')
      return
    }
    patch(itemKey, { busy: true })
    setMessage(null)
    try {
      const form = new FormData()
      form.set('itemKey', itemKey)
      form.set('file', file)
      const res = await adminMutate('/api/admin/dish-photo', { body: form })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; photo?: { src: string; alt: string } }
        | null
      if (!res.ok || data?.ok !== true || !data.photo) {
        setMessage(data?.message ?? 'That upload did not stick. Try it again.')
        return
      }
      patch(itemKey, { photo: data.photo })
      setMessage('Photo is live on the site')
    } catch {
      setMessage('That upload did not stick. Try it again.')
    } finally {
      patch(itemKey, { busy: false })
    }
  }

  async function removePhoto(itemKey: string) {
    const before = state[itemKey]
    patch(itemKey, { photo: null, busy: true })
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/dish-photo', {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage('Photo removed')
    } catch {
      patch(itemKey, { photo: before.photo })
      setMessage('That did not stick. Refresh and retry.')
    } finally {
      patch(itemKey, { busy: false })
    }
  }

  async function clearOrphan(itemKey: string) {
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey, soldOut: false }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setOrphanKeys((keys) => keys.filter((key) => key !== itemKey))
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  return (
    <section aria-label="The menu, as the site shows it">
      <input
        ref={fileInput}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={onFileChosen}
      />

      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">The menu, as customers see it</h2>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>
      <p className="mt-1 max-w-[62ch] text-sm text-ink-muted">
        Tap a photo slot to add or swap a dish shot; the switch takes a dish
        off tonight. Names and prices are the printed menu — they do not
        change from here.
      </p>

      {orphanKeys.length > 0 ? (
        <div className="mt-3 rounded border-2 border-ink p-3">
          <p className="text-sm font-bold">
            These marks point at dishes no longer on the printed menu. The page
            already ignores them — clear them here.
          </p>
          <ul className="mt-2 flex flex-col gap-1">
            {orphanKeys.map((key) => (
              <li key={key} className="flex items-center justify-between gap-3">
                <span className="font-mono text-sm">{key}</span>
                <button
                  type="button"
                  onClick={() => clearOrphan(key)}
                  className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase"
                >
                  Clear
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {/* The paper: the same material the customer holds. */}
      <div className="scene-paper mt-3 rounded-lg border border-hairline p-4 md:p-5">
        <div className="flex flex-col gap-6">
          {groups.map((group) => (
            <div key={group.categoryId}>
              <h3 className="font-display text-h2 uppercase leading-[0.95]">{group.title}</h3>
              <ul className="mt-3 grid gap-2 md:grid-cols-2 2xl:grid-cols-3">
                {group.dishes.map((dish) => {
                  const current = state[dish.itemKey]
                  const mark = current.soldOut ? HOLD_LABELS[current.hold] : undefined
                  return (
                    <li
                      key={dish.itemKey}
                      className="overflow-hidden rounded-lg border border-hairline bg-surface px-4 py-3"
                    >
                      <div className="flex items-start gap-3">
                        {current.photo ? (
                          <button
                            type="button"
                            disabled={current.busy}
                            onClick={() => pickPhoto(dish.itemKey)}
                            title="Swap photo"
                            className="img-frame relative size-16 shrink-0 overflow-hidden rounded"
                          >
                            <Image
                              src={current.photo.src}
                              alt={current.photo.alt}
                              fill
                              sizes="64px"
                              className="object-cover"
                            />
                          </button>
                        ) : (
                          <button
                            type="button"
                            disabled={current.busy}
                            onClick={() => pickPhoto(dish.itemKey)}
                            className="flex size-16 shrink-0 flex-col items-center justify-center rounded border border-dashed border-hairline text-[0.625rem] font-bold uppercase tracking-wide text-ink-muted"
                          >
                            {dish.hasCodePhoto ? 'Swap' : '+ Photo'}
                          </button>
                        )}
                        <RowText item={dish.item} mark={mark} />
                      </div>

                      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-hairline pt-2">
                        <span className="flex items-center gap-1">
                          {current.soldOut
                            ? HOLD_CHOICES.map((choice) => (
                                <button
                                  key={choice.value}
                                  type="button"
                                  aria-pressed={current.hold === choice.value}
                                  disabled={current.busy}
                                  onClick={() => setEightySix(dish.itemKey, true, choice.value)}
                                  className={`min-h-8 rounded border px-2 text-xs font-bold uppercase ${
                                    current.hold === choice.value
                                      ? 'border-ink bg-ink text-paper'
                                      : 'border-hairline text-ink-muted'
                                  }`}
                                >
                                  {choice.label}
                                </button>
                              ))
                            : current.photo ? (
                                <button
                                  type="button"
                                  disabled={current.busy}
                                  onClick={() => removePhoto(dish.itemKey)}
                                  className="min-h-8 rounded border border-hairline px-2 text-xs font-bold uppercase text-ink-muted"
                                >
                                  Remove photo
                                </button>
                              ) : null}
                        </span>
                        <label className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-ink-muted">
                          86
                          <button
                            type="button"
                            role="switch"
                            aria-checked={current.soldOut}
                            aria-label={`86 ${dish.item.name}`}
                            disabled={current.busy}
                            onClick={() =>
                              setEightySix(
                                dish.itemKey,
                                !current.soldOut,
                                current.soldOut ? current.hold : 'tonight',
                              )
                            }
                            className={`relative h-7 w-12 rounded-full border transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                              current.soldOut ? 'border-amber bg-amber' : 'border-hairline bg-paper'
                            }`}
                          >
                            <span
                              aria-hidden
                              className={`absolute top-0.5 size-5 rounded-full bg-ink transition-[left] duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                                current.soldOut ? 'left-6' : 'left-0.5'
                              }`}
                            />
                          </button>
                        </label>
                      </div>
                    </li>
                  )
                })}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
