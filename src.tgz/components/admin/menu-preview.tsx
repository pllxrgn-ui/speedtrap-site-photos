'use client'

import { useRef, useState } from 'react'
import Image from 'next/image'
import type { HoldUntil } from '@prisma/client'
import { ConfirmDialog } from '@/components/admin/confirm-dialog'
import { adminMutate } from '@/lib/admin/mutate'
import { HOLD_CHOICES, HOLD_LABELS } from '@/lib/overlay-shared'

// THE MENU EDITOR (build/09 owner's-word regime; contract §Back of House).
// The site's menu on its own paper, and every word of it is the control:
// tap a name, price or description to change it, tap + to add a dish,
// SOLD OUT to 86 one, the photo slot to dress one. Every change is a
// MenuEvent ledger row server-side and is live on the public page on the
// very next request. Prices are typed as money ("17.50") and stored as
// integer cents - never a float, never a guess.

export interface PreviewDish {
  id: string
  name: string
  description: string
  price: string // display form: "17.50" or "" for none
  soldOut: boolean
  hold: HoldUntil
  photo: { src: string; alt: string } | null
}

export interface PreviewGroup {
  categoryId: string
  title: string
  note: string
  dishes: PreviewDish[]
}

function priceLabel(price: string): string {
  return price === '' ? 'no price' : `$${price}`
}

// One editable span: renders as the menu, edits on tap, commits on Enter
// or blur, Escape restores. Kept dumb - the parent owns saving.
function InlineEdit({
  value,
  placeholder,
  ariaLabel,
  display,
  className,
  inputClassName,
  onCommit,
}: {
  value: string
  placeholder: string
  ariaLabel: string
  display: React.ReactNode
  className: string
  inputClassName: string
  onCommit: (next: string) => void
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value)

  if (!editing) {
    return (
      <button
        type="button"
        aria-label={`Edit ${ariaLabel}`}
        title={`Tap to edit ${ariaLabel}`}
        onClick={() => {
          setDraft(value)
          setEditing(true)
        }}
        className={`${className} rounded text-left decoration-dotted underline-offset-4 hover:underline`}
      >
        {display}
      </button>
    )
  }
  return (
    <input
      autoFocus
      aria-label={ariaLabel}
      value={draft}
      placeholder={placeholder}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={() => {
        setEditing(false)
        if (draft !== value) onCommit(draft)
      }}
      onKeyDown={(event) => {
        if (event.key === 'Enter') (event.target as HTMLInputElement).blur()
        if (event.key === 'Escape') {
          setDraft(value)
          setEditing(false)
        }
      }}
      className={inputClassName}
    />
  )
}

export function MenuPreview({ groups, orphans }: { groups: PreviewGroup[]; orphans: string[] }) {
  const [boards, setBoards] = useState(groups)
  const [orphanKeys, setOrphanKeys] = useState(orphans)
  const [message, setMessage] = useState<string | null>(null)
  const [removing, setRemoving] = useState<PreviewDish | null>(null)
  const [removingBoard, setRemovingBoard] = useState<PreviewGroup | null>(null)
  const [addingBoard, setAddingBoard] = useState(false)
  const [newBoardName, setNewBoardName] = useState('')
  const fileInput = useRef<HTMLInputElement>(null)
  const uploadTarget = useRef<string | null>(null)

  function patchDish(id: string, partial: Partial<PreviewDish>) {
    setBoards((current) =>
      current.map((group) => ({
        ...group,
        dishes: group.dishes.map((dish) => (dish.id === id ? { ...dish, ...partial } : dish)),
      })),
    )
  }

  function findDish(id: string): PreviewDish | undefined {
    for (const group of boards) {
      const dish = group.dishes.find((candidate) => candidate.id === id)
      if (dish) return dish
    }
    return undefined
  }

  async function saveField(id: string, field: 'name' | 'description' | 'price', next: string) {
    const before = findDish(id)
    if (!before) return
    patchDish(id, { [field]: field === 'price' ? next.trim().replace(/^\$/, '') : next } as Partial<PreviewDish>)
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/menu/${id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ [field]: next }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; dish?: { name: string; description: string | null; priceCents: number | null } }
        | null
      if (!res.ok || data?.ok !== true || !data.dish) {
        patchDish(id, { [field]: before[field] } as Partial<PreviewDish>)
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      // The server's parse is the truth (it normalises "$17.5" -> 17.50).
      patchDish(id, {
        name: data.dish.name,
        description: data.dish.description ?? '',
        price: data.dish.priceCents === null ? '' : (data.dish.priceCents / 100).toFixed(2),
      })
      setMessage('Live on the site')
    } catch {
      patchDish(id, { [field]: before[field] } as Partial<PreviewDish>)
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function addDish(categoryId: string) {
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/menu', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ categoryId }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; dish?: { id: string; name: string } }
        | null
      if (!res.ok || data?.ok !== true || !data.dish) {
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      const dish: PreviewDish = {
        id: data.dish.id,
        name: data.dish.name,
        description: '',
        price: '',
        soldOut: false,
        hold: 'tonight',
        photo: null,
      }
      setBoards((current) =>
        current.map((group) =>
          group.categoryId === categoryId ? { ...group, dishes: [...group.dishes, dish] } : group,
        ),
      )
      setMessage('Added - tap the name to rename it')
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function removeDish(dish: PreviewDish) {
    const before = boards
    setBoards((current) =>
      current.map((group) => ({
        ...group,
        dishes: group.dishes.filter((candidate) => candidate.id !== dish.id),
      })),
    )
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/menu/${dish.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      setMessage(`${dish.name} removed`)
    } catch {
      setBoards(before)
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function setSoldOut(id: string, soldOut: boolean, hold: HoldUntil) {
    const before = findDish(id)
    if (!before) return
    patchDish(id, { soldOut, hold })
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey: id, soldOut, hold }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage(soldOut ? 'Live on the site' : 'Back on')
    } catch {
      patchDish(id, { soldOut: before.soldOut, hold: before.hold })
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function moveDish(dish: PreviewDish, direction: 'up' | 'down') {
    const before = boards
    // Optimistic adjacent swap — exactly what the server does to sortIndex.
    setBoards((current) =>
      current.map((group) => {
        const index = group.dishes.findIndex((candidate) => candidate.id === dish.id)
        if (index === -1) return group
        const target = direction === 'up' ? index - 1 : index + 1
        if (target < 0 || target >= group.dishes.length) return group
        const dishes = [...group.dishes]
        ;[dishes[index], dishes[target]] = [dishes[target], dishes[index]]
        return { ...group, dishes }
      }),
    )
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/menu/${dish.id}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ move: direction }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage('New order is live on the site')
    } catch {
      setBoards(before)
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function saveBoardField(categoryId: string, field: 'title' | 'note', next: string) {
    const board = boards.find((group) => group.categoryId === categoryId)
    if (!board) return
    const beforeValue = field === 'title' ? board.title : board.note
    setBoards((current) =>
      current.map((group) =>
        group.categoryId === categoryId ? { ...group, [field]: next } : group,
      ),
    )
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/boards/${categoryId}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ [field]: next }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; board?: { title: string; note: string | null } }
        | null
      if (!res.ok || data?.ok !== true || !data.board) {
        setBoards((current) =>
          current.map((group) =>
            group.categoryId === categoryId ? { ...group, [field]: beforeValue } : group,
          ),
        )
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      setBoards((current) =>
        current.map((group) =>
          group.categoryId === categoryId
            ? { ...group, title: data.board!.title, note: data.board!.note ?? '' }
            : group,
        ),
      )
      setMessage('Live on the site')
    } catch {
      setBoards((current) =>
        current.map((group) =>
          group.categoryId === categoryId ? { ...group, [field]: beforeValue } : group,
        ),
      )
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function moveBoard(categoryId: string, direction: 'up' | 'down') {
    const before = boards
    const index = boards.findIndex((group) => group.categoryId === categoryId)
    const target = direction === 'up' ? index - 1 : index + 1
    if (index === -1 || target < 0 || target >= boards.length) return
    setBoards((current) => {
      const next = [...current]
      ;[next[index], next[target]] = [next[target], next[index]]
      return next
    })
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/boards/${categoryId}`, {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ move: direction }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage('New order is live on the site')
    } catch {
      setBoards(before)
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function addBoard() {
    const title = newBoardName.trim()
    if (!title) {
      setAddingBoard(false)
      return
    }
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/boards', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ title }),
      })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; board?: { id: string; title: string; note: string | null } }
        | null
      if (!res.ok || data?.ok !== true || !data.board) {
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      setBoards((current) => [
        ...current,
        { categoryId: data.board!.id, title: data.board!.title, note: data.board!.note ?? '', dishes: [] },
      ])
      setAddingBoard(false)
      setNewBoardName('')
      setMessage('Board added - it shows on the site once it has a dish')
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function removeBoard(board: PreviewGroup) {
    const before = boards
    setBoards((current) => current.filter((group) => group.categoryId !== board.categoryId))
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/boards/${board.categoryId}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(String(res.status))
      setMessage(`${board.title} removed`)
    } catch {
      setBoards(before)
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  function pickPhoto(id: string) {
    uploadTarget.current = id
    fileInput.current?.click()
  }

  async function onFileChosen(event: React.ChangeEvent<HTMLInputElement>) {
    const id = uploadTarget.current
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!id || !file) return
    if (file.size > 4 * 1024 * 1024) {
      setMessage('That photo is over 4MB. Send a smaller one.')
      return
    }
    setMessage(null)
    try {
      const form = new FormData()
      form.set('itemKey', id)
      form.set('file', file)
      const res = await adminMutate('/api/admin/dish-photo', { body: form })
      const data = (await res.json().catch(() => null)) as
        | { ok?: boolean; message?: string; photo?: { src: string; alt: string } }
        | null
      if (!res.ok || data?.ok !== true || !data.photo) {
        setMessage(data?.message ?? 'That upload did not stick. Try it again.')
        return
      }
      patchDish(id, { photo: data.photo })
      setMessage('Photo is live on the site')
    } catch {
      setMessage('That upload did not stick. Try it again.')
    }
  }

  async function removePhoto(id: string) {
    const before = findDish(id)
    patchDish(id, { photo: null })
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/dish-photo', {
        method: 'DELETE',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey: id }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setMessage('Photo removed')
    } catch {
      if (before) patchDish(id, { photo: before.photo })
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  async function clearOrphan(itemKey: string) {
    try {
      const res = await adminMutate('/api/admin/menu-state', {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ itemKey, soldOut: false }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setOrphanKeys((keys) => keys.filter((key) => key !== itemKey))
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    }
  }

  return (
    <section aria-label="The menu, as the site shows it">
      <input
        ref={fileInput}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={onFileChosen}
      />

      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">The menu, live</h2>
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>
      <p className="mt-1 max-w-[70ch] text-sm text-ink-muted">
        This IS the menu customers see. Tap any word — a board name, a dish,
        a price — to change it; the arrows move things; + adds a dish or a
        whole board; the photo slot dresses a dish. The SOLD OUT switch
        takes a dish off for a while — Tonight comes back on its own
        tomorrow, This week lasts seven days, Until I clear it waits for
        you. Every change is logged.
      </p>

      {orphanKeys.length > 0 ? (
        <div className="mt-3 rounded border-2 border-ink p-3">
          <p className="text-sm font-bold">
            Leftover marks from removed dishes. The page already ignores them —
            clear them here.
          </p>
          <ul className="mt-2 flex flex-col gap-1">
            {orphanKeys.map((key) => (
              <li key={key} className="flex items-center justify-between gap-3">
                <span className="font-mono text-sm">{key}</span>
                <button
                  type="button"
                  onClick={() => clearOrphan(key)}
                  className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase"
                >
                  Clear
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {/* The paper: the same material the customer holds. */}
      <div className="scene-paper mt-3 rounded-lg border border-hairline p-4 md:p-5">
        <div className="flex flex-col gap-6">
          {boards.map((group, groupIndex) => (
            <div key={group.categoryId}>
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                {/* The InlineEdit button lives INSIDE the h3 so the board
                    keeps its heading for screen-reader navigation. */}
                <h3 className="min-w-0">
                  <InlineEdit
                    value={group.title}
                    placeholder="Board name"
                    ariaLabel={`name of the ${group.title} board`}
                    display={
                      <span className="font-display text-h2 uppercase leading-[0.95]">
                        {group.title}
                      </span>
                    }
                    className="min-w-0"
                    inputClassName="w-full min-h-10 rounded border border-hairline bg-paper px-2 font-display text-h2 uppercase"
                    onCommit={(next) => saveBoardField(group.categoryId, 'title', next)}
                  />
                </h3>
                <span className="flex shrink-0 items-center gap-1">
                  <button
                    type="button"
                    aria-label={`Move ${group.title} up`}
                    disabled={groupIndex === 0}
                    onClick={() => moveBoard(group.categoryId, 'up')}
                    className="tap-feedback min-h-11 min-w-11 rounded border border-hairline font-mono text-sm font-bold disabled:opacity-30"
                  >
                    ↑
                  </button>
                  <button
                    type="button"
                    aria-label={`Move ${group.title} down`}
                    disabled={groupIndex === boards.length - 1}
                    onClick={() => moveBoard(group.categoryId, 'down')}
                    className="tap-feedback min-h-11 min-w-11 rounded border border-hairline font-mono text-sm font-bold disabled:opacity-30"
                  >
                    ↓
                  </button>
                  {group.dishes.length === 0 ? (
                    <button
                      type="button"
                      onClick={() => setRemovingBoard(group)}
                      className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted"
                    >
                      Remove board
                    </button>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => addDish(group.categoryId)}
                    className="tap-feedback min-h-11 shrink-0 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight"
                  >
                    + Add dish
                  </button>
                </span>
              </div>
              <InlineEdit
                value={group.note}
                placeholder="A line under the board name (optional)"
                ariaLabel={`note under ${group.title}`}
                display={
                  group.note ? (
                    <span className="text-sm text-ink-muted">{group.note}</span>
                  ) : (
                    <span className="text-sm italic text-ink-muted">add a line under the name…</span>
                  )
                }
                className="mt-1 block max-w-[60ch]"
                inputClassName="mt-1 block w-full min-h-9 rounded border border-hairline bg-paper px-2 text-sm"
                onCommit={(next) => saveBoardField(group.categoryId, 'note', next)}
              />
              {group.dishes.length === 0 ? (
                <p className="mt-2 text-sm italic text-ink-muted">
                  Empty — the site hides this board until it has a dish.
                </p>
              ) : null}
              <ul className="mt-3 grid gap-2 md:grid-cols-2 2xl:grid-cols-3">
                {group.dishes.map((dish, dishIndex) => (
                  <li
                    key={dish.id}
                    className="overflow-hidden rounded-lg border border-hairline bg-surface px-4 py-3"
                  >
                    <div className="flex items-start gap-3">
                      {dish.photo ? (
                        <button
                          type="button"
                          onClick={() => pickPhoto(dish.id)}
                          title="Swap photo"
                          className="img-frame relative size-16 shrink-0 overflow-hidden rounded"
                        >
                          <Image
                            src={dish.photo.src}
                            alt={dish.photo.alt}
                            fill
                            sizes="64px"
                            className="object-cover"
                          />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => pickPhoto(dish.id)}
                          className="flex size-16 shrink-0 flex-col items-center justify-center rounded border border-dashed border-hairline text-[0.625rem] font-bold uppercase tracking-wide text-ink-muted"
                        >
                          + Photo
                        </button>
                      )}

                      <div className={dish.soldOut ? 'min-w-0 flex-1 opacity-60' : 'min-w-0 flex-1'}>
                        <div className="flex items-baseline justify-between gap-3">
                          <InlineEdit
                            value={dish.name}
                            placeholder="Dish name"
                            ariaLabel={`name of ${dish.name}`}
                            display={dish.name}
                            className="min-w-0 text-[1.0625rem] font-extrabold leading-tight tracking-[-0.01em]"
                            inputClassName="w-full min-h-9 rounded border border-hairline bg-paper px-2 text-[1.0625rem] font-extrabold"
                            onCommit={(next) => saveField(dish.id, 'name', next)}
                          />
                          <span className="flex shrink-0 items-center gap-2">
                            {dish.soldOut ? (
                              <span className="rounded border border-hairline px-1.5 py-0.5 font-mono text-[0.6875rem] font-bold uppercase tracking-wide text-ink-muted">
                                {HOLD_LABELS[dish.hold]}
                              </span>
                            ) : null}
                            <InlineEdit
                              value={dish.price}
                              placeholder="17.50"
                              ariaLabel={`price of ${dish.name}`}
                              display={
                                <span
                                  className={`font-mono text-[1.0625rem] font-bold tabular-nums ${
                                    dish.price === '' ? 'text-ink-muted' : ''
                                  }`}
                                >
                                  {priceLabel(dish.price)}
                                </span>
                              }
                              className=""
                              inputClassName="w-24 min-h-9 rounded border border-hairline bg-paper px-2 text-right font-mono text-[1.0625rem] font-bold tabular-nums"
                              onCommit={(next) => saveField(dish.id, 'price', next)}
                            />
                          </span>
                        </div>
                        <InlineEdit
                          value={dish.description}
                          placeholder="One line about it (optional)"
                          ariaLabel={`description of ${dish.name}`}
                          display={
                            dish.description ? (
                              <span className="text-[0.9375rem] leading-snug text-ink-muted">
                                {dish.description}
                              </span>
                            ) : (
                              <span className="text-sm italic text-ink-muted">add a line…</span>
                            )
                          }
                          className="mt-1 block max-w-[44ch]"
                          inputClassName="mt-1 block w-full min-h-9 rounded border border-hairline bg-paper px-2 text-[0.9375rem]"
                          onCommit={(next) => saveField(dish.id, 'description', next)}
                        />
                      </div>
                    </div>

                    <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-hairline pt-2">
                      <span className="flex items-center gap-1">
                        <button
                          type="button"
                          aria-label={`Move ${dish.name} up`}
                          disabled={dishIndex === 0}
                          onClick={() => moveDish(dish, 'up')}
                          className="min-h-8 min-w-8 rounded border border-hairline font-mono text-xs font-bold text-ink-muted disabled:opacity-30"
                        >
                          ↑
                        </button>
                        <button
                          type="button"
                          aria-label={`Move ${dish.name} down`}
                          disabled={dishIndex === group.dishes.length - 1}
                          onClick={() => moveDish(dish, 'down')}
                          className="min-h-8 min-w-8 rounded border border-hairline font-mono text-xs font-bold text-ink-muted disabled:opacity-30"
                        >
                          ↓
                        </button>
                        {dish.soldOut ? (
                          HOLD_CHOICES.map((choice) => (
                            <button
                              key={choice.value}
                              type="button"
                              aria-pressed={dish.hold === choice.value}
                              onClick={() => setSoldOut(dish.id, true, choice.value)}
                              className={`min-h-8 rounded border px-2 text-xs font-bold uppercase ${
                                dish.hold === choice.value
                                  ? 'border-ink bg-ink text-paper'
                                  : 'border-hairline text-ink-muted'
                              }`}
                            >
                              {choice.label}
                            </button>
                          ))
                        ) : (
                          <>
                            {dish.photo ? (
                              <button
                                type="button"
                                onClick={() => removePhoto(dish.id)}
                                className="min-h-8 rounded border border-hairline px-2 text-xs font-bold uppercase text-ink-muted"
                              >
                                Remove photo
                              </button>
                            ) : null}
                            <button
                              type="button"
                              onClick={() => setRemoving(dish)}
                              className="min-h-8 rounded border border-hairline px-2 text-xs font-bold uppercase text-ink-muted"
                            >
                              Remove dish
                            </button>
                          </>
                        )}
                      </span>
                      <label className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-ink-muted">
                        Sold out
                        <button
                          type="button"
                          role="switch"
                          aria-checked={dish.soldOut}
                          aria-label={`Mark ${dish.name} sold out`}
                          onClick={() =>
                            setSoldOut(dish.id, !dish.soldOut, dish.soldOut ? dish.hold : 'tonight')
                          }
                          className={`relative h-7 w-12 rounded-full border transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                            dish.soldOut ? 'border-amber bg-amber' : 'border-hairline bg-paper'
                          }`}
                        >
                          <span
                            aria-hidden
                            className={`absolute top-0.5 size-5 rounded-full bg-ink transition-[left] duration-[var(--dur-state)] ease-[var(--ease-hover)] ${
                              dish.soldOut ? 'left-6' : 'left-0.5'
                            }`}
                          />
                        </button>
                      </label>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* A new board. Its link-name is minted from this first title and
              never changes after — renames are always safe. */}
          {addingBoard ? (
            <div className="flex flex-wrap items-center gap-2 border-t border-hairline pt-4">
              <input
                autoFocus
                aria-label="New board name"
                placeholder="Desserts"
                maxLength={40}
                value={newBoardName}
                onChange={(event) => setNewBoardName(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter') addBoard()
                  if (event.key === 'Escape') {
                    setAddingBoard(false)
                    setNewBoardName('')
                  }
                }}
                className="min-h-11 w-56 rounded border border-hairline bg-paper px-3 font-bold"
              />
              <button
                type="button"
                onClick={addBoard}
                className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper"
              >
                Add it
              </button>
              <button
                type="button"
                onClick={() => {
                  setAddingBoard(false)
                  setNewBoardName('')
                }}
                className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted"
              >
                Never mind
              </button>
            </div>
          ) : (
            <div className="border-t border-hairline pt-4">
              <button
                type="button"
                onClick={() => setAddingBoard(true)}
                className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight"
              >
                + Add board
              </button>
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={removingBoard !== null}
        onOpenChange={(open) => {
          if (!open) setRemovingBoard(null)
        }}
        title="Remove this board?"
        body={
          removingBoard
            ? `${removingBoard.title} comes off the menu. It is empty, so no dishes go with it. The change is logged by name.`
            : ''
        }
        confirmLabel="Remove it"
        onConfirm={() => {
          if (removingBoard) removeBoard(removingBoard)
          setRemovingBoard(null)
        }}
      />

      <ConfirmDialog
        open={removing !== null}
        onOpenChange={(open) => {
          if (!open) setRemoving(null)
        }}
        title="Remove this dish?"
        body={
          removing
            ? `${removing.name} comes off the menu everywhere - the site, its photo, its sold-out mark. The change is logged by name. It cannot be undone.`
            : ''
        }
        confirmLabel="Remove it"
        onConfirm={() => {
          if (removing) removeDish(removing)
          setRemoving(null)
        }}
      />
    </section>
  )
}
