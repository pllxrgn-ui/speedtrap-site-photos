import type { BookingStatus } from '@prisma/client'
import { STATUS_LABELS } from '@/lib/booking-status'

// Amber means "needs you" (contract §Back of House rule 3): NEW is the
// only amber thing on this screen. Everything settled goes quiet.
export function StatusPill({ status }: { status: BookingStatus }) {
  const tone =
    status === 'new'
      ? 'border-amber text-amber-ink'
      : status === 'confirmed'
        ? 'border-hairline text-ink'
        : 'border-hairline text-ink-muted'
  return (
    <span
      className={`inline-flex items-center rounded-full border px-3 py-1 font-display text-sm uppercase tracking-wide transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] ${tone}`}
    >
      {STATUS_LABELS[status]}
    </span>
  )
}
