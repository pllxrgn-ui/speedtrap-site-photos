'use client'

import { useState } from 'react'
import { adminMutate } from '@/lib/admin/mutate'

// Today's note: one 160-character line with a LIVE PREVIEW rendered in
// .scene-paper — the owner sees the actual material the customer sees
// (build/08 §4), not an abstraction of it. Expires overnight on its own.
export function BoardNote({ initial }: { initial: { body: string; published: boolean } }) {
  const [body, setBody] = useState(initial.body)
  const [published, setPublished] = useState(initial.published)
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function save(nextPublished: boolean) {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate('/api/admin/note', {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ body, published: nextPublished }),
      })
      const data = (await res.json().catch(() => null)) as { ok?: boolean; message?: string } | null
      if (!res.ok || data?.ok !== true) {
        setMessage(data?.message ?? 'That did not stick. Refresh and retry.')
        return
      }
      setPublished(nextPublished && body.trim().length > 0)
      setMessage(nextPublished && body.trim().length > 0 ? 'Live on the site' : 'Taken down')
    } catch {
      setMessage('That did not stick. Refresh and retry.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <section aria-label="Today's note" className="rounded-lg border border-hairline bg-surface p-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="font-display text-xl uppercase">Today&apos;s note</h2>
        <p className="font-mono text-xs uppercase tracking-widest text-ink-muted">
          clears itself overnight
        </p>
      </div>
      <textarea
        rows={2}
        maxLength={160}
        value={body}
        onChange={(event) => setBody(event.target.value)}
        className="mt-3 block w-full rounded border border-hairline bg-paper px-3 py-2"
        aria-label="Note text"
      />
      <p className="mt-1 text-right font-mono text-xs tabular-nums text-ink-muted">
        {body.length}/160
      </p>

      {body.trim() ? (
        <div className="scene-paper mt-2 rounded border border-hairline p-3">
          <p className="text-sm">
            <span className="mr-3 font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
              Today
            </span>
            <span className="font-bold">{body.trim()}</span>
          </p>
        </div>
      ) : null}

      <div className="mt-3 flex items-center gap-2">
        <button
          type="button"
          disabled={busy || body.trim().length === 0}
          onClick={() => save(true)}
          className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
        >
          {published ? 'Update' : 'Publish'}
        </button>
        {published ? (
          <button
            type="button"
            disabled={busy}
            onClick={() => save(false)}
            className="tap-feedback min-h-11 rounded border border-hairline px-4 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
          >
            Take down
          </button>
        ) : null}
        <p role="status" aria-live="polite" className="text-sm font-bold text-amber-ink">
          {message}
        </p>
      </div>
    </section>
  )
}
