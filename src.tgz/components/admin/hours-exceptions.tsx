'use client'

import { useState } from 'react'
import { noteClass, type StationNote } from '@/components/admin/station-message'
import { exceptionHours } from '@/lib/admin/hours-writes'
import { adminMutate } from '@/lib/admin/mutate'
import { exceptionSchema, labelBarDay, labelBarDayRange, spanEnd } from '@/lib/hours'

// CLOSING EARLY, OR CLOSED (build/13 section 4.2). The IMMEDIATE half of the
// screen: "closing at 8 tonight, private party" typed during service cannot
// queue behind an APPLY button, which is the SOLD OUT argument verbatim
// (build/09 addendum 3's first immediate exception).
//
// The list is OPTIMISTIC AND THEN AUTHORITATIVE: add, edit and remove update
// it from the RESPONSE BODY, never from a guess. The response carries the
// saved row and any overlap warning, so the list and the warning can never
// disagree with what the database holds.
//
// TODAY IS THE SERVICE DAY, NOT THE CALENDAR DAY. `today` arrives as a prop
// computed by barServiceDay() on the server, so a row does not move to Past
// while the bar is still working that night - and nothing here reads the
// browser's clock, which would disagree with the site.
//
// WHICH MEANS `today` IS FIXED FOR THE LIFE OF THIS RENDER, on purpose:
// there is no timer and no interval re-classifying rows at 4am. A screen
// left open across the roll keeps last night's split until it is reloaded,
// which is the honest trade - a self-updating list would fight the server's
// own service day and start disagreeing with the public page. The page is
// force-dynamic, so any navigation back to it is already correct.

export interface ExceptionView {
  id: string
  date: string
  endDate: string | null
  closed: boolean
  open: string | null
  close: string | null
  label: string | null
}

interface DraftRow {
  id: string | null
  date: string
  endDate: string
  closed: boolean
  open: string
  close: string
  label: string
}

const EMPTY: DraftRow = {
  id: null,
  date: '',
  endDate: '',
  closed: true,
  open: '',
  close: '',
  label: '',
}

// The reason is owner-typed free text on a PUBLIC page. The booking note is
// private and the owner will assume symmetry, so the copy breaks that
// assumption out loud rather than leaving it to be discovered.
const LABEL_HINT =
  "Why, in a few words - 'private party', 'holiday'. This shows on the website, so no names or phone numbers."

const CONTROL =
  'min-h-11 w-full rounded border border-hairline bg-paper px-2 text-sm font-bold text-ink'

/** How many spent rows the panel shows before the expander. Every row past
 *  this one is one tap away - THE BOARD counts them all (finding 3). */
const PAST_AT_REST = 10

/** How a dated row names itself on the card: a range keeps both ends, a
 *  single date names its weekday, and today is TONIGHT. */
function eyebrow(row: ExceptionView, today: string): string {
  const end = spanEnd(row)
  if (end !== row.date) return labelBarDayRange(row.date, end)
  return row.date === today ? 'Tonight' : labelBarDay(row.date)
}

function toDraft(row: ExceptionView): DraftRow {
  return {
    id: row.id,
    date: row.date,
    endDate: row.endDate ?? '',
    closed: row.closed,
    open: row.open ?? '',
    close: row.close ?? '',
    label: row.label ?? '',
  }
}

export function HoursExceptions({
  initial,
  today,
}: {
  initial: ExceptionView[]
  today: string
}) {
  const [rows, setRows] = useState<ExceptionView[]>(initial)
  const [draft, setDraft] = useState<DraftRow>(EMPTY)
  const [message, setMessage] = useState<StationNote>(null)
  const [busy, setBusy] = useState(false)
  const [allPast, setAllPast] = useState(false)

  const upcoming = rows
    .filter((row) => spanEnd(row) >= today)
    .sort((a, b) => a.date.localeCompare(b.date))
  // Past rows are NOT auto-deleted (no cron, section 1.6). They stay amber,
  // naming the day they came from, until the owner taps Remove. Ten is
  // plenty of history at rest for a screen that is not THE LOG.
  //
  // BUT EVERY ONE OF THEM MUST BE REACHABLE (review round 1, finding 3).
  // THE BOARD's rail link goes amber on the count of ALL past rows, so if
  // the eleventh could not be reached it could not be removed either, and
  // the amber would be permanent with nothing on screen to clear it. Hence
  // the expander: the default is ten, the door to the rest is one tap, and
  // the two surfaces cannot disagree about what "needs you" means.
  const pastAll = rows
    .filter((row) => spanEnd(row) < today)
    .sort((a, b) => b.date.localeCompare(a.date))
  const past = allPast ? pastAll : pastAll.slice(0, PAST_AT_REST)

  function patch(next: Partial<DraftRow>) {
    setDraft((current) => ({ ...current, ...next }))
  }

  function report(data: { warning?: string } | null, done: string) {
    // The overlap sentence is not a failure, but it does mean READ THIS -
    // which is what amber means back here (section 1.9, contract rule 3).
    setMessage(data?.warning ? { text: data.warning, tone: 'amber' } : { text: done, tone: 'ok' })
  }

  async function save() {
    const body = {
      date: draft.date,
      endDate: draft.endDate === '' ? null : draft.endDate,
      closed: draft.closed,
      open: draft.closed || draft.open === '' ? null : draft.open,
      close: draft.closed || draft.close === '' ? null : draft.close,
      label: draft.label.trim() === '' ? null : draft.label.trim(),
    }

    // The client pre-validates against the SAME schema the route enforces
    // (section 5.1), so a refusal reads in the station's own register
    // instead of arriving as a 400 after a round trip.
    const parsed = exceptionSchema.safeParse(body)
    if (!parsed.success) {
      setMessage({
        text: parsed.error.issues[0]?.message ?? 'That date did not make sense.',
        tone: 'amber',
      })
      return
    }

    setBusy(true)
    setMessage(null)
    try {
      // encodeURIComponent at the CALL SITE (build/09's as-built scar: seed
      // ids carrying slashes went unencoded and every edit 404'd). cuid()
      // has no slash, so this is belt and braces.
      const res = await adminMutate(
        draft.id
          ? `/api/admin/hours/exceptions/${encodeURIComponent(draft.id)}`
          : '/api/admin/hours/exceptions',
        {
          method: draft.id ? 'PATCH' : 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        },
      )
      const data = (await res.json().catch(() => null)) as {
        ok?: boolean
        message?: string
        warning?: string
        row?: ExceptionView
      } | null

      if (!res.ok || data?.ok !== true || !data.row) {
        setMessage({
          text: data?.message ?? 'That did not stick. Refresh and retry.',
          tone: 'amber',
        })
        return
      }

      const saved = data.row
      setRows((current) =>
        current.some((row) => row.id === saved.id)
          ? current.map((row) => (row.id === saved.id ? saved : row))
          : [...current, saved],
      )
      setDraft(EMPTY)
      report(data, 'Live on the site.')
    } catch {
      setMessage({ text: 'That did not stick. Refresh and retry.', tone: 'amber' })
    } finally {
      setBusy(false)
    }
  }

  async function remove(id: string) {
    setBusy(true)
    setMessage(null)
    try {
      const res = await adminMutate(`/api/admin/hours/exceptions/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      })
      const data = (await res.json().catch(() => null)) as {
        ok?: boolean
        message?: string
      } | null
      if (!res.ok || data?.ok !== true) {
        setMessage({
          text: data?.message ?? 'That did not stick. Refresh and retry.',
          tone: 'amber',
        })
        return
      }
      setRows((current) => current.filter((row) => row.id !== id))
      if (draft.id === id) setDraft(EMPTY)
      setMessage({ text: 'Taken off the site.', tone: 'ok' })
    } catch {
      setMessage({ text: 'That did not stick. Refresh and retry.', tone: 'amber' })
    } finally {
      setBusy(false)
    }
  }

  function row(view: ExceptionView, ended: boolean) {
    return (
      <li
        key={view.id}
        className={`rounded border-l-2 bg-surface p-3 ${ended ? 'border-amber' : 'border-ink'}`}
      >
        <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
          <p className="min-w-0">
            <span
              className={`mr-3 font-mono text-xs font-bold uppercase tracking-widest ${
                ended ? 'text-amber-ink' : 'text-ink-muted'
              }`}
            >
              {eyebrow(view, today)}
            </span>
            {/* The clock half in Martian Mono (design rule 4: every numeral
                is mono, no exceptions); the owner's reason stays in the
                reading face, because it is a sentence and not a number. */}
            <span className="font-bold">
              <span className="font-mono tabular-nums">{exceptionHours(view)}</span>
              {view.label?.trim() ? ` - ${view.label.trim()}` : ''}
              {ended ? ' - ended' : ''}
            </span>
          </p>
          <span className="flex flex-wrap items-center gap-2">
            {ended ? null : (
              <button
                type="button"
                disabled={busy}
                onClick={() => setDraft(toDraft(view))}
                className="tap-feedback min-h-11 min-w-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
              >
                Edit
              </button>
            )}
            <button
              type="button"
              disabled={busy}
              onClick={() => remove(view.id)}
              className="tap-feedback min-h-11 min-w-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted disabled:opacity-60"
            >
              Remove
            </button>
          </span>
        </div>
      </li>
    )
  }

  return (
    <section
      aria-label="Closing early, or closed"
      className="rounded-lg border border-hairline bg-surface p-4 lg:min-w-0"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <h2 className="font-display text-xl uppercase">Closing early, or closed</h2>
        <p className="font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
          Live as you type
        </p>
      </div>

      <h3 className="mt-4 font-mono text-xs font-bold uppercase tracking-widest text-ink-muted">
        Coming up
      </h3>
      {upcoming.length > 0 ? (
        <ul className="mt-2 flex flex-col gap-2">{upcoming.map((view) => row(view, false))}</ul>
      ) : (
        <p className="mt-2 text-sm font-bold text-ink-muted">
          Nothing dated. The week above is what the site shows.
        </p>
      )}

      <div className="mt-4 rounded border border-dashed border-hairline p-3">
        <h3 className="font-display text-lg uppercase">
          {draft.id ? 'Edit this date' : '+ Add a date'}
        </h3>

        <div className="mt-2 flex flex-wrap gap-2">
          <label className="min-w-0 flex-1 text-sm font-bold">
            <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">Date</span>
            <input
              type="date"
              value={draft.date}
              disabled={busy}
              onChange={(event) => patch({ date: event.target.value })}
              className={`mt-1 ${CONTROL} font-mono tabular-nums`}
            />
          </label>
          <label className="min-w-0 flex-1 text-sm font-bold">
            <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">
              Last day, optional
            </span>
            <input
              type="date"
              value={draft.endDate}
              disabled={busy}
              onChange={(event) => patch({ endDate: event.target.value })}
              className={`mt-1 ${CONTROL} font-mono tabular-nums`}
            />
          </label>
        </div>

        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
          <label className="inline-flex min-h-11 items-center gap-2 text-sm font-bold">
            <input
              type="radio"
              name="hours-exception-kind"
              checked={draft.closed}
              disabled={busy}
              onChange={() => patch({ closed: true })}
              className="size-5"
            />
            Closed all day
          </label>
          <label className="inline-flex min-h-11 items-center gap-2 text-sm font-bold">
            <input
              type="radio"
              name="hours-exception-kind"
              checked={!draft.closed}
              disabled={busy}
              onChange={() => patch({ closed: false })}
              className="size-5"
            />
            Closing early
          </label>
        </div>

        {draft.closed ? null : (
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {/* Same wrap-with-floor as the week rows: the meridiem must never
                be squeezed out of the native time picker at 320px. */}
            <input
              type="time"
              value={draft.open}
              aria-label="Opens"
              disabled={busy}
              onChange={(event) => patch({ open: event.target.value })}
              className={`${CONTROL} min-w-[8.5rem] flex-1 font-mono tabular-nums`}
            />
            <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">to</span>
            <input
              type="time"
              value={draft.close}
              aria-label="Closes"
              disabled={busy}
              onChange={(event) => patch({ close: event.target.value })}
              className={`${CONTROL} min-w-[8.5rem] flex-1 font-mono tabular-nums`}
            />
          </div>
        )}

        <label className="mt-2 block text-sm font-bold">
          <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">Why</span>
          <input
            type="text"
            maxLength={60}
            value={draft.label}
            disabled={busy}
            onChange={(event) => patch({ label: event.target.value })}
            className={`mt-1 ${CONTROL}`}
          />
        </label>
        <p className="mt-1 text-sm text-ink-muted">{LABEL_HINT}</p>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={busy}
            onClick={save}
            className="tap-feedback min-h-11 rounded bg-ink px-4 text-sm font-bold uppercase tracking-tight text-paper disabled:opacity-60"
          >
            {draft.id ? 'Save' : 'Add'}
          </button>
          {draft.id ? (
            <button
              type="button"
              disabled={busy}
              onClick={() => setDraft(EMPTY)}
              className="tap-feedback min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight disabled:opacity-60"
            >
              Cancel
            </button>
          ) : null}
          <p role="status" aria-live="polite" className={noteClass(message)}>
            {message?.text}
          </p>
        </div>
      </div>

      {past.length > 0 ? (
        <>
          <h3 className="mt-4 font-mono text-xs font-bold uppercase tracking-widest text-amber-ink">
            Past - these are off the site
          </h3>
          <ul className="mt-2 flex flex-col gap-2">{past.map((view) => row(view, true))}</ul>
          {pastAll.length > past.length ? (
            <button
              type="button"
              onClick={() => setAllPast(true)}
              className="tap-feedback mt-2 min-h-11 rounded border border-hairline px-3 text-sm font-bold uppercase tracking-tight text-ink-muted"
            >
              Show the other {pastAll.length - past.length}
            </button>
          ) : null}
        </>
      ) : null}
    </section>
  )
}
