'use client'

import { useState } from 'react'
import { Eye, EyeSlash } from '@phosphor-icons/react/dist/ssr'

// The peep button (Pol's ask, 2026-09-28): every passphrase field carries a
// show/hide toggle so the owner can check his typing instead of guessing
// behind the dots. type="button" so it can never submit the form; showing
// only flips the input's type - the value never goes anywhere new.
export function PeepInput({
  value,
  onChange,
  className,
  wrapperClassName,
  ...rest
}: Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'onChange' | 'value' | 'className'> & {
  value: string
  onChange: (value: string) => void
  className?: string
  wrapperClassName?: string
}) {
  const [shown, setShown] = useState(false)
  return (
    <span className={`relative block ${wrapperClassName ?? ''}`}>
      <input
        {...rest}
        type={shown ? 'text' : 'password'}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className={`${className ?? ''} w-full pr-12`}
      />
      <button
        type="button"
        onClick={() => setShown((current) => !current)}
        aria-pressed={shown}
        aria-label={shown ? 'Hide the passphrase' : 'Show the passphrase'}
        className="tap-feedback absolute inset-y-0 right-0 flex min-h-11 min-w-11 items-center justify-center rounded text-ink-muted hover:text-ink"
      >
        {shown ? (
          <EyeSlash size={20} weight="bold" aria-hidden />
        ) : (
          <Eye size={20} weight="bold" aria-hidden />
        )}
      </button>
    </span>
  )
}
