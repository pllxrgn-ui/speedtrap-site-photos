import { WarningCircle } from '@phosphor-icons/react/dist/ssr'

// Errors are marked with weight, a 2px ink border and an icon rather than
// red: build/03 §4.8 reserves red for the open/closed status only. Shared
// by the inquiry and booking forms so the invalid register cannot drift.
export function FieldError({ id, children }: { id: string; children?: string }) {
  if (!children) return null
  return (
    <p id={id} role="alert" className="mt-2 flex items-start gap-2 font-bold">
      <WarningCircle size={20} weight="fill" aria-hidden className="mt-[3px] shrink-0" />
      <span>{children}</span>
    </p>
  )
}
