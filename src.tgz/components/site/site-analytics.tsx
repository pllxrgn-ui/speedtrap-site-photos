'use client'

import type { ComponentProps } from 'react'
import { Analytics } from '@vercel/analytics/next'
import { scrubAnalyticsEvent } from '@/lib/analytics'

// The route is PINNED to "/" (review 2026-09-26). Left to itself the Next
// wrapper derives `route` from useParams(), and on a page with no dynamic
// segments it falls back to the QUERY: `/?fbclid=` (an empty value) turns
// into route "/[fbclid]". That field travels beside the url, so
// beforeSend's scrub never sees it. This is a one-page site (every public
// URL is "/", retired routes 308 to fragments), so "/" is simply true.
// Package 2.0.1 omits `route` from the Next wrapper's public props, but its
// component spreads caller props AFTER the computed { path, route }
// (dist/next/index.mjs, AnalyticsComponent), so an explicit route wins.
// The cast only widens the prop type; re-check that spread on any upgrade.
const PinnedRouteAnalytics = Analytics as (
  props: ComponentProps<typeof Analytics> & { route: string },
) => null

// Mounted by app/(site)/layout.tsx and nowhere else (lib/analytics.ts has
// the contract). Pageviews only - nothing on the page is click-tracked.
export function SiteAnalytics() {
  return <PinnedRouteAnalytics route="/" beforeSend={scrubAnalyticsEvent} />
}
