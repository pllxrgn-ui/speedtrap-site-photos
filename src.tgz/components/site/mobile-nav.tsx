'use client'

import * as Dialog from '@radix-ui/react-dialog'
import { List, Phone, X } from '@phosphor-icons/react/dist/ssr'
import { ButtonA } from '@/components/ui/button'
import { SECTIONS, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The only client code in the header. Everything else about the header is
// static markup and stays on the server (one dialog is not a reason to ship
// the logo, the nav and the phone number as client JS).
export function MobileNav() {
  return (
    <Dialog.Root>
      <Dialog.Trigger
        className="tap-feedback flex size-11 items-center justify-center rounded lg:hidden"
        aria-label="Open menu"
      >
        <List size={26} weight="bold" aria-hidden />
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-ink/40" />
        {/* onCloseAutoFocus preventDefault: Radix's focus restore races the
            hash navigation and makes anchor taps feel broken on a phone
            (build/07 §3). One prop, zero new JS. */}
        <Dialog.Content
          className="fixed inset-y-0 right-0 z-50 w-72 overflow-y-auto bg-paper p-6"
          onCloseAutoFocus={(event) => event.preventDefault()}
        >
          <Dialog.Title className="sr-only">Menu</Dialog.Title>
          <Dialog.Close
            className="tap-feedback mb-6 flex size-11 items-center justify-center rounded"
            aria-label="Close menu"
          >
            <X size={24} weight="bold" aria-hidden />
          </Dialog.Close>
          {/* All SEVEN anchors: below lg this dialog is the only nav, and
              four items would strand Gallery, Reviews and the Private Room. */}
          <nav className="flex flex-col gap-1" aria-label="Mobile">
            {SECTIONS.map((item) => (
              <Dialog.Close asChild key={item.href}>
                <a
                  href={item.href}
                  className="tick tap-feedback rounded px-3 py-3 text-lg font-bold uppercase hover:bg-surface"
                >
                  {item.label}
                </a>
              </Dialog.Close>
            ))}
            <ButtonA href={TEL_HREF} size="lg" className="mt-4 w-full">
              <Phone size={18} weight="bold" aria-hidden />
              Call {SITE.phoneDisplay}
            </ButtonA>
          </nav>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
