import type { ReactNode } from 'react'

// The one container (build/03 §1.4, widened by amendment 2026-09-14g):
// max-w-[90rem], gutters 16 / 24 / 32. The client asked the site to use the
// screen; the frame spends it through grids and media - text keeps its
// readable measure.
// Server component, no state. Pass section rhythm (py-*) and layout (grid,
// flex) through className; never re-declare the width or the gutters.
export function Container({
  className = '',
  children,
}: {
  className?: string
  children: ReactNode
}) {
  return (
    <div className={`mx-auto max-w-[90rem] px-4 md:px-6 lg:px-8 ${className}`}>
      {children}
    </div>
  )
}
