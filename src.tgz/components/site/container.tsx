import type { ReactNode } from 'react'

// The one container (build/03 §1.4): max-w-[1200px], gutters 16 / 24 / 32.
// Server component, no state. Pass section rhythm (py-*) and layout (grid,
// flex) through className; never re-declare the width or the gutters.
export function Container({
  className = '',
  children,
}: {
  className?: string
  children: ReactNode
}) {
  return (
    <div className={`mx-auto max-w-[1200px] px-4 md:px-6 lg:px-8 ${className}`}>
      {children}
    </div>
  )
}
