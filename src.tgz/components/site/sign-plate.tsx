import type { CSSProperties, ReactNode } from 'react'

// The sign-plate device (build/03 §1.4): --radius-sign, max twice per page.
// Amber plate carries INK text (10.17:1); never amber text on light.
export function SignPlate({
  tone = 'amber',
  className = '',
  style,
  children,
}: {
  tone?: 'amber' | 'ink' | 'paper'
  className?: string
  /** Entrance choreography only: --stt-i for the stagger index (build/03 §1.5). */
  style?: CSSProperties
  children: ReactNode
}) {
  const tones = {
    amber: 'bg-amber text-on-amber',
    ink: 'bg-ink text-paper',
    paper: 'bg-surface text-ink border-2 border-ink',
  }
  return (
    <div
      style={style}
      className={`rounded-sign px-5 py-3 font-extrabold uppercase tracking-tight ${tones[tone]} ${className}`}
    >
      {children}
    </div>
  )
}
