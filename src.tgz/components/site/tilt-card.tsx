'use client'

import { useEffect, useRef, type ReactNode } from 'react'

/** Degrees at the far corner. Small on purpose: this is a nod to depth, not a
 *  parlour trick. Past about 6deg the photo starts to look like a playing card. */
const MAX_DEG = 4

/**
 * Pointer tilt for the hero photo (build/03 §1.5). The single piece of new
 * JavaScript in the motion pass, and it ships nothing to a phone: the
 * (hover: hover) and (pointer: fine) gate returns before a listener is bound,
 * so touch devices carry the markup and zero behaviour.
 *
 * Children are server-rendered and passed straight through, so wrapping the
 * photo does not drag next/image or the hero into the client bundle.
 *
 * Transitions are switched off while the pointer is inside (the card must
 * track the cursor with no lag) and handed back on leave, where the CSS
 * spring in globals.css returns it to flat. That is the emil rule: the system
 * responds instantly, the object settles.
 */
export function TiltCard({
  children,
  className = '',
}: {
  children: ReactNode
  className?: string
}) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return

    let frame = 0
    let nextX = 0
    let nextY = 0

    // One write per frame. Writing the whole transform string onto the element
    // rather than a custom property keeps the recalculation off the element's
    // descendants, which is the documented cost of driving child transforms
    // through an inherited variable.
    const paint = () => {
      frame = 0
      el.style.transform = `perspective(900px) rotateX(${nextY}deg) rotateY(${nextX}deg)`
    }

    const onMove = (event: PointerEvent) => {
      const rect = el.getBoundingClientRect()
      if (rect.width === 0 || rect.height === 0) return
      // -1..1 from centre, then inverted on X so the card leans toward the
      // cursor rather than away from it.
      nextX = ((event.clientX - rect.left) / rect.width - 0.5) * 2 * MAX_DEG
      nextY = -((event.clientY - rect.top) / rect.height - 0.5) * 2 * MAX_DEG
      if (frame === 0) frame = requestAnimationFrame(paint)
    }

    const onEnter = () => {
      el.style.transition = 'none'
    }

    const onLeave = () => {
      if (frame !== 0) {
        cancelAnimationFrame(frame)
        frame = 0
      }
      el.style.transition = ''
      el.style.transform = ''
    }

    el.addEventListener('pointerenter', onEnter)
    el.addEventListener('pointermove', onMove)
    el.addEventListener('pointerleave', onLeave)
    // pointercancel covers a pen or a hybrid pointer being yanked away mid-move,
    // which otherwise leaves the card stuck at an angle with no transition on it.
    el.addEventListener('pointercancel', onLeave)

    return () => {
      if (frame !== 0) cancelAnimationFrame(frame)
      el.removeEventListener('pointerenter', onEnter)
      el.removeEventListener('pointermove', onMove)
      el.removeEventListener('pointerleave', onLeave)
      el.removeEventListener('pointercancel', onLeave)
      el.style.transition = ''
      el.style.transform = ''
    }
  }, [])

  return (
    <div ref={ref} className={`stt-tilt ${className}`}>
      {children}
    </div>
  )
}
