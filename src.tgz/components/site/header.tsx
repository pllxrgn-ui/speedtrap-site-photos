import Link from 'next/link'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { MobileNav } from '@/components/site/mobile-nav'
import { ButtonA } from '@/components/ui/button'
import { NAV, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Server component. The dialog island is components/site/mobile-nav.tsx.
//
// min-h, not h: at 200% text zoom a fixed 64px header pushes the nav to a
// negative offset and clips the phone button. flex-wrap plus vertical padding
// lets the bar grow instead. Still exactly 64px at normal zoom, which is what
// --header-h and every sticky offset on the site are keyed to.
export function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-hairline bg-paper">
      <Container className="flex min-h-[var(--header-h)] flex-wrap items-center justify-between gap-x-6 gap-y-2 py-2">
        {/* Hover language, build/03 §1.5: nav-shaped things grow an amber edge
            line. No lift on the header, because the bar itself is fixed and a
            control that lifts off a fixed surface reads as loose. */}
        <Link
          href="/"
          className="tick inline-flex min-h-11 items-center font-extrabold uppercase tracking-tight"
        >
          {SITE.name}
        </Link>

        <nav className="hidden flex-wrap items-center gap-x-6 gap-y-2 lg:flex" aria-label="Main">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="tick inline-flex min-h-11 items-center font-bold uppercase text-ink hover:text-amber-ink"
            >
              {item.label}
            </Link>
          ))}
          <ButtonA href={TEL_HREF} className="px-4">
            <Phone size={18} weight="bold" aria-hidden />
            {SITE.phoneDisplay}
          </ButtonA>
        </nav>

        <MobileNav />
      </Container>
    </header>
  )
}
