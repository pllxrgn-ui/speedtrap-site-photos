import Image from 'next/image'
import { LaneRule } from '@/components/art/lane-rule'
import { Container } from '@/components/site/container'
import { getHours } from '@/lib/hours-data'
import { DIRECTIONS_HREF, SECTIONS, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// THE HOURS BLURB HAS TWO REGIMES (build/13 §2.9). This component lives in
// app/(site)/layout.tsx, not the page, so it reads getHours() itself rather
// than taking a prop. The second call is FREE: same 'use cache' function,
// same 'overlay' tag, deduped inside the request - and threading a prop down
// through the layout would buy nothing but a wider surface.
export async function Footer() {
  const { published } = await getHours()
  return (
    // pb matches the sticky call bar, which now shows through lg (build/07).
    <footer className="scene-night grain bg-surface pb-24 lg:pb-0">
      {/* The lane stripe replaces the generic 1px top rule (build/03 §1.7).
          Same job, in the system. It is also the site's one signature delight
          moment (§1.5): the dashes creep forward, one dash period of travel
          on a loop, so the seam at the top of the footer is a road rather
          than a rule. Desktop and no-preference only, compositor transform,
          4px tall. */}
      <LaneRule drift />
      <Container className="grid gap-8 py-12 md:grid-cols-3">
        <div>
          {/* The real wordmark (client direction 2026-09-14). Ink art on
              transparency, inverts with the theme like every ink element. */}
          <Image
            src="/photos/logo-wordmark.webp"
            alt={SITE.name}
            width={822}
            height={480}
            sizes="220px"
            className="invert-on-dark h-auto w-full max-w-[220px]"
          />
          <p className="mt-4 text-ink-muted">
            On Highway 2 in Reardan, Washington. 22 miles west of Spokane, on
            your way to Davenport, Grand Coulee Dam and Lake Roosevelt.
          </p>
          <p className="mt-3">
            {/* Underlined links carry the accent in the underline itself
                (currentColor), which is the same rule as the edge line and
                the reason they do not also get a tick. */}
            <a
              href={TEL_HREF}
              className="inline-flex min-h-11 items-center font-mono font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              {SITE.phoneDisplay}
            </a>
          </p>
          <p>
            <a
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-11 items-center underline underline-offset-4 hover:text-amber-ink"
            >
              Get directions
            </a>
          </p>
        </div>

        {/* 44px rows: these are the only route to Gallery, Private Room and
            Reviews on a phone, so they are real targets, not a link list. */}
        <nav aria-label="Footer" className="grid grid-cols-2 content-start gap-x-6">
          {SECTIONS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="tick flex min-h-11 items-center hover:text-amber-ink"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="content-start">
          <p className="font-bold uppercase">Hours</p>
          <p className="mt-1 text-ink-muted">
            {published
              ? 'Our hours are on this page under Find us, kept current by us. Call if you need tonight’s.'
              : 'Call to confirm today’s hours: they matter to us and we would rather you hear them right than read them wrong.'}
          </p>
          <div className="mt-2 flex gap-6">
            <a
              href={SITE.social.facebook}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-11 items-center underline underline-offset-4 hover:text-amber-ink"
            >
              Facebook
            </a>
            <a
              href={SITE.social.instagram}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-11 items-center underline underline-offset-4 hover:text-amber-ink"
            >
              Instagram
            </a>
          </div>
        </div>
      </Container>
    </footer>
  )
}
