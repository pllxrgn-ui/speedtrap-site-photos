import Image from 'next/image'
import Link from 'next/link'
import { LaneRule } from '@/components/art/lane-rule'
import { Container } from '@/components/site/container'
import { DIRECTIONS_HREF, FOOTER_EXTRA, NAV, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

export function Footer() {
  return (
    <footer className="bg-surface pb-24 md:pb-0">
      {/* The lane stripe replaces the generic 1px top rule (build/03 §1.7).
          Same job, in the system. It is also the site's one signature delight
          moment (§1.5): the dashes creep forward, one dash period of travel
          on a loop, so the seam at the top of the footer is a road rather
          than a rule. Desktop and no-preference only, compositor transform,
          4px tall. */}
      <LaneRule drift />
      <Container className="grid gap-8 py-12 md:grid-cols-3">
        <div>
          {/* The real wordmark (client direction 2026-09-14). Ink art on
              transparency, inverts with the theme like every ink element. */}
          <Image
            src="/photos/logo-wordmark.webp"
            alt={SITE.name}
            width={822}
            height={480}
            className="invert-on-dark h-auto w-full max-w-[220px]"
          />
          <p className="mt-4 text-ink-muted">
            On Highway 2 in Reardan, Washington. 22 miles west of Spokane, on
            your way to Davenport, Grand Coulee Dam and Lake Roosevelt.
          </p>
          <p className="mt-3">
            {/* Underlined links carry the accent in the underline itself
                (currentColor), which is the same rule as the edge line and
                the reason they do not also get a tick. */}
            <a
              href={TEL_HREF}
              className="inline-flex min-h-11 items-center font-mono font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              {SITE.phoneDisplay}
            </a>
          </p>
          <p>
            <a
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-11 items-center underline underline-offset-4 hover:text-amber-ink"
            >
              Get directions
            </a>
          </p>
        </div>

        {/* 44px rows: these are the only route to Gallery, Private Room and
            Reviews on a phone, so they are real targets, not a link list. */}
        <nav aria-label="Footer" className="grid grid-cols-2 content-start">
          {[...NAV, ...FOOTER_EXTRA].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="tick flex min-h-11 items-center hover:text-amber-ink"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="content-start">
          <p className="font-bold uppercase">Hours</p>
          <p className="mt-1 text-ink-muted">
            Call to confirm today&apos;s hours: they matter to us and we would
            rather you hear them right than read them wrong.
          </p>
          <div className="mt-2 flex gap-6">
            <a
              href={SITE.social.facebook}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-11 items-center underline underline-offset-4 hover:text-amber-ink"
            >
              Facebook
            </a>
            <a
              href={SITE.social.instagram}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-11 items-center underline underline-offset-4 hover:text-amber-ink"
            >
              Instagram
            </a>
          </div>
        </div>
      </Container>
    </footer>
  )
}
