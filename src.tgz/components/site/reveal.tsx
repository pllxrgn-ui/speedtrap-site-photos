'use client'

import { useEffect, useRef, type ReactNode } from 'react'

// Section entrance (motion register, build/03 §1.5): 16px rise + fade, once,
// IO-driven. Never wrap the hero in this. Fails safe three ways: reduced-motion
// gates the CSS, no-JS never arms the hide, and elements already in view on
// mount skip the animation entirely (no flash).
//
// The IO logic below is load-bearing and was fixed the hard way. It is
// untouched by the 2026-09-13 motion pass: that pass only changed the CSS the
// classes point at, plus the `group` switch, which is a class name and nothing
// more.
export function Reveal({
  children,
  className = '',
  delay = 0,
  group = false,
}: {
  children: ReactNode
  className?: string
  /** ms, for a one-off delay between sibling Reveals (design §1.5). */
  delay?: number
  /**
   * Hold the wrapper still and let a `.stt-stagger` list inside it enter in
   * sequence. Use for a row of cards, quotes or tiles that read as a set;
   * plain Reveal is still right for a whole section arriving at once.
   */
  group?: boolean
}) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (el.getBoundingClientRect().top < window.innerHeight * 0.9) {
      el.classList.add('is-visible')
      return
    }
    el.classList.add('is-armed')
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            el.classList.add('is-visible')
            io.disconnect()
          }
        }
      },
      // Top margin grown to infinity, the same trick the sticky call bar uses:
      // "intersecting" then means "has reached or passed the trigger line",
      // not "is on screen right now". Without it an instant jump (End key, an
      // in-page anchor, a fling, a restored scroll position) samples the
      // observer once at the destination, every section skipped over in
      // between never changes intersection state, and they stay at opacity 0
      // for good. Reproduced on /about at 375px: two whole sections, including
      // the ink band, rendered blank.
      { rootMargin: '100000px 0px -10% 0px' },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  return (
    <div
      ref={ref}
      className={`reveal ${group ? 'reveal--group' : ''} ${className}`}
      style={delay > 0 ? { transitionDelay: `${delay}ms` } : undefined}
    >
      {children}
    </div>
  )
}
