'use client'

import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Mobile-only sticky bar (motion register #1). Appears once the hero
// sentinel (#hero-sentinel, rendered by each page's hero) leaves the
// viewport; if a page has no sentinel the bar shows immediately.
export function StickyCallBar() {
  const [visible, setVisible] = useState(false)
  // The bar outlives client navigation, but the sentinel does not: the home
  // hero unmounts on the way to /menu and a NEW one mounts on the way back.
  // Without re-running per route the observer stays bound to the dead node and
  // the bar sits over the hero at scroll 0. Verified: menu, then back.
  const pathname = usePathname()

  useEffect(() => {
    const sentinel = document.getElementById('hero-sentinel')
    if (!sentinel) {
      const id = requestAnimationFrame(() => setVisible(true))
      return () => cancelAnimationFrame(id)
    }
    // No state reset here: observe() always delivers an initial callback, so
    // the new route's sentinel sets the correct value on its own.
    // Huge bottom rootMargin makes "intersecting" mean "at or below the
    // viewport top", so the only state change is scrolling past the hero.
    // Without it, a fast fling can skip the 1px sentinel straight through
    // the viewport between IO evaluations and no callback ever fires.
    const io = new IntersectionObserver(
      (entries) => setVisible(!entries[entries.length - 1].isIntersecting),
      { rootMargin: '0px 0px 100000px 0px' },
    )
    io.observe(sentinel)
    return () => io.disconnect()
  }, [pathname])

  return (
    <nav
      aria-label="Call or get directions"
      // stt-callbar carries the spring (build/03 §1.5) and only exists inside
      // the no-preference block, so reduced motion gets an instant appearance
      // with no extra override needed.
      className={`stt-callbar fixed inset-x-0 bottom-0 z-40 flex gap-2 bg-surface p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] [box-shadow:var(--shadow-callbar)] md:hidden ${
        visible
          ? 'translate-y-0 opacity-100'
          : 'invisible pointer-events-none translate-y-4 opacity-0'
      }`}
    >
      <ButtonA href={TEL_HREF} size="lg" className="flex-1">
        Call {SITE.phoneDisplay}
      </ButtonA>
      <ButtonA
        href={DIRECTIONS_HREF}
        target="_blank"
        rel="noopener"
        variant="amber"
        size="lg"
        className="flex-1"
      >
        Directions
      </ButtonA>
    </nav>
  )
}
