'use client'

import { useEffect, useState } from 'react'
import { List, Phone } from '@phosphor-icons/react/dist/ssr'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// Sticky bar, below lg (build/07: 768-1023 has only the hamburger, so the
// bar now covers tablet too). Appears once the hero sentinel leaves the
// viewport. One route now, so no usePathname re-bind: the sentinel mounts
// once and stays.
export function StickyCallBar() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const sentinel = document.getElementById('hero-sentinel')
    if (!sentinel) {
      const id = requestAnimationFrame(() => setVisible(true))
      return () => cancelAnimationFrame(id)
    }
    // Huge bottom rootMargin makes "intersecting" mean "at or below the
    // viewport top", so the only state change is scrolling past the hero.
    // Without it, a fast fling can skip the 1px sentinel straight through
    // the viewport between IO evaluations and no callback ever fires.
    const io = new IntersectionObserver(
      (entries) => setVisible(!entries[entries.length - 1].isIntersecting),
      { rootMargin: '0px 0px 100000px 0px' },
    )
    io.observe(sentinel)
    return () => io.disconnect()
  }, [])

  return (
    <nav
      aria-label="Call or get directions"
      // stt-callbar carries the spring (build/03 §1.5) and only exists inside
      // the no-preference block, so reduced motion gets an instant appearance
      // with no extra override needed.
      className={`stt-callbar scene-night fixed inset-x-0 bottom-0 z-40 flex gap-2 bg-surface p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] [box-shadow:var(--shadow-callbar)] lg:hidden ${
        visible
          ? 'translate-y-0 opacity-100'
          : 'invisible pointer-events-none translate-y-4 opacity-0'
      }`}
    >
      {/* One-tap route back to the menu index from anywhere on the page. */}
      <a
        href="#menu"
        className="tap-feedback flex size-12 shrink-0 items-center justify-center rounded border border-hairline"
      >
        <List size={20} weight="bold" aria-hidden />
        <span className="sr-only">Menu</span>
      </a>
      {/* Icon + bare number, one line always: "Call (509) 530-9997" wrapped
          mid-number at 375 on the control that IS the tel-click KPI (spacing
          audit, taste #1). The phone glyph says "call". */}
      <ButtonA href={TEL_HREF} size="lg" className="flex-1">
        <Phone size={18} weight="bold" aria-hidden />
        <span className="whitespace-nowrap">{SITE.phoneDisplay}</span>
        <span className="sr-only">Call us</span>
      </ButtonA>
      <ButtonA
        href={DIRECTIONS_HREF}
        target="_blank"
        rel="noopener"
        variant="amber"
        size="lg"
        className="flex-1"
      >
        Directions
      </ButtonA>
    </nav>
  )
}
