import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { Odometer } from '@/components/ui/odometer'
import { getMenu } from '@/lib/menu-data'
import { barDateLabel } from '@/lib/provenance'
import { SITE } from '@/lib/site'

// THE NUMBERS (build/06 §8). Every figure is evidence-clean and DERIVED,
// not typed: the dish count comes from the LIVE menu (build/09 - the
// brief's "51" was measured wrong; never reintroduce a literal), the
// rating and as-of from lib/site.ts. Overpass Mono keeps every numeral (amendment
// 2026-09-14d #1); Anton takes the labels. No hover on figures: prices,
// hours and data never move (build/03 §1.5.4).
const pricedCountOf = (categories: { items: { price: number | null }[] }[]) =>
  categories.flatMap((category) => category.items).filter(
  (item) => item.price !== null,
).length

const MONTHS: Record<string, string> = {
  '01': 'January', '02': 'February', '03': 'March', '04': 'April',
  '05': 'May', '06': 'June', '07': 'July', '08': 'August',
  '09': 'September', '10': 'October', '11': 'November', '12': 'December',
}
const [asOfYear, asOfMonth] = SITE.rating.asOf.split('-')
const RATING_AS_OF = `${MONTHS[asOfMonth]} ${asOfYear}`

export async function Numbers() {
  const menu = await getMenu()
  const pricedCount = pricedCountOf(menu.categories)
  const pricedNote = menu.updatedAt ? `updated ${barDateLabel(menu.updatedAt)}` : 'on the menu'
  const stats = [
    {
      figure: String(SITE.rating.value),
      roll: true,
      label: 'Google rating',
      note: 'out of 5',
    },
    {
      figure: String(SITE.rating.count),
      roll: true,
      label: 'Google reviews',
      note: RATING_AS_OF,
    },
    { figure: '22', roll: false, label: 'miles west of Spokane', note: 'on Highway 2' },
    {
      figure: String(pricedCount),
      roll: false,
      label: 'dishes priced',
      note: pricedNote,
    },
  ]

  return (
    <section className="border-y border-hairline bg-surface py-16 md:py-20 lg:py-24">
      <Container>
        <Reveal group>
          <dl className="stt-stagger grid grid-cols-2 gap-x-6 gap-y-12 lg:grid-cols-4 lg:gap-x-8">
            {stats.map((stat) => (
              <div key={stat.label} className="border-t-2 border-ink pt-6">
                <dd aria-hidden className="font-mono text-figure font-bold tabular-nums text-ink">
                  {stat.roll ? (
                    <Odometer value={stat.figure} trigger="view" baseDelay={120} />
                  ) : (
                    stat.figure
                  )}
                </dd>
                <dt className="mt-3 font-display text-h3 uppercase leading-tight text-ink">
                  {stat.label}
                </dt>
                <p className="mt-1 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
                  {stat.note}
                </p>
              </div>
            ))}
          </dl>
          <p className="sr-only">
            Rated {SITE.rating.value} out of 5 from {SITE.rating.count}{' '}
            {SITE.rating.source} reviews as of {RATING_AS_OF}. {pricedCount}{' '}
            dishes priced on the live menu. 22 miles west of
            Spokane on Highway 2.
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
