import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { MENU } from '@/lib/menu'

// Flat colour fields with type, no photography (build/03 §1.6.6). Asymmetric
// on purpose: one large field plus two stacked, never three equal cards.
//
// Names come from lib/menu.ts rather than being retyped here: the same three
// dishes appear on /menu, and two copies of a dish name is exactly how a
// rename ends up half-applied. Blurbs fall back to a local line where the menu
// entry has no description yet.
const ITEMS = [
  { name: 'Blue Cheese Burger', blurb: 'The one people drive out for.' },
  { name: 'Chicken Philly', blurb: 'The other one people order by name.' },
  { name: 'Fish & Chips', blurb: 'Friday, with the clam chowder.' },
] as const

const pick = (name: string) => {
  const item = MENU.flatMap((category) => category.items).find(
    (candidate) => candidate.name === name,
  )
  // Loud on purpose: this renders at build time, so a rename in lib/menu.ts
  // fails the build instead of quietly dropping the flagship card.
  if (!item) throw new Error(`Signature item not found in MENU: ${name}`)
  return item
}

const [feature, ...rest] = ITEMS.map((entry) => {
  const item = pick(entry.name)
  return { name: item.name, blurb: item.description ?? entry.blurb }
})

export function SignatureItems() {
  return (
    <section className="border-b border-hairline bg-surface">
      <Container className="py-12 md:py-20">
        <Reveal>
          <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
            Order this
          </h2>
        </Reveal>

        {/* Three fields entering in sequence. This block predates the
            .stt-stagger mechanism and keeps its hand-written delays, because
            the sequence has to run across two different grid containers (the
            feature field, then the stacked pair) and nth-child cannot count
            across those. Same step, same curve, same register. */}
        <div className="mt-8 grid gap-4 md:grid-cols-5">
          <Reveal className="md:col-span-3">
            <article className="flex h-full min-h-[16rem] flex-col justify-end rounded bg-amber p-6 text-on-amber md:min-h-[22rem] md:p-8">
              {/* h3 stays at the 1.25rem token (§1.2) on all three fields. The
                  feature card gets its weight from the amber field and from the
                  line under the name, which is the card's actual selling point,
                  not from a heading set two steps out of the scale. */}
              <h3 className="text-xl font-extrabold uppercase leading-tight tracking-[-0.02em]">
                {feature.name}
              </h3>
              <p className="mt-2 max-w-[24ch] text-h2 font-extrabold leading-[1.15] tracking-[-0.02em]">
                {feature.blurb}
              </p>
            </article>
          </Reveal>

          {/* grid-rows-2 so the two stacked fields are the same height as each
              other whatever their copy runs to. */}
          <div className="grid gap-4 md:col-span-2 md:grid-rows-2">
            {rest.map((item, index) => (
              <Reveal key={item.name} delay={60 * (index + 1)}>
                <article className="flex h-full min-h-[10rem] flex-col justify-end rounded border border-hairline bg-paper p-6 md:p-8">
                  <h3 className="text-xl font-extrabold uppercase leading-tight tracking-[-0.02em]">
                    {item.name}
                  </h3>
                  <p className="mt-2 text-ink-muted">{item.blurb}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>

        <p className="mt-6">
          <Link
            href="/menu"
            className="inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            See the full menu
          </Link>
        </p>
      </Container>
    </section>
  )
}
