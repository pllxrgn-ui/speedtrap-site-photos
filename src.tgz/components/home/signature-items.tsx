import Image from 'next/image'
import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { MENU } from '@/lib/menu'

// Flat colour fields with type, no photography (build/03 §1.6.6; the art pass
// cut food illustrations from this exact slot). Asymmetric on purpose: one
// large field plus two stacked, never three equal cards.
//
// 2026-09-14: the fields became what they always claimed to be - menu
// entries. Each card links to its dish's own category on /menu and carries
// the real price in mono, straight from lib/menu.ts. Clickable now, so lift
// and tap-feedback are honest instead of a lie.
//
// Names come from lib/menu.ts rather than being retyped here: the same three
// dishes appear on /menu, and two copies of a dish name is exactly how a
// rename ends up half-applied. Blurbs are local: menu descriptions are
// ingredient lists and these cards want the punchline, not the recipe.
// Blurb honesty (audit build/05): the Philly praise in reviews names the
// chicken version, so the beef card describes itself from the printed menu
// instead of borrowing it; the Fish & Chips card price is the $15 basket,
// so the $12 Friday chowder combo stays off it (that combo lives on /events
// with no price coupling).
const ITEMS = [
  { name: 'Blue Cheese Burger', blurb: 'The one people drive out for.' },
  { name: 'Philly Cheesesteak', blurb: 'Prime rib, done the Philly way.' },
  { name: 'Fish & Chips', blurb: 'The Friday tradition.' },
] as const

const pick = (name: string) => {
  for (const category of MENU) {
    const item = category.items.find((candidate) => candidate.name === name)
    if (item) return { item, categoryId: category.id }
  }
  // Loud on purpose: this renders at build time, so a rename in lib/menu.ts
  // fails the build instead of quietly dropping the flagship card.
  throw new Error(`Signature item not found in MENU: ${name}`)
}

const [feature, ...rest] = ITEMS.map((entry) => {
  const { item, categoryId } = pick(entry.name)
  return {
    name: item.name,
    blurb: entry.blurb,
    price: item.price,
    href: `/menu#${categoryId}`,
  }
})

export function SignatureItems() {
  return (
    <section className="border-b border-hairline bg-surface">
      <Container className="py-12 md:py-20">
        <Reveal>
          <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
            Order this
          </h2>
        </Reveal>

        {/* Three fields entering in sequence. This block predates the
            .stt-stagger mechanism and keeps its hand-written delays, because
            the sequence has to run across two different grid containers (the
            feature field, then the stacked pair) and nth-child cannot count
            across those. Same step, same curve, same register. */}
        <div className="mt-8 grid gap-4 md:grid-cols-5">
          <Reveal className="md:col-span-3">
            <Link
              href={feature.href}
              className="lift tap-feedback relative flex h-full min-h-[16rem] flex-col justify-end overflow-hidden rounded bg-amber p-6 text-on-amber md:min-h-[22rem] md:p-8"
            >
              {/* Faded dish photo (client direction 2026-09-14), printed INTO
                  the amber: grayscale + multiply at 30% reads as screened
                  signage art, not a photo under a scrim. Only this card gets
                  one, because their burgers are the only dish family with a
                  real photo; the two stacked cards stay typographic until the
                  owner shoot. Positioned right so the text corner stays
                  clean amber (ink on amber at 30% multiply worst-case still
                  clears AA for this text size). */}
              <Image
                src="/photos/cheeseburgers-pass.webp"
                alt=""
                aria-hidden
                fill
                loading="lazy"
                sizes="(min-width: 768px) 680px, 100vw"
                className="object-cover object-right opacity-30 grayscale mix-blend-multiply"
              />
              {/* relative: the fill image is a positioned element and would
                  otherwise paint over this static text. */}
              <div className="relative">
                {/* h3 stays at the 1.25rem token (§1.2) on all three fields.
                    The feature card gets its weight from the amber field and
                    from the line under the name; the price is the third
                    voice, mono like every number on the site. */}
                <h3 className="text-xl font-extrabold uppercase leading-tight tracking-[-0.02em]">
                  {feature.name}
                </h3>
                <p className="mt-2 max-w-[24ch] text-h2 font-extrabold leading-[1.15] tracking-[-0.02em]">
                  {feature.blurb}
                </p>
                {feature.price !== null ? (
                  <p className="mt-4 font-mono text-2xl font-bold tabular-nums">
                    ${feature.price.toFixed(2)}
                  </p>
                ) : null}
              </div>
            </Link>
          </Reveal>

          {/* grid-rows-2 so the two stacked fields are the same height as each
              other whatever their copy runs to. */}
          <div className="grid gap-4 md:col-span-2 md:grid-rows-2">
            {rest.map((item, index) => (
              <Reveal key={item.name} delay={60 * (index + 1)}>
                <Link
                  href={item.href}
                  className="lift tap-feedback flex h-full min-h-[10rem] flex-col justify-end rounded border border-hairline bg-paper p-6 hover:border-ink md:p-8"
                >
                  <h3 className="text-xl font-extrabold uppercase leading-tight tracking-[-0.02em]">
                    {item.name}
                  </h3>
                  <p className="mt-2 text-ink-muted">{item.blurb}</p>
                  {item.price !== null ? (
                    <p className="mt-3 font-mono text-lg font-bold tabular-nums">
                      ${item.price.toFixed(2)}
                    </p>
                  ) : null}
                </Link>
              </Reveal>
            ))}
          </div>
        </div>

        <p className="mt-6">
          <Link
            href="/menu"
            className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
          >
            See the full menu
          </Link>
        </p>
      </Container>
    </section>
  )
}
