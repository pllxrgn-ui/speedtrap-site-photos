import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { HISTORY } from '@/lib/history'

// THE ROOM (build/06 §4): the template's story section carried by the real
// century. Heading and lead are verbatim from /about (as amended
// 2026-09-14); the era rows derive from lib/history.ts and link into the
// About ledger's anchors. Rows grow the edge line and never lift
// (build/03 §1.5.2).
const ENTRIES = HISTORY.filter((row) => row.kind === 'entry')

export function TheRoom() {
  return (
    <section className="bg-paper py-16 md:py-20 lg:py-28">
      <Container>
        <Reveal>
          <h2 className="font-display text-slab uppercase text-ink">
            <span className="stt-line block">
              <span className="stt-masked" style={{ '--stt-i': 0 } as React.CSSProperties}>
                Same building since
              </span>
            </span>
            <span className="stt-line block">
              <span className="stt-masked" style={{ '--stt-i': 1 } as React.CSSProperties}>
                the early <span className="font-mono tabular-nums">1900</span>s
              </span>
            </span>
          </h2>
          <p className="mt-6 max-w-[46ch] text-lg leading-relaxed text-ink-muted">
            Local histories say Reardan&apos;s first bank opened in this room. It
            has carried a few different names since, and it is still the same
            room.
          </p>
        </Reveal>

        <Reveal group className="mt-10">
          <ul className="stt-stagger border-t border-hairline">
            {ENTRIES.map((row) => (
              <li key={row.id} className="border-b border-hairline">
                <Link
                  href={`/about#${row.id}`}
                  className="tick grid gap-1 py-6 md:grid-cols-[10rem_10rem_1fr] md:items-baseline md:gap-6"
                >
                  <span className="font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-amber-ink">
                    {row.era}
                  </span>
                  <span className="font-display text-h3 uppercase text-ink">{row.name}</span>
                  <span className="max-w-[62ch] text-ink-muted">{row.body}</span>
                </Link>
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal className="mt-14 lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="border-t-2 border-ink pt-6 lg:col-span-7">
            <p className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
              Highway <span className="font-mono tabular-nums">2</span> runs
              straight and open until it hits Reardan.
            </p>
            <p className="mt-4 text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
              Then the limit drops.
            </p>
          </div>
          <p className="mt-6 max-w-[46ch] text-lg leading-relaxed text-ink-muted lg:col-span-4 lg:col-start-9 lg:mt-0 lg:self-end">
            The town gets a reputation with drivers who notice that late. The
            name was sitting right there, so we took it.
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
