import Image from 'next/image'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The page's single inverted ink band, carrying the corridor statement.
//
// BACKGROUND MAP (client direction 2026-09-14, replacing the strip diagram):
// a dark-treated OpenStreetMap render of Reardan with the amber locator pin
// baked in at the verified coordinates, offset right of center so the
// statement column never sits over the pin. The treatment is baked into the
// asset (inverted, tinted to asphalt) and a uniform ink tint sits over it -
// a solid overlay, not a gradient scrim (build/03 §4.8) - so paper text
// clears AA over the brightest map feature. Decorative: location is carried
// by the text and the /find-us map, so the image is aria-hidden empty-alt.
// ODbL attribution chip is required and stays.
export function CorridorBand() {
  return (
    // fixed-ink-scene: the map asset is baked dark, so this band's ink/paper
    // are pinned and do NOT flip in dark mode (globals.css). Without the pin,
    // dark mode set near-black text over the dark map.
    <section className="fixed-ink-scene relative overflow-hidden bg-ink text-paper">
      <Image
        src="/photos/map-reardan-dark.webp"
        alt=""
        fill
        aria-hidden
        sizes="100vw"
        className="object-cover"
      />
      <span aria-hidden className="absolute inset-0 bg-ink/20" />

      <Container className="relative py-16 md:py-28">
        <Reveal>
          <div className="grid gap-8 lg:grid-cols-12 lg:items-end lg:gap-12">
            <div className="lg:col-span-7">
              {/* Anton + the masked line reveal (build/06 §7); fired by the
                  surrounding Reveal so it inherits all three fail-safes. */}
              <h2 className="max-w-[18ch] font-display text-slab uppercase">
                <span className="stt-line block">
                  <span className="stt-masked">Right on Highway 2</span>
                </span>
                <span className="stt-line block">
                  <span className="stt-masked" style={{ '--stt-i': 1 } as React.CSSProperties}>
                    in Reardan
                  </span>
                </span>
              </h2>
              <p className="mt-6 max-w-[40ch] text-xl leading-relaxed">
                <span className="font-mono tabular-nums">22</span> miles west of
                Spokane, on your way to Davenport, Grand Coulee Dam and Lake
                Roosevelt.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row lg:col-span-5 lg:flex-col lg:items-stretch">
              <ButtonA
                href={DIRECTIONS_HREF}
                target="_blank"
                rel="noopener"
                variant="amber"
                size="lg"
              >
                Directions
              </ButtonA>
              {/* The one place the inverse variant belongs. */}
              <ButtonA href={TEL_HREF} variant="inverse" size="lg">
                Call <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
              </ButtonA>
            </div>
          </div>
        </Reveal>
      </Container>

      {/* ODbL attribution for the background render. Required, do not remove;
          it travels with map-reardan-dark.webp if that asset ever relocates.
          text-sm: the audit's 14px type floor (build/05). */}
      <span className="absolute bottom-2 right-3 z-10 text-sm text-paper/70">
        &copy; OpenStreetMap contributors
      </span>
    </section>
  )
}
