import { CorridorMap } from '@/components/art/corridor-map'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// The page's single inverted ink band (build/03 §1.4). One per page, carrying
// the strongest statement: where this place sits on the corridor.
//
// Statement left, the two actions right at lg. The statement used to sit in a
// 52ch prose column and leave the right 40% of the band empty; a prose measure
// is the wrong measure for a band that exists to be read at a glance.
export function CorridorBand() {
  return (
    <section className="bg-ink text-paper">
      <Container className="py-16 md:py-28">
        <Reveal>
          <div className="grid gap-8 lg:grid-cols-12 lg:items-end lg:gap-12">
            <div className="lg:col-span-7">
              <h2 className="max-w-[18ch] text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em]">
                Right on Highway 2 in Reardan
              </h2>
              <p className="mt-6 max-w-[40ch] text-xl leading-relaxed">
                <span className="font-mono tabular-nums">22</span> miles west of
                Spokane, on your way to Davenport, Grand Coulee Dam and Lake
                Roosevelt.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row lg:col-span-5 lg:flex-col lg:items-stretch">
              <ButtonA
                href={DIRECTIONS_HREF}
                target="_blank"
                rel="noopener"
                variant="amber"
                size="lg"
              >
                Directions
              </ButtonA>
              {/* The one place the inverse variant belongs: a secondary action
                  that has to sit on the ink band without becoming a second
                  accent (build/03 §4 guardrail 8). */}
              <ButtonA href={TEL_HREF} variant="inverse" size="lg">
                Call <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
              </ButtonA>
            </div>
          </div>

          {/* The strip map (build/03 §1.7). It draws the sentence above it, so
              it goes under the statement and across the full band rather than
              inside the seven-column statement block. currentColor is the
              band's text-paper here, so no tone prop is needed. */}
          <CorridorMap className="mt-12 border-t border-paper/25 pt-10 md:mt-14" />
        </Reveal>
      </Container>
    </section>
  )
}
