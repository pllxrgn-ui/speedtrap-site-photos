import type { CSSProperties } from 'react'
import Image from 'next/image'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { SignPlate } from '@/components/site/sign-plate'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// THE NAME (build/06 §2). LCP section: zero images, the <h1> is the LCP
// element. Never wrapped in Reveal. Line 1 is a transform-only letter ripple
// (opacity 1, final box, frame 1 - LCP-safe); line 2 gets the template's
// masked unmask, landing on the amber word. CALL and MENU are painted and
// tappable at t=0; everything after them is decorative-to-the-decision.
//
// Letters DERIVE from SITE.name (spelling still pending the owner,
// CLIENT-QUESTIONS #3): a ruling there propagates here with no retyping.
const step = (index: number) => ({ '--stt-i': index }) as CSSProperties

const words = SITE.name.split(' ')
if (words.length < 3) throw new Error('SITE.name no longer splits into name + support lines')
const LINE_ONE = words[0].toUpperCase()
const LINE_TWO = words[1].toUpperCase()
const PLATE = words.slice(2).join(' ')

// [VOICE] - swagger, asserts no fact.
const ROLES = ['Bar.', 'Grill.', 'Taps.', 'On Highway 2.']

function RippleLetters({ text, from }: { text: string; from: number }) {
  return (
    <>
      {[...text].map((letter, index) => (
        <span key={index} className="stt-letter" style={step(from + index)}>
          {letter}
        </span>
      ))}
    </>
  )
}

function MaskedLetters({ text, from }: { text: string; from: number }) {
  return (
    <>
      {[...text].map((letter, index) => (
        <span key={index} className="stt-masked" style={step(from + index)}>
          {letter}
        </span>
      ))}
    </>
  )
}

export function NameHero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-hairline bg-paper">
      {/* THE FULL HOUSE (client direction 2026-09-15: the hero needs life,
          not typography in a void). Their own packed-bar night photo as the
          scene, darkened by the solid-overlay device the corridor band
          established - text sits on near-ink ground, never on raw photo.
          The room glows through: bottles, bodies, bar light. Replaces the
          laurel ghost, whose job this photo does better. */}
      <Image
        src="/photos/bar-full-house.webp"
        alt=""
        aria-hidden
        fill
        priority
        sizes="100vw"
        className="object-cover object-center"
      />
      <span aria-hidden className="absolute inset-0 bg-paper/80" />
      {/* The pool of light the sign throws on the room (amendment f: the
          gradient ban lifts for light sources). Static, decorative. */}
      <div aria-hidden className="glow-pool pointer-events-none absolute inset-x-0 top-0 h-[75%]" />
      {/* Pads per the spacing audit (build/05a fixlist A3): everything on the
          4px scale, and the page's tallest element finally gets a seam that
          scales with it. pt-6 held at 375 - the fold budget is untouched. */}
      <Container className="relative pb-12 pt-6 md:pb-16 md:pt-8 lg:grid lg:grid-cols-12 lg:gap-8 lg:pb-24 lg:pt-12">
        {/* The name owns the full row: SPEED at the 25rem cap needs ~1060px of
            track (gate 2 measurement) and cols 1-8 wrap it. whitespace-nowrap
            is load-bearing - the letters are inline-block spans, which create
            break opportunities inside a single word. */}
        <h1 className="font-display text-name uppercase lg:col-span-12">
          <span className="sr-only">{SITE.name}</span>
          <span aria-hidden className="block whitespace-nowrap tracking-[-0.01em] text-ink">
            <RippleLetters text={LINE_ONE} from={0} />
          </span>
          {/* The amber word: the joke, told once, in typography. --amber-ink
              on light, raw amber in dark (token flip). Tracking 0.118em,
              solved by PIXEL SCAN of painted glyph extents (SPEED ink 862px,
              TRAP needed +9.3px per gap at the 400px cap). Two earlier
              records (0.085 "flush", then 0.095) measured element boxes,
              which lie - boxes fill the track. Scan, do not box. */}
          {/* The lit sign. The halo lives on a TRANSPARENT duplicate outside
              the unmask clip: text-shadow paints even with transparent fill,
              and inside .stt-maskline the glow would fill the clip box and
              print a hard rectangle (seen at gate). The duplicate rises in
              after the letters land; reduced motion shows it immediately. */}
          <span aria-hidden className="relative block">
            <span
              style={step(8)}
              className="sign-lit stt-rise pointer-events-none absolute inset-0 whitespace-nowrap tracking-[0.118em] text-transparent"
            >
              {LINE_TWO}
            </span>
            <span className="stt-maskline block whitespace-nowrap tracking-[0.118em] text-amber-ink">
              <MaskedLetters text={LINE_TWO} from={LINE_ONE.length} />
            </span>
          </span>
        </h1>

        {/* Full-row plate + edge line (own grid row, lg:mt-0 kills the
            margin+gap double-space): the amber rule now runs to the container
            edge, resolving one of the hero's three ragged right edges. */}
        <div className="mt-6 flex flex-wrap items-center gap-4 lg:col-span-12 lg:mt-0">
          <SignPlate tone="amber" style={step(4)} className="stt-rise text-h3">
            {PLATE}
          </SignPlate>
          <div aria-hidden className="relative h-[2px] min-w-16 flex-1 bg-ink">
            <div className="stt-edge absolute inset-x-0 -top-px h-[4px] bg-amber" />
          </div>
        </div>

        <div className="lg:col-span-8 lg:mt-0">
          {/* Role words: one tracked row on a phone (fold economics), the
              template's stacked lines where there is room. */}
          <p
            style={step(5)}
            className="stt-rise mt-6 font-extrabold uppercase tracking-wide text-ink-muted md:hidden"
          >
            {ROLES.join(' ')}
          </p>
          {/* Real text, not aria-hidden: the masked spans hold whole words,
              so reading order and selection survive the choreography. */}
          <div className="mt-8 hidden md:block">
            {ROLES.map((role, index) => (
              <span
                key={role}
                className="stt-maskline block text-h2 font-extrabold uppercase leading-[1.1] text-ink-muted"
              >
                <span className="stt-masked stt-role" style={step(index)}>
                  {role}
                </span>
              </span>
            ))}
          </div>
        </div>

        <div className="mt-8 flex flex-col justify-end lg:col-span-4 lg:col-start-9 lg:mt-0">
          <p
            style={step(7)}
            className="stt-rise max-w-[46ch] text-lg leading-relaxed lg:text-right"
          >
            Burgers, cold beer and a full bar on Highway 2 in Reardan, 22 miles
            west of Spokane.
          </p>
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-3 lg:col-span-12 lg:mt-0">
          <ButtonA href={TEL_HREF} variant="ink" size="lg">
            <Phone size={18} weight="bold" aria-hidden />
            Call {SITE.phoneDisplay}
          </ButtonA>
          <ButtonA href="#menu" variant="ghost" size="lg">
            View Menu
          </ButtonA>
          {/* Directions demotes to a link at 375: the sticky bar carries it as
              an amber button one flick away, and the fold belongs to CALL.
              Visibility lives on WRAPPERS: display utilities on the controls
              themselves lose to the components' own display classes by
              stylesheet order, and both variants rendered at 375 (spacing
              audit, taste #2). */}
          <span className="md:hidden">
            <a
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Directions
            </a>
          </span>
          <span className="hidden md:inline-flex">
            <ButtonA
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              variant="amber"
              size="lg"
            >
              Directions
            </ButtonA>
          </span>
        </div>

        {/* Watched by StickyCallBar: sits right after the CTA row so the bar
            arms as soon as the buttons clear the viewport. Below lg the
            header's phone button hides behind the hamburger, so the hero CALL
            is the only one-tap call until this bar arms. */}
        <div id="hero-sentinel" aria-hidden="true" className="lg:col-span-12" />

        <p style={step(9)} className="stt-rise mt-6 text-ink-muted lg:col-span-12 lg:mt-0">
          The internet has six versions of our hours, so get them from us.{' '}
          <a
            href={TEL_HREF}
            className="tick font-bold text-ink underline underline-offset-4 hover:text-amber-ink"
          >
            Call for today&apos;s hours
          </a>
        </p>
      </Container>
    </section>
  )
}
