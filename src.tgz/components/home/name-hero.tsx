import type { CSSProperties } from 'react'
import Image from 'next/image'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { SignPlate } from '@/components/site/sign-plate'
import { ButtonA, ButtonLink } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// THE TOTEM (v3, client direction 2026-09-15: "not aligned properly").
// The flush-tracking lockup is dead - a centered sign totem cannot be
// misaligned: SPEED over TRAP over the plate, symmetric like the roadside
// sign and their own sticker art. Both lines ride the LCP-safe letter
// ripple; the unmask and its glow-duplicate workaround are retired with it.
// Behind everything: THE FULL HOUSE - their packed bar, darkened by the
// solid-overlay device, the room glowing through.
const step = (index: number) => ({ '--stt-i': index }) as CSSProperties

const words = SITE.name.split(' ')
if (words.length < 3) throw new Error('SITE.name no longer splits into name + support lines')
const LINE_ONE = words[0].toUpperCase()
const LINE_TWO = words[1].toUpperCase()
const PLATE = words.slice(2).join(' ')

// [VOICE] - swagger, asserts no fact.
const ROLES = ['Bar', 'Grill', 'Taps', 'On Highway 2']

function RippleLetters({ text, from }: { text: string; from: number }) {
  return (
    <>
      {[...text].map((letter, index) => (
        <span key={index} className="stt-letter" style={step(from + index)}>
          {letter}
        </span>
      ))}
    </>
  )
}

export function NameHero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-hairline bg-paper">
      <Image
        src="/photos/bar-full-house.webp"
        alt=""
        aria-hidden
        fill
        priority
        sizes="100vw"
        className="object-cover object-center"
      />
      <span aria-hidden className="absolute inset-0 bg-paper/80" />
      <div aria-hidden className="glow-pool pointer-events-none absolute inset-x-0 top-0 h-[75%]" />

      <Container className="relative flex flex-col items-center pb-12 pt-8 text-center md:pb-16 md:pt-10 lg:pb-24 lg:pt-14">
        <h1 className="font-display text-name uppercase">
          <span className="sr-only">{SITE.name}</span>
          <span aria-hidden className="block whitespace-nowrap tracking-[-0.01em] text-ink">
            <RippleLetters text={LINE_ONE} from={0} />
          </span>
          {/* The lit word: glow rides the letters directly now - no mask, so
              no clipped-halo rectangle to work around. */}
          <span aria-hidden className="sign-lit block whitespace-nowrap tracking-[-0.01em] text-amber-ink">
            <RippleLetters text={LINE_TWO} from={LINE_ONE.length} />
          </span>
        </h1>

        {/* The plate hangs centered under the name, rules running out both
            sides - a hung sign, not a strip. */}
        <div className="mt-6 flex w-full items-center gap-4">
          <div aria-hidden className="relative h-[2px] flex-1 bg-ink">
            <div className="stt-edge absolute inset-x-0 -top-px h-[4px] bg-amber" />
          </div>
          <SignPlate tone="amber" style={step(4)} className="stt-rise text-h3">
            {PLATE}
          </SignPlate>
          <div aria-hidden className="relative h-[2px] flex-1 bg-ink">
            <div className="stt-edge absolute inset-x-0 -top-px h-[4px] bg-amber" />
          </div>
        </div>

        {/* One centered role line, amber chips between - the lane's own
            separator, so the two bands speak the same language. */}
        <p
          style={step(5)}
          className="stt-rise mt-8 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 font-extrabold uppercase tracking-wide text-ink md:text-xl"
        >
          {ROLES.map((role, index) => (
            <span key={role} className="flex items-center gap-x-3">
              {role}
              {index < ROLES.length - 1 ? (
                <span aria-hidden className="inline-block size-1.5 bg-amber" />
              ) : null}
            </span>
          ))}
        </p>

        <p style={step(6)} className="stt-rise mt-5 max-w-[52ch] text-lg leading-relaxed text-ink-muted">
          Burgers, cold beer and a full bar on Highway 2 in Reardan, 22 miles
          west of Spokane.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <ButtonA href={TEL_HREF} variant="ink" size="lg">
            <Phone size={18} weight="bold" aria-hidden />
            Call {SITE.phoneDisplay}
          </ButtonA>
          <ButtonLink href="#menu" variant="ghost" size="lg">
            View Menu
          </ButtonLink>
          <a
            href={DIRECTIONS_HREF}
            target="_blank"
            rel="noopener"
            className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink md:hidden"
          >
            Directions
          </a>
          <ButtonA
            href={DIRECTIONS_HREF}
            target="_blank"
            rel="noopener"
            variant="amber"
            size="lg"
            className="hidden md:inline-flex"
          >
            Directions
          </ButtonA>
        </div>

        {/* Watched by StickyCallBar: right after the CTAs, so the bar arms
            the moment the buttons leave the viewport. */}
        <div id="hero-sentinel" aria-hidden="true" />

        <p style={step(7)} className="stt-rise mt-6 text-ink-muted">
          The internet has six versions of our hours, so get them from us.{' '}
          <a
            href={TEL_HREF}
            className="tick font-bold text-ink underline underline-offset-4 hover:text-amber-ink"
          >
            Call for today&apos;s hours
          </a>
        </p>
      </Container>
    </section>
  )
}
