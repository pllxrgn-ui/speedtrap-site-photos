import type { CSSProperties } from 'react'
import Image from 'next/image'
import { Phone, Star } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { SignPlate } from '@/components/site/sign-plate'
import { TiltCard } from '@/components/site/tilt-card'
import { ButtonA, ButtonLink } from '@/components/ui/button'
import { Odometer } from '@/components/ui/odometer'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// LCP section. Never wrapped in Reveal. Leads with the business's real
// wordmark (their own artwork, alpha-matted from their Facebook logo) and a
// real photo of the room: client direction 2026-09-13, photography-forward, no
// drawn illustration. Hours deliberately absent.
//
// ENTRANCE (motion pass, 2026-09-13). Pure CSS, no observer, no JS, runs once
// on paint. Two registers:
//   .stt-settle  transform only, never opacity. The logo and the photo are the
//                LCP candidates, and an element at opacity 0 is not an LCP
//                candidate at all, so neither may ever start hidden. They
//                arrive at full strength and settle the last 8px.
//   .stt-rise    opacity plus 14px. Everything that is not the LCP.
// --stt-i is the stagger index; the step itself (60ms desktop, 38ms mobile)
// lives in globals.css so the whole site shortens together on a phone.
const step = (index: number) => ({ '--stt-i': index }) as CSSProperties

export function Hero() {
  return (
    <section className="border-b border-hairline bg-paper">
      <Container className="py-12 md:py-16">
        <div className="grid gap-10 lg:grid-cols-12 lg:items-center lg:gap-12">
          <div className="lg:col-span-7">
            {/* The real logo. Ink-colored art on transparency; inverts to
                paper in dark mode via .invert-on-dark. */}
            <Image
              src="/photos/logo-wordmark.webp"
              alt={`${SITE.name} logo`}
              width={960}
              height={576}
              priority
              className="stt-settle invert-on-dark h-auto w-full max-w-[440px]"
            />

            <h1
              style={step(1)}
              className="stt-rise mt-6 text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em]"
            >
              Worth getting pulled over for.
            </h1>
            <p
              style={step(2)}
              className="stt-rise mt-4 max-w-[62ch] text-lg leading-relaxed"
            >
              Burgers, cold beer and a full bar on Highway 2 in Reardan, 22 miles
              west of Spokane.
            </p>

            {/* The three CTAs arrive one after another rather than as a block.
                They are the point of the page, so they are the last thing to
                move and the only thing that moves in sequence. */}
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <ButtonLink
                href="/menu"
                variant="ink"
                size="lg"
                style={step(3)}
                className="stt-rise"
              >
                View Menu
              </ButtonLink>
              <ButtonA
                href={TEL_HREF}
                variant="ghost"
                size="lg"
                style={step(4)}
                className="stt-rise"
              >
                <Phone size={18} weight="bold" aria-hidden />
                Call {SITE.phoneDisplay}
              </ButtonA>
              <ButtonA
                href={DIRECTIONS_HREF}
                target="_blank"
                rel="noopener"
                variant="amber"
                size="lg"
                style={step(5)}
                className="stt-rise"
              >
                Directions
              </ButtonA>
            </div>

            <p style={step(6)} className="stt-rise mt-6 text-ink-muted">
              Hours move around, so we would rather you heard them from us.{' '}
              <a
                href={TEL_HREF}
                className="tick font-bold text-ink underline underline-offset-4 hover:text-amber-ink"
              >
                Call for today&apos;s hours
              </a>
            </p>
          </div>

          <div className="lg:col-span-5">
            {/* Real photo, no identifiable faces at hero scale (patron shots
                stay small in the gallery). Fixed container, hairline frame,
                no text on it (build/03 §1.6).

                The settle and the tilt sit on two different elements on
                purpose: an animation with a fill mode would otherwise pin the
                transform the tilt needs to write. Outer settles, inner tilts. */}
            <div style={step(1)} className="stt-settle mx-auto max-w-[420px]">
              <TiltCard>
                <div className="img-frame relative aspect-square overflow-hidden rounded">
                  <Image
                    src="/photos/cheeseburgers-pass.webp"
                    alt="Six open-faced cheeseburgers lined up on the kitchen pass."
                    fill
                    priority
                    sizes="(min-width: 1024px) 420px, 100vw"
                    className="object-cover"
                  />
                </div>
              </TiltCard>
            </div>

            <SignPlate tone="paper" style={step(4)} className="stt-rise mt-4 inline-block">
              <span className="sr-only">
                Rated {SITE.rating.value} out of 5 from {SITE.rating.count}{' '}
                {SITE.rating.source} reviews.
              </span>
              <span aria-hidden className="flex items-center gap-2">
                <Star size={22} weight="fill" />
                {/* Rolls on paint rather than on view: it is above the fold on
                    every viewport, so there is no view to wait for. The delay
                    puts it just behind the plate it sits on. */}
                <Odometer
                  value={String(SITE.rating.value)}
                  trigger="load"
                  baseDelay={420}
                  className="font-mono text-3xl tabular-nums"
                />
                <span className="text-sm">out of 5</span>
              </span>
              <span aria-hidden className="mt-1 block font-mono text-sm tabular-nums">
                {SITE.rating.count} {SITE.rating.source} reviews
              </span>
            </SignPlate>
          </div>
        </div>
      </Container>

      {/* Watched by StickyCallBar. Must stay at the end of the hero. */}
      <div id="hero-sentinel" aria-hidden="true" />
    </section>
  )
}
