import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { VISIT_FACTS } from '@/lib/facts'

// Practical follow-through to the ink band. The facts themselves live in
// lib/facts.ts, shared with /find-us and the FAQ answers, so the same cleared
// fact cannot end up worded three different ways. No street address: the E/W
// Broadway conflict is unresolved and SITE.address is null.
export function FindUsTeaser() {
  return (
    <section className="bg-paper">
      <Container className="py-12 md:py-20">
        <Reveal>
          <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
            Good to know
          </h2>
        </Reveal>

        {/* Facts arrive one at a time (build/03 §1.5): the stagger is doing
            the reading order, which is what a stagger is for. */}
        <Reveal group>
          <dl className="stt-stagger mt-8 max-w-[62ch]">
            {VISIT_FACTS.map((fact) => (
              <div
                key={fact.id}
                className="grid gap-1 border-t border-hairline py-4 md:grid-cols-[8rem_1fr] md:gap-6"
              >
                <dt className="font-mono text-sm uppercase tracking-wide text-ink-muted">
                  {fact.label}
                </dt>
                <dd>{fact.teaser}</dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal>
          <p className="mt-6">
            <Link
              href="/find-us"
              className="inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Find us
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
