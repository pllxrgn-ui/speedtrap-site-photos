// THE LANE (build/06 §3; build/03 amendment 2026-09-14d #2 - the scoped
// marquee lift). A doubled Anton type track, clocked ONLY by the user's own
// scroll (animation-timeline: view()): starts when they move, stops dead
// when they stop, so WCAG 2.2.2 never engages. Browsers without view() get
// a static cropped sign line - designed, not broken. Every word is [VOICE]
// (swagger, asserts no fact); Taco Tuesday is deliberately absent because
// lib/events.ts marks it confirmed:false and a decorative band cannot hedge.
const WORDS = [
  'Worth getting pulled over for',
  'Cold beer',
  'Full bar',
  'Burgers',
  'On Highway 2',
  'Call ahead',
]

function LaneCopy({ hidden = false }: { hidden?: boolean }) {
  return (
    <span aria-hidden={hidden || undefined} className="flex items-center">
      {WORDS.map((word) => (
        <span key={word} className="flex items-center whitespace-nowrap">
          <span className="font-display text-lane uppercase text-ink">{word}</span>
          {/* A hard-edged amber chip, not punctuation. */}
          <span aria-hidden className="mx-[0.6em] inline-block size-[0.28em] bg-amber" />
        </span>
      ))}
    </span>
  )
}

export function LaneBand() {
  return (
    <section className="overflow-hidden border-y border-hairline bg-surface py-6 md:py-8 lg:py-10">
      <div className="stt-lane-track flex w-max">
        <LaneCopy />
        <LaneCopy hidden />
      </div>
    </section>
  )
}
