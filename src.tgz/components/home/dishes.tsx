import Image from 'next/image'
import type { MenuCategory } from '@/lib/menu'

// THE FEATURE CARDS (build/07: dishes.tsx is now the #menu section's opener;
// its old section shell, photo band and trailing link died with the fold -
// the gallery section carries the photos once). build/09: the menu is the
// database now, so picks are SOFT - a renamed or deleted signature dish
// drops its card instead of crashing the page, and its price always
// mirrors the live menu.
const pick = (menu: MenuCategory[], name: string) => {
  for (const category of menu) {
    const item = category.items.find((candidate) => candidate.name === name)
    if (item) return { item, categoryId: category.id, categoryTitle: category.title }
  }
  return null
}

// Blurbs 1/3/4 are the cleared strings from the retired signature cards;
// blurb 2 is the verbatim printed-menu description. The $12 Friday chowder
// figure stays off card 4 (conflicting posts, research/05).
const CARDS = [
  { name: 'Blue Cheese Burger', blurb: 'The one people drive out for.' },
  {
    name: 'Speed Trap Burger',
    blurb:
      'Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.',
  },
  { name: 'Philly Cheesesteak', blurb: 'Prime rib, done the Philly way.' },
  { name: 'Fish & Chips', blurb: 'The Friday tradition.' },
]

export function FeatureCards({ menu }: { menu: MenuCategory[] }) {
  const cards = CARDS.flatMap((entry) => {
    const found = pick(menu, entry.name)
    if (!found) return []
    return [{
      name: found.item.name,
      blurb: entry.blurb,
      price: found.item.price,
      category: found.categoryTitle,
      // In-page anchor: the categories render further down this same section.
      href: `#${found.categoryId}`,
    }]
  })
  if (cards.length === 0) return null
  const [feature, ...rest] = cards
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:gap-6">
      {/* Poster anatomy: name top, price bottom (the justify-end version left
          a 463px dead amber void when the grid stretched the card). Blend
          photo per Amendment 2026-09-14c - the one photo exception. */}
      <a
        href={feature.href}
        className="lift tap-feedback relative flex min-h-[16rem] flex-col overflow-hidden rounded bg-amber p-6 text-on-amber md:min-h-[22rem] md:p-8"
      >
        <Image
          src="/photos/cheeseburgers-pass.webp"
          alt=""
          aria-hidden
          fill
          loading="lazy"
          sizes="(min-width: 768px) 680px, 100vw"
          className="object-cover object-right opacity-30 grayscale mix-blend-multiply"
        />
        <span className="relative flex h-full flex-col">
          <span className="block font-display text-h2 uppercase leading-none">
            {feature.name}
          </span>
          <span className="mt-3 block max-w-[24ch] text-h2 font-extrabold leading-[1.15] tracking-[-0.02em]">
            {feature.blurb}
          </span>
          {feature.price !== null ? (
            <span className="mt-auto block pt-6 font-mono text-2xl font-bold tabular-nums">
              ${feature.price.toFixed(2)}
            </span>
          ) : null}
        </span>
      </a>

      <div className="grid gap-4 lg:gap-6">
        {rest.map((card) => (
          <a
            key={card.name}
            href={card.href}
            className="halftone lift tap-feedback flex min-h-[10rem] flex-col justify-end overflow-hidden rounded border border-hairline bg-paper p-6 hover:border-ink md:p-8"
          >
            <span className="block font-display text-h3 uppercase leading-tight text-ink">
              {card.name}
            </span>
            <span className="mt-2 block text-ink-muted">{card.blurb}</span>
            <span className="mt-3 flex items-baseline justify-between gap-4">
              <span className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                {card.category}
              </span>
              {card.price !== null ? (
                <span className="font-mono text-lg font-bold tabular-nums">
                  ${card.price.toFixed(2)}
                </span>
              ) : null}
            </span>
          </a>
        ))}
      </div>
    </div>
  )
}
