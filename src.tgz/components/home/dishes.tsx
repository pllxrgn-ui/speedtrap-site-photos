import Image from 'next/image'
import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { MENU } from '@/lib/menu'
import { PHOTOS } from '@/lib/photos'

// ORDER THIS (build/06 §5): the template's ventures grid carried by the four
// signature dishes. Names and prices are pick()-ed from lib/menu.ts at build
// time - a rename or a price change there fails the build here rather than
// desyncing (the shipped signature-items pattern, kept).
const pick = (name: string) => {
  for (const category of MENU) {
    const item = category.items.find((candidate) => candidate.name === name)
    if (item) return { item, categoryId: category.id, categoryTitle: category.title }
  }
  throw new Error(`Signature dish not found in MENU: ${name}`)
}

// Blurbs 1/3/4 are the cleared strings from the retired signature-items
// card set; blurb 2 is the verbatim printed-menu description. The $12
// Friday chowder figure stays off card 4 (conflicting posts, research/05).
const CARDS = [
  { name: 'Blue Cheese Burger', blurb: 'The one people drive out for.' },
  {
    name: 'Speed Trap Burger',
    blurb:
      'Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.',
  },
  { name: 'Philly Cheesesteak', blurb: 'Prime rib, done the Philly way.' },
  { name: 'Fish & Chips', blurb: 'The Friday tradition.' },
].map((entry) => {
  const { item, categoryId, categoryTitle } = pick(entry.name)
  return {
    name: item.name,
    blurb: entry.blurb,
    price: item.price,
    category: categoryTitle,
    href: `/menu#${categoryId}`,
  }
})

// The photo band: real photos below the name moment (the client directive's
// permitted placement). street-band-daylight is excluded on weight - 105KB,
// a tenth of the page budget for decoration (build/06 §5, figure recorded).
const BAND_SRCS = [
  '/photos/bar-full-house.webp',
  '/photos/chili-crockpot.webp',
  '/photos/broadway-out-front.webp',
]
const BAND = BAND_SRCS.map((src) => {
  const photo = PHOTOS.find((candidate) => candidate.src === src)
  if (!photo) throw new Error(`Photo band asset missing from lib/photos.ts: ${src}`)
  return photo
})

export function Dishes() {
  const [feature, ...rest] = CARDS
  return (
    <section className="border-y border-hairline bg-surface py-16 md:py-20 lg:py-28">
      <Container>
        <Reveal>
          <h2 className="font-display text-slab uppercase text-ink">
            <span className="stt-line block">
              <span className="stt-masked">Order this</span>
            </span>
          </h2>
        </Reveal>

        <Reveal group className="mt-10">
          <div className="stt-stagger grid gap-4 md:grid-cols-2 lg:gap-6">
            {/* Feature card: treatment unchanged from Amendment 2026-09-14c -
                the one blend-print photo exception, not generalised. */}
            <Link
              href={feature.href}
              className="lift tap-feedback relative flex min-h-[16rem] flex-col justify-end overflow-hidden rounded bg-amber p-6 text-on-amber md:min-h-[22rem] md:p-8"
            >
              <Image
                src="/photos/cheeseburgers-pass.webp"
                alt=""
                aria-hidden
                fill
                loading="lazy"
                sizes="(min-width: 768px) 680px, 100vw"
                className="object-cover object-right opacity-30 grayscale mix-blend-multiply"
              />
              <span className="relative block">
                <span className="block font-display text-h2 uppercase leading-none">
                  {feature.name}
                </span>
                <span className="mt-2 block max-w-[24ch] text-h2 font-extrabold leading-[1.15] tracking-[-0.02em]">
                  {feature.blurb}
                </span>
                {feature.price !== null ? (
                  <span className="mt-4 block font-mono text-2xl font-bold tabular-nums">
                    ${feature.price.toFixed(2)}
                  </span>
                ) : null}
              </span>
            </Link>

            <div className="grid gap-4 lg:mt-16 lg:gap-6">
              {/* lg:mt-16 is a MARGIN, never a transform: .lift:hover writes
                  transform and a translated card would snap on first hover
                  (build/06 §5, reason of record). */}
              {rest.map((card) => (
                <Link
                  key={card.name}
                  href={card.href}
                  className="lift tap-feedback flex min-h-[10rem] flex-col justify-end rounded border border-hairline bg-paper p-6 hover:border-ink md:p-8"
                >
                  <span className="block font-display text-h3 uppercase leading-tight text-ink">
                    {card.name}
                  </span>
                  <span className="mt-2 block text-ink-muted">{card.blurb}</span>
                  <span className="mt-3 flex items-baseline justify-between gap-4">
                    <span className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                      {card.category}
                    </span>
                    {card.price !== null ? (
                      <span className="font-mono text-lg font-bold tabular-nums">
                        ${card.price.toFixed(2)}
                      </span>
                    ) : null}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal group className="mt-12">
          <div className="stt-stagger grid grid-cols-2 gap-4 lg:grid-cols-4 lg:gap-6">
            {BAND.map((photo) => (
              <div key={photo.src} className="img-frame photo-zoom relative aspect-square overflow-hidden rounded">
                <Image
                  src={photo.src}
                  alt={photo.alt}
                  fill
                  loading="lazy"
                  sizes="(min-width: 1024px) 280px, 50vw"
                  className="object-cover"
                />
              </div>
            ))}
            <Link
              href="/gallery"
              className="lift tap-feedback flex aspect-square flex-col items-start justify-end rounded border border-hairline bg-paper p-6 hover:border-ink"
            >
              <span className="font-display text-h3 uppercase leading-tight text-ink">
                See the gallery
              </span>
              <span className="mt-2 text-ink-muted">Real pictures of this place.</span>
            </Link>
          </div>
        </Reveal>

        <Reveal>
          <p className="mt-8">
            <Link
              href="/menu"
              className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              See the full menu
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
