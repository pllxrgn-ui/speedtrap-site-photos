import Image from 'next/image'
import type { FeatureCardData } from '@/lib/menu-data'

// THE FEATURE CARDS (build/07 opener; build/09 addendum 6: the picks are
// OWNER-CHOSEN FeatureSpot rows now, read through getFeatures()). Purely
// presentational: whatever spots resolve, render; a dark or dead spot
// already dropped upstream, and prices always mirror the live menu. Slot
// 1 is the poster; the blended pass-photo is ambient texture (Amendment
// 2026-09-14c), not a claim about the dish on the card.
export function FeatureCards({ cards }: { cards: FeatureCardData[] }) {
  if (cards.length === 0) return null
  const [feature, ...rest] = cards
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:gap-6">
      {/* Poster anatomy: name top, price bottom (the justify-end version left
          a 463px dead amber void when the grid stretched the card). */}
      <a
        href={`#${feature.categoryId}`}
        className="lift tap-feedback relative flex min-h-[16rem] flex-col overflow-hidden rounded bg-amber p-6 text-on-amber md:min-h-[22rem] md:p-8"
      >
        {/* Owner-editable (2026-09-23): the dish's own photo wears the
            SAME blend format; cleared, the signature pass shot returns.
            The 30% multiply cap is what keeps the poster text legible
            over any photo, dark ones included. */}
        <Image
          src={feature.photo?.src ?? '/photos/cheeseburgers-pass.webp'}
          alt=""
          aria-hidden
          fill
          loading="lazy"
          sizes="(min-width: 768px) 680px, 100vw"
          className="object-cover object-right opacity-30 grayscale mix-blend-multiply"
        />
        <span className="relative flex h-full flex-col">
          <span className="block font-display text-h2 uppercase leading-none">
            {feature.name}
          </span>
          {feature.blurb ? (
            <span className="mt-3 block max-w-[24ch] text-h2 font-extrabold leading-[1.15] tracking-[-0.02em]">
              {feature.blurb}
            </span>
          ) : null}
          {feature.price !== null ? (
            <span className="mt-auto block pt-6 font-mono text-2xl font-bold tabular-nums">
              ${feature.price.toFixed(2)}
            </span>
          ) : null}
        </span>
      </a>

      {/* auto-rows-fr: the three cards share EQUAL heights (client feedback
          2026-09-23 - content-sized rows read as sloppy), and equal heights
          keep the logo defaults the same size across cards too. */}
      <div className="grid auto-rows-fr gap-4 lg:gap-6">
        {rest.map((card) => (
          <a
            key={card.slot}
            href={`#${card.categoryId}`}
            className="halftone lift tap-feedback relative flex min-h-[10rem] flex-col justify-end overflow-hidden rounded border border-hairline bg-paper p-6 hover:border-ink md:p-8"
          >
            {/* The dish's own photo fades in from the RIGHT edge (client
                direction 2026-09-23); with no photo the laurel logo is the
                stated default — a quiet mark, never an empty box. The name
                text carries the meaning, so this stays decorative. */}
            <span
              aria-hidden
              className="absolute inset-y-0 right-0 w-2/5 [mask-image:linear-gradient(to_left,black_45%,transparent)]"
            >
              <Image
                src={card.photo?.src ?? '/photos/logo-laurel.webp'}
                alt=""
                fill
                loading="lazy"
                sizes="260px"
                className={
                  card.photo ? 'object-cover' : 'object-contain object-right p-5 opacity-20'
                }
              />
            </span>
            <span className="relative block font-display text-h3 uppercase leading-tight text-ink">
              {card.name}
            </span>
            {card.blurb ? (
              <span className="relative mt-2 block max-w-[38ch] text-ink-muted">{card.blurb}</span>
            ) : null}
            <span className="relative mt-3 flex items-baseline justify-between gap-4">
              <span className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                {card.categoryTitle}
              </span>
              {card.price !== null ? (
                <span className="rounded bg-paper/85 px-1.5 py-0.5 font-mono text-lg font-bold tabular-nums">
                  ${card.price.toFixed(2)}
                </span>
              ) : null}
            </span>
          </a>
        ))}
      </div>
    </div>
  )
}
