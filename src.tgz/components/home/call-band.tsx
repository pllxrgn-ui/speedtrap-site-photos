import Link from 'next/link'
import { ArrowRight } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { VISIT_FACTS } from '@/lib/facts'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// CALL (build/06 §10). The giant action is the TELEPHONE NUMBER - tel clicks
// are the contracted KPI and no owner email exists. Hover ruling of record:
// the template slides the whole link 14px; our contract says rows grow an
// edge line and nothing slides - so the link is row-shaped and only the
// arrow glyph moves, 6px. The Good-to-know ledger is LOAD-BEARING: trimming
// it deletes "Wheelchair accessible entrance, restroom and seating." from
// the home page.
export function CallBand() {
  return (
    <section className="bg-paper py-20 md:py-24 lg:py-28">
      <Container className="lg:grid lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-7">
          <Reveal>
            <h2 className="font-display text-slab uppercase text-ink">
              <span className="stt-line block">
                <span className="stt-masked">Call us</span>
              </span>
            </h2>
          </Reveal>
          <Reveal className="mt-6">
            <a
              href={TEL_HREF}
              className="tick group inline-flex min-h-12 flex-wrap items-center gap-x-4 font-mono text-call font-bold tabular-nums text-ink hover:text-amber-ink"
            >
              {SITE.phoneDisplay}
              <ArrowRight
                aria-hidden
                weight="bold"
                className="size-[0.6em] text-amber transition-transform duration-[var(--dur-hover)] ease-[var(--ease-hover)] group-hover:translate-x-1.5"
              />
            </a>
            <p className="mt-6">
              <a
                href={DIRECTIONS_HREF}
                target="_blank"
                rel="noopener"
                className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
              >
                Get directions
              </a>
            </p>
          </Reveal>
        </div>

        <Reveal group className="mt-12 lg:col-span-4 lg:col-start-9 lg:mt-0">
          <dl className="stt-stagger border-t border-hairline">
            {VISIT_FACTS.map((fact) => (
              <div
                key={fact.id}
                className="grid grid-cols-[6rem_1fr] gap-4 border-b border-hairline py-4"
              >
                <dt className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                  {fact.label}
                </dt>
                <dd>{fact.teaser}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3">
            <Link
              href="/find-us"
              className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Find us
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
