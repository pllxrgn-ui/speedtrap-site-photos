import { ArrowRight } from '@phosphor-icons/react/dist/ssr'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// CALL (build/07 §1.12). The giant action is the TELEPHONE NUMBER - tel
// clicks are the contracted KPI and no owner email exists. Hover ruling: the
// link is row-shaped, only the arrow glyph moves 6px. The old Good-to-know
// teaser ledger MOVED to #find-us at its stronger (body) length - build/06's
// LOAD-BEARING note is honored there, do not restore the duplicate here.
// The statement is the retired /find-us ink band's copy, verbatim.
export function CallBand() {
  return (
    <section
      id="call"
      tabIndex={-1}
      className="anchor-section border-t border-hairline bg-surface py-20 md:py-24 lg:py-28"
    >
      <Container className="lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
        <div className="lg:col-span-7">
          <Reveal>
            <h2 className="font-display text-slab uppercase text-ink">
              <span className="stt-line block">
                <span className="stt-masked">Call us</span>
              </span>
            </h2>
          </Reveal>
          <Reveal className="mt-6">
            <a
              href={TEL_HREF}
              className="tick group inline-flex min-h-12 flex-wrap items-center gap-x-4 font-mono text-call font-bold tabular-nums text-ink hover:text-amber-ink"
            >
              {SITE.phoneDisplay}
              <ArrowRight
                aria-hidden
                weight="bold"
                className="size-[0.6em] text-amber transition-transform duration-[var(--dur-hover)] ease-[var(--ease-hover)] group-hover:translate-x-1.5"
              />
            </a>
            <p className="mt-6">
              <a
                href={DIRECTIONS_HREF}
                target="_blank"
                rel="noopener"
                className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
              >
                Get directions
              </a>
            </p>
          </Reveal>
        </div>

        <Reveal className="mt-10 lg:col-span-4 lg:col-start-9 lg:mt-0">
          <p className="max-w-[40ch] text-lg leading-relaxed text-ink-muted">
            One number does all of it. Hours, a table for a big group, a
            takeout order, or whether the kitchen is still on.
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
