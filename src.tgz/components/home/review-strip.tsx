import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { QUOTES, type Quote } from '@/lib/quotes'

// Verbatim only, attribution always, no avatars (build/03 §3, guardrail 5).
// Three of the four cleared quotes, covering food, service and both platforms.
// Selection only: wording is never touched here.
//
// Selected by id, not by index: [0, 2, 3] silently reads undefined the moment a
// quote is pulled from QUOTES (which happens when a reviewer deletes a review),
// and undefined.text throws at render. Missing ids just drop out, and if the
// picks all vanish the strip falls back to whatever is cleared.
const PICKS = ['blue-cheese-burger', 'service', 'local-establishment']

const picked = PICKS.map((id) => QUOTES.find((quote) => quote.id === id)).filter(
  (quote): quote is Quote => quote !== undefined,
)
const STRIP = picked.length > 0 ? picked : QUOTES.slice(0, 3)

export function ReviewStrip() {
  return (
    <section className="border-b border-hairline bg-paper">
      <Container className="py-12 md:py-20">
        <Reveal>
          <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
            What people say
          </h2>
        </Reveal>

        {/* Three quotes reading as a set, so they arrive as a set: group mode
            holds the wrapper still and staggers the figures behind the
            heading above (build/03 §1.5). */}
        <Reveal group>
          <div className="stt-stagger mt-8 grid gap-8 md:grid-cols-3">
            {STRIP.map((quote) => (
              <figure key={quote.id} className="border-t-2 border-ink pt-5">
                <blockquote className="max-w-[42ch] text-xl leading-snug font-bold">
                  {quote.text}
                </blockquote>
                <figcaption className="mt-3 text-ink-muted">
                  {quote.author}
                  <span className="block font-mono text-sm tabular-nums">
                    {quote.source}, {quote.year}
                  </span>
                </figcaption>
              </figure>
            ))}
          </div>
        </Reveal>

        <Reveal>
          <p className="mt-8">
            <Link
              href="/reviews"
              className="inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Read all the reviews
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
