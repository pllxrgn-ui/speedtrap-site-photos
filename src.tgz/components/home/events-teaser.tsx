import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { RECURRING } from '@/lib/events'

// Nothing in RECURRING is owner-confirmed yet, so this renders the rhythm and
// says so. No dates, no times beyond what the data file already carries.
const TEASER_IDS: string[] = ['taco-tuesday', 'fish-fry-friday', 'karaoke']
const TEASER = RECURRING.filter((event) => TEASER_IDS.includes(event.id))

export function EventsTeaser() {
  return (
    <section className="border-b border-hairline bg-surface">
      <Container className="py-12 md:py-20">
        <Reveal>
          <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
            The week, roughly
          </h2>
          <p className="mt-3 max-w-[62ch] text-ink-muted">
            This is the rhythm, not a promise. Call ahead if you are driving out
            for one of them.
          </p>
        </Reveal>

        {/* The rows are the content here, so they stagger in behind the
            heading rather than the block arriving whole (build/03 §1.5). */}
        <Reveal group>
          <dl className="stt-stagger mt-8">
            {TEASER.map((event) => (
              <div
                key={event.id}
                className="grid gap-1 border-t border-hairline py-5 md:grid-cols-[10rem_1fr] md:gap-6"
              >
                <dt className="font-mono text-sm uppercase tracking-wide text-ink-muted">
                  {event.day}
                </dt>
                <dd>
                  <span className="block text-xl font-extrabold uppercase leading-tight tracking-[-0.02em]">
                    {event.title}
                  </span>
                  <span className="mt-1 block text-ink-muted">{event.blurb}</span>
                </dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <Reveal>
          <p className="mt-6">
            <Link
              href="/events"
              className="inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              See everything that is on
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
