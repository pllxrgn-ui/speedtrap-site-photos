import type { CSSProperties } from 'react'
import Link from 'next/link'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { QUOTES, type Quote } from '@/lib/quotes'

// WHAT PEOPLE SAY (build/06 §9). All four cleared quotes render, selected by
// id (never index - the pattern that survives a reviewer deleting a review),
// wording never touched. The featured quote gets the template's word-by-word
// reveal ONCE; words keep real text so selection and pronunciation survive.
// CUT from the template: portraits (reviewer photos are permanently
// off-limits) and the stateful selector (a client island to hide quotes we
// can show at once). Server-rendered figures, on the record.
const byId = (id: string): Quote => {
  const quote = QUOTES.find((candidate) => candidate.id === id)
  if (!quote) throw new Error(`Quote missing from lib/quotes.ts: ${id}`)
  return quote
}

const FEATURED = byId('blue-cheese-burger')
const SUPPORTING = ['best-in-50-miles', 'service', 'local-establishment'].map(byId)

export function Voices() {
  const words = FEATURED.text.split(' ')
  return (
    <section className="border-y border-hairline bg-surface py-16 md:py-20 lg:py-24">
      <Container className="lg:grid lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-7">
          <Reveal>
            <h2 className="font-display text-slab uppercase text-ink">
              <span className="stt-line block">
                <span className="stt-masked">What people say</span>
              </span>
            </h2>
          </Reveal>
          <Reveal className="mt-8">
            <figure>
              <blockquote>
                <p className="stt-words max-w-[24ch] text-h1 font-extrabold uppercase leading-[1.08] tracking-[-0.02em]">
                  <span aria-hidden>&ldquo;</span>
                  {words.map((word, index) => (
                    <span
                      key={index}
                      className="inline-block"
                      style={{ '--stt-i': index } as CSSProperties}
                    >
                      {word}
                      {index < words.length - 1 ? ' ' : ''}
                    </span>
                  ))}
                  <span aria-hidden>&rdquo;</span>
                </p>
              </blockquote>
              <figcaption className="mt-6 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
                {FEATURED.author} &middot; {FEATURED.source}, {FEATURED.year}
              </figcaption>
            </figure>
          </Reveal>
        </div>

        <Reveal group className="mt-12 lg:col-span-4 lg:col-start-9 lg:mt-0">
          <ul className="stt-stagger">
            {SUPPORTING.map((quote) => (
              <li key={quote.id} className="border-t-2 border-ink py-6">
                <blockquote>
                  <p className="text-xl font-bold leading-snug">
                    &ldquo;{quote.text}&rdquo;
                  </p>
                </blockquote>
                <p className="mt-3 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
                  {quote.author} &middot; {quote.source}, {quote.year}
                </p>
              </li>
            ))}
          </ul>
          <p className="mt-2">
            <Link
              href="/reviews"
              className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Read all the reviews
            </Link>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
