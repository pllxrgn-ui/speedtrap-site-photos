import type { CSSProperties } from 'react'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { PLATFORM_LINKS, QUOTES, type Quote } from '@/lib/quotes'

// WHAT PEOPLE SAY (build/06 §9). All four cleared quotes render, selected by
// id (never index - the pattern that survives a reviewer deleting a review),
// wording never touched. The featured quote gets the template's word-by-word
// reveal ONCE; words keep real text so selection and pronunciation survive.
// CUT from the template: portraits (reviewer photos are permanently
// off-limits) and the stateful selector (a client island to hide quotes we
// can show at once). Server-rendered figures, on the record.
const byId = (id: string): Quote => {
  const quote = QUOTES.find((candidate) => candidate.id === id)
  if (!quote) throw new Error(`Quote missing from lib/quotes.ts: ${id}`)
  return quote
}

const FEATURED = byId('blue-cheese-burger')
const SUPPORTING = ['best-in-50-miles', 'service', 'local-establishment'].map(byId)

const PLATFORMS = [
  { label: 'Google', href: PLATFORM_LINKS.google },
  { label: 'Yelp', href: PLATFORM_LINKS.yelp },
  { label: 'TripAdvisor', href: PLATFORM_LINKS.tripadvisor },
]

export function Voices() {
  const words = FEATURED.text.split(' ')
  return (
    <section
      id="reviews"
      tabIndex={-1}
      className="anchor-section group border-y border-hairline bg-paper py-16 md:py-20 lg:py-24"
    >
      <Container className="lg:grid lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-7">
          <Reveal>
            <div className="border-t-2 border-ink transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber" />
            <h2 className="pt-5 font-display text-slab uppercase text-ink">
              <span className="stt-line block">
                <span className="stt-masked">What people say</span>
              </span>
            </h2>
            {/* The /reviews honesty lede, verbatim - it is the section's
                warranty and travels with the quotes. */}
            <p className="mt-4 max-w-[62ch] text-ink-muted">
              Every quote here is copied word for word from a public review,
              with the name and platform exactly as they appear there. Nothing
              is edited and nothing is written by us.
            </p>
          </Reveal>
          <Reveal className="mt-8">
            <figure>
              <blockquote>
                <p className="stt-words max-w-[24ch] text-h1 font-extrabold uppercase leading-[1.08] tracking-[-0.02em]">
                  <span aria-hidden>&ldquo;</span>
                  {words.map((word, index) => (
                    <span
                      key={index}
                      className="inline-block"
                      style={{ '--stt-i': index } as CSSProperties}
                    >
                      {word}
                      {index < words.length - 1 ? ' ' : ''}
                    </span>
                  ))}
                  <span aria-hidden>&rdquo;</span>
                </p>
              </blockquote>
              <figcaption className="mt-6 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
                {FEATURED.author} &middot; {FEATURED.source}, {FEATURED.year}
              </figcaption>
            </figure>
          </Reveal>
        </div>

        <Reveal group className="mt-12 lg:col-span-4 lg:col-start-9 lg:mt-0">
          <ul className="stt-stagger">
            {SUPPORTING.map((quote) => (
              <li key={quote.id} className="border-t-2 border-ink py-6">
                <blockquote>
                  <p className="text-xl font-bold leading-snug">
                    &ldquo;{quote.text}&rdquo;
                  </p>
                </blockquote>
                <p className="mt-3 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
                  {quote.author} &middot; {quote.source}, {quote.year}
                </p>
              </li>
            ))}
          </ul>
          {/* Straight to the platforms, unfiltered (absorbed from /reviews). */}
          <ul className="mt-6">
            {PLATFORMS.map((platform) => (
              <li key={platform.label} className="border-t border-hairline">
                <a
                  href={platform.href}
                  target="_blank"
                  rel="noopener"
                  className="tick flex min-h-12 items-center font-bold uppercase tracking-tight underline underline-offset-4 hover:text-amber-ink"
                >
                  {platform.label}
                </a>
              </li>
            ))}
          </ul>
          <p className="mt-4">
            <a
              href={PLATFORM_LINKS.google}
              target="_blank"
              rel="noopener"
              className="tick inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
            >
              Leave us a review on Google
            </a>
          </p>
        </Reveal>
      </Container>
    </section>
  )
}
