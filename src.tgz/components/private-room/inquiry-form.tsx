'use client'

import { useEffect, useRef, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { CheckCircle, WarningCircle } from '@phosphor-icons/react/dist/ssr'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'
import { OCCASIONS, inquirySchema, type InquiryInput } from '@/lib/inquiry'

// The page only mounts this when NEXT_PUBLIC_INQUIRY_ENABLED === '1'. Until the
// owner picks an inbox there is nowhere for a message to land, and a form that
// says "thanks, we will be in touch" into a void is worse than no form.
// Success here is only ever claimed after the server confirms delivery.

type Status =
  | { kind: 'idle' }
  | { kind: 'sent' }
  | { kind: 'failed'; message: string }

const CALL_INSTEAD = `We could not send that from here. Call ${SITE.phoneDisplay} and we will sort it out in two minutes.`

// Fields the server may name in a validation issue; anything else is ignored.
const FIELD_NAMES: Record<string, true> = {
  name: true,
  phone: true,
  date: true,
  headcount: true,
  occasion: true,
  message: true,
}

// Focus lands on the confirmation so screen readers announce it; the form it
// replaced took the old focus point with it.
function SentPanel() {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => ref.current?.focus(), [])
  return (
    <div
      ref={ref}
      role="status"
      tabIndex={-1}
      className="rounded border border-hairline bg-surface p-6 md:p-8"
    >
      <p className="flex items-center gap-3 text-h2 leading-[1.15] font-extrabold uppercase tracking-tight">
        <CheckCircle size={32} weight="fill" aria-hidden />
        That is with us
      </p>
      <p className="mt-4 max-w-[62ch] leading-relaxed">
        We have your date and your headcount. Expect a call back with a straight
        answer on whether the room fits. If you would rather not wait, the phone
        works both ways.
      </p>
      <p className="mt-4">
        <a href={TEL_HREF} className="font-mono text-lg font-bold underline underline-offset-4 hover:text-amber-ink">
          {SITE.phoneDisplay}
        </a>
      </p>
    </div>
  )
}

const fieldLabel = 'block font-bold uppercase tracking-tight'
const fieldHint = 'mt-1 text-sm text-ink-muted'
const inputBase =
  'mt-2 block w-full min-h-11 rounded bg-surface px-3 py-2 text-ink placeholder:text-ink-muted'
const inputRest = `${inputBase} border border-hairline`
// Errors are marked with weight, a 2px ink border and an icon rather than red:
// build/03 §4.8 reserves red for the open/closed status only.
const inputInvalid = `${inputBase} border-2 border-ink`

function FieldError({ id, children }: { id: string; children?: string }) {
  if (!children) return null
  return (
    <p id={id} role="alert" className="mt-2 flex items-start gap-2 font-bold">
      <WarningCircle size={20} weight="fill" aria-hidden className="mt-[3px] shrink-0" />
      <span>{children}</span>
    </p>
  )
}

export function InquiryForm() {
  const [status, setStatus] = useState<Status>({ kind: 'idle' })

  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<InquiryInput>({
    resolver: zodResolver(inquirySchema),
    defaultValues: {
      name: '',
      phone: '',
      date: '',
      headcount: '',
      occasion: '',
      message: '',
      hp_referrer: '',
    },
  })

  const onSubmit = handleSubmit(async (values) => {
    setStatus({ kind: 'idle' })
    try {
      const response = await fetch('/api/inquiry', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(values),
      })
      const body = (await response.json().catch(() => null)) as
        | { ok?: boolean; message?: string; issues?: { field: string; message: string }[] }
        | null

      if (!response.ok || body?.ok !== true) {
        // Server-side rejections mark their fields, not just the banner.
        for (const issue of body?.issues ?? []) {
          if (issue.field in FIELD_NAMES) {
            setError(issue.field as keyof InquiryInput, { message: issue.message })
          }
        }
        setStatus({ kind: 'failed', message: body?.message ?? CALL_INSTEAD })
        return
      }

      setStatus({ kind: 'sent' })
      reset()
    } catch {
      setStatus({ kind: 'failed', message: CALL_INSTEAD })
    }
  })

  if (status.kind === 'sent') {
    return <SentPanel />
  }

  return (
    <form noValidate onSubmit={onSubmit} className="relative">
      {/* Honeypot. Off screen, not focusable, hidden from assistive tech.
          Field name deliberately matches no browser autofill heuristic (a
          "company" field gets address-autofilled by Chrome, flagging real
          customers as bots). TODO: add Cloudflare Turnstile once the owner
          has an account and we have a real site key. */}
      <div aria-hidden className="pointer-events-none absolute left-[-9999px] top-0 h-0 w-0 overflow-hidden">
        <label htmlFor="inquiry-hp">Leave this field empty</label>
        <input id="inquiry-hp" type="text" tabIndex={-1} autoComplete="off" {...register('hp_referrer')} />
      </div>

      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="inquiry-name" className={fieldLabel}>
            Your name
          </label>
          <input
            id="inquiry-name"
            type="text"
            autoComplete="name"
            aria-invalid={errors.name ? true : undefined}
            aria-describedby={errors.name ? 'inquiry-name-error' : undefined}
            className={errors.name ? inputInvalid : inputRest}
            {...register('name')}
          />
          <FieldError id="inquiry-name-error">{errors.name?.message}</FieldError>
        </div>

        <div>
          <label htmlFor="inquiry-phone" className={fieldLabel}>
            Phone
          </label>
          <input
            id="inquiry-phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="509 555 0123"
            aria-invalid={errors.phone ? true : undefined}
            aria-describedby={errors.phone ? 'inquiry-phone-error' : undefined}
            className={`${errors.phone ? inputInvalid : inputRest} font-mono`}
            {...register('phone')}
          />
          <FieldError id="inquiry-phone-error">{errors.phone?.message}</FieldError>
        </div>

        <div>
          <label htmlFor="inquiry-date" className={fieldLabel}>
            Date you want
          </label>
          <input
            id="inquiry-date"
            type="date"
            aria-invalid={errors.date ? true : undefined}
            aria-describedby={errors.date ? 'inquiry-date-error' : undefined}
            className={`${errors.date ? inputInvalid : inputRest} font-mono`}
            {...register('date')}
          />
          <FieldError id="inquiry-date-error">{errors.date?.message}</FieldError>
        </div>

        <div>
          <label htmlFor="inquiry-headcount" className={fieldLabel}>
            How many people
          </label>
          <input
            id="inquiry-headcount"
            type="text"
            inputMode="numeric"
            placeholder="24"
            aria-invalid={errors.headcount ? true : undefined}
            aria-describedby={
              errors.headcount ? 'inquiry-headcount-error' : 'inquiry-headcount-hint'
            }
            className={`${errors.headcount ? inputInvalid : inputRest} font-mono`}
            {...register('headcount')}
          />
          {errors.headcount ? (
            <FieldError id="inquiry-headcount-error">{errors.headcount.message}</FieldError>
          ) : (
            <p id="inquiry-headcount-hint" className={fieldHint}>
              A rough number is fine. We will tell you if the room fits it.
            </p>
          )}
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="inquiry-occasion" className={fieldLabel}>
            What is the occasion
          </label>
          <select
            id="inquiry-occasion"
            aria-invalid={errors.occasion ? true : undefined}
            aria-describedby={errors.occasion ? 'inquiry-occasion-error' : undefined}
            className={errors.occasion ? inputInvalid : inputRest}
            {...register('occasion')}
          >
            <option value="">Pick one</option>
            {OCCASIONS.map((occasion) => (
              <option key={occasion} value={occasion}>
                {occasion}
              </option>
            ))}
          </select>
          <FieldError id="inquiry-occasion-error">{errors.occasion?.message}</FieldError>
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="inquiry-message" className={fieldLabel}>
            Anything else
          </label>
          <textarea
            id="inquiry-message"
            rows={5}
            aria-invalid={errors.message ? true : undefined}
            aria-describedby={errors.message ? 'inquiry-message-error' : 'inquiry-message-hint'}
            className={errors.message ? inputInvalid : inputRest}
            {...register('message')}
          />
          {errors.message ? (
            <FieldError id="inquiry-message-error">{errors.message.message}</FieldError>
          ) : (
            <p id="inquiry-message-hint" className={fieldHint}>
              Food, drinks, a start time, whether you need the room to yourselves.
              Optional.
            </p>
          )}
        </div>
      </div>

      {status.kind === 'failed' && (
        <div
          role="alert"
          className="mt-8 flex items-start gap-3 rounded border-2 border-ink bg-surface p-4"
        >
          <WarningCircle size={24} weight="fill" aria-hidden className="mt-1 shrink-0" />
          <div>
            <p className="font-bold">{status.message}</p>
            <p className="mt-2">
              <a
                href={TEL_HREF}
                className="font-mono text-lg font-bold underline underline-offset-4"
              >
                {SITE.phoneDisplay}
              </a>
            </p>
          </div>
        </div>
      )}

      <div className="mt-8 flex flex-wrap items-center gap-4">
        {/* No spinner: the motion register (build/03 §1.5) allows five moving
            things site wide and this is not one of them. The label and the
            disabled state carry the loading state instead. */}
        <button
          type="submit"
          disabled={isSubmitting}
          aria-busy={isSubmitting}
          className="lift tap-feedback inline-flex min-h-12 items-center justify-center gap-2 rounded bg-amber px-6 font-bold uppercase tracking-tight text-[#17181A] disabled:opacity-70"
        >
          {isSubmitting ? 'Sending' : 'Send it'}
        </button>
        <p className="text-ink-muted">
          In a hurry?{' '}
          <a href={TEL_HREF} className="font-mono font-bold underline underline-offset-4 hover:text-amber-ink">
            {SITE.phoneDisplay}
          </a>
        </p>
      </div>
    </form>
  )
}
