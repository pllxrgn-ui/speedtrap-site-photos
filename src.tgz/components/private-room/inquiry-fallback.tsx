import { Phone } from '@phosphor-icons/react/dist/ssr'
import { ButtonA } from '@/components/ui/button'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

// What the private room page shows while NEXT_PUBLIC_INQUIRY_ENABLED is off.
// There is no inbox to deliver an inquiry to yet, so the honest move is to send
// people to the phone rather than to a form that swallows their booking.

export function InquiryFallback() {
  return (
    <div className="rounded border border-hairline bg-surface p-6 md:p-8">
      <h2 className="text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
        Call us and we will sort it out in two minutes
      </h2>
      <p className="mt-4 max-w-[62ch] leading-relaxed">
        A date, a headcount, and roughly what you have in mind. That is the whole
        conversation. You will know before you hang up whether the room is free and
        whether it fits your group.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        {/* Demoted from amber 2026-09-22: the amber-fill cap is spent by the
            booking submit ONE BLOCK DOWN (build/08 §0) - two lit asks in
            adjacent blocks would argue with each other. */}
        <ButtonA href={TEL_HREF} variant="ink" className="min-h-12">
          <Phone size={20} weight="bold" aria-hidden />
          Call {SITE.phoneDisplay}
        </ButtonA>
      </div>
      <p className="mt-6 text-sm text-ink-muted">
        Booking by phone for now. An online form lands here once the inbox behind it
        is real.
      </p>
    </div>
  )
}
