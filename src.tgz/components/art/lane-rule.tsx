// Illustration tier, build/03 §1.7. A lane stripe standing in for a section
// rule: a continuous hairline seam with amber dashes riding on it.
//
// No viewBox on purpose. The dashes are laid out in CSS pixels against a 100%
// width, so they tile at their drawn length at every viewport instead of being
// stretched by preserveAspectRatio="none", which is what turns a lane stripe
// into a smear on a wide screen.
//
// Not a gradient (§4.8): stroke-dasharray is hard-edged repetition.
//
// DRIFT (motion pass, 2026-09-13). The dashed line is drawn starting 44px to
// the left of the box and animated by exactly +44px to 0, which is one whole
// dash period (24 on, 20 off), so the loop has no seam and the overhang keeps
// both ends covered at every frame. transform on a <g>, not stroke-dashoffset:
// dashoffset is a paint property and the register is transform and opacity
// only. Desktop and prefers-reduced-motion: no-preference only; the gate lives
// in globals.css with the rest of the layer.
export function LaneRule({
  className = '',
  drift = false,
}: {
  className?: string
  /** Turn on the creeping loop. Rationed: the footer seam and the 404. */
  drift?: boolean
}) {
  return (
    <svg
      width="100%"
      height="4"
      className={`block h-1 w-full ${className}`}
      aria-hidden="true"
      focusable="false"
    >
      <line x1="0" y1="2" x2="100%" y2="2" stroke="var(--hairline)" strokeWidth="4" />
      <g className={drift ? 'stt-lane-drift' : undefined}>
        <line
          x1="-44"
          y1="2"
          x2="100%"
          y2="2"
          stroke="var(--amber)"
          strokeWidth="4"
          strokeDasharray="24 20"
        />
      </g>
    </svg>
  )
}
