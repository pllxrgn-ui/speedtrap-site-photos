// Strip map of the US-2 corridor. All DOM text and CSS shapes, no drawn
// artwork (client direction 2026-09-13: no pictorial SVG). currentColor makes
// one component work on paper and inside the ink band. No distance is printed
// that is not verified: the Grand Coulee leg is labelled by direction.

type Node = {
  label: string
  sub?: string
  leg?: string
  kind: 'town' | 'here' | 'onward'
}

const NODES: Node[] = [
  { label: 'Spokane', leg: '22 mi west', kind: 'town' },
  { label: 'Reardan', sub: 'Speed Trap Tap House', leg: 'Highway 2 west', kind: 'here' },
  { label: 'Grand Coulee', sub: 'Lake Roosevelt', kind: 'onward' },
]

function Marker({ kind }: { kind: Node['kind'] }) {
  if (kind === 'here') {
    // stt-locate draws the locator ring (build/03 §1.5): two passes at a 2.2s
    // period when the band scrolls into view, then it rests for good. The
    // ring only exists inside a <Reveal> that has gone visible, so there is
    // nothing to paint at rest and nothing at all under reduced motion.
    return (
      <span
        aria-hidden="true"
        className="stt-locate relative block h-4 w-4 shrink-0 rounded-full border-[3px] border-current bg-amber"
      />
    )
  }
  if (kind === 'onward') {
    return (
      <span
        aria-hidden="true"
        className="block h-0 w-0 shrink-0 border-y-8 border-l-[12px] border-y-transparent border-l-current"
      />
    )
  }
  return (
    <span aria-hidden="true" className="block h-4 w-4 shrink-0 border-2 border-current" />
  )
}

export function CorridorMap({ className = '' }: { className?: string }) {
  return (
    <ol className={`grid gap-y-7 md:grid-cols-3 md:gap-y-0 ${className}`}>
      {NODES.map((node, i) => {
        const last = i === NODES.length - 1
        return (
          <li
            key={node.label}
            className="relative grid grid-cols-[1rem_1fr] gap-x-3 md:block md:pr-6"
          >
            <div className="md:flex md:items-center md:gap-3">
              <Marker kind={node.kind} />
              {last ? null : (
                <span aria-hidden="true" className="hidden h-0.5 flex-1 bg-current md:block" />
              )}
            </div>

            {last ? null : (
              <span
                aria-hidden="true"
                className="absolute left-[7px] top-6 -bottom-7 w-0.5 bg-current md:hidden"
              />
            )}

            <div className="md:mt-3">
              <p className="font-mono text-sm font-bold uppercase tracking-wide">
                {node.label}
              </p>
              {node.sub ? <p className="mt-0.5 text-sm">{node.sub}</p> : null}
              {node.leg ? (
                <p className="mt-1 font-mono text-sm tabular-nums opacity-70">{node.leg}</p>
              ) : null}
            </div>
          </li>
        )
      })}
    </ol>
  )
}
