import { NextResponse, type NextRequest } from 'next/server'

// Convenience redirect ONLY — never the authorization boundary (build/08
// §2 row 9, veto 8): Edge cannot run Prisma, so this checks nothing but
// cookie SHAPE. The real gate is requireSession() in the admin layout and
// every /api/admin handler, enforced mechanically by
// scripts/check-admin-auth.mjs inside `pnpm gate`.
export function middleware(request: NextRequest) {
  const hasSessionCookie = Boolean(request.cookies.get('stt_admin')?.value)
  const { pathname } = request.nextUrl
  if (!hasSessionCookie && pathname !== '/admin/login') {
    return NextResponse.redirect(new URL('/admin/login', request.url))
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/admin', '/admin/:path*'],
}
