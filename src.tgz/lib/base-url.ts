// Canonical base URL. The domain is chosen but not yet registered
// (CLIENT-QUESTIONS #12); override with NEXT_PUBLIC_SITE_URL on Vercel
// previews so sitemap/robots URLs match the deployment.
export const BASE_URL =
  process.env.NEXT_PUBLIC_SITE_URL ?? 'https://speedtraptaphouse.com'
