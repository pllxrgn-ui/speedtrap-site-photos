// Canonical base URL, in priority order:
// 1. NEXT_PUBLIC_SITE_URL - set this at real-domain cutover (CLIENT-QUESTIONS
//    #12) and everything (sitemap, robots, OG, origin check) follows.
// 2. VERCEL_PROJECT_PRODUCTION_URL - Vercel's build-time system env carrying
//    the clean production alias (thespeedtrap.vercel.app). Without this, the
//    client-preview phase advertised og:image/sitemap on the UNREGISTERED
//    .com (measured ENOTFOUND: every share rendered imageless - audit
//    build/05 M11/M12).
// 3. The chosen-but-unregistered domain, for local builds only.
export const BASE_URL =
  process.env.NEXT_PUBLIC_SITE_URL ??
  (process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : 'https://speedtraptaphouse.com')
