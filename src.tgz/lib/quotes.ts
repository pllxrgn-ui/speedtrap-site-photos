// Verbatim review quotes ONLY — research/01, cleared list in
// build/02-content-plan.md. Never edit wording, never invent, always attribute.

export type Quote = {
  /** Stable key for selecting a subset (the home strip) without using indexes. */
  id: string
  text: string
  author: string
  source: 'Yelp' | 'Google'
  year: number
}

export const QUOTES: Quote[] = [
  {
    id: 'blue-cheese-burger',
    text: 'The Blue Cheese Burger was the best burger I have ever eaten!',
    author: 'Tom R., Coeur d’Alene',
    source: 'Yelp',
    year: 2026,
  },
  {
    id: 'best-in-50-miles',
    text: 'Best burger in 50 miles!!',
    author: 'Ross L.',
    source: 'Yelp',
    year: 2023,
  },
  {
    id: 'service',
    text: 'The crowning jewel of this place is the service.',
    author: 'Jason S., Cheney',
    source: 'Yelp',
    year: 2021,
  },
  {
    id: 'local-establishment',
    text: 'Great local establishment, food is amazing!',
    author: 'Vance L.',
    source: 'Google',
    year: 2026,
  },
]

export const PLATFORM_LINKS = {
  google: 'https://maps.app.goo.gl/DcbbzRMCaruzBMrK9',
  yelp: 'https://www.yelp.com/biz/speed-trap-tap-house-reardan',
  tripadvisor:
    'https://www.tripadvisor.com/Restaurant_Review-g58701-d19257596-Reviews-Speed_Trap_Tap_House-Reardan_Washington.html',
}
