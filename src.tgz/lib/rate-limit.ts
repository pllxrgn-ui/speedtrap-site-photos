// Fixed-window rate limiting in the Postgres we already have — no KV, no
// Upstash (build/08 §7, "costs deliberately not incurred"). One atomic
// upsert per window: INSERT .. ON CONFLICT .. count = count + 1. Counting
// continues past the limit on purpose: a flood keeps its own window hot.

export interface RateWindow {
  bucket: string
  windowMs: number
  limit: number
}

export type RateDecision = { allowed: true } | { allowed: false; retryAfterSeconds: number }

// Structural subset of PrismaClient so tests can pass a fake store.
export interface RateStore {
  rateHit: {
    upsert(args: {
      where: { bucket_windowStart: { bucket: string; windowStart: Date } }
      create: { bucket: string; windowStart: Date; count: number }
      update: { count: { increment: number } }
    }): Promise<{ count: number }>
  }
}

export async function takeRateSlots(
  db: RateStore,
  windows: RateWindow[],
  now = Date.now(),
): Promise<RateDecision> {
  for (const window of windows) {
    const startMs = Math.floor(now / window.windowMs) * window.windowMs
    const windowStart = new Date(startMs)
    const row = await db.rateHit.upsert({
      where: { bucket_windowStart: { bucket: window.bucket, windowStart } },
      create: { bucket: window.bucket, windowStart, count: 1 },
      update: { count: { increment: 1 } },
    })
    if (row.count > window.limit) {
      // Deny at the FIRST violated window and STOP. The offender's own
      // bucket was incremented above (a flood keeps its own window hot),
      // but the windows after it — the shared global ceiling in
      // particular — must not be charged for a request that is already
      // refused: one abusive IP could otherwise spend the whole global
      // budget and lock every real customer out (review 2026-09-22,
      // finding 1). Callers therefore list per-IP windows BEFORE global.
      return {
        allowed: false,
        retryAfterSeconds: Math.ceil((startMs + window.windowMs - now) / 1000),
      }
    }
  }
  return { allowed: true }
}

const HOUR_MS = 3_600_000
const DAY_MS = 24 * HOUR_MS
const FIFTEEN_MIN_MS = 900_000

// Budgets from build/08 §2 row 4. Bucket names carry the window length
// (:h/:d) because (bucket, windowStart) is the primary key — at midnight an
// hour window and a day window share a start time, and an unsuffixed name
// would double-count into one row. Per-IP windows come FIRST (see the
// short-circuit above); the GLOBAL ceiling exists for a distributed flood,
// never to let one IP starve everyone else.
export function bookingWindows(ipHash: string | null): RateWindow[] {
  const windows: RateWindow[] = []
  if (ipHash) {
    windows.push({ bucket: `book:h:${ipHash}`, windowMs: HOUR_MS, limit: 5 })
    windows.push({ bucket: `book:d:${ipHash}`, windowMs: DAY_MS, limit: 20 })
  }
  windows.push({ bucket: 'book:global:h', windowMs: HOUR_MS, limit: 60 })
  return windows
}

export function loginWindows(ipHash: string | null): RateWindow[] {
  const windows: RateWindow[] = []
  if (ipHash) {
    windows.push({ bucket: `login:${ipHash}`, windowMs: FIFTEEN_MIN_MS, limit: 5 })
  }
  windows.push({ bucket: 'login:global', windowMs: FIFTEEN_MIN_MS, limit: 20 })
  return windows
}
