// FAQ seed from build/02-content-plan.md. Only verified facts get a firm
// answer; everything else says "call us" honestly rather than guessing.
//
// The parking, accessibility, reservations and takeout answers come from
// lib/facts.ts, which is also what /find-us and the home teaser render, so the
// page copy, this list and the FAQPage JSON-LD built from it cannot drift.

import { visitFact } from './facts'

export type Faq = { q: string; a: string }

export const FAQS: Faq[] = [
  {
    q: 'Are kids welcome?',
    a: 'Yes. Families eat here all the time, and Google lists us as good for kids.',
  },
  {
    q: 'Is there parking?',
    a: visitFact('parking').answer,
  },
  {
    q: 'Is it wheelchair accessible?',
    a: visitFact('access').answer,
  },
  {
    q: 'Can I book the private room or a big group?',
    a: visitFact('reservations').answer,
  },
  {
    q: 'Do you do takeout?',
    a: visitFact('dining').answer,
  },
  {
    q: 'Gluten-free or vegetarian options?',
    a: 'Some, yes. Call and ask about today’s options and we will steer you right.',
  },
]
