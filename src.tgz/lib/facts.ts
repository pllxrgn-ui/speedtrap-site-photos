// The cleared "before you come" facts, in one place.
//
// Source: Google business attributes for this listing, cleared in
// build/02-content-plan.md §Find Us. These four are rendered in three places
// (the home teaser, the /find-us grid and the FAQ answers that feed the
// FAQPage JSON-LD), which is exactly how the same fact ends up phrased three
// different ways. One record per fact, three registers of the same sentence.
//
// NOT in here, on purpose: the street address (the E/W Broadway conflict is
// unresolved, CLIENT-QUESTIONS #3) and hours (six sources, six answers).
//
// Group size: "call ahead for groups of six or more" was an audit
// recommendation, never an owner-confirmed policy, so no number appears in any
// of these strings. Reservations are accepted, big groups should call. That is
// the whole verified claim.

export type VisitFactId = 'parking' | 'access' | 'dining' | 'reservations'

export type VisitFact = {
  id: VisitFactId
  /** Mono label for the home teaser row. */
  label: string
  /** Heading on /find-us. */
  title: string
  /** Full sentence on /find-us. */
  body: string
  /** One line for the home teaser. */
  teaser: string
  /** Verbatim FAQ answer, reused by lib/faq.ts and its FAQPage markup. */
  answer: string
}

export const VISIT_FACTS: readonly VisitFact[] = [
  {
    id: 'parking',
    label: 'Parking',
    title: 'Parking is free',
    body: 'A free lot, plus free parking on the street. Pull in, leave the meter money at home.',
    teaser: 'Free lot, plus street parking out front.',
    answer: 'Free lot plus free street parking, right off Highway 2.',
  },
  {
    id: 'access',
    label: 'Access',
    title: 'Wheelchair accessible',
    body: 'Accessible entrance, accessible restroom, accessible seating and accessible parking.',
    teaser: 'Wheelchair accessible entrance, restroom and seating.',
    answer: 'Yes. Accessible entrance, restroom, seating, and parking.',
  },
  {
    id: 'dining',
    label: 'Eating',
    title: 'Dine in or take out',
    body: 'Eat here, or call it in and pick it up on your way through.',
    teaser: 'Dine in, or call it in and pick it up.',
    answer: 'Yes. Call it in and pick it up.',
  },
  {
    id: 'reservations',
    label: 'Booking',
    title: 'Reservations, yes',
    body: 'We take them. Call ahead for a big group so the kitchen can keep up with you.',
    teaser: 'Reservations accepted. Call ahead for big groups.',
    answer:
      'Yes, we take reservations. Call ahead for a big group so the kitchen can keep up.',
  },
]

export function visitFact(id: VisitFactId): VisitFact {
  const fact = VISIT_FACTS.find((candidate) => candidate.id === id)
  if (!fact) throw new Error(`Unknown visit fact: ${id}`)
  return fact
}
