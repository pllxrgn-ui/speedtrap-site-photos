import { randomBytes, timingSafeEqual } from 'node:crypto'

// Double-submit CSRF (build/08 §2 row 7): the stt_csrf cookie is READABLE
// by page JS on purpose — lib/admin/mutate.ts copies it into the
// x-stt-csrf header, and a cross-site request can send the cookie but can
// never read it to forge the header. SameSite=Lax and the origin gate are
// the layers in front; this is the one that holds if both slip.
export const CSRF_COOKIE = 'stt_csrf'
export const CSRF_HEADER = 'x-stt-csrf'

export function newCsrfToken(): string {
  return randomBytes(32).toString('hex')
}

export function cookieValue(request: Request, name: string): string | null {
  const header = request.headers.get('cookie')
  if (!header) return null
  for (const pair of header.split(';')) {
    const eq = pair.indexOf('=')
    if (eq === -1) continue
    if (pair.slice(0, eq).trim() === name) return pair.slice(eq + 1).trim()
  }
  return null
}

export function csrfOk(request: Request): boolean {
  const presented = request.headers.get(CSRF_HEADER)
  const expected = cookieValue(request, CSRF_COOKIE)
  if (!presented || !expected) return false
  const a = Buffer.from(presented)
  const b = Buffer.from(expected)
  return a.length === b.length && timingSafeEqual(a, b)
}
