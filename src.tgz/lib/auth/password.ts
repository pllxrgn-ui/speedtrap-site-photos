import {
  randomBytes,
  scrypt as scryptCb,
  timingSafeEqual,
  type ScryptOptions,
} from 'node:crypto'

// Hand-wrapped: util.promisify types collapse to the 3-argument overload
// and lose the cost options, which are the whole point.
function scrypt(
  password: string,
  salt: Buffer,
  keyLength: number,
  options: ScryptOptions,
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCb(password, salt, keyLength, options, (error, key) =>
      error ? reject(error) : resolve(key),
    )
  })
}

// Self-describing hash format — scrypt:N:r:p:salt_hex:key_hex — so the
// parameters can be raised later without invalidating the stored value
// (build/08 §2 row 6). scripts/hash-password.mjs produces it; only the
// HASH ever reaches an env var, never the passphrase.
export const SCRYPT_N = 16384
export const SCRYPT_R = 8
export const SCRYPT_P = 1
const KEY_LENGTH = 64
const SCRYPT_MAXMEM = 64 * 1024 * 1024

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16)
  const key = (await scrypt(password, salt, KEY_LENGTH, {
    N: SCRYPT_N,
    r: SCRYPT_R,
    p: SCRYPT_P,
    maxmem: SCRYPT_MAXMEM,
  })) as Buffer
  return `scrypt:${SCRYPT_N}:${SCRYPT_R}:${SCRYPT_P}:${salt.toString('hex')}:${key.toString('hex')}`
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split(':')
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false
  const N = Number(parts[1])
  const r = Number(parts[2])
  const p = Number(parts[3])
  if (![N, r, p].every((n) => Number.isInteger(n) && n > 0)) return false
  const salt = Buffer.from(parts[4], 'hex')
  const expected = Buffer.from(parts[5], 'hex')
  if (salt.length < 8 || expected.length !== KEY_LENGTH) return false
  try {
    const key = (await scrypt(password, salt, expected.length, {
      N,
      r,
      p,
      maxmem: SCRYPT_MAXMEM,
    })) as Buffer
    return timingSafeEqual(key, expected)
  } catch {
    return false
  }
}

// Every auth response leaves after the same floor, success or failure, so
// response timing teaches an attacker nothing (§2 row 6: constant ~250ms).
export async function withMinDuration<T>(minMs: number, work: () => Promise<T>): Promise<T> {
  const startedAt = Date.now()
  try {
    return await work()
  } finally {
    const elapsed = Date.now() - startedAt
    if (elapsed < minMs) {
      await new Promise((resolve) => setTimeout(resolve, minMs - elapsed))
    }
  }
}
