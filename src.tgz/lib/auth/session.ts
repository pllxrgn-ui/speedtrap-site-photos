import { createHash, randomBytes } from 'node:crypto'
import { cookies } from 'next/headers'
import type { Session } from '@prisma/client'
import { getDb } from '@/lib/db'
import { CSRF_COOKIE } from '@/lib/auth/csrf'

// Server-side sessions (build/08 §0 fork D): the cookie carries 32 random
// bytes and the database stores only their sha256, so a DB dump hands over
// no live sessions and any session can be revoked by deleting its row.
export const SESSION_COOKIE = 'stt_admin'

const ROLLING_MS = 8 * 60 * 60 * 1000 // rolling 8h
const ABSOLUTE_MS = 7 * 24 * 60 * 60 * 1000 // hard 7d

function tokenHashOf(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

export async function createSession(ipHash: string | null): Promise<string> {
  const db = getDb()
  const token = randomBytes(32).toString('hex')
  const now = Date.now()
  // ONE owner account (#B2): every prior session dies at login, which is
  // also what makes fixation structurally impossible — no pre-login token
  // can survive into the authenticated state.
  await db.session.deleteMany({})
  await db.session.create({
    data: {
      tokenHash: tokenHashOf(token),
      expiresAt: new Date(now + ROLLING_MS),
      absoluteEnd: new Date(now + ABSOLUTE_MS),
      ipHash,
    },
  })
  return token
}

// Revocation keys off the HASH the session row already carries, so logout
// has exactly one read path: requireSession found the row, and the same
// row is what dies (review: reading the raw token a second time from the
// request could silently diverge from the jar requireSession used).
export async function revokeSession(tokenHash: string): Promise<void> {
  await getDb().session.deleteMany({ where: { tokenHash } })
}

async function validSessionFor(token: string): Promise<Session | null> {
  const db = getDb()
  const session = await db.session.findUnique({ where: { tokenHash: tokenHashOf(token) } })
  if (!session) return null
  const now = Date.now()
  if (session.expiresAt.getTime() <= now || session.absoluteEnd.getTime() <= now) return null
  // Roll the window on activity, but never past the absolute end.
  const nextExpiry = new Date(Math.min(now + ROLLING_MS, session.absoluteEnd.getTime()))
  return db.session.update({
    where: { tokenHash: session.tokenHash },
    data: { lastSeenAt: new Date(now), expiresAt: nextExpiry },
  })
}

// THE authorization boundary (§2 row 9): called in the admin layout AND in
// every /api/admin handler — scripts/check-admin-auth.mjs greps for it in
// `pnpm gate`. The middleware redirect is convenience only.
export async function requireSession(): Promise<Session | null> {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (!token) return null
  try {
    return await validSessionFor(token)
  } catch {
    // A database failure must read as "not signed in", never as a crash
    // inside a layout render.
    return null
  }
}

// Set-Cookie values built by hand so route handlers stay plain Response
// objects (testable without the Next runtime). Secure is unconditional —
// browsers exempt localhost from the Secure requirement in dev.
export function sessionCookie(token: string): string {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${ROLLING_MS / 1000}`
}

export function csrfCookie(token: string): string {
  // Deliberately NOT HttpOnly — the double-submit pattern needs page JS to
  // read it (lib/auth/csrf.ts).
  return `${CSRF_COOKIE}=${token}; Path=/; Secure; SameSite=Lax; Max-Age=${ROLLING_MS / 1000}`
}

export function clearedAuthCookies(): string[] {
  return [
    `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`,
    `${CSRF_COOKIE}=; Path=/; Secure; SameSite=Lax; Max-Age=0`,
  ]
}
