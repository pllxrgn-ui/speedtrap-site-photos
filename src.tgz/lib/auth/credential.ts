// Which passphrase hash is ACTIVE (build/09 addendum 7). The database row
// wins the moment it exists — that is what makes the passphrase rotatable
// from inside the admin without a redeploy. The ADMIN_PASSWORD_HASH env
// var is the bootstrap and the recovery path: delete the row (Neon
// console) and the env passphrase opens the door again.

import type { PrismaClient } from '@prisma/client'

export async function activeAdminHash(
  db: Pick<PrismaClient, 'adminCredential'>,
): Promise<string | null> {
  const row = await db.adminCredential.findUnique({ where: { id: 1 } })
  return row?.hash ?? process.env.ADMIN_PASSWORD_HASH ?? null
}
