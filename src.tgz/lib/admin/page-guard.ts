import { cache } from 'react'
import { redirect } from 'next/navigation'
import type { Session } from '@prisma/client'
import { requireSession } from '@/lib/auth/session'

// THE PAGE WALL (security fix 2026-09-28, ported from Betty's review F1).
// Next renders an App Router layout and its page IN PARALLEL: when only the
// (authed) layout checked the session, a forged stt_admin cookie (any value
// passes the middleware's shape check) got a 307 to the sign-in whose body
// still carried the page's server payload - THE BOOK's bookings (name,
// phone, note), THE LOG's lines, THE BOARD's editor props, THE HOURS rows.
// So every page under app/admin/(authed) calls this FIRST, before any
// getDb(), and the layout calls it too. scripts/check-admin-auth.mjs fails
// the gate on a page that does not.
//
// cache() makes the layout and the page share one session read per
// request (requireSession rolls the window with a write).
const sessionForRender = cache(requireSession)

export async function requireAdminPage(): Promise<Session> {
  const session = await sessionForRender()
  if (!session) redirect('/admin/login')
  return session
}
