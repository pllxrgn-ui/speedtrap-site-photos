// THE LOG's sentences (build/09 addendum 4). Every MenuEvent ledger row
// renders as one plain-words line — the same register as the tray, so
// what the owner reviewed before applying is what the log says happened.
// Pure on purpose: the wording is pinned by tests, because a log that
// quietly rewords itself is a log nobody can trust.

export interface MenuLogEvent {
  actor: string
  dishName: string
  field: string
  from: string | null
  to: string | null
}

const price = (value: string | null) => value ?? 'no price'

export function menuEventLine(event: MenuLogEvent): string {
  // The two seed rows are the ledger's floor — the day the site opened.
  if (event.actor === 'seed') return `Opening entry: ${event.dishName}`

  switch (event.field) {
    case 'price':
      return `${event.dishName} — price ${price(event.from)} → ${price(event.to)}`
    case 'name':
      return `Renamed ${event.from ?? event.dishName} → ${event.to ?? event.dishName}`
    case 'description':
      return event.to
        ? `${event.dishName} — line now “${event.to}”`
        : `${event.dishName} — line cleared`
    case 'created':
      return `Added ${event.dishName}`
    case 'deleted':
      return `Removed ${event.dishName}`
    case 'order':
      return `Moved ${event.dishName}`
    case 'board-created':
      return `Added the ${event.dishName} board`
    case 'board-renamed':
      return `Renamed the ${event.from ?? event.dishName} board → ${event.to ?? event.dishName}`
    case 'board-note':
      return event.to
        ? `${event.dishName} board — line now “${event.to}”`
        : `${event.dishName} board — line cleared`
    case 'board-order':
      return `Moved the ${event.dishName} board`
    case 'board-deleted':
      return `Removed the ${event.dishName} board`
    default:
      // A field this module does not know yet still shows up honestly
      // rather than vanishing from the record.
      return `${event.dishName} — ${event.field}`
  }
}
