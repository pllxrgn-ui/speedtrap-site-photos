import { csrfOk } from '@/lib/auth/csrf'
import { requireSession } from '@/lib/auth/session'
import { isAllowedOrigin } from '@/lib/http/origin'

// The one gauntlet every admin MUTATION runs: origin, then a real session
// row (requireSession — THE boundary, §2 row 9), then the double-submit
// token. scripts/check-admin-auth.mjs accepts `adminGuards(` as proof a
// route runs it. Returns the refusal Response, or null to proceed.
export async function adminGuards(request: Request): Promise<Response | null> {
  if (!isAllowedOrigin(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }
  const session = await requireSession()
  if (!session) {
    return Response.json({ ok: false, message: 'Not signed in.' }, { status: 401 })
  }
  if (!csrfOk(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }
  return null
}
