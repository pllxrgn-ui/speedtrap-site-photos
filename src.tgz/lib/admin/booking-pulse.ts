// THE WATCHER's brain (build/09 addendum 5), pure so the cling rule is
// unit-tested: the laptop clings on a NEW ARRIVAL — a booking created
// since the last look — never on a count change alone (confirming a
// ticket shrinks the count; that is the owner working, not news).

export interface BookingPulse {
  newCount: number
  /** ISO stamp of the newest still-new request, null when the book is clear. */
  latestAt: string | null
}

/** True exactly when `next` carries an arrival newer than `prev` saw.
 *  The first look (prev null) only sets the baseline — reopening the
 *  laptop onto three old tickets must not cling three times. */
export function isNewArrival(prev: BookingPulse | null, next: BookingPulse): boolean {
  if (prev === null) return false
  if (next.latestAt === null) return false
  if (prev.latestAt === null) return true
  // ISO-8601 UTC strings order lexicographically.
  return next.latestAt > prev.latestAt
}

/** The tab title carries the waiting count — visible from another window. */
export function titleWithBadge(base: string, newCount: number): string {
  const bare = base.replace(/^\(\d+\) /, '')
  return newCount > 0 ? `(${newCount}) ${bare}` : bare
}

/** Desktop notification copy. NO PII on purpose: a notification can sit
 *  on a lock screen — it says the book needs eyes, not who called. */
export function notificationBody(newCount: number): string {
  return newCount === 1
    ? 'The book has 1 request waiting.'
    : `The book has ${newCount} requests waiting.`
}
