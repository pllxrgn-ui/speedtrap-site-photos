// THE TRAY (build/09 addendum 3). Menu edits stop going live one tap at a
// time: they queue as DRAFTS, the preview shows the future site, and one
// "Apply to the site" replays them through the same per-change APIs — so
// the MenuEvent ledger keeps one row per applied change and the server
// model does not change at all. This module is the tray's brain, kept
// PURE (no fetch, no React, no storage) so every rule here is unit-tested:
// what queues, what coalesces, what cancels out, how the draft view is
// rebuilt, and how a saved tray replays onto a fresh baseline.
//
// THE INVARIANT every rule must preserve: replaying the pending list onto
// the baseline produces exactly the view the owner reviewed. Coalescing
// may only rewrite the list into an equivalent one (same final view).

import { z } from 'zod'
import type { HoldUntil } from '@prisma/client'

export interface PreviewDish {
  id: string
  name: string
  description: string
  price: string // display form: "17.50" or "" for none
  soldOut: boolean
  hold: HoldUntil
  photo: { src: string; alt: string } | null
  /** true while the dish exists only in the tray (not yet applied). */
  draft?: boolean
}

export interface PreviewGroup {
  categoryId: string
  title: string
  note: string
  dishes: PreviewDish[]
  /** true while the board exists only in the tray (not yet applied). */
  draft?: boolean
}

// ---------------------------------------------------------------------------
// The changes themselves. Draft-created rows carry ids minted client-side
// with the `draft-` prefix; Apply maps them to real ids as it creates them.

const draftChangeSchema = z.discriminatedUnion('kind', [
  z.object({
    kind: z.literal('dish-edit'),
    id: z.string().min(1).max(120),
    dishName: z.string().max(60),
    field: z.enum(['name', 'description', 'price']),
    from: z.string().max(200),
    to: z.string().max(200),
  }),
  z.object({
    kind: z.literal('dish-add'),
    id: z.string().min(1).max(120),
    categoryId: z.string().min(1).max(120),
    boardTitle: z.string().max(40),
  }),
  z.object({
    kind: z.literal('dish-remove'),
    id: z.string().min(1).max(120),
    dishName: z.string().max(60),
  }),
  z.object({
    kind: z.literal('dish-move'),
    id: z.string().min(1).max(120),
    dishName: z.string().max(60),
    direction: z.enum(['up', 'down']),
  }),
  z.object({
    kind: z.literal('board-edit'),
    id: z.string().min(1).max(120),
    boardTitle: z.string().max(40),
    field: z.enum(['title', 'note']),
    from: z.string().max(200),
    to: z.string().max(200),
  }),
  z.object({
    kind: z.literal('board-add'),
    id: z.string().min(1).max(120),
    title: z.string().min(1).max(40),
  }),
  z.object({
    kind: z.literal('board-remove'),
    id: z.string().min(1).max(120),
    boardTitle: z.string().max(40),
  }),
  z.object({
    kind: z.literal('board-move'),
    id: z.string().min(1).max(120),
    boardTitle: z.string().max(40),
    direction: z.enum(['up', 'down']),
  }),
])

export type DraftChange = z.infer<typeof draftChangeSchema>

export const isDraftId = (id: string): boolean => id.startsWith('draft-')

// ---------------------------------------------------------------------------
// Client-side validation, mirroring the server EXACTLY (the server stays
// the authority at apply time; this only keeps a bad value from sitting in
// the tray and failing an apply later).

export function validateDraftValue(
  kind: 'dish-name' | 'dish-description' | 'board-title' | 'board-note',
  value: string,
): string | null {
  const trimmed = value.trim()
  if (kind === 'dish-name' && (trimmed.length < 1 || trimmed.length > 60)) {
    return 'A dish needs a name, 60 characters or fewer.'
  }
  if (kind === 'dish-description' && trimmed.length > 200) {
    return 'Keep the description under 200 characters.'
  }
  if (kind === 'board-title' && (trimmed.length < 1 || trimmed.length > 40)) {
    return 'A board needs a name, 40 characters or fewer.'
  }
  if (kind === 'board-note' && trimmed.length > 200) {
    return 'Keep the note under 200 characters.'
  }
  return null
}

/** Mirrors the server's parsePriceInput + cap. Returns the normalized
 *  display string ("17.50", "" for none) or an error message. */
export function normalizePriceInput(raw: string): { ok: true; value: string } | { ok: false; message: string } {
  const trimmed = raw.trim()
  if (trimmed === '') return { ok: true, value: '' }
  const cleaned = trimmed.replace(/^\$/, '')
  if (cleaned === '' || !/^\d{1,4}(\.\d{1,2})?$/.test(cleaned)) {
    return { ok: false, message: 'A price like 17 or 17.50 — or empty for none.' }
  }
  const cents = Math.round(Number(cleaned) * 100)
  if (cents > 999_99) return { ok: false, message: 'That is not a bar price.' }
  return { ok: true, value: (cents / 100).toFixed(2) }
}

// ---------------------------------------------------------------------------
// Queueing. Every rule preserves the invariant (see header).

export function queueDraft(pending: DraftChange[], change: DraftChange): DraftChange[] {
  if (change.kind === 'dish-edit' || change.kind === 'board-edit') {
    const index = pending.findIndex(
      (entry) => entry.kind === change.kind && entry.id === change.id && entry.field === change.field,
    )
    if (index !== -1) {
      const existing = pending[index] as Extract<DraftChange, { kind: 'dish-edit' | 'board-edit' }>
      // Second edit to the same field replaces the first; editing back to
      // the ORIGINAL value cancels the entry entirely.
      if (existing.from === change.to) {
        return pending.filter((_, i) => i !== index)
      }
      return pending.map((entry, i) => (i === index ? { ...existing, to: change.to } : entry))
    }
    if (change.from === change.to) return pending // an edit that changes nothing queues nothing
    return [...pending, change]
  }

  if (change.kind === 'dish-move' || change.kind === 'board-move') {
    // An immediately-opposite move of the same row cancels the pair (a
    // swap and its unswap are the identity). Only ADJACENT pairs cancel:
    // with anything in between, positions may have shifted.
    const last = pending[pending.length - 1]
    if (
      last &&
      last.kind === change.kind &&
      last.id === change.id &&
      last.direction !== change.direction
    ) {
      return pending.slice(0, -1)
    }
    return [...pending, change]
  }

  if (change.kind === 'dish-remove' && isDraftId(change.id) && cancelIsSound(pending, change.id, 'dish-move')) {
    // Removing a dish that only exists in the tray cancels everything
    // about it — net nothing ever reaches the server.
    return pending.filter((entry) => entry.id !== change.id)
  }
  if (change.kind === 'board-remove' && isDraftId(change.id)) {
    if (cancelIsSound(pending, change.id, 'board-move')) return withoutBoard(pending, change.id)
    // Another board moved while this one sat in the tray, so this one has to
    // keep its place in the rail and take a real removal instead. Its draft
    // dishes still never reach the server — and a board only deletes when it
    // is EMPTY, so they have to go either way or the remove would not fit.
    return [
      ...withoutDraftDishesOn(pending, change.id).filter(
        (entry) => !(entry.kind === 'board-edit' && entry.id === change.id),
      ),
      change,
    ]
  }
  if (change.kind === 'dish-remove') {
    // Field edits on a dish that is being removed are moot — but its MOVES
    // stay: each move also displaced a NEIGHBOUR, and dropping the move
    // would silently un-move that neighbour (invariant violation). Draft
    // dishes land here too when their wholesale cancel was not sound.
    return [
      ...pending.filter((entry) => !(entry.kind === 'dish-edit' && entry.id === change.id)),
      change,
    ]
  }
  if (change.kind === 'board-remove') {
    return [
      ...pending.filter((entry) => !(entry.kind === 'board-edit' && entry.id === change.id)),
      change,
    ]
  }

  return [...pending, change]
}

/** Cancelling a queued row outright is only sound while NO OTHER row moved
 *  after it appeared. A move is POSITIONAL: a later move may have swapped
 *  against this very row, and erasing the row re-points that swap at a
 *  different neighbour — a board the owner never reordered would come out
 *  in a different order, which is the "same final view" half of the header
 *  invariant broken. When that has happened the row keeps its entries and
 *  takes an ordinary removal instead: more work at apply time, same view. */
function cancelIsSound(
  pending: DraftChange[],
  id: string,
  moveKind: 'dish-move' | 'board-move',
): boolean {
  const first = pending.findIndex((entry) => entry.id === id)
  if (first === -1) return true
  return !pending.some(
    (entry, index) => index > first && entry.kind === moveKind && entry.id !== id,
  )
}

/** Everything about the draft dishes queued onto a board — they cannot
 *  outlive it, whichever way the board itself goes. */
function withoutDraftDishesOn(pending: DraftChange[], boardId: string): DraftChange[] {
  const dishIds = new Set(
    pending
      .filter(
        (entry): entry is Extract<DraftChange, { kind: 'dish-add' }> =>
          entry.kind === 'dish-add' && entry.categoryId === boardId,
      )
      .map((entry) => entry.id),
  )
  return pending.filter((entry) => !dishIds.has(entry.id))
}

/** Everything about a draft board AND the draft dishes queued onto it. */
function withoutBoard(pending: DraftChange[], boardId: string): DraftChange[] {
  return withoutDraftDishesOn(pending, boardId).filter((entry) => entry.id !== boardId)
}

/** The tray's per-line ✕. Dropping a draft-add cascades to everything that
 *  depends on it; the caller rebuilds the view afterwards. */
export function dropDraft(pending: DraftChange[], index: number): DraftChange[] {
  const target = pending[index]
  if (!target) return pending
  const remaining = pending.filter((_, i) => i !== index)
  if (target.kind === 'dish-add') {
    return remaining.filter((entry) => entry.id !== target.id)
  }
  if (target.kind === 'board-add') {
    return withoutBoard(remaining, target.id)
  }
  return remaining
}

// ---------------------------------------------------------------------------
// The draft view: baseline (server truth) + pending, replayed in order.
// Tolerant on purpose — a saved tray restored onto a FRESH baseline may
// contain changes that no longer fit; those drop with a count instead of
// wedging the editor.

export interface ReplayResult {
  groups: PreviewGroup[]
  kept: DraftChange[]
  dropped: number
}

export function replayDrafts(baseline: PreviewGroup[], pending: DraftChange[]): ReplayResult {
  let groups = baseline
  const kept: DraftChange[] = []
  let dropped = 0
  for (const change of pending) {
    const next = applyChangeToView(groups, change)
    if (next === null) {
      dropped += 1
      continue
    }
    groups = next
    kept.push(change)
  }
  return { groups, kept, dropped }
}

/** One change onto the view, immutably. Returns null when the change no
 *  longer fits (unknown id, non-empty board removal). */
export function applyChangeToView(groups: PreviewGroup[], change: DraftChange): PreviewGroup[] | null {
  switch (change.kind) {
    case 'board-add': {
      if (groups.some((group) => group.categoryId === change.id)) return null
      return [
        ...groups,
        { categoryId: change.id, title: change.title, note: '', dishes: [], draft: true },
      ]
    }
    case 'board-remove': {
      const board = groups.find((group) => group.categoryId === change.id)
      if (!board || board.dishes.length > 0) return null
      return groups.filter((group) => group.categoryId !== change.id)
    }
    case 'board-edit': {
      const board = groups.find((group) => group.categoryId === change.id)
      if (!board) return null
      return groups.map((group) =>
        group.categoryId === change.id
          ? { ...group, [change.field === 'title' ? 'title' : 'note']: change.to }
          : group,
      )
    }
    case 'board-move': {
      const index = groups.findIndex((group) => group.categoryId === change.id)
      if (index === -1) return null
      const target = change.direction === 'up' ? index - 1 : index + 1
      if (target < 0 || target >= groups.length) return groups // edge: harmless no-op
      const next = [...groups]
      ;[next[index], next[target]] = [next[target], next[index]]
      return next
    }
    case 'dish-add': {
      const board = groups.find((group) => group.categoryId === change.categoryId)
      if (!board) return null
      const dish: PreviewDish = {
        id: change.id,
        name: 'New dish',
        description: '',
        price: '',
        soldOut: false,
        hold: 'tonight',
        photo: null,
        draft: true,
      }
      return groups.map((group) =>
        group.categoryId === change.categoryId
          ? { ...group, dishes: [...group.dishes, dish] }
          : group,
      )
    }
    case 'dish-remove': {
      if (!groups.some((group) => group.dishes.some((dish) => dish.id === change.id))) return null
      return groups.map((group) => ({
        ...group,
        dishes: group.dishes.filter((dish) => dish.id !== change.id),
      }))
    }
    case 'dish-edit': {
      if (!groups.some((group) => group.dishes.some((dish) => dish.id === change.id))) return null
      return groups.map((group) => ({
        ...group,
        dishes: group.dishes.map((dish) =>
          dish.id === change.id ? { ...dish, [change.field]: change.to } : dish,
        ),
      }))
    }
    case 'dish-move': {
      const board = groups.find((group) => group.dishes.some((dish) => dish.id === change.id))
      if (!board) return null
      const index = board.dishes.findIndex((dish) => dish.id === change.id)
      const target = change.direction === 'up' ? index - 1 : index + 1
      if (target < 0 || target >= board.dishes.length) return groups // edge: harmless no-op
      const dishes = [...board.dishes]
      ;[dishes[index], dishes[target]] = [dishes[target], dishes[index]]
      return groups.map((group) => (group.categoryId === board.categoryId ? { ...group, dishes } : group))
    }
  }
}

// ---------------------------------------------------------------------------
// The tray's human-readable lines — what the owner reviews before Apply.

export function describeDraft(change: DraftChange): string {
  const price = (value: string) => (value === '' ? 'no price' : `$${value}`)
  switch (change.kind) {
    case 'dish-edit':
      if (change.field === 'price') return `${change.dishName} — price ${price(change.from)} → ${price(change.to)}`
      if (change.field === 'name') return `Rename ${change.from} → ${change.to}`
      return change.to
        ? `${change.dishName} — new line: “${change.to}”`
        : `${change.dishName} — clear its line`
    case 'dish-add':
      return `Add a dish to ${change.boardTitle}`
    case 'dish-remove':
      return `Remove ${change.dishName}`
    case 'dish-move':
      return `Move ${change.dishName} ${change.direction}`
    case 'board-edit':
      if (change.field === 'title') return `Rename the ${change.from} board → ${change.to}`
      return change.to
        ? `${change.boardTitle} board — new line: “${change.to}”`
        : `${change.boardTitle} board — clear its line`
    case 'board-add':
      return `Add the ${change.title} board`
    case 'board-remove':
      return `Remove the ${change.boardTitle} board`
    case 'board-move':
      return `Move the ${change.boardTitle} board ${change.direction}`
  }
}

// ---------------------------------------------------------------------------
// The apply plan: one HTTP request per change, in order, with draft ids
// resolved through the map that Apply builds as it creates rows.

export interface ApplyRequest {
  method: 'POST' | 'PATCH' | 'DELETE'
  url: string
  body: Record<string, string> | null
  /** set on the *-add changes: Apply records responseId under this key. */
  createsId?: string
}

export function applyRequestFor(change: DraftChange, resolve: (id: string) => string): ApplyRequest {
  switch (change.kind) {
    case 'dish-add':
      return {
        method: 'POST',
        url: '/api/admin/menu',
        body: { categoryId: resolve(change.categoryId) },
        createsId: change.id,
      }
    case 'dish-edit':
      return {
        method: 'PATCH',
        url: `/api/admin/menu/${encodeURIComponent(resolve(change.id))}`,
        body: { [change.field]: change.to },
      }
    case 'dish-remove':
      return {
        method: 'DELETE',
        url: `/api/admin/menu/${encodeURIComponent(resolve(change.id))}`,
        body: null,
      }
    case 'dish-move':
      return {
        method: 'PATCH',
        url: `/api/admin/menu/${encodeURIComponent(resolve(change.id))}`,
        body: { move: change.direction },
      }
    case 'board-add':
      return {
        method: 'POST',
        url: '/api/admin/boards',
        body: { title: change.title },
        createsId: change.id,
      }
    case 'board-edit':
      return {
        method: 'PATCH',
        url: `/api/admin/boards/${encodeURIComponent(resolve(change.id))}`,
        body: { [change.field]: change.to },
      }
    case 'board-remove':
      return {
        method: 'DELETE',
        url: `/api/admin/boards/${encodeURIComponent(resolve(change.id))}`,
        body: null,
      }
    case 'board-move':
      return {
        method: 'PATCH',
        url: `/api/admin/boards/${encodeURIComponent(resolve(change.id))}`,
        body: { move: change.direction },
      }
  }
}

// ---------------------------------------------------------------------------
// Persistence. The tray survives a dead tab: localStorage on the client,
// parsed defensively here so a stale or mangled payload restores to an
// empty tray instead of a crash.

const storedTraySchema = z.object({
  version: z.literal(1),
  pending: z.array(draftChangeSchema).max(200),
})

export const TRAY_STORAGE_KEY = 'stt-menu-tray-v1'

export function serializeTray(pending: DraftChange[]): string {
  return JSON.stringify({ version: 1, pending })
}

export function parseTray(raw: string | null): DraftChange[] {
  if (!raw) return []
  try {
    return storedTraySchema.parse(JSON.parse(raw)).pending
  } catch {
    return []
  }
}
