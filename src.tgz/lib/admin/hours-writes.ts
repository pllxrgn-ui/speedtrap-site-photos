// THE HOURS, the write half's pure helpers (build/13 section 5.2 and 1.9).
//
// lib/hours.ts is the frozen pure module and it carries the READ side: day
// order, the service day, precedence, the formatters, the schemas. Three
// things only the WRITE path needs are not in it, and they live here rather
// than inside a route file because both exception routes need them and a
// copy in each is how two wordings start:
//
//   1. what counts as NO CHANGE for a weekday (an edit that changed nothing
//      logs nothing - menu/[id]/route.ts:153, the rule this ports);
//   2. what a dated row reads as in the ledger and in a sentence;
//   3. the station's overlap sentence (section 1.9), which states the
//      outcome rather than asking a question, because the write already
//      succeeded and resolveException() has already decided.
//
// Every value here goes through lib/hours.ts's DISPLAY formatters, so the
// ledger says what the page said, in the same words.

import {
  dayStateOf,
  formatRange,
  isSingleDate,
  labelBarDayRange,
  shortBarDay,
  spanEnd,
  type DayState,
  type ExceptionSpan,
  type HoursDayRow,
} from '@/lib/hours'

// ---------------------------------------------------------------------------
// THE WEEK
// ---------------------------------------------------------------------------

/** The PUT carries all seven days every time, so most of them are unchanged.
 *  A day that did not move writes no row and logs no event. */
export function sameDay(prior: HoursDayRow | null | undefined, wanted: DayState): boolean {
  const before = dayStateOf(prior)
  if (before.state !== wanted.state) return false
  if (before.state === 'open' && wanted.state === 'open') {
    return before.open === wanted.open && before.close === wanted.close
  }
  return true
}

/** The ledger discriminator for a weekday change (section 1.1's closed set). */
export function dayField(wanted: DayState): 'day-unset' | 'day-closed' | 'day-hours' {
  if (wanted.state === 'unset') return 'day-unset'
  if (wanted.state === 'closed') return 'day-closed'
  return 'day-hours'
}

// ---------------------------------------------------------------------------
// DATED ROWS
// ---------------------------------------------------------------------------

// ExceptionSpan, spanEnd() and isSingleDate() USED TO LIVE HERE, over the
// same `endDate ?? date` rule lib/hours.ts was already computing twice with
// two different spellings - and one of them disagreed about an omitted
// endDate (review round 1, finding 6). They are lib/hours.ts's now; this
// file imports them and adds only what the WRITE path needs.

export interface ExceptionShape extends ExceptionSpan {
  closed: boolean
  open?: string | null
  close?: string | null
  label?: string | null
}

/** The ledger subject: "2026-12-25" or "2026-12-24..2027-01-02" (section 1.1).
 *  Machine-readable on purpose - THE LOG formats it for a person in Wave S-C,
 *  and a row it cannot parse must still name the day it happened to. */
export function exceptionSubject(row: ExceptionSpan): string {
  return isSingleDate(row) ? row.date : `${row.date}..${spanEnd(row)}`
}

/** "Closed" | "11am - 8pm" - the same vocabulary dayLedgerValue() uses for
 *  the week, so one ledger column reads in one register. */
export function exceptionHours(row: ExceptionShape): string {
  if (row.closed || row.open == null || row.close == null) return 'Closed'
  return formatRange(row.open, row.close)
}

/** The whole row in one line, reason included: "Closed - holiday". What the
 *  ledger records when a dated row ARRIVES or LEAVES, where the change is the
 *  row itself rather than one of its fields. */
export function exceptionSummary(row: ExceptionShape): string {
  const hours = exceptionHours(row)
  const reason = row.label?.trim()
  return reason ? `${hours} - ${reason}` : hours
}

/** How a dated row names itself in a sentence: "Dec 25" or "Dec 24 - Jan 2".
 *  shortBarDay was a local copy here while lib/hours.ts was frozen; it is an
 *  export there now (review round 1, finding 6). */
export function spanLabel(row: ExceptionSpan): string {
  return isSingleDate(row) ? shortBarDay(row.date) : labelBarDayRange(row.date, spanEnd(row))
}

/** Do two dated rows share a day? String comparison throughout (section 0.4). */
export function spansOverlap(a: ExceptionSpan, b: ExceptionSpan): boolean {
  return a.date <= spanEnd(b) && b.date <= spanEnd(a)
}

// THE STATION WARNS; THE DATABASE DOES NOT REFUSE (section 1.9).
//
// Overlap is legal data - "closed Dec 24 to Jan 2" plus "Dec 25 closed -
// holiday" is the headline use case, and a UNIQUE or exclusion constraint
// would reject it. What is not legal is AMBIGUITY, and resolveException()
// already removed that: the most specific live row wins, and among equals the
// newest. So this sentence states the outcome. It never asks a question - a
// confirmation dialog in the middle of service, for a case the rule already
// handles, is the wrong control.
//
// Two endings, because there are two rules and the copy may not blur them:
// a single date against a range is decided by SPECIFICITY, two rows of the
// same kind by RECENCY.
export function overlapWarning(
  saved: ExceptionSpan,
  others: readonly ExceptionSpan[],
): string | null {
  const clashes = others.filter((other) => spansOverlap(saved, other))
  if (clashes.length === 0) return null

  const savedSingle = isSingleDate(saved)
  const differentKind = clashes.find((other) => isSingleDate(other) !== savedSingle)

  if (differentKind) {
    // The specific one wins, whichever of the two was just written.
    const [specific, broad] = savedSingle ? [saved, differentKind] : [differentKind, saved]
    return `${spanLabel(specific)} is already covered by ${spanLabel(broad)}. The more specific date wins on the site.`
  }

  return `${spanLabel(saved)} overlaps ${spanLabel(clashes[0])}. The newest one wins on the site.`
}
