// Every admin mutation goes through here so a bare fetch cannot forget the
// CSRF header (build/08 §2 row 7). Client-side only: it reads the
// deliberately JS-readable stt_csrf cookie and mirrors it into x-stt-csrf.
export async function adminMutate(path: string, init: RequestInit = {}): Promise<Response> {
  const csrf =
    document.cookie
      .split('; ')
      .find((pair) => pair.startsWith('stt_csrf='))
      ?.slice('stt_csrf='.length) ?? ''
  return fetch(path, {
    ...init,
    method: init.method ?? 'POST',
    headers: { ...(init.headers ?? {}), 'x-stt-csrf': csrf },
  })
}
