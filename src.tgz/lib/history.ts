// Building history, rendered as the About page's ledger (components/about/
// ledger.tsx). Every line traces to research/03 §A3 (seattlebars.org post
// body, directly observed) via build/02-content-plan.md §About; the two
// context rows and their scans trace to assets/archival/MANIFEST.md.
//
// Two things are deliberately absent and must stay absent:
//   1. Any changeover date for the Speed Trap. "Sept 2020" is a reader comment,
//      second-hand, so the last entry is phrased as "today" instead.
//   2. Any ownership narrative. "New owners" is a release blocker
//      (build/00-spec.md copy rule, CLAUDE.md) and no owner is named here.
//
// Caption honesty (spec, 2026-09-14): no arithmetic against a circa date; the
// c.1899 scene and the Sanborn plate may never be captioned as showing THIS
// building (the 1899 street predates it; the footprint match on the plate is
// a researcher's note, not what the sheet states).

export type HistoryRow = {
  /** 'entry' rows are the room's own eras (2px rule, anchor target);
   *  'context' rows are the town around it (hairline rule, muted). */
  kind: 'entry' | 'context'
  /** Anchor id, entries only. */
  id: string | null
  /** Mono date column. Circa stays circa. */
  era: string
  name: string
  body: string
  evidence: {
    src: string
    alt: string
    /** Must match RATIO_CLASS in lib/photos.ts. */
    frame: '3:2' | '4:5' | '1:1' | '16:9'
    designation: string
    date: string
    /** Verbatim from a MANIFEST.md row; null ONLY where permission is an
     *  open gate (the 2025 storefront, pending Katie Garrett's written OK). */
    source: string | null
    /** Amber provenance plate under the frame. Sanborn only. */
    plate?: true
  } | null
}

export const HISTORY: HistoryRow[] = [
  {
    kind: 'context',
    id: null,
    era: 'Circa 1899',
    name: 'Broadway',
    body: 'Wooden storefronts at Broadway and Lake Street.',
    evidence: {
      src: '/photos/broadway-c1899.webp',
      alt: 'Wooden storefronts along an unpaved street at Broadway and Lake Street in Reardan.',
      frame: '3:2',
      designation: 'Broadway and Lake Street',
      date: 'Circa 1899',
      source: 'Reardan Memorial Library, via Washington Rural Heritage',
    },
  },
  {
    kind: 'entry',
    id: 'bank',
    era: '1905',
    name: 'Bank',
    body: "The Stevenson Building goes up on Broadway; local histories say it opened as Reardan's first bank.",
    evidence: {
      src: '/photos/sanborn-1905-broadway.webp',
      alt: 'A 1905 Sanborn fire insurance map plate of the Broadway business block in Reardan.',
      frame: '4:5',
      designation: 'Sanborn fire insurance map, Broadway, detail',
      date: 'August 1905',
      source: 'Sanborn Map Company, 1905, via Library of Congress',
      plate: true,
    },
  },
  {
    kind: 'entry',
    id: 'tavern',
    era: 'After 1905',
    name: 'Tavern',
    body: "It becomes Bonstrom's Place, a tavern and card room, and stays one for more than twenty five years.",
    evidence: null,
  },
  {
    kind: 'context',
    id: null,
    era: 'Circa 1908 to 1918',
    name: 'The town',
    body: 'The whole town from above, the main street across the middle distance.',
    evidence: {
      src: '/photos/birdseye-reardan-postcard.webp',
      alt: 'A real photo postcard of Reardan seen from above: barns and board fences in front, a water tower, and the main street across the middle distance.',
      frame: '16:9',
      designation: 'Birds eye view, Reardan',
      date: 'Circa 1908 to 1918',
      source: 'Real photo postcard, collection of Flickr user snelson951',
    },
  },
  {
    kind: 'entry',
    id: 'bar-grill',
    era: '2006',
    name: 'Bar & grill',
    body: "Bubba's Bar & Grill takes over the room.",
    evidence: null,
  },
  {
    kind: 'entry',
    id: 'tap-house',
    era: 'Today',
    name: 'Tap house',
    body: 'The Speed Trap Tap House. Same building, same corner of Highway 2.',
    evidence: {
      src: '/photos/storefront-corner.webp',
      alt: 'The front of the building on Broadway: brick two-story, live music mural, flower baskets over the sidewalk.',
      frame: '1:1',
      designation: 'The same building',
      date: '2025',
      // Katie Garrett's written permission is still an open gate: do not
      // author a credit line until it lands (assets/third-party/MANIFEST.md).
      source: null,
    },
  },
]

/** The four anchorable eras, for the dateline index. */
export const LEDGER_INDEX = HISTORY.filter(
  (row): row is HistoryRow & { id: string } => row.kind === 'entry' && row.id !== null,
)
