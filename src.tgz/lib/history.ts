import type { Photo } from '@/lib/photos'

// Building history. Every line traces to research/03 §A3 (seattlebars.org post
// body, directly observed) via build/02-content-plan.md §About.
//
// Two things are deliberately absent and must stay absent:
//   1. Any changeover date for the Speed Trap. "Sept 2020" is a reader comment,
//      second-hand, so the last entry is phrased as "today" instead.
//   2. Any ownership narrative. "New owners" is a release blocker
//      (build/00-spec.md copy rule, CLAUDE.md) and no owner is named here.
export type HistoryEntry = {
  /** What the room was. One or two words, the field's headline. */
  name: string
  /**
   * Mono era line under the name. Every entry is a point in time of the same
   * kind, so the column reads consistently: the old labels mixed two years,
   * a duration ("25 years") and "Today" in one stack. The duration itself is
   * a verified fact and now lives in the body copy, where it belongs.
   */
  era: string
  body: string
  /** Grayscale slot (build/03 §1.6 rule 5). Null until archival scans exist. */
  photo: Photo | null
}

export const HISTORY: HistoryEntry[] = [
  {
    name: 'Bank',
    era: '1905',
    body: "The Stevenson Building goes up on Broadway and opens as Reardan's first bank. Photo: Washington Rural Heritage, Reardan Memorial Library collection, around 1904.",
    // License: No Copyright - United States (verified at source,
    // assets/archival/MANIFEST.md). The archive's own caption documents this
    // building's tavern lineage.
    photo: {
      src: '/photos/stevenson-building-c1904.webp',
      alt: 'A crowd gathered in front of the Stevenson Building around 1904, signs for J.C. Driscoll General Merchandise on the facade.',
      ratio: '3:2',
      category: 'exterior',
    },
  },
  {
    name: 'Tavern',
    era: 'After 1905',
    body: "It becomes Bonstrom's Place, a tavern and card room, and stays one for more than twenty five years.",
    photo: null,
  },
  {
    name: 'Bar & grill',
    era: '2006',
    body: "Bubba's Bar & Grill takes over the room.",
    photo: null,
  },
  {
    name: 'Tap house',
    era: 'Today',
    body: 'The Speed Trap Tap House. Same building, same corner of Highway 2.',
    photo: null,
  },
]
