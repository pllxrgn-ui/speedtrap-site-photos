import { SITE } from './site'

// schema.org requires full day names; the WeeklyHours keys are lowercase
// three-letter. Guarded by lib/jsonld.test.ts.
const DAY_NAME: Record<string, string> = {
  mon: 'Monday',
  tue: 'Tuesday',
  wed: 'Wednesday',
  thu: 'Thursday',
  fri: 'Friday',
  sat: 'Saturday',
  sun: 'Sunday',
}

// Restaurant JSON-LD per build/04-seo-schema.md. Address and hours are
// omitted, not guessed, until owner-verified. No review/rating markup
// (self-serving review markup violates Google policy).
export function restaurantJsonLd(site: typeof SITE = SITE) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Restaurant',
    name: site.name,
    telephone: site.phone,
    servesCuisine: 'American',
    priceRange: '$$',
    acceptsReservations: true,
    geo: {
      '@type': 'GeoCoordinates',
      latitude: site.geo.lat,
      longitude: site.geo.lng,
    },
    ...(site.address && {
      address: {
        '@type': 'PostalAddress',
        streetAddress: site.address.street,
        addressLocality: site.address.city,
        addressRegion: site.address.state,
        postalCode: site.address.zip,
      },
    }),
    ...(site.hours.verified &&
      site.hours.weekly && {
        openingHoursSpecification: Object.entries(site.hours.weekly)
          .filter(([, h]) => h !== null)
          .map(([day, h]) => ({
            '@type': 'OpeningHoursSpecification',
            dayOfWeek: DAY_NAME[day],
            opens: h!.open,
            closes: h!.close,
          })),
      }),
    sameAs: [site.social.facebook, site.social.instagram],
  }
}
