import { BASE_URL } from './base-url'
import { FAQS } from './faq'
import type { PublishedHours } from './hours-data'
import { SEED_MENU, type MenuCategory } from './menu'
import { menuProvenance } from './provenance'
import { SITE } from './site'

// schema.org requires full day names; the keys are the lowercase
// three-letter HoursDay.day primary keys the owner's rows carry
// (build/13). Still contract, still guarded by lib/jsonld.test.ts.
const DAY_NAME: Record<string, string> = {
  mon: 'Monday',
  tue: 'Tuesday',
  wed: 'Wednesday',
  thu: 'Thursday',
  fri: 'Friday',
  sat: 'Saturday',
  sun: 'Sunday',
}

// Restaurant JSON-LD per build/04-seo-schema.md. Address is omitted, not
// guessed, until owner-verified. No review/rating markup (self-serving
// review markup violates Google policy).
//
// HOURS ARE DATABASE ROWS NOW (build/13 §3), not a typed constant, so they
// arrive as an argument. Three rules, all load-bearing:
//
// 1. THE GATE IS THE PAGE'S GATE. PublishedHours exists only when all seven
//    days do (lib/hours-data.ts), so the structured data and the Find Us
//    card can never disagree about what is published. No rows, no key.
// 2. A CLOSED DAY EMITS NOTHING. Absence of a day is how schema.org says
//    closed, and it is the behaviour this file has always been pinned on.
// 3. DATED EXCEPTIONS NEVER ENTER STRUCTURED DATA - no
//    specialOpeningHoursSpecification, ever (§3.3). A "closed Dec 25"
//    sitting in Google's index on Dec 27 is build/08 §5's stale-SoldOut
//    failure with a worse consequence: the customer does not order the
//    wrong dish, they do not come at all. Google's refresh cadence is not
//    ours to control and a dated closure's useful life is measured in
//    hours. Exceptions are a PAGE fact, surfaced within 300s by the route's
//    cache profile, where the expiry is ours. Pinned by lib/jsonld.test.ts.
export function restaurantJsonLd(
  hours: PublishedHours | null = null,
  site: typeof SITE = SITE,
) {
  // A close after midnight emits exactly as the owner stored it (opens 11,
  // closes 01). That is Google's own form for a past-midnight close: no
  // arithmetic, no split into two specs.
  const openingHours = (hours?.days ?? []).flatMap((entry) =>
    entry.state.state === 'open'
      ? [
          {
            '@type': 'OpeningHoursSpecification',
            dayOfWeek: DAY_NAME[entry.day],
            opens: entry.state.open,
            closes: entry.state.close,
          },
        ]
      : [],
  )
  return {
    '@context': 'https://schema.org',
    '@type': 'Restaurant',
    name: site.name,
    telephone: site.phone,
    // One-pager (build/07): the menu is a fragment, and hasMenu is the only
    // way a crawler learns which fragment. Derived, never typed.
    hasMenu: `${BASE_URL}/#menu`,
    servesCuisine: 'American',
    priceRange: '$$',
    acceptsReservations: true,
    geo: {
      '@type': 'GeoCoordinates',
      latitude: site.geo.lat,
      longitude: site.geo.lng,
    },
    ...(site.address && {
      address: {
        '@type': 'PostalAddress',
        streetAddress: site.address.street,
        addressLocality: site.address.city,
        addressRegion: site.address.state,
        postalCode: site.address.zip,
      },
    }),
    ...(openingHours.length > 0 && { openingHoursSpecification: openingHours }),
    sameAs: [site.social.facebook, site.social.instagram],
  }
}

// Menu JSON-LD (build/04 wanted this live the day prices landed). Offers are
// emitted only for items that actually carry a price; a null price emits a
// bare MenuItem, mirroring the page. No rating markup here either.
export function menuJsonLd(menu: MenuCategory[] = SEED_MENU, updatedAtIso: string | null = null) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Menu',
    url: `${BASE_URL}/#menu`,
    name: `${SITE.name} Menu`,
    // build/09: the JSON-LD now describes the LIVE menu (it re-renders
    // under the same overlay cache as the page). Specials and 86 state
    // still never enter structured data — a stale SoldOut emitted to
    // Google remains the failure mode (build/08 §5 ruling holds).
    ...(menuProvenance(updatedAtIso).jsonLdDescription && {
      description: menuProvenance(updatedAtIso).jsonLdDescription,
    }),
    hasMenuSection: menu
      .filter((category) => category.items.length > 0)
      .map((category) => ({
        '@type': 'MenuSection',
        name: category.title,
        ...(category.note && { description: category.note }),
        hasMenuItem: category.items.map((item) => ({
          '@type': 'MenuItem',
          name: item.name,
          ...(item.description && { description: item.description }),
          ...(item.price !== null && {
            offers: {
              '@type': 'Offer',
              price: item.price.toFixed(2),
              priceCurrency: 'USD',
            },
          }),
        })),
      })),
  }
}

// FAQPage markup from the same source the page renders (lib/faq.ts), so the
// two can never drift. Lifted out of the retired /find-us route (build/07)
// so it gets the same test coverage as the other two blocks.
export function faqJsonLd(faqs: typeof FAQS = FAQS) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.q,
      acceptedAnswer: { '@type': 'Answer', text: faq.a },
    })),
  }
}
