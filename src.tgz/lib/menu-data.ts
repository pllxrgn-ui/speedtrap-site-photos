// THE MENU, from the database (build/09 owner's-word regime). Cached under
// the same 'overlay' tag as everything the admin publishes, so an edit is
// on the page the very next request. When no database is reachable — a
// build, a test, an outage — the July 2026 SEED renders instead: the site
// can NEVER lose its menu.

import { cacheLife, cacheTag } from 'next/cache'
import { getDb } from '@/lib/db'
import { CATEGORIES, SEED_MENU, type MenuCategory, type MenuItem } from '@/lib/menu'

export interface MenuData {
  categories: MenuCategory[]
  /** ISO stamp of the latest change — drives "Prices updated <date>". Null
   *  only on the seed fallback. */
  updatedAt: string | null
}

export const SEED_FALLBACK: MenuData = { categories: SEED_MENU, updatedAt: null }

export async function getMenu(): Promise<MenuData> {
  'use cache'
  cacheTag('overlay')
  cacheLife({ stale: 300, revalidate: 900, expire: 86_400 })

  if (!process.env.DATABASE_URL) return SEED_FALLBACK

  try {
    const db = getDb()
    const [boards, dishes] = await Promise.all([
      db.menuBoard.findMany({ orderBy: { sortIndex: 'asc' } }),
      db.menuDish.findMany({ orderBy: [{ categoryId: 'asc' }, { sortIndex: 'asc' }] }),
    ])
    if (dishes.length === 0) return SEED_FALLBACK

    let latest = 0
    const byCategory = new Map<string, MenuItem[]>()
    for (const dish of dishes) {
      if (dish.updatedAt.getTime() > latest) latest = dish.updatedAt.getTime()
      const tags: ('gf' | 'v')[] = []
      if (dish.gf) tags.push('gf')
      if (dish.v) tags.push('v')
      const item: MenuItem = {
        id: dish.id,
        name: dish.name,
        ...(dish.description ? { description: dish.description } : {}),
        price: dish.priceCents === null ? null : dish.priceCents / 100,
        ...(tags.length ? { tags } : {}),
        ...(dish.houseMade ? { houseMade: true } : {}),
      }
      const list = byCategory.get(dish.categoryId)
      if (list) list.push(item)
      else byCategory.set(dish.categoryId, [item])
    }

    // Boards come from the database too (addendum): title, note and ORDER
    // are the owner's. An empty MenuBoard table (a database from before
    // the boards migration) falls back to the code shells so the menu
    // never renders headless. A board with NO dishes stays off the public
    // page — an empty "Desserts" heading sells nothing.
    const shells = boards.length
      ? boards.map((board) => ({
          id: board.id,
          title: board.title,
          ...(board.note ? { note: board.note } : {}),
        }))
      : CATEGORIES

    return {
      categories: shells
        .map((shell) => ({
          id: shell.id,
          title: shell.title,
          ...(shell.note ? { note: shell.note } : {}),
          items: byCategory.get(shell.id) ?? [],
        }))
        .filter((category) => category.items.length > 0),
      updatedAt: new Date(latest).toISOString(),
    }
  } catch {
    // A cold or absent database must never take the menu down with it.
    return SEED_FALLBACK
  }
}
