// THE MENU, from the database (build/09 owner's-word regime). Cached under
// the same 'overlay' tag as everything the admin publishes, so an edit is
// on the page the very next request. When no database is reachable — a
// build, a test, an outage — the July 2026 SEED renders instead: the site
// can NEVER lose its menu.
//
// A DATABASE FAILURE IS NOT A CACHED ANSWER (build/12 item 2, the S
// detector; build/13 §0.2, commit 0). Each read is TWO functions, and the
// split is the whole point:
//
//   readX()  — the 'use cache' shell. It handles the one failure that is a
//              stable, honest answer (no DATABASE_URL: a build, a preview,
//              a test) and returns the seed for it, because that answer is
//              true for as long as the deployment lasts and is worth
//              caching. It has NO try/catch: a thrown query rejects out of
//              the shell.
//   getX()   — the uncached wrapper that catches. A query that threw
//              degrades THAT ONE REQUEST, and the next request tries the
//              database again.
//
// Before this split the catch sat INSIDE the shell, so one cold Neon start
// baked July's prices into a cache entry for up to the full expire window.
//
// AS-BUILT NOTE — does 'use cache' cache a rejected promise? NO, verified
// empirically against the installed next@16.3.5, not from the docs. A
// rejection inside the shell is encoded into the RSC stream;
// `use-cache-wrapper.js:668-705` (collectResult) closes that stream as
// errored, and the default handler's `set()`
// (`server/lib/cache-handlers/default.js:104-144`) DRAINS the stream to
// measure it before storing — draining an errored stream throws, the catch
// swallows it, and `memoryCache.set()` is never reached. Probe result: a
// resolved value is a HIT on the next get(), a rejection is a MISS.
// Caveat worth keeping: Next's own comment there says retaining an errored
// entry is "a CacheHandler choice", so this is a property of the shipped
// default handler at 16.3.5, not a framework guarantee. The split above is
// correct either way — it is what makes the rejection reach the wrapper at
// all instead of being converted into a cacheable value inside the shell.

import { cacheLife, cacheTag } from 'next/cache'
import { getDb } from '@/lib/db'
import { CATEGORIES, SEED_MENU, type MenuCategory, type MenuItem } from '@/lib/menu'

export interface MenuData {
  categories: MenuCategory[]
  /** ISO stamp of the latest change — drives "Prices updated <date>". Null
   *  only on the seed fallback. */
  updatedAt: string | null
}

/** No database to ask (build, preview, test), or a database with no dishes
 *  in it. An honest answer that stays true, so it is cached. */
export const SEED_FALLBACK: MenuData = { categories: SEED_MENU, updatedAt: null }

/** The same menu, for the request where the database was configured and the
 *  query THREW. Deep-equal to SEED_FALLBACK on purpose — the plate a customer
 *  sees is identical, because losing the menu is the worst outcome this repo
 *  has — but a DIFFERENT OBJECT, so a call site (and the tests) can tell "this
 *  build has no database" from "the database did not answer". Ending that
 *  conflation is the detector half of build/12 item 2. */
export const SEED_UNREACHABLE: MenuData = { categories: SEED_MENU, updatedAt: null }

/** The cached shell. NO try/catch in here, deliberately — see the header. */
async function readMenu(): Promise<MenuData> {
  'use cache'
  cacheTag('overlay')
  cacheLife({ stale: 300, revalidate: 900, expire: 86_400 })

  if (!process.env.DATABASE_URL) return SEED_FALLBACK

  const db = getDb()
  const [boards, dishes] = await Promise.all([
    // id tiebreak: a sortIndex tie must never flip board order between
    // renders (racing moves can no-op; they must not add nondeterminism).
    db.menuBoard.findMany({ orderBy: [{ sortIndex: 'asc' }, { id: 'asc' }] }),
    db.menuDish.findMany({ orderBy: [{ categoryId: 'asc' }, { sortIndex: 'asc' }] }),
  ])
  if (dishes.length === 0) return SEED_FALLBACK

  let latest = 0
  const byCategory = new Map<string, MenuItem[]>()
  for (const dish of dishes) {
    if (dish.updatedAt.getTime() > latest) latest = dish.updatedAt.getTime()
    const tags: ('gf' | 'v')[] = []
    if (dish.gf) tags.push('gf')
    if (dish.v) tags.push('v')
    const item: MenuItem = {
      id: dish.id,
      name: dish.name,
      ...(dish.description ? { description: dish.description } : {}),
      price: dish.priceCents === null ? null : dish.priceCents / 100,
      ...(tags.length ? { tags } : {}),
      ...(dish.houseMade ? { houseMade: true } : {}),
    }
    const list = byCategory.get(dish.categoryId)
    if (list) list.push(item)
    else byCategory.set(dish.categoryId, [item])
  }

  // Boards come from the database too (addendum): title, note and ORDER
  // are the owner's. An empty MenuBoard table (a database from before
  // the boards migration) falls back to the code shells so the menu
  // never renders headless. A board with NO dishes stays off the public
  // page — an empty "Desserts" heading sells nothing.
  const shells = boards.length
    ? boards.map((board) => ({
        id: board.id,
        title: board.title,
        ...(board.note ? { note: board.note } : {}),
      }))
    : CATEGORIES

  return {
    categories: shells
      .map((shell) => ({
        id: shell.id,
        title: shell.title,
        ...(shell.note ? { note: shell.note } : {}),
        items: byCategory.get(shell.id) ?? [],
      }))
      .filter((category) => category.items.length > 0),
    updatedAt: new Date(latest).toISOString(),
  }
}

export async function getMenu(): Promise<MenuData> {
  try {
    return await readMenu()
  } catch {
    // A cold or absent database must never take the menu down with it — but
    // it must not become a cache entry either. This catch is OUTSIDE the
    // shell, so the seed renders for this one request and the next request
    // asks the database again.
    return SEED_UNREACHABLE
  }
}

// ---------------------------------------------------------------------------
// THE FAVORITES (build/09 addendum 6): the four feature cards, owner-picked.

export interface FeatureCardData {
  slot: number
  name: string
  blurb: string | null
  price: number | null
  categoryId: string
  categoryTitle: string
  /** The dish's own photo (DishPhoto — shared with the menu editor's photo
   *  slot). Null renders the laurel logo default on the white cards. */
  photo: { src: string; alt: string } | null
}

// The cards as shipped in code — the fallback when the table is empty or
// no database is reachable, resolved by NAME so the page never breaks.
const SEED_FEATURES: { name: string; blurb: string }[] = [
  { name: 'Blue Cheese Burger', blurb: 'The one people drive out for.' },
  {
    name: 'Speed Trap Burger',
    blurb:
      'Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.',
  },
  { name: 'Philly Cheesesteak', blurb: 'Prime rib, done the Philly way.' },
  { name: 'Fish & Chips', blurb: 'The Friday tradition.' },
]

function seedFeatureFallback(): FeatureCardData[] {
  return SEED_FEATURES.flatMap((entry, index) => {
    for (const category of SEED_MENU) {
      const item = category.items.find((candidate) => candidate.name === entry.name)
      if (item) {
        return [{
          slot: index + 1,
          name: item.name,
          blurb: entry.blurb,
          price: item.price ?? null,
          categoryId: category.id,
          categoryTitle: category.title,
          photo: null, // seed fallback has no owner uploads by definition
        }]
      }
    }
    return []
  })
}

/** The cached shell. Same two-function split as readMenu/getMenu — the cards
 *  are content on the same page and carry the same staleness risk, so the
 *  catch is not allowed to live inside the cache here either. */
async function readFeatures(): Promise<FeatureCardData[]> {
  'use cache'
  cacheTag('overlay')
  cacheLife({ stale: 300, revalidate: 900, expire: 86_400 })

  if (!process.env.DATABASE_URL) return seedFeatureFallback()

  const db = getDb()
  const [spots, dishes, boards, dishPhotos] = await Promise.all([
    db.featureSpot.findMany({ orderBy: { slot: 'asc' } }),
    db.menuDish.findMany(),
    db.menuBoard.findMany(),
    db.dishPhoto.findMany(),
  ])
  // An empty table (a database from before the favorites migration)
  // falls back to the code cards — the section never just vanishes.
  if (spots.length === 0) return seedFeatureFallback()

  const dishById = new Map(dishes.map((dish) => [dish.id, dish]))
  const boardById = new Map(boards.map((board) => [board.id, board]))
  const photoByDish = new Map(dishPhotos.map((photo) => [photo.itemKey, photo]))
  return spots.flatMap((spot) => {
    if (!spot.dishId) return [] // a dark spot drops its card, on purpose
    const dish = dishById.get(spot.dishId)
    if (!dish) return [] // a deleted dish drops its card instead of lying
    return [{
      slot: spot.slot,
      name: dish.name,
      // The owner's line wins; the dish's own menu line is the fallback.
      blurb: spot.blurb ?? dish.description ?? null,
      price: dish.priceCents === null ? null : dish.priceCents / 100,
      categoryId: dish.categoryId,
      categoryTitle: boardById.get(dish.categoryId)?.title ?? dish.categoryId,
      photo: (() => {
        const photo = photoByDish.get(dish.id)
        return photo ? { src: photo.url, alt: photo.alt } : null
      })(),
    }]
  })
}

export async function getFeatures(): Promise<FeatureCardData[]> {
  try {
    return await readFeatures()
  } catch {
    return seedFeatureFallback()
  }
}
