// Phone numbers never reach runtime logs in the clear (build/08 veto 16):
// Vercel logs are a PII sink otherwise. "+15095309997" -> "+1509•••9997".
export function redactPhone(value: string): string {
  const digits = value.replace(/\D/g, '')
  if (digits.length < 7) return '•••'
  const prefix = value.trim().startsWith('+') ? '+' : ''
  return `${prefix}${digits.slice(0, digits.length - 7)}•••${digits.slice(-4)}`
}
