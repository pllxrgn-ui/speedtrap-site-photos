import type { BookingStatus } from '@prisma/client'

// The queue's grammar, shared by the PATCH route (server validation) and
// the ticket rail (which actions to offer). A transition not in this map
// is a 400, so no UI bug can walk a booking backwards.
export const ALLOWED_TRANSITIONS: Record<BookingStatus, readonly BookingStatus[]> = {
  new: ['confirmed', 'declined', 'cancelled'],
  confirmed: ['completed', 'no_show', 'cancelled'],
  declined: [],
  cancelled: [],
  no_show: [],
  completed: [],
}

// Status words the owner actually says — Big Shoulders renders them in the
// pill, so they stay short (§4 rule 4).
export const STATUS_LABELS: Record<BookingStatus, string> = {
  new: 'New',
  confirmed: 'Confirmed',
  declined: "Can't do it",
  cancelled: 'Cancelled',
  no_show: 'No-show',
  completed: 'Done',
}

export function canTransition(from: BookingStatus, to: BookingStatus): boolean {
  // Total on purpose: if the enum ever gains a value without a map entry,
  // the answer is "no move allowed", never a thrown 500 (review finding 2).
  return ALLOWED_TRANSITIONS[from]?.includes(to) ?? false
}
