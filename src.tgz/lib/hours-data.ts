// THE HOURS, READ (build/13 §2). The one function between the owner's rows
// and the Find Us card. lib/hours.ts holds the pure machinery; this file
// holds the database, the cache and the view the page renders.
//
// HOURS HAVE NO CONTENT FALLBACK TO GO STALE, AND THAT IS THE DESIGN (§0.2).
// There is no SEED_HOURS constant in this repo, by construction — the
// migration seeds nothing and scripts/check-no-seeded-hours.mjs fails the
// gate on a clock literal in source. So getHours() returns the ABSENCE shape
// on every failure path (no DATABASE_URL, an empty table, a partial week, a
// thrown query, a Neon cold start) and the absence shape renders the block
// that is on the site today, verbatim: "Call for today's hours." That
// sentence is true in every one of those states. A cached absence is a
// downgrade to the phone; it is never a lie. On a site whose founding line
// is "there are six different sets of hours for this place floating around
// the internet", a cached WRONG table would be the product's founding
// failure.
//
// THE TWO-FUNCTION SPLIT is menu-data.ts's, for the reason written in its
// header: the 'use cache' shell has NO try/catch, so a thrown query rejects
// out of it and degrades ONE request instead of being baked into a cache
// entry. The uncached wrapper catches.
//
// THE CACHE PROFILE IS A ROUTE-LEVEL FACT, NOT AN HOURS-LEVEL ONE (§0.2).
// Next reports, for a route, the SHORTEST revalidate and expire across every
// cache it contains. `/` already reads getMenu() and readOverlay() at
// 300/900/86_400; adding this read at 60/300/3600 re-profiles the WHOLE
// one-pager — menu, overlay, favorites and all — to 300/3600. Hours cannot
// have "their own" profile on a page they share. The trade is taken
// deliberately: a day-old menu is tolerable, a dated closure that outlives
// its bar-day is not, and one hour bounds the worst case. It is NOT
// justified by "the bar is closed at that hour" — a close after midnight is
// a supported state (lib/hours.ts crossesMidnight), so the bar may well be
// open then. What makes the trade safe is that the shorter expire means more
// cold renders, and a cold render no longer bakes a database failure into a
// cache entry (build/12 item 2's detector, shipped in commit 0).
//
// THE SERVICE DAY IS COMPUTED INSIDE THE SHELL, on purpose: a dated notice
// is filtered against the day the cache entry was filled, and expire: 3600
// is what bounds how long a rolled-over notice can linger. Never pass a live
// clock as a cache argument — every request would be its own cache key and
// the profile above would buy nothing.

import { cacheLife, cacheTag } from 'next/cache'
import { getDb } from '@/lib/db'
import {
  DAY_ORDER,
  type DayId,
  type DayState,
  type ExceptionRow,
  barServiceDay,
  dayStateOf,
  formatRange,
  formatTime,
  isPublishable,
  isSingleDate,
  labelBarDay,
  labelBarDayRange,
  liveExceptionsWhere,
  resolveException,
  shortBarDay,
  spanEnd,
} from '@/lib/hours'

// ---------------------------------------------------------------------------
// THE VIEW
// ---------------------------------------------------------------------------

export interface PublishedDay {
  day: DayId
  /** Never `unset`: isPublishable() is the gate, and it is the same gate the
   *  JSON-LD uses — the two can never disagree about what is published. */
  state: DayState
}

/** The weekly table, and it EXISTS ONLY WHEN ALL SEVEN DAYS DO (§2.2). A
 *  customer who sees Mon-Thu listed and Fri-Sun missing reads the gap as
 *  closed, which is a guess this project is under a release blocker not to
 *  make. Consumed by the public block and by lib/jsonld.ts. */
export interface PublishedHours {
  /** In DAY_ORDER, always — never the order findMany() handed back. */
  days: readonly PublishedDay[]
  /** max(HoursDay.updatedAt) as ISO: the provenance stamp's only input. */
  updatedAt: string
}

/** One dated notice, already resolved to a single winning row for the days it
 *  covers (§1.9), already worded (§2.5). The component renders strings. */
export interface ExceptionLine {
  key: string
  /** "Today" · "Wed, Dec 25" · "Dec 24 - Jan 2". Uppercased by CSS. */
  eyebrow: string
  body: string
  today: boolean
}

export interface HoursView {
  /** Null renders today's absence block, byte for byte. */
  week: PublishedHours | null
  /** week !== null, for the copy surfaces that only need the question
   *  answered — and the ONE prop hours are allowed to put into booking.
   *  Owner-entered hours are a PUBLISHING fact, never a booking-capacity
   *  fact (§0.3, veto 1). */
  published: boolean
  /** Rendered whenever they exist, table or no table (§2.6): "closed Dec 25"
   *  is useful and non-guessed even while the week says call. */
  exceptions: readonly ExceptionLine[]
  /** CARRIED, NOT RENDERED (§0.2). The public page shows the same absence
   *  whether there is no database or the database did not answer; the admin
   *  screen can tell them apart. True only when a query actually returned. */
  reachable: boolean
}

/** The absence shape. Returned on EVERY failure path — see the header. */
export const HOURS_ABSENT: HoursView = {
  week: null,
  published: false,
  exceptions: [],
  reachable: false,
}

// ---------------------------------------------------------------------------
// THE DATED NOTICES
// ---------------------------------------------------------------------------

/** More than three dated notices on a bar's front page is clutter, and the
 *  fourth is months away. */
const MAX_LINES = 3

/** How far ahead a dated notice is worth printing. */
const HORIZON_DAYS = 60

/** Bar-day string arithmetic, in UTC — the string already IS the bar's day,
 *  so re-interpreting it in Pacific would shift it (lib/hours.ts labelBarDay
 *  carries the same reasoning). UTC has no DST, so a day is always 24h here.
 *
 *  Anchored at midday rather than midnight as belt-and-braces: nothing can
 *  round a noon stamp onto the wrong calendar day.
 *
 *  Local rather than in lib/hours.ts because that module is frozen; if a
 *  second caller ever appears, it belongs beside barServiceDay(). */
function addBarDays(day: string, count: number): string {
  const shifted = new Date(`${day}T12:00:00Z`).getTime() + count * 86_400_000
  return new Date(shifted).toISOString().slice(0, 10)
}

function bodyFor(row: ExceptionRow, today: boolean): string {
  const reason = row.label ? ` - ${row.label}` : ''
  // A RANGE WHOSE EYEBROW READS "TODAY" HAS HAD ITS SPAN HIDDEN, so the body
  // carries it (review round 1, blocker 1). Without this, a ten-day closure
  // read "Closed today." on its third day and invited the customer to try
  // again tomorrow — the 22-mile drive this whole feature exists to prevent.
  // Only when the eyebrow is TODAY: on a future line the eyebrow already
  // says "Dec 24 - Jan 2" and repeating the end would be noise.
  const through = today && !isSingleDate(row) ? ` through ${shortBarDay(spanEnd(row))}` : ''
  // The half-row (closed false, one time missing) cannot exist — the shape
  // CHECK forbids it — but if one ever did it reads as closed rather than
  // crashing the card.
  if (row.closed || row.open === null || row.close === null) {
    return `${today && !through ? 'Closed today' : 'Closed'}${through}${reason}.`
  }
  // "Closing at 8pm" is the today voice for ONE evening. Over a span it
  // would under-claim, so a multi-day early close prints both ends and the
  // last day it applies to.
  if (today && !through) return `Closing at ${formatTime(row.close)}${reason}.`
  return `Open ${formatRange(row.open, row.close)}${through}${reason}.`
}

function lineFor(row: ExceptionRow, today: boolean): ExceptionLine {
  return {
    key: `${row.date}|${row.endDate ?? ''}|${row.createdAt.getTime()}`,
    // A row that wins TODAY is labelled TODAY whatever its own span: the
    // reader standing in front of the door needs the day named, not the
    // block it came from. The span is not lost — bodyFor() carries it.
    eyebrow: today
      ? 'Today'
      : isSingleDate(row)
        ? labelBarDay(row.date)
        : labelBarDayRange(row.date, spanEnd(row)),
    body: bodyFor(row, today),
    today,
  }
}

/** ONE LINE PER SERVICE DAY, decided by resolveException() — walk the days a
 *  row could cover, ask the resolver which row wins for each, and emit a line
 *  per WINNING ROW. So "Dec 24 - Jan 2 / closed" plus "Dec 25 / closed -
 *  holiday" produce two lines with different eyebrows and never two
 *  contradicting claims about Dec 25. Ascending by the day each row first
 *  wins, capped at MAX_LINES. */
export function exceptionLines(rows: readonly ExceptionRow[], today: string): ExceptionLine[] {
  const horizon = addBarDays(today, HORIZON_DAYS)
  // Live rows are already filtered by the query; this drops the ones that
  // START beyond the horizon.
  const inWindow = rows.filter((row) => row.date <= horizon)
  const lines: ExceptionLine[] = []
  const seen = new Set<ExceptionRow>()
  for (let day = today; day <= horizon; day = addBarDays(day, 1)) {
    const winner = resolveException(inWindow, day)
    if (winner === null || seen.has(winner)) continue
    seen.add(winner)
    lines.push(lineFor(winner, day === today))
    if (lines.length === MAX_LINES) break
  }
  return lines
}

// ---------------------------------------------------------------------------
// THE READ
// ---------------------------------------------------------------------------

async function queryHours(today: string): Promise<HoursView> {
  const db = getDb()
  const [days, exceptions] = await Promise.all([
    db.hoursDay.findMany(),
    db.hoursException.findMany({
      // The object WHOLE, never a spread of its keys: a spread would drop
      // any second key the filter ever grows (review round 1, finding 7).
      where: liveExceptionsWhere(today),
      orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
    }),
  ])

  const published = isPublishable(days)
  const byDay = new Map(days.map((row) => [row.day, row]))
  return {
    week: published
      ? {
          // DAY_ORDER, never the query: HoursDay.day is a String @id, so
          // findMany() hands back fri,mon,sat,sun,thu,tue,wed.
          days: DAY_ORDER.map((day) => ({ day, state: dayStateOf(byDay.get(day)) })),
          // The MAX, not the first row: the stamp claims the freshest change.
          updatedAt: new Date(
            Math.max(...days.map((row) => row.updatedAt.getTime())),
          ).toISOString(),
        }
      : null,
    published,
    exceptions: exceptionLines(exceptions, today),
    reachable: true,
  }
}

/** The cached shell. NO try/catch in here, deliberately — see the header. */
async function readHoursCached(): Promise<HoursView> {
  'use cache'
  cacheTag('overlay')
  cacheLife({ stale: 60, revalidate: 300, expire: 3600 })

  // No database to ask (build, preview, test). An honest answer that stays
  // true for the life of the deployment, so it is worth caching — and it is
  // the same absence a failure returns, because the page has nothing else to
  // say either way.
  if (!process.env.DATABASE_URL) return HOURS_ABSENT

  return await queryHours(barServiceDay())
}

/** The owner's hours, or the absence that renders "call".
 *
 *  `now` is the injectable seam (§9.2.8): tests and the hand-check drive the
 *  date boundaries through an explicit clock, never the machine's. Passing it
 *  BYPASSES the cache on purpose — a live clock as a cache key would make
 *  every request a miss. */
export async function getHours(now?: Date): Promise<HoursView> {
  try {
    if (now) {
      if (!process.env.DATABASE_URL) return HOURS_ABSENT
      return await queryHours(barServiceDay(now))
    }
    return await readHoursCached()
  } catch {
    // The catch is OUTSIDE the shell: a cold or absent database degrades this
    // one request, and the next request asks again. The page says "call",
    // which is true, instead of printing a table nobody stands behind.
    return HOURS_ABSENT
  }
}
