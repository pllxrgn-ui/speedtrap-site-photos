// Shared validation contract for the table-booking request. The Phase 4
// form and the API route both parse against this so a request can never be
// accepted by one and silently dropped by the other — the same contract
// pattern as lib/inquiry.ts.

import { z } from 'zod'
import { sanitize, sanitizePhone } from '@/lib/sanitize'

export const TIME_WINDOWS = ['lunch', 'afternoon', 'evening', 'late'] as const
export type TimeWindowValue = (typeof TIME_WINDOWS)[number]

// Rough windows, NEVER clock times: the site is under a written rule not to
// print hours it cannot stand behind (content.test.ts pins hours.weekly to
// null). Confirming #B3 upgrades the form; until then the honesty rule
// lives in this type. Labels sit beside the enum so copy cannot drift.
export const TIME_WINDOW_LABELS: Record<TimeWindowValue, string> = {
  lunch: 'Lunch',
  afternoon: 'Afternoon',
  evening: 'Evening',
  late: 'Late',
}

export const MAX_ADVANCE_DAYS = 90 // proposed in #B4; server-side cap
export const RETENTION_DAYS = 90 // promised on the form, enforced by the cron
export const MAX_PARTY_SIZE = 40 // mirrored by the DB CHECK constraint

const digitsOnly = (value: string) => value.replace(/\D/g, '')

// Two days of slack, same reasoning as lib/inquiry.ts: the visitor's clock
// and the server's clock are in different timezones and we would rather
// accept a stale date than reject somebody booking today.
const PAST_SLACK_MS = 48 * 60 * 60 * 1000
const DAY_MS = 86_400_000

const dateInRange = (value: string) => {
  const time = Date.parse(`${value}T00:00:00Z`)
  if (!Number.isFinite(time)) return false
  const now = Date.now()
  return time >= now - PAST_SLACK_MS && time <= now + MAX_ADVANCE_DAYS * DAY_MS
}

export const bookingSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Tell us who to ask for.')
    .max(80, 'That is longer than a name needs to be. Shorten it.'),
  phone: z
    .string()
    .trim()
    .max(30, 'That is longer than a phone number. Check it.')
    .refine(
      (value) => digitsOnly(value).length >= 10,
      'We need all ten digits so we can call you back.',
    )
    // phoneDigits is VarChar(15) — E.164's own maximum. Without this cap,
    // "+1 (509) 530-9997 ext 12345" passes as a 27-char string, overflows
    // the column and turns into an unlogged 500 (review finding 2).
    .refine(
      (value) => digitsOnly(value).length <= 15,
      'That looks like more than one number. Just the one you answer.',
    ),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Pick the day you have in mind.')
    .refine(
      dateInRange,
      `From today up to ${MAX_ADVANCE_DAYS} days out. Further ahead, call us.`,
    ),
  partySize: z
    .number('Pick how many of you.')
    .int('A whole number of people.')
    .min(1, 'At least one person, we assume.')
    .max(MAX_PARTY_SIZE, 'For a crowd that size, call us about the private room.'),
  timeWindow: z.enum(TIME_WINDOWS, 'Pick roughly when.'),
  // Deliberately hinted toward logistics, never allergies or accessibility
  // needs — a free-text health detail is a legal exposure the note must not
  // solicit (build/08 §2, WA MHMD flag; hint copy lives in the Phase 4 form).
  note: z
    .string()
    .trim()
    .max(500, 'Keep this under 500 characters and we will get the rest on the phone.')
    .optional(),
  // Honeypot — see lib/http/honeypot.ts for the naming lesson.
  hp_referrer: z.string().optional(),
})

export type BookingInput = z.infer<typeof bookingSchema>

export const phoneDigits = digitsOnly

// requestedOn + 90 days, computed at insert so the purge cron never has to
// do date math against a promise made earlier under different rules.
export function purgeAfterOf(date: string): Date {
  return new Date(Date.parse(`${date}T00:00:00Z`) + RETENTION_DAYS * DAY_MS)
}

// Runs BEFORE bookingSchema on BOTH sides — the route does, and the Phase 4
// form must call this before its own client-side parse, or a name at the
// 80-char cap that starts with "=" validates in the browser and 400s on the
// server (the exact divergence this shared contract exists to prevent).
// sanitize() can grow a value by one character, so the length caps have to
// bound the post-transform value. Phones keep their + via sanitizePhone.
export function presanitizeBooking(payload: unknown): unknown {
  if (typeof payload !== 'object' || payload === null) return payload
  const raw = payload as Record<string, unknown>
  return {
    ...raw,
    name: typeof raw.name === 'string' ? sanitize(raw.name) : raw.name,
    phone: typeof raw.phone === 'string' ? sanitizePhone(raw.phone.trim()) : raw.phone,
    note: typeof raw.note === 'string' ? sanitize(raw.note) : raw.note,
  }
}
