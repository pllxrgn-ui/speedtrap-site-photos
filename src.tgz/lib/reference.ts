import { randomInt } from 'node:crypto'

// The reference is quotable on the phone over bar noise, so the alphabet
// drops 0/O, 1/I/L: "ST-7K2M" cannot be misheard into a different code.
// Uniqueness is the database's job (Booking.reference is @unique) — the
// caller retries on the rare collision, this function just draws.
const ALPHABET = '23456789ABCDEFGHJKMNPQRSTVWXYZ'

export function newReference(): string {
  let code = ''
  for (let i = 0; i < 4; i += 1) {
    code += ALPHABET[randomInt(ALPHABET.length)]
  }
  return `ST-${code}`
}
