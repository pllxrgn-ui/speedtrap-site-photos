import { createHash } from 'node:crypto'

// The pepper turns an IP into an opaque bucket key: never a raw IP in any
// row or log, and rotating PII_HASH_PEPPER deliberately severs correlation
// with old rows (build/08 §1). Without a pepper there is no hash at all —
// hashing with an empty secret would be a lookup table, not a mask.
export function hashIp(ip: string | null): string | null {
  const pepper = process.env.PII_HASH_PEPPER
  if (!pepper || !ip) return null
  return createHash('sha256').update(`${pepper}${ip}`).digest('hex')
}

export function clientIpOf(request: Request): string | null {
  const forwarded = request.headers.get('x-forwarded-for')
  const first = forwarded?.split(',')[0]?.trim()
  if (first) return first
  return request.headers.get('x-real-ip')
}
