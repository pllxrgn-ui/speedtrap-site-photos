import { BASE_URL } from '@/lib/base-url'

// Closes audit M5 for every POST route that imports it. The allow-set
// (build/08 §2 row 2): the canonical BASE_URL origin, the origin the
// request itself was served from (this is what un-403s preview hosts), the
// proxy-reported host, and localhost for dev.
//
// An ABSENT Origin passes deliberately (curl, tests, some webviews) —
// tightening that is a stated decision with its own test, never a side
// effect (build/08 veto 19). And do not "fix" BASE_URL by dropping its
// VERCEL_PROJECT_PRODUCTION_URL fallback (veto 20): production matches
// today; preview hosts were the breakage.
const LOCALHOST = /^https?:\/\/localhost(:\d+)?$/

// BASE_URL is env-derived; a scheme-less typo at domain cutover
// (CLIENT-QUESTIONS #12) must degrade to "blocked origin", never to a
// thrown 500 on every POST route that imports this file.
const BASE_ORIGIN = (() => {
  try {
    return new URL(BASE_URL).origin
  } catch {
    return null
  }
})()

export function isAllowedOrigin(request: Request): boolean {
  const origin = request.headers.get('origin')
  if (!origin) return true
  if (LOCALHOST.test(origin)) return true
  if (BASE_ORIGIN && origin === BASE_ORIGIN) return true
  if (origin === new URL(request.url).origin) return true
  // Trust boundary, on the record: x-forwarded-host is only meaningful
  // behind a proxy that OVERWRITES it (Vercel does). Off-platform it is
  // client-settable, so this whole gate is a browser-CSRF layer, never the
  // authorization boundary — that is requireSession + the double-submit
  // token (Phase 3, build/08 §2 rows 7-9).
  const forwardedHost = request.headers.get('x-forwarded-host')?.split(',')[0]?.trim()
  if (forwardedHost && origin === `https://${forwardedHost}`) return true
  return false
}
