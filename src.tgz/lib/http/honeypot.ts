// Shared by every public POST form. The field is named hp_referrer so no
// browser autofill heuristic matches it — a field named "company" gets
// filled by Chrome's address autofill, which would flag real customers as
// bots (hard-won: lib/inquiry.ts:63-68). Routes check this BEFORE
// validation and answer 200 so the bot learns nothing from the status.
export function isHoneypotHit(payload: unknown): boolean {
  if (typeof payload !== 'object' || payload === null) return false
  const trap = (payload as { hp_referrer?: unknown }).hp_referrer
  return typeof trap === 'string' && trap.trim() !== ''
}
