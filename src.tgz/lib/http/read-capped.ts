// Closes audit M6. The old check trusted the Content-Length header, and
// `Number(null) === 0` let a chunked body with NO declared length buffer
// unbounded (measured at 280× the intended cap). This reader counts actual
// bytes off the wire and stops at the cap. `await request.text()` buffers
// everything first and does NOT fix this.

export type CappedBody =
  | { ok: true; bytes: Buffer }
  | { ok: false; reason: 'too-large' | 'unreadable' }

export type CappedJson =
  | { ok: true; value: unknown }
  | { ok: false; reason: 'too-large' | 'unreadable' }

// The shared byte counter every capped consumer builds on — JSON bodies
// AND multipart uploads (the dish-photo route re-opened M6 by calling
// formData() on the raw request; review 2026-09-22). Anything that parses
// a body first reads it through here.
export async function readBodyCapped(request: Request, maxBytes: number): Promise<CappedBody> {
  // Cheap pre-check: an honestly declared oversize never costs a byte.
  const declared = Number(request.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > maxBytes) {
    return { ok: false, reason: 'too-large' }
  }

  if (request.body) {
    const reader = request.body.getReader()
    const chunks: Uint8Array[] = []
    let received = 0
    try {
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        received += value.byteLength
        if (received > maxBytes) {
          await reader.cancel()
          return { ok: false, reason: 'too-large' }
        }
        chunks.push(value)
      }
      return { ok: true, bytes: Buffer.concat(chunks) }
    } catch {
      return { ok: false, reason: 'unreadable' }
    }
  }

  // No stream on this Request implementation. The declared-length check
  // above already ran; arrayBuffer() on a bodyless request is at worst
  // empty — and test environments land here.
  try {
    const bytes = Buffer.from(await request.arrayBuffer())
    if (bytes.byteLength > maxBytes) return { ok: false, reason: 'too-large' }
    return { ok: true, bytes }
  } catch {
    return { ok: false, reason: 'unreadable' }
  }
}

export async function readJsonCapped(request: Request, maxBytes: number): Promise<CappedJson> {
  const body = await readBodyCapped(request, maxBytes)
  if (!body.ok) return body
  try {
    return { ok: true, value: JSON.parse(body.bytes.toString('utf8')) }
  } catch {
    return { ok: false, reason: 'unreadable' }
  }
}
