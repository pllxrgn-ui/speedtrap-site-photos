// Closes audit M6. The old check trusted the Content-Length header, and
// `Number(null) === 0` let a chunked body with NO declared length buffer
// unbounded (measured at 280× the intended cap). This reader counts actual
// bytes off the wire and stops at the cap. `await request.text()` buffers
// everything first and does NOT fix this.

export type CappedJson =
  | { ok: true; value: unknown }
  | { ok: false; reason: 'too-large' | 'unreadable' }

export async function readJsonCapped(request: Request, maxBytes: number): Promise<CappedJson> {
  // Cheap pre-check: an honestly declared oversize never costs a byte.
  const declared = Number(request.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > maxBytes) {
    return { ok: false, reason: 'too-large' }
  }

  let text: string
  if (request.body) {
    const reader = request.body.getReader()
    const chunks: Uint8Array[] = []
    let received = 0
    try {
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        received += value.byteLength
        if (received > maxBytes) {
          await reader.cancel()
          return { ok: false, reason: 'too-large' }
        }
        chunks.push(value)
      }
      text = Buffer.concat(chunks).toString('utf8')
    } catch {
      return { ok: false, reason: 'unreadable' }
    }
  } else {
    // No stream on this Request implementation. The declared-length check
    // above already ran; text() on a bodyless request is at worst ''.
    try {
      text = await request.text()
    } catch {
      return { ok: false, reason: 'unreadable' }
    }
  }

  try {
    return { ok: true, value: JSON.parse(text) }
  } catch {
    return { ok: false, reason: 'unreadable' }
  }
}
