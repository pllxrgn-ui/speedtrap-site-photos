import type { HoldUntil } from '@prisma/client'

// Shared between the cached overlay read (server), the admin board
// (client) and the public 86 mark — one vocabulary for how long a dish is
// off. Veto 13: the DEFAULT hold expires on its own; "until I clear it"
// is the deliberate exception the owner has to pick.
export const HOLD_LABELS: Record<HoldUntil, string> = {
  tonight: '86 tonight',
  this_week: '86 this week',
  cleared: "86'd",
}

export const HOLD_CHOICES: { value: HoldUntil; label: string }[] = [
  { value: 'tonight', label: 'Tonight' },
  { value: 'this_week', label: 'This week' },
  { value: 'cleared', label: 'Until I clear it' },
]
