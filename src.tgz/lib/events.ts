// Recurring rhythm from research/01 §11 + Facebook posts. Dated one-off
// events (karaoke nights, live music dates) are PLACEHOLDER until the owner
// confirms the schedule — do not render a dated calendar from guesses.

export type RecurringEvent = {
  id: string
  day: string
  title: string
  blurb: string
  confirmed: boolean // false = seen in reviews/posts, not owner-confirmed
}

export const RECURRING: RecurringEvent[] = [
  {
    id: 'taco-tuesday',
    day: 'Tuesday',
    title: 'Taco Tuesday',
    blurb: 'The special people plan their week around.',
    confirmed: false,
  },
  {
    id: 'fish-fry-friday',
    day: 'Friday',
    title: 'Fish & Chips + Clam Chowder',
    blurb: 'Friday tradition. Sometimes with live music.',
    confirmed: false,
  },
  {
    id: 'karaoke',
    day: 'Select Fridays',
    title: 'Karaoke Night',
    blurb: 'Roughly monthly, mic opens around 7.',
    confirmed: false,
  },
  {
    id: 'live-music',
    day: 'Watch this space',
    title: 'Live Music',
    blurb: 'Local acts on the calendar when they land.',
    confirmed: false,
  },
  {
    id: 'prime-rib',
    day: 'When they have it',
    title: 'Prime Rib',
    blurb: 'Ask, or watch the specials board.',
    confirmed: false,
  },
]

export const MULE_DAYS_NOTE =
  'Mule Days hits Reardan the first Saturday of June. Expect a parade, a crowd, and a busy kitchen.'
