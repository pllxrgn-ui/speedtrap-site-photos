import { sanitize } from '@/lib/sanitize'

export interface BookingNotification {
  reference: string
  name: string
  phone: string
  date: string
  timeWindow: string
  partySize: number
  note?: string
}

// Notification channel v1: one webhook the owner controls (#B1 decides the
// real target; Twilio only then). A BROKEN webhook must never fail the
// booking — by the time this runs the row is committed and THE BOOK in
// /admin is the source of truth. This is a ping, not the record.
export async function notifyBooking(input: BookingNotification): Promise<boolean> {
  const webhookUrl = process.env.BOOKING_NOTIFY_WEBHOOK_URL
  if (!webhookUrl) return false
  try {
    const delivered = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      signal: AbortSignal.timeout(8000),
      body: JSON.stringify({
        source: 'table-booking',
        reference: input.reference,
        name: sanitize(input.name),
        phone: sanitize(input.phone),
        date: input.date,
        window: input.timeWindow,
        partySize: input.partySize,
        note: input.note ? sanitize(input.note) : undefined,
      }),
    })
    return delivered.ok
  } catch {
    return false
  }
}
