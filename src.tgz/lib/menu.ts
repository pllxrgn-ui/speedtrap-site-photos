// Menu items transcribed from the business's own printed menu, photographed
// in-house and dated "As of 7/2026" by the uploader (research/05 §Yelp).
// That makes the ITEM LIST solid second-hand evidence. Prices are NOT wired:
// every price stays null until the owner confirms, because three menu
// generations with different prices are in evidence and only the owner knows
// which numbers hold this week. UI renders no price row when price is null;
// the gate blocks launch regardless until owner-verified (flag below).

export type MenuItem = {
  name: string
  description?: string
  price: number | null
  tags?: ('gf' | 'v')[]
  houseMade?: boolean
}

export type MenuCategory = {
  id: string
  title: string
  note?: string
  items: MenuItem[]
}

export const MENU_VERIFIED = false // owner has not confirmed items or prices

export const MENU: MenuCategory[] = [
  {
    id: 'burgers',
    title: 'Burgers',
    // Topping line is from the printed menu itself; "hand-formed" claims are
    // still held until the owner confirms (build/02).
    note: 'The reason most people pull over. Mayo, lettuce, tomato, pickles and onions on every one, fries on the side.',
    items: [
      { name: 'Speed Trap Burger', description: 'Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.', price: null },
      { name: 'Blue Cheese Burger', description: 'Blue cheese, grilled onions, bacon. The one people drive out for.', price: null },
      { name: 'Jail House Burger', description: 'Jalapeño and cheddar.', price: null },
      { name: 'Hawaiian Burger', description: 'Teriyaki, pineapple, bacon, Swiss.', price: null },
      { name: 'Farmers Burger', description: 'Bacon, egg and cheddar.', price: null },
      { name: 'Mushroom Burger', description: 'Grilled mushrooms, Swiss.', price: null },
      { name: 'Bacon Cheeseburger', price: null },
      { name: 'Classic Cheeseburger', price: null },
      { name: 'Classic Hamburger', price: null },
    ],
  },
  {
    id: 'dinners',
    title: 'Dinners',
    note: 'With your choice of potato, plus soup or salad.',
    items: [
      { name: 'Hamburger Steak Dinner', description: 'Grilled mushrooms and onions, smothered in gravy.', price: null },
      { name: 'Open Faced Sandwich', description: 'Prime rib or turkey under brown gravy.', price: null },
      { name: 'Country Fried Steak', description: 'Smothered in cream gravy.', price: null },
      { name: 'Pork Rib Tips Dinner', description: 'Slathered in barbecue sauce.', price: null },
    ],
  },
  {
    id: 'sandwiches',
    title: 'Sandwiches',
    items: [
      { name: 'Philly Cheesesteak', description: 'Prime rib, jalapeño, onion, Swiss. Also comes as chicken.', price: null },
      { name: 'Classic French Dip', description: 'House prime rib, Swiss, jus for dunking.', price: null },
      { name: 'The Chicken Sandwich', description: 'Grilled or crispy, with mayo, lettuce and tomato.', price: null },
      { name: "John's Pork Chop Sandwich", description: 'Fried patty, mustard, pickles, onions.', price: null },
      { name: 'Patty Melt', description: '1000 island, Swiss and grilled onions on rye.', price: null },
      { name: 'Club Sandwich', description: 'Turkey, ham, bacon, tomato, lettuce and cheese.', price: null },
      { name: 'Classic BLT', price: null },
      { name: 'Grilled Ham & Cheese', price: null },
    ],
  },
  {
    id: 'appetizers',
    title: 'Appetizers',
    items: [
      { name: 'Chicken Gizzards', price: null },
      { name: 'Cordon Blue Balls', description: 'Yes, that is the real name.', price: null },
      { name: 'Breaded Chicken Wings', price: null },
      { name: 'Mozzarella Sticks', price: null },
      { name: 'Jalapeño Poppers', price: null },
      { name: 'Fried Mushrooms', price: null },
      { name: 'Macaroni Gouda Bites', price: null },
      { name: 'Basket of Fries or Tater Tots', price: null },
      { name: 'Basket of Onion Rings or Sweet Potato Fries', price: null },
    ],
  },
  {
    id: 'baskets',
    title: 'Baskets',
    note: 'With fries.',
    items: [
      { name: 'Fish & Chips', price: null },
      { name: 'Chicken Strips', price: null },
      { name: 'Steak Fingers', price: null },
      { name: 'Breaded Shrimp', price: null },
      { name: 'Gizzards & Side', price: null },
      { name: 'Two Taco Basket', price: null },
    ],
  },
  {
    id: 'salads-sides',
    title: 'Salads & Sides',
    items: [
      { name: 'Chief Salad', description: 'Easily feeds two.', price: null },
      { name: 'Taco Salad', price: null },
      { name: 'Grilled Chicken Salad', price: null },
      { name: 'Chicken BLT Salad', price: null },
      { name: 'Patty Melt Salad', price: null },
      { name: 'Side House Salad', price: null },
      { name: 'Mac Salad or Soup', description: 'Cup or bowl.', price: null },
      { name: 'Chips & Salsa', price: null },
    ],
  },
  {
    id: 'drinks',
    title: 'Drinks & Taps',
    note: 'Full bar. Rotating drafts, can and bottle beer, wine, cocktails, coffee.',
    items: [], // PLACEHOLDER: tap list pending owner; do not invent drafts
  },
]
