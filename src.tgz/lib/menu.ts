// Menu draft compiled from reviews/posts/aggregators — build/02-content-plan.md.
// PLACEHOLDER: every price is null until the owner confirms the real menu.
// UI renders no price row when price is null; the gate blocks launch regardless
// until this file is owner-verified (verified flag below).

export type MenuItem = {
  name: string
  description?: string
  price: number | null
  tags?: ('gf' | 'v')[]
  houseMade?: boolean
}

export type MenuCategory = {
  id: string
  title: string
  note?: string
  items: MenuItem[]
}

export const MENU_VERIFIED = false // owner has not confirmed items or prices

export const MENU: MenuCategory[] = [
  {
    id: 'burgers',
    title: 'Burgers',
    // "Hand-formed patties, made to order" is held until the owner confirms
    // it (build/02: house-made callouts need confirmation before printing).
    note: 'The reason most people pull over.',
    items: [
      { name: 'Blue Cheese Burger', description: 'The one people drive out for.', price: null },
      { name: 'Bacon Cheeseburger', price: null },
      { name: 'Grilled Chicken Bacon Burger', price: null },
      { name: 'Mushroom Burger', price: null },
      { name: 'Tap House Burger', description: 'Super-sized. Ask before you commit.', price: null },
      { name: 'Tavern Burger', description: 'The throwback. Add fries if you know what is good for you.', price: null },
    ],
  },
  {
    id: 'sandwiches',
    title: 'Sandwiches',
    items: [
      { name: 'Chicken Philly', price: null },
      { name: 'Reuben', price: null },
      { name: 'Chicken Sandwich', description: 'On a toasted bun.', price: null },
    ],
  },
  {
    id: 'baskets',
    title: 'Baskets & Bar Food',
    items: [
      { name: 'Chicken Tenders', price: null },
      { name: 'Steak Fingers', price: null },
      { name: 'Chicken Wings', price: null },
      { name: 'Onion Rings', price: null },
      { name: 'Jalapeño Poppers', description: 'Stuffed with cream cheese.', price: null },
      { name: 'Mac & Cheese Bites', price: null },
      { name: 'Fish & Chips', price: null },
      { name: 'Loaded Fries', price: null },
      // houseMade tag held until owner confirms (a customer review says the
      // fry sauce is house-made, but the kitchen has not confirmed in writing).
      { name: 'Fries with Fry Sauce', price: null },
    ],
  },
  {
    id: 'salads-sides',
    title: 'Salads & Sides',
    items: [
      { name: 'Chief Salad', description: 'Easily feeds two.', price: null },
      { name: 'Mac Salad', price: null },
      { name: 'Tots', price: null },
    ],
  },
  {
    id: 'drinks',
    title: 'Drinks & Taps',
    note: 'Full bar. Rotating drafts, can and bottle beer, wine, cocktails, coffee.',
    items: [], // PLACEHOLDER: tap list pending owner; do not invent drafts
  },
]
