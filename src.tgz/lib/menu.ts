// Menu transcribed from the business's own printed menu, photographed
// in-house and dated "As of 7/2026" by the uploader (research/05 §Yelp,
// full-resolution evidence in assets/menu-evidence/).
//
// PRICES: live since 2026-09-14 (Pol's direction). They carry the printed
// menu's own date, disclosed on the page as "prices from the July 2026 menu",
// because an empty price column reads as a broken site while a dated one
// reads as an honest one. MENU_VERIFIED stays false until the owner ticks
// the prefilled sheet in CLIENT-QUESTIONS #2; when that lands, flip the flag
// and clear MENU_PRICES_AS_OF. content.test.ts pins drift canaries to the
// research/05 transcription so nobody "adjusts" a number without evidence.

export type MenuItem = {
  name: string
  description?: string
  price: number | null
  tags?: ('gf' | 'v')[]
  houseMade?: boolean
}

export type MenuCategory = {
  id: string
  title: string
  note?: string
  items: MenuItem[]
}

export const MENU_VERIFIED = false // owner has not confirmed items or prices

/** Set = prices render, with this label disclosed on the page.
 *  Null = prices hidden entirely (the pre-2026-09-14 posture). */
export const MENU_PRICES_AS_OF: string | null = 'July 2026'

export const MENU: MenuCategory[] = [
  {
    id: 'burgers',
    title: 'Burgers',
    // Topping line is from the printed menu itself; "hand-formed" claims are
    // still held until the owner confirms (build/02).
    note: 'The reason most people pull over. Mayo, lettuce, tomato, pickles and onions on every one, fries on the side.',
    items: [
      { name: 'Speed Trap Burger', description: 'Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.', price: 20 },
      { name: 'Blue Cheese Burger', description: 'Blue cheese, grilled onions, bacon. The one people drive out for.', price: 17 },
      { name: 'Jail House Burger', description: 'Jalapeño and cheddar.', price: 15 },
      { name: 'Hawaiian Burger', description: 'Teriyaki, pineapple, bacon, Swiss.', price: 17 },
      { name: 'Farmers Burger', description: 'Bacon, egg and cheddar.', price: 17 },
      { name: 'Mushroom Burger', description: 'Grilled mushrooms, Swiss.', price: 15 },
      { name: 'Bacon Cheeseburger', price: 16 },
      { name: 'Classic Cheeseburger', price: 14 },
      { name: 'Classic Hamburger', price: 13 },
    ],
  },
  {
    id: 'dinners',
    title: 'Dinners',
    note: 'With your choice of potato, plus soup or salad.',
    items: [
      { name: 'Hamburger Steak Dinner', description: 'Grilled mushrooms and onions, smothered in gravy.', price: 19 },
      { name: 'Open Faced Sandwich', description: 'Prime rib or turkey under brown gravy.', price: 18 },
      { name: 'Country Fried Steak', description: 'Smothered in cream gravy.', price: 18 },
      { name: 'Pork Rib Tips Dinner', description: 'Slathered in barbecue sauce.', price: 19 },
    ],
  },
  {
    id: 'sandwiches',
    title: 'Sandwiches',
    note: 'Served with fries.',
    items: [
      { name: 'Philly Cheesesteak', description: 'Prime rib, jalapeño, onion, Swiss. The marinated chicken version runs $16.', price: 18 },
      { name: 'Classic French Dip', description: 'House prime rib, Swiss, jus for dunking.', price: 16 },
      { name: 'The Chicken Sandwich', description: 'Grilled, with mayo, lettuce and tomato. Crispy version runs $14.', price: 16 },
      { name: "John's Pork Chop Sandwich", description: 'Fried patty, mustard, pickles, onions.', price: 14 },
      { name: 'Patty Melt', description: '1000 island, Swiss and grilled onions on rye.', price: 15 },
      { name: 'Club Sandwich', description: 'Turkey, ham, bacon, tomato, lettuce and cheese.', price: 20 },
      { name: 'Classic BLT', price: 14 },
      { name: 'Grilled Ham & Cheese', price: 15 },
    ],
  },
  {
    id: 'appetizers',
    title: 'Appetizers',
    items: [
      { name: 'Chicken Gizzards', price: 12 },
      { name: 'Cordon Blue Balls', description: 'Yes, that is the real name.', price: 11 },
      { name: 'Breaded Chicken Wings', price: 13 },
      { name: 'Mozzarella Sticks', price: 12 },
      { name: 'Jalapeño Poppers', price: 10 },
      { name: 'Fried Mushrooms', price: 10 },
      { name: 'Macaroni Gouda Bites', price: 12 },
      { name: 'Basket of Fries or Tater Tots', price: 7 },
      { name: 'Basket of Onion Rings or Sweet Potato Fries', price: 10 },
    ],
  },
  {
    id: 'baskets',
    title: 'Baskets',
    note: 'With fries.',
    items: [
      { name: 'Fish & Chips', price: 15 },
      { name: 'Chicken Strips', price: 14 },
      { name: 'Steak Fingers', price: 14 },
      { name: 'Breaded Shrimp', price: 14 },
      { name: 'Gizzards & Side', price: 14 },
      { name: 'Two Taco Basket', price: 10 },
    ],
  },
  {
    id: 'salads-sides',
    title: 'Salads & Sides',
    items: [
      { name: 'Chief Salad', description: 'Easily feeds two.', price: 16 },
      { name: 'Taco Salad', price: 15 },
      { name: 'Grilled Chicken Salad', price: 14 },
      { name: 'Chicken BLT Salad', price: 15 },
      { name: 'Patty Melt Salad', price: 14 },
      { name: 'Side House Salad', price: 4 },
      { name: 'Cup of Mac Salad or Soup', price: 4 },
      { name: 'Bowl of Mac Salad or Soup', price: 6 },
      { name: 'Chips & Salsa', price: 5 },
    ],
  },
  {
    id: 'drinks',
    title: 'Drinks & Taps',
    // The bar itself stays a sentence, not a list: the tap list rotates and
    // inventing drafts is a release blocker (build/03 §4 guardrail 5). The
    // soft side below is printed on the July 2026 menu. The tap-list
    // statement ("The tap list rotates. Ask what is pouring.") lives in the
    // drinks spread on the page, at sign scale.
    note: 'Full bar: rotating drafts, can and bottle beer, wine, cocktails.',
    items: [
      { name: 'Fountain Soda', price: 3 },
      { name: 'Can of Soda', price: 1.5 },
      { name: 'Brewed Iced Tea', price: 3 },
      { name: 'Hot Coffee or Tea', price: 3 },
      { name: 'Juice', description: 'Cranberry, pineapple or orange.', price: 3 },
    ],
  },
]
