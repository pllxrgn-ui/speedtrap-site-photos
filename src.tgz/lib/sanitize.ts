// Lifted verbatim from the inquiry route (build/08 §2 row 13) so the same
// neutering runs on every write AND on the CSV export — a value that can
// execute as a spreadsheet formula must die in one place, not two.
// Control characters out; a leading =, +, - or @ neutered so the value can
// never execute as a formula if the sink is a spreadsheet.
// The class is written with \u escapes ON PURPOSE: raw control bytes in
// this file made git classify it as binary, which made the repo's only
// formula defence undiffable forever (review 2026-09-22, finding 9).
export function sanitize(value: string): string {
  // Order matters: controls become spaces, the TRIM then strips any that
  // landed at the edges, and only then is the leading character judged -
  // otherwise a control-char prefix turns "=SUM(...)" into " =SUM(...)",
  // a later .trim() re-exposes the "=", and the formula survives
  // (review follow-up 1).
  return value
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .trim()
    .replace(/^([=+\-@])/, "'$1")
}

// Phones keep their leading + (E.164 is what every mobile keyboard
// produces): the formula-neutering apostrophe belongs at the spreadsheet
// boundary, not stored inside a tel: link (review finding 7). The CSV
// export still runs full sanitize() on every cell, phone included.
export function sanitizePhone(value: string): string {
  return value.replace(/[\u0000-\u001F\u007F]/g, ' ')
}
