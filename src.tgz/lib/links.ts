import { SITE } from './site'

export const TEL_HREF = `tel:${SITE.phone}`

// Coordinates, not street address: E/W Broadway is unresolved (research/03).
export const DIRECTIONS_HREF = `https://www.google.com/maps/dir/?api=1&destination=${SITE.geo.lat},${SITE.geo.lng}`

// ONE PAGE (build/07): the site is a single route and these are its sections.
// Ids mirror the routes they replaced so the redirect map stays one-to-one
// and guessable. Labels keep the familiar route words even where the section
// headings read differently - a nav label is a scan target.
// ORDER IS SCROLL ORDER (amendment 2026-09-23, build/07 "VISITOR-ORDER
// REORDER"). The header bar, the mobile dialog and the footer all render
// straight off this array, so it must track app/(site)/page.tsx block by
// block or the nav lies about where things are. #about sits SEVENTH now,
// not third - THE ROOM moved below the numbers. Anchors themselves never
// change; only their position in this list does.
export const SECTIONS = [
  { href: '#menu', label: 'Menu' },
  { href: '#events', label: 'Events' },
  { href: '#find-us', label: 'Find Us' },
  // Block 13 (build/08 §3). Measured with all 8 items + phone at 1024-1280
  // before shipping; `nav` shortens it for the bar.
  { href: '#book', label: 'Book a Table', nav: 'Book' },
  { href: '#gallery', label: 'Gallery' },
  { href: '#reviews', label: 'Reviews' },
  { href: '#about', label: 'About' },
  { href: '#private-room', label: 'Private Room & Catering', nav: 'Private Room' },
] as const

/** Header nav: ALL sections (client directive 2026-09-15 - "navs for the
 *  reviews gallery everything"). `nav` overrides a label too long for the
 *  bar; the footer keeps the full label for scent. */
export const NAV = SECTIONS

/** Retired route -> fragment map. Single source: next.config.ts builds its
 *  redirects() from this, and lib/anchors.test.ts asserts every destination
 *  fragment has a rendered anchor - renaming an id cannot silently turn a
 *  redirect into a scroll-to-top. */
export const RETIRED_ROUTES = [
  { source: '/menu', destination: '/#menu' },
  { source: '/events', destination: '/#events' },
  { source: '/about', destination: '/#about' },
  { source: '/find-us', destination: '/#find-us' },
  { source: '/gallery', destination: '/#gallery' },
  { source: '/reviews', destination: '/#reviews' },
  { source: '/private-room', destination: '/#private-room' },
] as const
