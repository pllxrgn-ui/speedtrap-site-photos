import { SITE } from './site'

export const TEL_HREF = `tel:${SITE.phone}`

// Coordinates, not street address: E/W Broadway is unresolved (research/03).
export const DIRECTIONS_HREF = `https://www.google.com/maps/dir/?api=1&destination=${SITE.geo.lat},${SITE.geo.lng}`

export const NAV = [
  { href: '/menu', label: 'Menu' },
  { href: '/events', label: 'Events' },
  { href: '/about', label: 'About' },
  { href: '/find-us', label: 'Find Us' },
] as const

export const FOOTER_EXTRA = [
  { href: '/gallery', label: 'Gallery' },
  { href: '/private-room', label: 'Private Room & Catering' },
  { href: '/reviews', label: 'Reviews' },
] as const
