import { MENU } from '@/lib/menu'

// Menu items have no id — identity is the display name (lib/menu.ts). The
// 86 board needs a stable foreign key into code, so this derives one, and
// menu-keys.test.ts pins ALL of them literally: renaming a dish fails
// `pnpm gate` instead of silently orphaning an 86 flag at the bar
// (build/08 §1). Orphaned ItemState rows are ignored by the page and
// surfaced in the admin's orphan strip.

export function slugifyDish(name: string): string {
  return name
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

export function menuKey(categoryId: string, dishName: string): string {
  return `${categoryId}/${slugifyDish(dishName)}`
}

export const MENU_KEYS: readonly string[] = MENU.flatMap((category) =>
  category.items.map((item) => menuKey(category.id, item.name)),
)

export const MENU_KEY_SET: ReadonlySet<string> = new Set(MENU_KEYS)
