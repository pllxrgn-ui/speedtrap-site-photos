// Shared validation contract for the private-room inquiry. The client form and
// the API route both parse against this, so a message can never be accepted by
// one and silently dropped by the other. Guarded by lib/inquiry.test.ts.

import { z } from 'zod'

export const OCCASIONS = [
  'Birthday',
  'Anniversary',
  'Wedding or reception',
  'Celebration of life',
  'Business or club meeting',
  'Holiday party',
  'Catering, off site',
  'Something else',
] as const

const digitsOnly = (value: string) => value.replace(/\D/g, '')

// Two days of slack, deliberately. The visitor's clock and the server's clock
// are in different timezones and we would rather accept a stale date than
// reject somebody booking today.
const PAST_SLACK_MS = 48 * 60 * 60 * 1000

const isUpcoming = (value: string) => {
  const time = Date.parse(`${value}T00:00:00Z`)
  return Number.isFinite(time) && time >= Date.now() - PAST_SLACK_MS
}

export const inquirySchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Tell us who to ask for.')
    .max(80, 'That is longer than a name needs to be. Shorten it.'),
  phone: z
    .string()
    .trim()
    .max(30, 'That is longer than a phone number. Check it.')
    .refine(
      (value) => digitsOnly(value).length >= 10,
      'We need all ten digits so we can call you back.',
    ),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Pick the date you have in mind.')
    .refine(isUpcoming, 'That date has already gone by. Pick one from today on.'),
  headcount: z
    .string()
    .regex(/^\d{1,4}$/, 'A whole number of people, digits only.')
    .refine((value) => Number(value) >= 1, 'At least one person, we assume.'),
  occasion: z
    .string()
    .refine(
      (value) => (OCCASIONS as readonly string[]).includes(value),
      'Pick the closest occasion.',
    ),
  message: z
    .string()
    .trim()
    .max(2000, 'Keep this under 2000 characters and we will get the rest on the phone.')
    .optional(),
  // Honeypot. Real people never see or tab into this, so anything in it is a
  // bot. Named so no browser autofill heuristic matches it (a field named
  // "company" gets filled by Chrome's address autofill, which would flag real
  // customers as bots). Kept loose on purpose: the API route checks it before
  // validation and answers 200 so the bot learns nothing from the response.
  hp_referrer: z.string().optional(),
})

export type InquiryInput = z.infer<typeof inquirySchema>
