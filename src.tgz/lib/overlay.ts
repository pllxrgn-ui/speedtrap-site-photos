// THE OVERLAY BOUNDARY (build/08 §0 fork C, veto 4). What the admin can
// put on the page: three specials, an 86 mark per dish, one note. Under
// the build/09 owner's-word regime the MENU itself is edited through
// /api/admin/menu (MenuEvent ledger per change); the overlay stays the
// ephemeral layer ON TOP of it. Special.priceLabel remains TEXT and stays
// out of the Menu JSON-LD offers.

import { cacheLife, cacheTag } from 'next/cache'
import { getDb } from '@/lib/db'
import { HOLD_LABELS } from '@/lib/overlay-shared'

export interface OverlaySpecial {
  slot: number
  title: string
  body: string | null
  priceLabel: string | null // a LABEL. Never parsed, never a number.
  publishedAt: string // ISO — drives the freshness stamp
  photo: OverlayPhoto | null // owner-uploaded shot (addendum 2)
}

export interface OverlayPhoto {
  src: string
  alt: string
}

export interface Overlay {
  specials: OverlaySpecial[]
  soldOut: Record<string, string> // menuKey -> hold label for the mark
  photos: Record<string, OverlayPhoto> // menuKey -> owner-uploaded dish shot
  note: string | null
}

export const EMPTY_OVERLAY: Overlay = { specials: [], soldOut: {}, photos: {}, note: null }

/** The same absence, for the request where the database was configured and
 *  the query THREW. Deep-equal to EMPTY_OVERLAY — the page looks the same,
 *  which is the point of absence-over-failure — but a DIFFERENT OBJECT, so a
 *  call site can tell "no database in this build" (stable, cached) from "the
 *  database did not answer" (a failure, never cached). build/13 §0.2. */
export const OVERLAY_UNREACHABLE: Overlay = { specials: [], soldOut: {}, photos: {}, note: null }

// 'use cache' + cacheTag('overlay'): the one-pager stays cached (veto 7 —
// the 1.02s LCP is composition, not luck) and every admin publish calls
// revalidateTag('overlay','max') so the VERY NEXT request recomputes
// (as-built amendment to veto 6: updateTag is Server-Action-only here). cacheLife keeps
// a 15-minute revalidate underneath, so time-based expiries (an 86 that
// ends tonight) surface even if nobody touches the board again.
//
// A DATABASE FAILURE IS NOT A CACHED ANSWER (build/12 item 2 S detector,
// build/13 §0.2 commit 0). The read is TWO functions: the shell below caches
// the no-DATABASE_URL answer, which is stable and true for the life of the
// deployment, and has NO try/catch — a thrown query rejects out of it and is
// caught by the uncached wrapper, so one cold Neon start degrades one request
// instead of being baked into a cache entry. lib/menu-data.ts's header
// carries the as-built note on how 16.3.5 treats a rejected promise.
async function readOverlayCached(): Promise<Overlay> {
  'use cache'
  cacheTag('overlay')
  cacheLife({ stale: 300, revalidate: 900, expire: 86_400 })

  // A build or preview without a database renders the printed menu alone —
  // absence over failure, same regime as every optional surface.
  if (!process.env.DATABASE_URL) return EMPTY_OVERLAY

  const db = getDb()
  const now = new Date()
  const [specials, states, note, dishPhotos] = await Promise.all([
    db.special.findMany({
      where: {
        published: true,
        startsOn: { lte: now },
        OR: [{ endsOn: null }, { endsOn: { gte: now } }],
      },
      orderBy: { id: 'asc' },
    }),
    db.itemState.findMany({ where: { soldOut: true } }),
    db.siteNote.findUnique({ where: { id: 1 } }),
    db.dishPhoto.findMany(),
  ])

  // Owner-uploaded shots (their own media — permission inherent).
  // build/09: keys are MenuDish ids; deleting a dish cascades its photo
  // away in the same transaction, so no orphan filter is needed — a
  // stray row simply never matches a rendered dish.
  const photos: Record<string, OverlayPhoto> = {}
  for (const photo of dishPhotos) {
    photos[photo.itemKey] = { src: photo.url, alt: photo.alt }
  }

  const soldOut: Record<string, string> = {}
  for (const state of states) {
    // Expired holds never reach the page — the customer never sees a
    // stale 86 (§2 row 16). Key existence is the render join's problem.
    if (state.expiresAt && state.expiresAt.getTime() <= now.getTime()) continue
    soldOut[state.itemKey] = HOLD_LABELS[state.hold]
  }

  return {
    specials: specials
      .filter((special) => special.publishedAt !== null)
      .map((special) => ({
        slot: special.id,
        title: special.title,
        body: special.body,
        priceLabel: special.priceLabel,
        publishedAt: (special.publishedAt as Date).toISOString(),
        photo: special.photoUrl
          ? { src: special.photoUrl, alt: special.photoAlt ?? special.title }
          : null,
      })),
    soldOut,
    photos,
    note:
      note?.published && note.body && (!note.expiresAt || note.expiresAt > now)
        ? note.body
        : null,
  }
}

export async function readOverlay(): Promise<Overlay> {
  try {
    return await readOverlayCached()
  } catch {
    // A cold or absent database must never take the menu down with it — and
    // must not become a cache entry either. This catch is OUTSIDE the shell.
    return OVERLAY_UNREACHABLE
  }
}
