// THE OVERLAY BOUNDARY (build/08 §0 fork C, veto 4). What the admin can
// put on the page: three specials, an 86 mark per dish, one note. What it
// can NEVER put on the page: a board price. Special.priceLabel is TEXT and
// stays out of the Menu JSON-LD offers; lib/menu.ts remains code-truth for
// every number, and MENU_VERIFIED === true (a commit by Pol, veto 5) is
// the only gate that ever opens fuller menu CRUD.

import { cacheLife, cacheTag } from 'next/cache'
import { getDb } from '@/lib/db'
import { MENU_KEY_SET } from '@/lib/menu-keys'
import { HOLD_LABELS } from '@/lib/overlay-shared'

export interface OverlaySpecial {
  slot: number
  title: string
  body: string | null
  priceLabel: string | null // a LABEL. Never parsed, never a number.
  publishedAt: string // ISO — drives the freshness stamp
}

export interface OverlayPhoto {
  src: string
  alt: string
}

export interface Overlay {
  specials: OverlaySpecial[]
  soldOut: Record<string, string> // menuKey -> hold label for the mark
  photos: Record<string, OverlayPhoto> // menuKey -> owner-uploaded dish shot
  note: string | null
}

export const EMPTY_OVERLAY: Overlay = { specials: [], soldOut: {}, photos: {}, note: null }

// 'use cache' + cacheTag('overlay'): the one-pager stays cached (veto 7 —
// the 1.02s LCP is composition, not luck) and every admin publish calls
// revalidateTag('overlay','max') so the VERY NEXT request recomputes
// (as-built amendment to veto 6: updateTag is Server-Action-only here). cacheLife keeps
// a 15-minute revalidate underneath, so time-based expiries (an 86 that
// ends tonight) surface even if nobody touches the board again.
export async function readOverlay(): Promise<Overlay> {
  'use cache'
  cacheTag('overlay')
  cacheLife({ stale: 300, revalidate: 900, expire: 86_400 })

  // A build or preview without a database renders the printed menu alone —
  // absence over failure, same regime as every optional surface.
  if (!process.env.DATABASE_URL) return EMPTY_OVERLAY

  try {
    const db = getDb()
    const now = new Date()
    const [specials, states, note, dishPhotos] = await Promise.all([
      db.special.findMany({
        where: {
          published: true,
          startsOn: { lte: now },
          OR: [{ endsOn: null }, { endsOn: { gte: now } }],
        },
        orderBy: { id: 'asc' },
      }),
      db.itemState.findMany({ where: { soldOut: true } }),
      db.siteNote.findUnique({ where: { id: 1 } }),
      db.dishPhoto.findMany(),
    ])

    // Owner-uploaded shots (their own media — permission inherent). An
    // orphaned photo row is ignored exactly like an orphaned 86 mark.
    const photos: Record<string, OverlayPhoto> = {}
    for (const photo of dishPhotos) {
      if (!MENU_KEY_SET.has(photo.itemKey)) continue
      photos[photo.itemKey] = { src: photo.url, alt: photo.alt }
    }

    const soldOut: Record<string, string> = {}
    for (const state of states) {
      // Expired holds and orphaned keys never reach the page — the admin
      // surfaces them, the customer never sees a stale 86 (§2 row 16).
      if (state.expiresAt && state.expiresAt.getTime() <= now.getTime()) continue
      if (!MENU_KEY_SET.has(state.itemKey)) continue
      soldOut[state.itemKey] = HOLD_LABELS[state.hold]
    }

    return {
      specials: specials
        .filter((special) => special.publishedAt !== null)
        .map((special) => ({
          slot: special.id,
          title: special.title,
          body: special.body,
          priceLabel: special.priceLabel,
          publishedAt: (special.publishedAt as Date).toISOString(),
        })),
      soldOut,
      photos,
      note:
        note?.published && note.body && (!note.expiresAt || note.expiresAt > now)
          ? note.body
          : null,
    }
  } catch {
    // A cold or absent database must never take the menu down with it.
    return EMPTY_OVERLAY
  }
}
