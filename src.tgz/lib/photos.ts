// Gallery photo data.
//
// This ships EMPTY on purpose. The owner shoot has not happened yet and stock
// photography is banned for the life of this project (build/00-spec.md, and
// build/03-design-direction.md §1.6 rule 6: a missing photo slot ships as a
// flat color field, never as someone else's picture). The grid and the
// lightbox below are real and finished: drop entries into PHOTOS and the page
// switches from the empty state to the grid with no other change.

export type Photo = {
  src: string
  alt: string
  ratio: '3:2' | '4:5' | '1:1' | '16:9'
  category: 'seating' | 'bar' | 'private-room' | 'food' | 'events' | 'exterior'
  /** CSS object-position, tuned per image so a bad crop cannot break the grid. */
  objectPosition?: string
}

/**
 * All files are WebP under /public/photos. See build/03 §1.6 rule 8 for the
 * shot list. Provenance, one of two manifests per entry:
 * - assets/owner-social/MANIFEST.md: posted by the business itself, reuse
 *   authorized verbally by the client 2026-09-13.
 * - assets/third-party/MANIFEST.md: the two exterior shots, taken by a
 *   personal contact of the client side who gave permission (relayed by Pol
 *   2026-09-14).
 * LAUNCH GATE: written confirmation of BOTH permissions is still pending
 * (CLIENT-QUESTIONS, Photos section). Anonymous reviewer photos remain
 * off-limits: the owner cannot license a stranger's photographs, and only
 * the photographer's own permission (as above) unlocks one.
 *
 * Still missing (no public frame exists, owner shoot pending): seating and
 * the private room.
 */
export const PHOTOS: Photo[] = [
  {
    src: '/photos/storefront-corner.webp',
    alt: 'The front of the building on Broadway: brick two-story, live music mural, flower baskets over the sidewalk.',
    ratio: '1:1',
    category: 'exterior',
  },
  // sign-over-broadway.webp PULLED 2026-09-14: the Yelp upload is credited
  // "Jeff R.", not the photographer whose permission we hold (Katie Garrett).
  // It returns if and when Jeff R.'s own written OK exists. File stays in the
  // assets repo, unused.
  {
    src: '/photos/bar-logo-wall.webp',
    alt: 'The Speed Trap logo painted on the wall above the bar, a police lightbar on the counter.',
    ratio: '4:5',
    category: 'bar',
  },
  {
    src: '/photos/bar-full-house.webp',
    alt: 'The long bar on a full night, staff pouring behind it.',
    ratio: '1:1',
    category: 'bar',
  },
  {
    src: '/photos/cheeseburgers-pass.webp',
    alt: 'Six open-faced cheeseburgers lined up on the kitchen pass.',
    ratio: '1:1',
    category: 'food',
  },
  {
    src: '/photos/chili-crockpot.webp',
    alt: 'A crockpot of chili set up on the bar.',
    ratio: '1:1',
    category: 'food',
  },
  {
    src: '/photos/street-band-daylight.webp',
    alt: 'A band playing under canopies on the street outside.',
    ratio: '1:1',
    category: 'events',
  },
  {
    src: '/photos/broadway-out-front.webp',
    alt: 'Broadway Avenue out front, a police cruiser rolling past.',
    ratio: '1:1',
    category: 'exterior',
  },
]

// Seating is FIRST, permanently. The loudest documented gap in the Google
// reviews is that no photo of the seating exists anywhere online (research/01).
export const CATEGORY_ORDER: readonly Photo['category'][] = [
  'seating',
  'bar',
  'private-room',
  'food',
  'events',
  'exterior',
]

export const CATEGORY_LABEL: Record<Photo['category'], string> = {
  seating: 'Booths and seating',
  bar: 'The bar',
  'private-room': 'The private room',
  food: 'Food',
  events: 'Live nights',
  exterior: 'Out front on Highway 2',
}

// Fixed containers, always (build/03 §1.6 rule 2). Literal strings so the
// Tailwind v4 source scanner can see them.
export const RATIO_CLASS: Record<Photo['ratio'], string> = {
  '3:2': 'aspect-[3/2]',
  '4:5': 'aspect-[4/5]',
  '1:1': 'aspect-square',
  '16:9': 'aspect-video',
}
