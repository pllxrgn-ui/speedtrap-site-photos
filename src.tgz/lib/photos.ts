// Gallery photo data.
//
// This ships EMPTY on purpose. The owner shoot has not happened yet and stock
// photography is banned for the life of this project (build/00-spec.md, and
// build/03-design-direction.md §1.6 rule 6: a missing photo slot ships as a
// flat color field, never as someone else's picture). The grid and the
// lightbox below are real and finished: drop entries into PHOTOS and the page
// switches from the empty state to the grid with no other change.

export type Photo = {
  src: string
  alt: string
  ratio: '3:2' | '4:5' | '1:1' | '16:9'
  category: 'seating' | 'bar' | 'private-room' | 'food' | 'events' | 'exterior'
  /** CSS object-position, tuned per image so a bad crop cannot break the grid. */
  objectPosition?: string
}

/**
 * All files are WebP under /public/photos. See build/03 §1.6 rule 8 for the
 * shot list. Provenance: every entry below is a photo the business itself
 * posted on its own Facebook or Instagram (assets/owner-social/MANIFEST.md),
 * reuse authorized verbally by the client 2026-09-13. LAUNCH GATE: written
 * confirmation of that permission is still pending (CLIENT-QUESTIONS #15).
 * Reviewer photos from Google/Yelp/TripAdvisor are never used: the owner
 * cannot license other people's photographs.
 *
 * Still missing (no public frame exists, owner shoot pending): seating,
 * private-room, and an exterior that actually shows the building.
 */
export const PHOTOS: Photo[] = [
  {
    src: '/photos/bar-logo-wall.webp',
    alt: 'The Speed Trap logo painted on the wall above the bar, a police lightbar on the counter.',
    ratio: '4:5',
    category: 'bar',
  },
  {
    src: '/photos/bar-full-house.webp',
    alt: 'The long bar on a full night, staff pouring behind it.',
    ratio: '1:1',
    category: 'bar',
  },
  {
    src: '/photos/cheeseburgers-pass.webp',
    alt: 'Six open-faced cheeseburgers lined up on the kitchen pass.',
    ratio: '1:1',
    category: 'food',
  },
  {
    src: '/photos/chili-crockpot.webp',
    alt: 'A crockpot of chili set up on the bar.',
    ratio: '1:1',
    category: 'food',
  },
  {
    src: '/photos/street-band-daylight.webp',
    alt: 'A band playing under canopies on the street outside.',
    ratio: '1:1',
    category: 'events',
  },
  {
    src: '/photos/broadway-out-front.webp',
    alt: 'Broadway Avenue out front, a police cruiser rolling past.',
    ratio: '1:1',
    category: 'exterior',
  },
]

// Seating is FIRST, permanently. The loudest documented gap in the Google
// reviews is that no photo of the seating exists anywhere online (research/01).
export const CATEGORY_ORDER: readonly Photo['category'][] = [
  'seating',
  'bar',
  'private-room',
  'food',
  'events',
  'exterior',
]

export const CATEGORY_LABEL: Record<Photo['category'], string> = {
  seating: 'Booths and seating',
  bar: 'The bar',
  'private-room': 'The private room',
  food: 'Food',
  events: 'Live nights',
  exterior: 'Out front on Highway 2',
}

// Fixed containers, always (build/03 §1.6 rule 2). Literal strings so the
// Tailwind v4 source scanner can see them.
export const RATIO_CLASS: Record<Photo['ratio'], string> = {
  '3:2': 'aspect-[3/2]',
  '4:5': 'aspect-[4/5]',
  '1:1': 'aspect-square',
  '16:9': 'aspect-video',
}
