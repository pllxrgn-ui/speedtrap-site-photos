// Single source of truth for business facts. Every value here traces to
// research/ or an owner answer — see build/02-content-plan.md for provenance.
// Values awaiting the owner are typed so the UI must handle their absence;
// the release gate greps for PLACEHOLDER before anything ships.

export type WeeklyHours = Record<
  'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun',
  { open: string; close: string } | null
>

export const SITE = {
  // PLACEHOLDER: brand spelling pending owner (state trade name: "SPEEDTRAP TAPHOUSE")
  name: 'Speed Trap Tap House',
  phone: '+15095309997', // verified: consistent across all sources (research/01 §2)
  phoneDisplay: '(509) 530-9997',
  // PLACEHOLDER: E vs W Broadway unresolved (research/03 §A2) — do not render
  // a street address until the owner confirms; geo is verified.
  address: null as null | { street: string; city: string; state: string; zip: string },
  geo: { lat: 47.6693168, lng: -117.8802055 }, // research/01 §2
  hours: {
    // Boolean, not literal: flips to true the day the owner confirms.
    verified: false as boolean,
    // Stays null until the owner confirms; UI renders "Call to confirm hours".
    weekly: null as WeeklyHours | null,
  },
  social: {
    facebook: 'https://www.facebook.com/speedtraptaphouse',
    instagram: 'https://www.instagram.com/reardanspeedtrap',
  },
  rating: { value: 4.4, count: 101, source: 'Google', asOf: '2026-09-13' }, // research/03 §B1
} as const
