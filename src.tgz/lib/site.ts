// Single source of truth for business facts. Every value here traces to
// research/ or an owner answer — see build/02-content-plan.md for provenance.
// Values awaiting the owner are typed so the UI must handle their absence;
// the release gate greps for PLACEHOLDER before anything ships.
//
// HOURS ARE NOT HERE (build/13, 2026-09-23). They are HoursDay /
// HoursException rows the owner enters in /admin, read through
// lib/hours-data.ts. Nothing in this file may ever carry a clock time:
// "no guessed hours in UI or schema" is a release blocker, and
// scripts/check-no-seeded-hours.mjs enforces BOTH halves mechanically.
// The old `hours: { verified, weekly }` field was DELETED rather than
// nulled - a dead field is an invitation to re-derive hours from it.

export const SITE = {
  // PLACEHOLDER: brand spelling pending owner (state trade name: "SPEEDTRAP TAPHOUSE")
  name: 'Speed Trap Tap House',
  phone: '+15095309997', // verified: consistent across all sources (research/01 §2)
  phoneDisplay: '(509) 530-9997',
  // PLACEHOLDER: E vs W Broadway unresolved (research/03 §A2) — do not render
  // a street address until the owner confirms; geo is verified.
  address: null as null | { street: string; city: string; state: string; zip: string },
  geo: { lat: 47.6693168, lng: -117.8802055 }, // research/01 §2
  social: {
    facebook: 'https://www.facebook.com/speedtraptaphouse',
    instagram: 'https://www.instagram.com/reardanspeedtrap',
  },
  rating: { value: 4.4, count: 101, source: 'Google', asOf: '2026-09-13' }, // research/03 §B1
} as const
