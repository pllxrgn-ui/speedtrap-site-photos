import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient }

// Lazy on purpose: `next build` evaluates route modules to collect config,
// and the client constructor resolves DATABASE_URL — a module-scope client
// would make every build require a database. Nothing may call this until a
// request-path guard has checked the env (build/08 §2 row 11). The global
// stash keeps dev hot-reload from leaking a pool per reload against Neon's
// free-tier connection cap.
export function getDb(): PrismaClient {
  if (!globalForPrisma.prisma) {
    globalForPrisma.prisma = new PrismaClient()
  }
  return globalForPrisma.prisma
}
