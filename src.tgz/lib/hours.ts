// THE HOURS, the pure half (build/13). Day order, the service day, the
// precedence rule, the formatters, the zod schemas and the read shape — no
// database import, no React, no Next. Everything here is a function of its
// arguments, which is why the boundary cases that cost a customer a 22-mile
// drive can be pinned in lib/hours.test.ts instead of hoped for.
//
// THIS FILE HOLDS NO HOURS. It holds the machinery for hours the OWNER
// types. There is no SEED_HOURS constant here and there never will be —
// "no guessed hours in UI or schema" is a release blocker, and
// scripts/check-no-seeded-hours.mjs enforces both halves mechanically. The
// TIME and BAR_DAY patterns below are regex literals, not quoted clock
// strings, so they would not trip that gate even if this file were not
// already on its exclusion list.

import { z } from 'zod'
import { barToday } from '@/lib/provenance'

// ---------------------------------------------------------------------------
// DAY ORDER
// ---------------------------------------------------------------------------

// ORDER LIVES HERE, NOWHERE ELSE. HoursDay.day is a String @id, so
// findMany() hands back fri,mon,sat,sun,thu,tue,wed — nothing in Postgres
// knows Monday comes first. This repo has already been bitten by the class
// (menu-data.ts:30-31, "a sortIndex tie must never flip board order between
// renders"). isPublishable, the view builder, the JSON-LD emitter and the
// week editor all map over DAY_ORDER and look rows up by key.
export const DAY_ORDER = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'] as const

export type DayId = (typeof DAY_ORDER)[number]

const DAY_NAMES: Record<DayId, string> = {
  mon: 'Monday',
  tue: 'Tuesday',
  wed: 'Wednesday',
  thu: 'Thursday',
  fri: 'Friday',
  sat: 'Saturday',
  sun: 'Sunday',
}

export function dayName(day: DayId): string {
  return DAY_NAMES[day]
}

// ---------------------------------------------------------------------------
// ROW SHAPES
//
// Structural, not imported from @prisma/client: this module stays free of
// the database in every sense, and a Prisma row assigns to these anyway.
// ---------------------------------------------------------------------------

export interface HoursDayRow {
  day: string
  closed: boolean
  open: string | null
  close: string | null
}

/** The date half of a dated row. EVERYTHING that reasons about WHEN a row
 *  applies takes this shape: a Prisma row, an unsaved draft and a parsed API
 *  body all assign to it.
 *
 *  `endDate` is optional AND nullable on purpose. A request body omits it, a
 *  database row carries null, and the two must never answer differently —
 *  they did before this was consolidated (review round 1, finding 6): the
 *  read side compared `endDate === null` and called an omitted end a RANGE,
 *  while the write side compared spanEnd() and called it a single date. One
 *  spelling, below, and nothing re-derives it. */
export interface ExceptionSpan {
  date: string
  endDate?: string | null
}

export interface ExceptionRow extends ExceptionSpan {
  endDate: string | null
  closed: boolean
  open: string | null
  close: string | null
  label: string | null
  /** The tiebreak in resolveException — load-bearing, not decoration. */
  createdAt: Date
}

/** A weekday as the editor and the PUT body see it. Absence of a row is
 *  UNSET, which is NOT closed: the editor ships empty and the page has to
 *  be able to say so. */
export type DayState =
  | { state: 'unset' }
  | { state: 'closed' }
  | { state: 'open'; open: string; close: string }

/** Read a database row (or its absence) as a DayState. */
export function dayStateOf(row: HoursDayRow | null | undefined): DayState {
  if (!row) return { state: 'unset' }
  if (row.closed || row.open === null || row.close === null) return { state: 'closed' }
  return { state: 'open', open: row.open, close: row.close }
}

// ---------------------------------------------------------------------------
// THE SERVICE DAY
// ---------------------------------------------------------------------------

/** How far past midnight the bar's day runs, in hours. */
const SERVICE_DAY_ROLL_HOURS = 4

// THE service day. A bar's day does not end at midnight; it ends when the
// door locks. 4am is safely past any "or later" close the door sign predicts
// (close = '01:00' is a supported state, see crossesMidnight) and safely
// before any open. EVERY exception filter and EVERY exception label goes
// through this, never through barToday() directly.
//
// Without it: at 00:20 on Saturday, with the bar physically open on FRIDAY's
// service, a Saturday closure would start rendering "TODAY / Closed" over an
// open bar, and Friday's "closing at 8" row would vanish mid-service.
//
// barToday() keeps its existing callers and its existing meaning. Nothing in
// this feature calls it for an exception.
export function barServiceDay(now: Date = new Date()): string {
  return barToday(new Date(now.getTime() - SERVICE_DAY_ROLL_HOURS * 60 * 60 * 1000))
}

// ---------------------------------------------------------------------------
// FORMATTERS
//
// SEPARATOR IS AN ASCII HYPHEN, NEVER AN EN OR EM DASH.
// scripts/check-no-placeholder.mjs bans both dashes in RENDERED output and
// scans the built .html/.rsc/.body files, so "11am – 10pm" would fail
// `pnpm gate`. Pinned by test, because the failure surfaces at build time in
// a different repo area than the edit that caused it.
// ---------------------------------------------------------------------------

/** "11:00" -> "11am", "22:00" -> "10pm", "20:30" -> "8:30pm", "00:00" -> "12am". */
export function formatTime(hhmm: string): string {
  const hour = Number(hhmm.slice(0, 2))
  const minute = hhmm.slice(3, 5)
  const suffix = hour < 12 ? 'am' : 'pm'
  const twelve = hour % 12 === 0 ? 12 : hour % 12
  return minute === '00' ? `${twelve}${suffix}` : `${twelve}:${minute}${suffix}`
}

/** The door sign reads "Fri-Sat 11-11 OR LATER", so a close at or before the
 *  open is the NEXT day, not a typo. A naive `close > open` validator would
 *  reject an owner typing 01:00 — which is the exact failure the sign
 *  predicts. This is also why the service day rolls at 4am. */
export function crossesMidnight(open: string, close: string): boolean {
  return close <= open
}

/** "11:00","22:00" -> "11am - 10pm" · "11:00","01:00" -> "11am - 1am". */
export function formatRange(open: string, close: string): string {
  return `${formatTime(open)} - ${formatTime(close)}`
}

/** A bar-day string as a public eyebrow: "2026-12-25" -> "Wed, Dec 25".
 *
 *  Named labelBarDay, not barDayLabel, on purpose: barDateLabel in
 *  lib/provenance.ts formats an INSTANT in America/Los_Angeles, and this
 *  formats a bar-day STRING in UTC. Opposite timezone semantics one
 *  character apart would be a trap in the module the repo calls its honesty
 *  machinery. UTC is correct here precisely because the string already IS
 *  the bar's day — re-interpreting it in Pacific would shift it back one. */
export function labelBarDay(date: string): string {
  return new Date(`${date}T00:00:00Z`).toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  })
}

/** A month-and-day label with no weekday: "2026-12-25" -> "Dec 25". Same UTC
 *  posture as labelBarDay, for the same reason. Three callers wanted this and
 *  two of them had written their own copy (review round 1, finding 6): the
 *  range eyebrow below, the station's overlap sentence, and the public
 *  "closed through Jan 2" line. */
export function shortBarDay(date: string): string {
  return new Date(`${date}T00:00:00Z`).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  })
}

/** A range eyebrow: "2026-12-24","2027-01-02" -> "Dec 24 - Jan 2". The
 *  weekday is dropped — over a span it tells the reader nothing. */
export function labelBarDayRange(date: string, endDate: string): string {
  return `${shortBarDay(date)} - ${shortBarDay(endDate)}`
}

/** What the ledger records for a weekday: "11am - 10pm" | "Closed" | null.
 *  Reuses the DISPLAY formatter on purpose, so the log says what the page
 *  said, in the same words. */
export function dayLedgerValue(value: DayState | HoursDayRow | null | undefined): string | null {
  const state = value && 'state' in value ? value : dayStateOf(value)
  if (state.state === 'unset') return null
  if (state.state === 'closed') return 'Closed'
  return formatRange(state.open, state.close)
}

// ---------------------------------------------------------------------------
// THE WEEKLY GATE
// ---------------------------------------------------------------------------

/** ALL SEVEN DAYS OR NONE. A customer who sees Mon-Thu listed and Fri-Sun
 *  missing reads the gap as CLOSED — which is a guess this project is under
 *  a release blocker not to make. Iterates DAY_ORDER rather than the query
 *  result, so a seven-row array missing one id and carrying a duplicate
 *  fails instead of passing on length. */
export function isPublishable(days: readonly HoursDayRow[]): boolean {
  const byDay = new Map(days.map((row) => [row.day, row]))
  return DAY_ORDER.every((day) => {
    const row = byDay.get(day)
    if (!row) return false
    return row.closed ? true : row.open !== null && row.close !== null
  })
}

// ---------------------------------------------------------------------------
// PRECEDENCE — exactly one exception wins per service day
// ---------------------------------------------------------------------------

/** Does this row cover that bar-day? String comparison throughout:
 *  lexicographic order on ISO dates IS chronological order, so no Date
 *  arithmetic, no DST, no server-locale exposure. */
export function covers(row: ExceptionSpan, day: string): boolean {
  return row.date <= day && day <= spanEnd(row)
}

/** Inclusive last day. A row with no endDate covers exactly its own date. */
export function spanEnd(row: ExceptionSpan): string {
  return row.endDate ?? row.date
}

/** THE ONE SPELLING of "is this a range", over spanEnd() so that null and
 *  undefined cannot disagree. Used by resolveException, by the public view
 *  builder's copy and by the write half's ledger subject and overlap
 *  sentence — four callers that must never drift, which is why they are not
 *  allowed to write `endDate === null` themselves. */
export function isSingleDate(row: ExceptionSpan): boolean {
  return spanEnd(row) === row.date
}

// The one place that decides which dated row is true for a day. Overlap is
// LEGAL DATA (the migration adds no uniqueness or exclusion constraint,
// because a UNIQUE(date) would reject the headline use case: "closed Dec 24
// to Jan 2" plus "Dec 25 closed - holiday"). Ambiguity is not legal, so:
//
//   A SINGLE-DATE ROW BEATS A RANGE. Someone who writes a date exactly is
//   correcting the block he drew around it, whatever order he typed them in.
//
//   AMONG EQUALS, THE NEWEST createdAt WINS. The only information left is
//   which one he typed last. createdAt rather than updatedAt, so editing an
//   old row's label cannot silently promote it over a newer one.
//
// Used by the public view builder, the JSON-LD gate's fixture and the admin
// list. Never re-derived at a call site.
export function resolveException(
  rows: readonly ExceptionRow[],
  day: string, // a barServiceDay() string, never a Date
): ExceptionRow | null {
  let winner: ExceptionRow | null = null
  for (const row of rows) {
    if (!covers(row, day)) continue
    if (winner === null) {
      winner = row
      continue
    }
    const rowSingle = isSingleDate(row)
    const winnerSingle = isSingleDate(winner)
    if (rowSingle !== winnerSingle) {
      if (rowSingle) winner = row
      continue
    }
    if (row.createdAt.getTime() > winner.createdAt.getTime()) winner = row
  }
  return winner
}

// ---------------------------------------------------------------------------
// THE READ SHAPE
// ---------------------------------------------------------------------------

/** The live-exceptions filter, in Prisma terms.
 *
 *  NOT `WHERE coalesce("endDate","date") >= :today` — Prisma cannot express
 *  that, and reaching for $queryRaw to get it would be the wrong instinct at
 *  this size. The @@index([date]) does not serve this OR especially well
 *  either; the table will hold tens of rows in its life, so the index is
 *  habit-conformance, not need. Stated here so the implementer does not go
 *  looking for a raw query.
 *
 *  NOT `as const` (review round 1, finding 7). Freezing it forced every
 *  caller to write `{ OR: [...liveExceptionsWhere(day).OR] }` to satisfy
 *  Prisma's mutable array, and a spread of ONE key silently drops any second
 *  key this function ever grows. Callers pass the object WHOLE. */
export function liveExceptionsWhere(day: string) {
  return { OR: [{ endDate: null, date: { gte: day } }, { endDate: { gte: day } }] }
}

// ---------------------------------------------------------------------------
// ZOD — the same rules the client pre-validates against and the server
// enforces, mirroring the CHECK constraints in the migration.
// ---------------------------------------------------------------------------

export const DAY_ID = z.enum(DAY_ORDER)
export const TIME = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'A time like 11:00 or 20:30.')
export const BAR_DAY = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'A date like 2026-12-25.')

export const dayStateSchema = z.discriminatedUnion('state', [
  z.object({ day: DAY_ID, state: z.literal('unset') }),
  z.object({ day: DAY_ID, state: z.literal('closed') }),
  z.object({ day: DAY_ID, state: z.literal('open'), open: TIME, close: TIME }),
])

export const weekSchema = z
  .object({ days: z.array(dayStateSchema).length(7) })
  .refine((week) => new Set(week.days.map((day) => day.day)).size === 7, 'one entry per day')

/** Closed all day with no times, or open with BOTH — the same tri-state the
 *  HoursDay_shape_check and HoursException_shape_check enforce in SQL. */
function hasLegalShape(value: {
  closed: boolean
  open?: string | null
  close?: string | null
}): boolean {
  return value.closed
    ? value.open == null && value.close == null
    : value.open != null && value.close != null
}

export const exceptionSchema = z
  .object({
    date: BAR_DAY,
    endDate: BAR_DAY.nullable().optional(),
    closed: z.boolean(),
    open: TIME.nullable().optional(),
    close: TIME.nullable().optional(),
    label: z.string().max(60).nullable().optional(),
  })
  .refine(hasLegalShape, 'Closed all day, or both times.')
  .refine(
    (value) => !value.endDate || value.endDate >= value.date,
    'The last day cannot be before the first.',
  )

export type WeekInput = z.infer<typeof weekSchema>
export type ExceptionInput = z.infer<typeof exceptionSchema>
