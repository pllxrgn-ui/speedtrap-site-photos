// ONE tested pure module drives the menu plate copy, the Menu JSON-LD
// description, the admin board's header and the specials' freshness stamp
// (build/08 §5 Phase 5) — four surfaces that must never drift apart,
// because provenance IS the product's honesty machinery.

export const BAR_TIME_ZONE = 'America/Los_Angeles' // Reardan's clock, not the server's

export function barToday(now: Date = new Date()): string {
  return now.toLocaleDateString('en-CA', { timeZone: BAR_TIME_ZONE })
}

export function menuProvenance(asOf: string | null) {
  return {
    // The public plate label (menu-section) — non-negotiable while asOf set.
    plateLabel: asOf
      ? `Prices from the ${asOf} menu.`
      : 'Prices at the bar while we finish this page.',
    // The Menu JSON-LD description (lib/jsonld.ts) — byte-for-byte what it
    // said before this module existed; jsonld.test.ts holds it still.
    jsonLdDescription: asOf ? `Prices as printed on the ${asOf} menu.` : null,
    // The admin board header, verbatim from build/08 §4 — the owner sees
    // WHY the board cannot touch a price.
    adminBoardLine: asOf
      ? `Prices come from the ${asOf} printed menu and cannot be changed here. To change a price, tick the sheet.`
      : 'Prices are not printed here yet. To publish prices, tick the sheet.',
  }
}

// The freshness stamp a published special carries ON THE PAGE. It ages
// honestly: the day it was published it says today; left up, it starts
// naming the weekday it came from instead of quietly lying.
export function specialProvenance(publishedAt: Date, now: Date = new Date()): string {
  if (barToday(publishedAt) === barToday(now)) return 'From the kitchen, today.'
  const weekday = publishedAt.toLocaleDateString('en-US', {
    weekday: 'long',
    timeZone: BAR_TIME_ZONE,
  })
  return `From the kitchen, ${weekday}.`
}
