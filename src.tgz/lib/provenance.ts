// ONE tested pure module drives the menu plate copy, the Menu JSON-LD
// description, the admin board's header and the specials' freshness stamp
// (build/08 §5 Phase 5) — four surfaces that must never drift apart,
// because provenance IS the product's honesty machinery.

export const BAR_TIME_ZONE = 'America/Los_Angeles' // Reardan's clock, not the server's

export function barToday(now: Date = new Date()): string {
  return now.toLocaleDateString('en-CA', { timeZone: BAR_TIME_ZONE })
}

export function barDateLabel(iso: string): string {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    timeZone: BAR_TIME_ZONE,
  })
}

// v2 (build/09 owner's-word regime): provenance went DYNAMIC. The menu is
// the database, every change is a MenuEvent ledger row, and the page
// discloses the freshest edit date instead of a frozen month. The seed
// fallback (updatedAt null) keeps the pre-regime wording.
export function menuProvenance(updatedAtIso: string | null) {
  const dateLabel = updatedAtIso ? barDateLabel(updatedAtIso) : null
  return {
    // The public plate label (menu-section). "Menu", not "Prices": the
    // date is MenuDish.updatedAt, which a reorder or a rename bumps too —
    // claiming "prices updated" on a reorder would be the exact kind of
    // quiet over-claim the provenance machinery exists to prevent
    // (addendum, 2026-09-22).
    plateLabel: dateLabel
      ? `Menu updated ${dateLabel}.`
      : 'Prices at the bar while we finish this page.',
    // The Menu JSON-LD description (lib/jsonld.ts) — same string on purpose.
    jsonLdDescription: dateLabel ? `Menu updated ${dateLabel}.` : null,
    // The admin board header: the owner reads what editing MEANS now.
    // Tray regime (addendum 3): edits wait for APPLY — "immediately"
    // would be a lie now, and the ledger got its own screen (addendum 4).
    adminBoardLine: dateLabel
      ? `This is the live menu. Tap a name, price or description to change it - edits wait in the tray until you apply them, and every applied change lands in the log. Last change ${dateLabel}.`
      : 'This is the live menu. Tap a name, price or description to change it - edits wait in the tray until you apply them, and every applied change lands in the log.',
  }
}

// The freshness stamp a published special carries ON THE PAGE. It ages
// honestly: the day it was published it says today; left up, it starts
// naming the weekday it came from instead of quietly lying.
export function specialProvenance(publishedAt: Date, now: Date = new Date()): string {
  if (barToday(publishedAt) === barToday(now)) return 'From the kitchen, today.'
  const weekday = publishedAt.toLocaleDateString('en-US', {
    weekday: 'long',
    timeZone: BAR_TIME_ZONE,
  })
  return `From the kitchen, ${weekday}.`
}
