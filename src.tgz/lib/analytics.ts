// Pageviews only (Pol's scope decision 2026-09-26: "is the site getting
// visits, and is it running" - no click, call or form tracking; the
// conversion counter and custom events were dropped the same day).
// Vercel Web Analytics is cookieless and runs from the site's own origin.
// The script path is NOT fixed: v2 takes it from the build-time env Vercel
// injects (NEXT_PUBLIC_VERCEL_OBSERVABILITY_CLIENT_CONFIG / _BASEPATH);
// /_vercel/insights/script.js is only the package's fallback. To check a
// deploy, read the <script src> out of the rendered DOM (it is injected
// after hydration, so not in view-source) per CLAUDE.md "To go live". It
// mounts in app/(site)/layout.tsx ONLY, so /admin is never tracked;
// scrubAnalyticsEvent below is the belt to that brace.

// Campaign tags are link metadata WE write (e.g. on the Google listing's
// website link), not visitor data, and they feed Vercel's utm dimensions.
// Every other query parameter — fbclid, anything a future form might put
// in a URL — is dropped, and so is the fragment.
const KEPT_PARAMS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term']

export function scrubAnalyticsEvent<E extends { url: string }>(event: E): E | null {
  let url: URL
  try {
    url = new URL(event.url)
  } catch {
    return null
  }
  if (url.pathname === '/admin' || url.pathname.startsWith('/admin/')) return null
  const kept = new URLSearchParams()
  for (const key of KEPT_PARAMS) {
    const value = url.searchParams.get(key)
    if (value !== null) kept.set(key, value)
  }
  url.search = kept.toString()
  url.hash = ''
  return { ...event, url: url.toString() }
}
