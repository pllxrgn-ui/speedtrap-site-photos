import type { Metadata } from 'next'
import {
  Car,
  CalendarCheck,
  ForkKnife,
  Phone,
  Wheelchair,
} from '@phosphor-icons/react/dist/ssr'
import { FaqAccordion } from '@/components/find-us/faq-accordion'
import { HoursBlock } from '@/components/find-us/hours-block'
import { MapBlock } from '@/components/find-us/map-block'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { VISIT_FACTS, type VisitFactId } from '@/lib/facts'
import { FAQS } from '@/lib/faq'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Find Us',
  description:
    'On Highway 2 in Reardan, Washington, 22 miles west of Spokane. Directions, parking, accessibility and the number to call for today’s hours.',
}

// No street address anywhere on this page. The state license record says 245 W
// Broadway and Yelp, TripAdvisor and the building history all say 245 E: an
// unresolved conflict and a release blocker (CLIENT-QUESTIONS #3). Location is
// communicated by corridor, by landmark and by the coordinates behind
// DIRECTIONS_HREF, all of which are verified.
//
// The fact copy itself lives in lib/facts.ts and is shared with the home teaser
// and the FAQ. Only the icon mapping is a view concern, so only it lives here.
const FACT_ICON: Record<VisitFactId, typeof Car> = {
  parking: Car,
  access: Wheelchair,
  dining: ForkKnife,
  reservations: CalendarCheck,
}

// FAQPage markup from the same source the page renders, so the two can never
// drift apart.
const faqJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQS.map((faq) => ({
    '@type': 'Question',
    name: faq.q,
    acceptedAnswer: { '@type': 'Answer', text: faq.a },
  })),
}

export default function FindUsPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <section className="border-b border-hairline">
        <Container className="py-12 md:py-20">
          <h1 className="text-h1 leading-[1.05] font-extrabold uppercase tracking-[-0.02em] text-balance">
            Find us
          </h1>
          <p className="mt-6 max-w-[62ch] text-lg leading-relaxed">
            On Highway 2 in Reardan, 22 miles west of Spokane. If you are headed for
            Davenport, Grand Coulee Dam or Lake Roosevelt, you drive right past the
            front door. We are on the highway itself, so you will see the sign before
            you are looking for it.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonA
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              variant="amber"
              size="lg"
            >
              Get directions
            </ButtonA>
            <ButtonA href={TEL_HREF} variant="ghost" size="lg">
              <Phone size={20} weight="bold" aria-hidden />
              Call {SITE.phoneDisplay}
            </ButtonA>
          </div>

          {/* The pinned map block below does the locating work (client
              direction 2026-09-14: the strip diagram is retired). */}
        </Container>
      </section>

      <section className="border-b border-hairline bg-surface">
        <Container className="py-12 md:py-20">
          <Reveal>
            <div className="grid gap-6 lg:grid-cols-2">
              <MapBlock />
              <HoursBlock />
            </div>
          </Reveal>
        </Container>
      </section>

      {/* The one inverted ink band on this page (build/03 §1.4): the phone
          number, which is the single most useful thing on it. Statement left,
          the number itself right at lg, so the band fills the container and the
          number reads as the answer to the sentence next to it. */}
      <section className="bg-ink text-paper">
        <Container className="py-16 md:py-28">
          <Reveal>
            <div className="grid gap-8 lg:grid-cols-12 lg:items-center lg:gap-12">
              <p className="text-h2 leading-[1.15] font-extrabold uppercase tracking-[-0.02em] text-balance lg:col-span-7">
                One number does all of it. Hours, a table for a big group, a takeout
                order, or whether the kitchen is still on.
              </p>
              <p className="lg:col-span-5 lg:justify-self-end">
                <a
                  href={TEL_HREF}
                  className="tap-feedback inline-flex min-h-12 items-center font-mono text-h1 leading-[1.1] font-bold tabular-nums tracking-tight"
                >
                  {SITE.phoneDisplay}
                </a>
              </p>
            </div>
          </Reveal>
        </Container>
      </section>

      <section className="border-b border-hairline">
        <Container className="py-12 md:py-20">
          <Reveal>
            <h2 className="text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
              Before you come
            </h2>
            <dl className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {VISIT_FACTS.map((fact) => {
                const Icon = FACT_ICON[fact.id]
                return (
                  <div key={fact.id}>
                    <dt className="text-xl font-bold">
                      <Icon size={32} weight="bold" aria-hidden className="block" />
                      <span className="mt-4 block">{fact.title}</span>
                    </dt>
                    <dd className="mt-2 max-w-[40ch] leading-relaxed text-ink-muted">
                      {fact.body}
                    </dd>
                  </div>
                )
              })}
            </dl>
          </Reveal>
        </Container>
      </section>

      <section className="border-b border-hairline bg-surface">
        <Container className="py-12 md:py-20">
          <Reveal>
            <div className="grid gap-8 lg:grid-cols-12 lg:gap-12">
              <div className="lg:col-span-4">
                <h2 className="text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
                  Questions we get
                </h2>
                <p className="mt-4 max-w-[40ch] leading-relaxed text-ink-muted">
                  If yours is not here, call and ask. Nobody here minds the phone.
                </p>
              </div>
              <div className="lg:col-span-8">
                <FaqAccordion items={FAQS} />
              </div>
            </div>
          </Reveal>
        </Container>
      </section>

      <section>
        <Container className="py-12 md:py-20">
          <Reveal>
            <h2 className="text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
              Find us elsewhere
            </h2>
            <p className="mt-4 max-w-[62ch] leading-relaxed text-ink-muted">
              Specials, live music and whatever is coming out of the kitchen this week
              land here first.
            </p>
            <div className="mt-6 flex flex-wrap gap-x-6">
              <a
                href={SITE.social.facebook}
                target="_blank"
                rel="noopener"
                className="inline-flex min-h-11 items-center font-bold uppercase underline underline-offset-4"
              >
                Facebook
              </a>
              <a
                href={SITE.social.instagram}
                target="_blank"
                rel="noopener"
                className="inline-flex min-h-11 items-center font-bold uppercase underline underline-offset-4"
              >
                Instagram
              </a>
            </div>
          </Reveal>
        </Container>
      </section>
    </>
  )
}
