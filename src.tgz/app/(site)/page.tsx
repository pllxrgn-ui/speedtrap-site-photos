import { CallBand } from '@/components/home/call-band'
import { CorridorBand } from '@/components/home/corridor-band'
import { LaneBand } from '@/components/home/lane-band'
import { NameHero } from '@/components/home/name-hero'
import { Numbers } from '@/components/home/numbers'
import { Voices } from '@/components/home/voices'
import { BookSection } from '@/components/page/book-section'
import { GallerySection } from '@/components/page/gallery-section'
import { MenuSection } from '@/components/page/menu-section'
import { PrivateSection } from '@/components/page/private-section'
import { RoomSection } from '@/components/page/room-section'
import { VisitSection } from '@/components/page/visit-section'
import { WeekSection } from '@/components/page/week-section'
import { faqJsonLd, menuJsonLd } from '@/lib/jsonld'

// ONE PAGE, NOTHING LOST (build/07). The whole site on one route: 13 blocks
// and the cap is SPENT (build/08 §3 ruled booking in as the thirteenth) -
// there is no fourteenth, and lib/anchors.test.ts trips if one appears.
// Every retired route 308s to its fragment (next.config.ts <-
// RETIRED_ROUTES). Menu + FAQPage JSON-LD live here; the Restaurant block
// stays in the layout.
//
// THE FILM (amendment 2026-09-14f, "Night Sign"): the page is shot at night -
// scene-night pins warm asphalt grounds in BOTH themes, with film grain - and
// the MENU alone is scene-paper: the physical menu in your hands under the
// bar light, floating on one ambient shadow. Scenes are materials, not
// themes; the corridor band's own baked-dark pin nests inside untouched.
export default function HomePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(menuJsonLd()) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd()) }}
      />
      <div className="scene-night grain">
        <NameHero />
        <LaneBand />
      </div>
      <div className="scene-paper paper-insert relative">
        <MenuSection />
      </div>
      <div className="scene-night grain">
        <WeekSection />
        <RoomSection />
        <CorridorBand />
        <VisitSection />
        <GallerySection />
        <Voices />
        <Numbers />
        <PrivateSection />
        <BookSection />
        <CallBand />
      </div>
    </>
  )
}
