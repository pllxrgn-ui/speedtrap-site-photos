import { CallBand } from '@/components/home/call-band'
import { CorridorBand } from '@/components/home/corridor-band'
import { LaneBand } from '@/components/home/lane-band'
import { NameHero } from '@/components/home/name-hero'
import { Numbers } from '@/components/home/numbers'
import { Voices } from '@/components/home/voices'
import { BookSection } from '@/components/page/book-section'
import { GallerySection } from '@/components/page/gallery-section'
import { MenuSection } from '@/components/page/menu-section'
import { PrivateSection } from '@/components/page/private-section'
import { RoomSection } from '@/components/page/room-section'
import { VisitSection } from '@/components/page/visit-section'
import { WeekSection } from '@/components/page/week-section'
import { faqJsonLd, menuJsonLd } from '@/lib/jsonld'
import { getMenu } from '@/lib/menu-data'

// ONE PAGE, NOTHING LOST (build/07). The whole site on one route: 13 blocks
// and the cap is SPENT (build/08 §3 ruled booking in as the thirteenth) -
// there is no fourteenth, and lib/anchors.test.ts trips if one appears.
// Every retired route 308s to its fragment (next.config.ts <-
// RETIRED_ROUTES). Menu + FAQPage JSON-LD live here; the Restaurant block
// stays in the layout.
//
// VISITOR-JOB ORDER (amendment 2026-09-23, build/07 "VISITOR-ORDER REORDER"):
// the block sequence is what a visitor needs in the order they need it -
// menu, this week, where/when, book, look inside, what people say, the
// numbers, THEN the building's story. THE ROOM (#about, ~4,200px, the
// second-longest block on the page) moved from position 5 to position 11:
// build/10's owner-lens finding was that the history sat ahead of hours,
// map, photos and reviews. CORRIDOR BAND rides directly before FIND US
// because "US-2, 22 mi west of Spokane" IS the location tease. Ids,
// redirects and JSON-LD are untouched - only the render order moved.
//
// THE FILM (amendment 2026-09-14f, "Night Sign"): the page is shot at night -
// scene-night pins warm asphalt grounds in BOTH themes, with film grain - and
// the MENU alone is scene-paper: the physical menu in your hands under the
// bar light, floating on one ambient shadow. Scenes are materials, not
// themes; the corridor band's own baked-dark pin nests inside untouched.
export default async function HomePage() {
  // The live menu (build/09): one read feeds the JSON-LD and the menu
  // section, cached under the overlay tag - an admin edit shows on the
  // very next request.
  const menu = await getMenu()
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(menuJsonLd(menu.categories, menu.updatedAt)) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd()) }}
      />
      <div className="scene-night grain">
        <NameHero />
        <LaneBand />
      </div>
      <div className="scene-paper paper-insert relative">
        <MenuSection menu={menu} />
      </div>
      <div className="scene-night grain">
        <WeekSection />
        <CorridorBand />
        <VisitSection />
        <BookSection />
        <GallerySection />
        <Voices />
        <Numbers />
        <RoomSection />
        <PrivateSection />
        <CallBand />
      </div>
    </>
  )
}
