import { Footer } from '@/components/site/footer'
import { Header } from '@/components/site/header'
import { StickyCallBar } from '@/components/site/sticky-call-bar'
import { restaurantJsonLd } from '@/lib/jsonld'

// The customer-facing chrome, exactly as the root layout carried it before
// /admin existed. Moved into this group so the back office can render bare
// (build/08 §4: the admin is the station, never the film's front of house).
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(restaurantJsonLd()) }}
      />
      {/* First focusable thing on every page. Hidden until focused, then an
          ink plate top-left, on the same system as every other control. */}
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:inline-flex focus:min-h-11 focus:items-center focus:rounded focus:bg-ink focus:px-4 focus:font-bold focus:uppercase focus:tracking-tight focus:text-paper"
      >
        Skip to content
      </a>
      <Header />
      <main id="main" tabIndex={-1}>
        {children}
      </main>
      <Footer />
      <StickyCallBar />
    </>
  )
}
