import { Footer } from '@/components/site/footer'
import { Header } from '@/components/site/header'
import { SiteAnalytics } from '@/components/site/site-analytics'
import { StickyCallBar } from '@/components/site/sticky-call-bar'

// The customer-facing chrome, exactly as the root layout carried it before
// /admin existed. Moved into this group so the back office can render bare
// (build/08 §4: the admin is the station, never the film's front of house).
//
// NO STRUCTURED DATA HERE ANY MORE (build/13 §3.2). The Restaurant block
// needs the owner's hours, this layout is synchronous and has no data, and
// emitting structured data from two files is how two files start disagreeing.
// All three blocks - Restaurant, Menu, FAQPage - are emitted by page.tsx,
// which already reads everything they need. The layout is chrome again.
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      {/* First focusable thing on every page. Hidden until focused, then an
          ink plate top-left, on the same system as every other control. */}
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:inline-flex focus:min-h-11 focus:items-center focus:rounded focus:bg-ink focus:px-4 focus:font-bold focus:uppercase focus:tracking-tight focus:text-paper"
      >
        Skip to content
      </a>
      <Header />
      <main id="main" tabIndex={-1}>
        {children}
      </main>
      <Footer />
      <StickyCallBar />
      {/* Public page only - /admin lives outside (site) and is never
          counted (lib/analytics.ts). */}
      <SiteAnalytics />
    </>
  )
}
