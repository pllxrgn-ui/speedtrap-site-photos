import type { CSSProperties } from 'react'
import type { Metadata } from 'next'
import Image from 'next/image'
import { Crew } from '@/components/about/crew'
import { Ledger, LedgerIndex } from '@/components/about/ledger'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { Odometer } from '@/components/ui/odometer'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'

export const metadata: Metadata = {
  title: 'About',
  description:
    'The Speed Trap Tap House sits in the early-1900s Stevenson Building on Highway 2 in Reardan, Washington. First a bank by local accounts, then a tavern and card room, then a bar and grill.',
}

// Same stagger-index helper as the home hero and the menu masthead.
const step = (index: number) => ({ '--stt-i': index }) as CSSProperties

export default function AboutPage() {
  return (
    <>
      {/* Masthead. No Reveal: LCP section, the c.1904 scan is priority and
          settles (transform only), everything else rises. */}
      <section className="border-b border-hairline py-12 md:py-16 lg:py-20">
        <Container className="lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
          <div className="lg:col-span-7">
            <p className="stt-rise font-mono text-sm font-bold uppercase tracking-wide tabular-nums text-ink-muted">
              The Stevenson Building &middot; Reardan, Washington &middot;{' '}
              <span className="tabular-nums">22</span> miles west of Spokane
            </p>
            {/* "Early 1900s", not a hard year: the h1 shared a grid row with a
                scan the archive dates "circa 1904", and the 1905 figure traces
                to a bar blog - two dates printed as fact about one wall is the
                kind of thing this site does not do (audit build/05 M8). */}
            <h1
              style={step(1)}
              className="stt-rise mt-4 text-display font-extrabold uppercase leading-[1.02] tracking-[-0.03em]"
            >
              Same building since the early{' '}
              <span className="font-mono tabular-nums">1900</span>s
            </h1>
            <p
              style={step(2)}
              className="stt-rise mt-6 max-w-[46ch] text-lg leading-relaxed text-ink-muted"
            >
              Local histories say Reardan&apos;s first bank opened in this room.
              It has carried a few different names since, and it is still the
              same room.
            </p>
          </div>

          <div style={step(1)} className="stt-settle mt-10 lg:col-span-5 lg:mt-0">
            <div className="img-frame relative aspect-[3/2] overflow-hidden rounded grayscale md:max-w-[34rem]">
              <Image
                src="/photos/stevenson-building-c1904.webp"
                alt="A crowd gathered in front of the Stevenson Building around 1904, signs for J.C. Driscoll General Merchandise on the facade."
                fill
                priority
                sizes="(min-width: 1024px) 455px, (min-width: 768px) 544px, 100vw"
                className="object-cover"
              />
            </div>
            {/* Identical designation to the ledger's Today row, different
                date: that matching label IS the then/now argument. */}
            <p className="mt-3 font-mono text-sm uppercase tracking-wide tabular-nums text-ink-muted">
              The same building &middot; Circa 1904 &middot; Reardan Memorial
              Library, via Washington Rural Heritage
            </p>
          </div>

          <div className="lg:col-span-12">
            <LedgerIndex />
          </div>
        </Container>
      </section>

      <Ledger />

      {/* Why the name: the one surface band. Statement left, story right,
          column 7 empty on purpose. All copy recomposed from the existing
          paragraph; no new claims. */}
      <section className="bg-surface py-16 md:py-20 lg:py-24">
        <Container>
          <div className="border-t-2 border-ink" />
          <Reveal className="pt-10 lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="lg:col-span-6">
              <p className="font-mono text-sm font-bold uppercase tracking-wide text-ink-muted">
                Why the name
              </p>
              <p className="mt-4 text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
                Highway <span className="font-mono tabular-nums">2</span> runs
                straight and open until it hits Reardan.
              </p>
              <div className="mt-6 border-t-2 border-ink pt-6">
                <p className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.03em]">
                  Then the limit drops.
                </p>
              </div>
            </div>
            <div className="mt-8 lg:col-span-5 lg:col-start-8 lg:mt-0 lg:self-end">
              <p className="max-w-[46ch] text-lg leading-relaxed">
                The town gets a reputation with drivers who notice that late.
                The name was sitting right there, so we took it.
              </p>
            </div>
          </Reveal>
        </Container>
      </section>

      {/* The page's one inverted ink band: the only About fact that is both
          verified and worth a band (Odessa Record, directly observed). The
          Odometer is aria-hidden, so the sr-only sentence carries the fact. */}
      <Reveal>
        <section className="bg-ink py-20 text-paper md:py-24 lg:py-28">
          <Container className="lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
            <p aria-hidden className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em] lg:col-span-7">
              In May <span className="font-mono tabular-nums">2026</span> the town
              held its Memorial Day observance in here, and{' '}
              <Odometer
                value="55"
                trigger="view"
                baseDelay={200}
                className="font-mono tabular-nums"
              />{' '}
              people packed in.
            </p>
            <p className="sr-only">
              In May 2026 the town held its Memorial Day observance in here, and
              55 people packed in.
            </p>
            <div className="mt-8 border-l-2 border-paper/40 pl-4 lg:col-span-4 lg:col-start-9 lg:mt-0 lg:pl-6">
              <p className="font-mono text-sm uppercase tracking-wide text-paper/70">Source</p>
              <p className="mt-1 font-bold">Odessa Record</p>
              <p className="font-mono text-sm tabular-nums text-paper/70">May 2026</p>
            </div>
          </Container>
        </section>
      </Reveal>

      {/* Renders nothing until the staff give named permission. See the file. */}
      <Crew />

      <section className="border-t border-hairline py-12 md:py-16 lg:py-20">
        <Container className="lg:grid lg:grid-cols-12 lg:items-center lg:gap-8">
          <div className="lg:col-span-6">
            <h2 className="text-h2 font-extrabold uppercase tracking-tight">Stop in</h2>
            <p className="mt-4 max-w-[46ch] text-ink-muted">
              We are on Highway <span className="font-mono tabular-nums">2</span>{' '}
              in the middle of Reardan. Call ahead if you are bringing a crowd.
            </p>
          </div>
          <div className="mt-8 flex flex-col gap-3 md:flex-row lg:col-span-5 lg:col-start-8 lg:mt-0 lg:flex-col">
            <ButtonA href={TEL_HREF} variant="amber" size="lg">
              Call us
            </ButtonA>
            <ButtonA
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              variant="ghost"
              size="lg"
            >
              Directions
            </ButtonA>
          </div>
        </Container>
      </section>
    </>
  )
}
