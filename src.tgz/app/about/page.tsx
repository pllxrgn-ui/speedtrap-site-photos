import type { Metadata } from 'next'
import { Crew } from '@/components/about/crew'
import { HistoryStrip } from '@/components/about/history-strip'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { DIRECTIONS_HREF, TEL_HREF } from '@/lib/links'

export const metadata: Metadata = {
  title: 'About',
  description:
    'The Speed Trap Tap House sits in the 1905 Stevenson Building on Highway 2 in Reardan, Washington. First a bank, then a tavern and card room, then a bar and grill.',
}

export default function AboutPage() {
  return (
    <>
      <section className="border-b border-hairline">
        <Container className="py-12 md:py-20">
          <h1 className="text-h1 font-extrabold uppercase tracking-tight">
            Same building since 1905
          </h1>
          <p className="mt-4 max-w-[62ch] text-ink-muted">
            Reardan&apos;s first bank opened in this room. It has carried a few
            different names since, and it is still the same room.
          </p>
        </Container>
      </section>

      <section className="border-b border-hairline">
        <Container className="py-16 md:py-28">
          <Reveal>
            <h2 className="text-h2 font-extrabold uppercase tracking-tight">
              The building
            </h2>
            <div className="mt-8">
              <HistoryStrip />
            </div>
          </Reveal>
        </Container>
      </section>

      <section className="border-b border-hairline bg-surface">
        <Container className="py-12 md:py-20">
          <Reveal>
            <h2 className="text-h2 font-extrabold uppercase tracking-tight">
              Why the name
            </h2>
            <p className="mt-4 max-w-[62ch]">
              Highway 2 runs straight and open until it hits Reardan, where the
              limit drops and the town gets a reputation with drivers who notice
              that late. The name was sitting right there, so we took it.
            </p>
          </Reveal>
        </Container>
      </section>

      {/* One inverted ink band per page (build/03 §1.4), carrying the page's
          strongest statement. This one is the only About fact that is both
          verified and worth a band: Odessa Record, directly observed. */}
      <section className="bg-ink text-paper">
        <Container className="py-16 md:py-28">
          <Reveal>
            <p className="max-w-[24ch] text-h2 font-extrabold uppercase tracking-tight">
              In May 2026 the town held its Memorial Day observance in here, and{' '}
              <span className="font-mono tabular-nums">55</span> people packed in.
            </p>
            <p className="mt-6 text-sm text-paper/70">Odessa Record, May 2026</p>
          </Reveal>
        </Container>
      </section>

      {/* Renders nothing until the staff give named permission. See the file. */}
      <Crew />

      <section className="border-t border-hairline">
        <Container className="py-12 md:py-20">
          <h2 className="text-h2 font-extrabold uppercase tracking-tight">Stop in</h2>
          <p className="mt-4 max-w-[62ch] text-ink-muted">
            We are on Highway 2 in the middle of Reardan, 22 miles west of
            Spokane. Call ahead if you are bringing a crowd.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonA href={TEL_HREF} variant="amber" size="lg">
              Call us
            </ButtonA>
            <ButtonA
              href={DIRECTIONS_HREF}
              target="_blank"
              rel="noopener"
              variant="ghost"
              size="lg"
            >
              Directions
            </ButtonA>
          </div>
        </Container>
      </section>
    </>
  )
}
