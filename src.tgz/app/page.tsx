import { CorridorBand } from '@/components/home/corridor-band'
import { EventsTeaser } from '@/components/home/events-teaser'
import { FindUsTeaser } from '@/components/home/find-us-teaser'
import { Hero } from '@/components/home/hero'
import { ReviewStrip } from '@/components/home/review-strip'
import { SignatureItems } from '@/components/home/signature-items'

// Surface rhythm (build/03 §1.4): paper, surface, paper, surface, the single
// inverted ink band, back to paper. Metadata comes from the root layout.
export default function HomePage() {
  return (
    <>
      <Hero />
      <SignatureItems />
      <ReviewStrip />
      <EventsTeaser />
      <CorridorBand />
      <FindUsTeaser />
    </>
  )
}
