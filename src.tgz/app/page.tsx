import { CallBand } from '@/components/home/call-band'
import { CorridorBand } from '@/components/home/corridor-band'
import { LaneBand } from '@/components/home/lane-band'
import { NameHero } from '@/components/home/name-hero'
import { Numbers } from '@/components/home/numbers'
import { Voices } from '@/components/home/voices'
import { GallerySection } from '@/components/page/gallery-section'
import { MenuSection } from '@/components/page/menu-section'
import { PrivateSection } from '@/components/page/private-section'
import { RoomSection } from '@/components/page/room-section'
import { VisitSection } from '@/components/page/visit-section'
import { WeekSection } from '@/components/page/week-section'
import { faqJsonLd, menuJsonLd } from '@/lib/jsonld'

// ONE PAGE, NOTHING LOST (build/07). The whole site on one route: 12 blocks,
// alternating grounds, exactly ONE inversion (the corridor band), block cap
// 13 - do not add a fourteenth. Every retired route 308s to its fragment
// (next.config.ts <- RETIRED_ROUTES). Menu + FAQPage JSON-LD live here; the
// Restaurant block stays in the layout.
export default function HomePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(menuJsonLd()) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd()) }}
      />
      <NameHero />
      <LaneBand />
      <MenuSection />
      <WeekSection />
      <RoomSection />
      <CorridorBand />
      <VisitSection />
      <GallerySection />
      <Voices />
      <Numbers />
      <PrivateSection />
      <CallBand />
    </>
  )
}
