import { CallBand } from '@/components/home/call-band'
import { CorridorBand } from '@/components/home/corridor-band'
import { Dishes } from '@/components/home/dishes'
import { EventsTeaser } from '@/components/home/events-teaser'
import { LaneBand } from '@/components/home/lane-band'
import { NameHero } from '@/components/home/name-hero'
import { Numbers } from '@/components/home/numbers'
import { TheRoom } from '@/components/home/the-room'
import { Voices } from '@/components/home/voices'

// THE ONE-PAGER (build/06, "Daylight signage cinema"). Surface rhythm:
// paper, surface, paper, surface, paper, the single inverted ink band,
// paper, surface, paper - alternating, exactly one inversion (build/03
// §1.4). Block count is CAPPED AT 10 (header/footer excluded); do not add
// an eleventh. Metadata comes from the root layout.
export default function HomePage() {
  return (
    <>
      <NameHero />
      <LaneBand />
      <TheRoom />
      <Dishes />
      <EventsTeaser />
      <CorridorBand />
      <Numbers />
      <Voices />
      <CallBand />
    </>
  )
}
