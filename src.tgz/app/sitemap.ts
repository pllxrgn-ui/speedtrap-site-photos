import type { MetadataRoute } from 'next'
import { BASE_URL } from '@/lib/base-url'

const ROUTES = [
  '',
  '/menu',
  '/events',
  '/gallery',
  '/about',
  '/private-room',
  '/find-us',
  '/reviews',
]

export default function sitemap(): MetadataRoute.Sitemap {
  return ROUTES.map((path) => ({
    url: `${BASE_URL}${path}`,
    changeFrequency: path === '/events' || path === '/menu' ? 'weekly' : 'monthly',
    priority: path === '' ? 1 : path === '/menu' ? 0.9 : 0.6,
  }))
}
