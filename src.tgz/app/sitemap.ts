import type { MetadataRoute } from 'next'
import { BASE_URL } from '@/lib/base-url'

// ONE PAGE (build/07): the sitemap is one entry. Weekly because the page now
// carries the menu and the weekly rhythm - the two things that used to make
// /menu and /events the weekly routes.
export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url: BASE_URL,
      changeFrequency: 'weekly',
      priority: 1,
    },
  ]
}
