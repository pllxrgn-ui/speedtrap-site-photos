import type { Metadata } from 'next'
import { GalleryEmpty } from '@/components/gallery/gallery-empty'
import { GalleryGrid } from '@/components/gallery/gallery-grid'
import { Container } from '@/components/site/container'
import { PHOTOS } from '@/lib/photos'

export const metadata: Metadata = {
  title: 'Gallery',
  description:
    'A look inside the Speed Trap Tap House on Highway 2 in Reardan, Washington. Booths, the bar, the private room and the food.',
}

export default function GalleryPage() {
  const hasPhotos = PHOTOS.length > 0

  return (
    <>
      <section className="border-b border-hairline">
        <Container className="py-12 md:py-20">
          <h1 className="text-h1 font-extrabold uppercase tracking-tight">
            Inside the Speed Trap
          </h1>
          <p className="mt-4 max-w-[62ch] text-ink-muted">
            {hasPhotos
              ? 'Shot in the building, not bought from a photo library. Tap any picture to see it bigger.'
              : 'One room on Highway 2 in Reardan, with booths, a bar and a private room.'}
          </p>
        </Container>
      </section>

      {hasPhotos ? <GalleryGrid /> : <GalleryEmpty />}
    </>
  )
}
