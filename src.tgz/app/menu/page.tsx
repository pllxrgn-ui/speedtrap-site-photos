import type { CSSProperties } from 'react'
import type { Metadata } from 'next'
import Image from 'next/image'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { CategoryNav } from '@/components/menu/category-nav'
import { BoardSection, MenuList, RailSection } from '@/components/menu/menu-category'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { menuJsonLd } from '@/lib/jsonld'
import { TEL_HREF } from '@/lib/links'
import { MENU, MENU_PRICES_AS_OF, type MenuCategory } from '@/lib/menu'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  // "Menu & Prices" restored 2026-09-14, the day lib/menu.ts got real prices
  // (build/04-seo-schema.md wanted exactly this).
  title: 'Menu & Prices',
  description:
    'The full menu with prices for Speed Trap Tap House in Reardan, Washington: burgers, dinners, sandwiches, baskets and a full bar. Specials change daily, so call ahead.',
}

// Same stagger-index helper the home hero uses (components/home/hero.tsx).
const step = (index: number) => ({ '--stt-i': index }) as CSSProperties

// Loud on purpose: the page places categories by id, so a rename in
// lib/menu.ts fails the build instead of silently dropping a section.
const pick = (id: string): MenuCategory => {
  const category = MENU.find((c) => c.id === id)
  if (!category) throw new Error(`Menu category missing: ${id}`)
  return category
}

const BURGERS = pick('burgers')
const DINNERS = pick('dinners')
const SANDWICHES = pick('sandwiches')
const APPETIZERS = pick('appetizers')
const BASKETS = pick('baskets')
const SALADS = pick('salads-sides')
const DRINKS = pick('drinks')

// The overture quotes the first sentence of the Burgers note at statement
// scale. Render-time split only, guarded: promote the sentence only when a
// remainder exists and it is short enough to hold one line of h1; otherwise
// the note renders whole in the rail and the overture copy is just the photo
// band. No authored copy either way.
const burgersSentences = (BURGERS.note ?? '').split(/(?<=\.)\s+/)
const OVERTURE =
  burgersSentences.length > 1 && burgersSentences[0].length < 60
    ? {
        lede: burgersSentences[0],
        rest: burgersSentences.slice(1).join(' '),
      }
    : null
const BURGERS_RAIL = OVERTURE ? { ...BURGERS, note: undefined } : BURGERS

// The empty-state sentence, kept when the tap list itself is the one thing
// this page cannot honestly print (build/03 §4 guardrail 5).
const DRINKS_STATEMENT = 'The tap list rotates. Ask what is pouring.'
// "Full bar:" leads the note in ink; the inventory after the colon is muted.
const [drinksLead, drinksRest] = (() => {
  const note = DRINKS.note ?? ''
  const at = note.indexOf(':')
  return at === -1 ? [note, ''] : [note.slice(0, at + 1), note.slice(at + 1)]
})()

export default function MenuPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(menuJsonLd()) }}
      />

      {/* Masthead. Home-hero choreography verbatim: rise for type, settle for
          the photo so it stays a full-strength LCP candidate from frame one. */}
      <section className="border-b border-hairline bg-surface py-10 md:py-16 lg:py-24">
        <Container className="lg:grid lg:grid-cols-12 lg:items-end lg:gap-8">
          <div className="lg:col-span-7">
            <h1 className="stt-rise text-display font-extrabold uppercase leading-[1.05] tracking-[-0.02em]">
              Menu
            </h1>
            <p
              style={step(1)}
              className="stt-rise mt-5 max-w-[38ch] text-lg leading-relaxed text-ink-muted"
            >
              Burgers, baskets, sandwiches and a full bar. The whole list, on one
              page, no download.
            </p>

            {/* Price provenance plate. The amber is a 2px left edge, the same
                amber edge .tick wipes on every row: page vocabulary, not a
                generic callout. Not a ButtonA: the ink band at the foot of the
                page owns this page's one amber fill. */}
            <div
              style={step(2)}
              className="stt-rise mt-8 max-w-[42ch] border-l-2 border-amber bg-paper py-4 pl-5 pr-4"
            >
              <p className="text-sm font-bold uppercase tracking-wide text-ink-muted">
                {MENU_PRICES_AS_OF
                  ? `Prices from the ${MENU_PRICES_AS_OF} menu.`
                  : 'Prices at the bar while we finish this page.'}
              </p>
              <a
                href={TEL_HREF}
                className="tick mt-2 inline-flex min-h-11 flex-wrap items-baseline gap-x-3 font-extrabold uppercase tracking-tight hover:text-amber-ink"
              >
                Call for today&apos;s specials
                <span className="font-mono text-h2 tabular-nums">{SITE.phoneDisplay}</span>
              </a>
            </div>
          </div>

          <div style={step(1)} className="stt-settle mt-10 lg:col-span-5 lg:mt-0">
            {/* People-free by rule: this is the page-top slot, and the two
                photos with identifiable faces (bar-logo-wall, and to a lesser
                degree bar-full-house) stay out of it, the same call that
                reshuffled the home hero. Food opens the menu. */}
            {/* md cap at 34rem: uncapped, this ran 720px+ wide through the
                whole tablet band, upscaling a 640px source (audit M4). */}
            <div className="img-frame relative aspect-[3/2] overflow-hidden rounded md:aspect-[4/5] md:max-w-[34rem]">
              <Image
                src="/photos/cheeseburgers-pass.webp"
                alt="Six open-faced cheeseburgers lined up on the kitchen pass."
                fill
                priority
                sizes="(min-width: 1024px) 455px, (min-width: 768px) 544px, 100vw"
                className="object-cover"
              />
            </div>
          </div>
        </Container>
      </section>

      <CategoryNav categories={MENU} />

      {/* Burgers overture: the note's first sentence at statement scale beside
          the burgers photo. One Reveal, one move, one band. Removing the note
          from the Burgers rail is what keeps that rail short. */}
      {OVERTURE ? (
        <section className="border-b border-hairline bg-surface">
          <Container className="py-10 md:py-12 lg:py-0">
            <Reveal className="lg:grid lg:grid-cols-12 lg:items-center lg:gap-8">
              {/* The full house is the statement's evidence: the room, mid
                  rush, exactly as the business posted it. Crowd scale, not a
                  portrait; the same shot already ships in the gallery. */}
              <div className="img-frame relative -mx-4 aspect-[4/3] overflow-hidden rounded md:mx-0 md:max-w-[34rem] lg:col-span-5 lg:-ml-8 lg:w-[calc(100%+2rem)]">
                <Image
                  src="/photos/bar-full-house.webp"
                  alt="The long bar on a full night, staff pouring behind it."
                  fill
                  loading="lazy"
                  sizes="(min-width: 1024px) 487px, (min-width: 768px) 544px, 100vw"
                  className="object-cover"
                />
              </div>
              <div className="mt-8 lg:col-span-6 lg:col-start-7 lg:mt-0 lg:py-16">
                <p className="text-balance text-h1 font-extrabold leading-[1.08] tracking-[-0.02em]">
                  {OVERTURE.lede}
                </p>
                <p className="mt-4 max-w-[42ch] text-lg leading-relaxed text-ink-muted">
                  {OVERTURE.rest}
                </p>
              </div>
            </Reveal>
          </Container>
        </section>
      ) : null}

      {/* Rails: prose categories, sticky head, two tracks. */}
      <RailSection category={BURGERS_RAIL} rows={5} rowsMd={5} lead />
      <RailSection category={DINNERS} rows={2} rowsMd={2} lead />
      <RailSection category={SANDWICHES} rows={4} rowsMd={4} lead />

      {/* Board band: the two tight list categories change the page's ground
          instead of repeating the rail a fourth and fifth time. Appetizers
          runs three tracks; Baskets runs two inside eight columns, and the
          third-track air is placed, not leftover. */}
      <section className="border-y border-hairline bg-surface py-14 md:py-16 lg:py-24">
        <Container className="space-y-14 lg:space-y-16">
          <BoardSection category={APPETIZERS} rows={3} rowsMd={5} />
          <div className="lg:grid lg:grid-cols-12 lg:gap-x-8">
            <div className="lg:col-span-8">
              <BoardSection category={BASKETS} rows={3} rowsMd={3} />
            </div>
          </div>
        </Container>
      </section>

      <RailSection category={SALADS} rows={5} rowsMd={5} />

      {/* Drinks & Taps spread: the one category at display scale, because the
          category whose list this page cannot honestly print gets room and a
          sign instead of an apology (the soft side, printed on the July 2026
          menu, is the list below). Ground returns to paper before the ink
          band. */}
      <section
        id={DRINKS.id}
        aria-labelledby={`${DRINKS.id}-title`}
        className="group scroll-mt-[calc(var(--header-h)+5rem)] py-16 lg:py-28"
      >
        <Container>
          <Reveal group className="lg:grid lg:grid-cols-12 lg:items-center lg:gap-8">
            <div className="lg:col-span-7">
              <h2
                id={`${DRINKS.id}-title`}
                className="text-balance text-display font-extrabold uppercase leading-[1.02] tracking-[-0.03em]"
              >
                {DRINKS.title}
              </h2>
              <div className="mt-8 border-t-2 border-ink pt-6 transition-colors duration-[var(--dur-state)] ease-[var(--ease-hover)] group-target:border-amber">
                <p className="max-w-[16ch] text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em]">
                  {DRINKS_STATEMENT}
                </p>
              </div>
              <p className="mt-6 max-w-[46ch] text-lg leading-relaxed">
                <span className="font-extrabold">{drinksLead}</span>
                <span className="text-ink-muted">{drinksRest}</span>
              </p>
              {DRINKS.items.length > 0 ? (
                <MenuList items={DRINKS.items} rows={3} rowsMd={3} className="mt-10" />
              ) : null}
            </div>

            <div className="mt-10 lg:col-span-5 lg:mt-0">
              {/* Its own alt text places it: "set up on the bar". This is the
                  bar-side photo that carries no faces. */}
              <div className="img-frame relative aspect-square overflow-hidden rounded md:max-w-[34rem]">
                <Image
                  src="/photos/chili-crockpot.webp"
                  alt="A crockpot of chili set up on the bar."
                  fill
                  loading="lazy"
                  sizes="(min-width: 1024px) 455px, (min-width: 768px) 544px, 100vw"
                  className="object-cover"
                />
              </div>
            </div>
          </Reveal>
        </Container>
      </section>

      {/* The one inverted ink band on this page (build/03 §1.4). Statement left,
          action right at lg so the band fills instead of stranding both in the
          left third of a 1200px container. */}
      <Reveal>
        <section className="bg-ink py-16 text-paper md:py-28">
          <Container className="grid gap-8 lg:grid-cols-12 lg:items-center lg:gap-12">
            <h2 className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em] lg:col-span-7">
              Not sure what is on today
            </h2>
            <div className="lg:col-span-5">
              <p className="max-w-[44ch] text-lg leading-relaxed">
                The kitchen runs specials that never make it onto a page this
                tidy. One call gets you the real answer.
              </p>
              <ButtonA href={TEL_HREF} variant="amber" size="lg" className="mt-6">
                <Phone size={18} weight="bold" aria-hidden />
                Call {SITE.phoneDisplay}
              </ButtonA>
            </div>
          </Container>
        </section>
      </Reveal>
    </>
  )
}
