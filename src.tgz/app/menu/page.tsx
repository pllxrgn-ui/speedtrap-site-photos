import type { Metadata } from 'next'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { CategoryNav } from '@/components/menu/category-nav'
import { MenuCategorySection } from '@/components/menu/menu-category'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { TEL_HREF } from '@/lib/links'
import { MENU } from '@/lib/menu'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  // Plain "Menu" until prices are real. build/04-seo-schema.md wants
  // "Menu & Prices"; restore it the day lib/menu.ts carries actual prices,
  // not before, because the page currently shows none.
  title: 'Menu',
  description:
    'Burgers, sandwiches, baskets and a full bar in Reardan, Washington. The food list is here. Prices are at the bar while we confirm them, so call ahead.',
}

// Only the drinks category ships empty: the tap list is not owner-confirmed and
// inventing drafts is a release blocker (build/03 §4 guardrail 5).
const EMPTY_NOTES: Record<string, string> = {
  drinks: 'The tap list rotates. Ask what is pouring.',
}

// Every price is null today, so every row has an empty right-hand column. A
// 768px row with 220px of content in it has no rhythm and reads as broken, so
// the list runs at a tighter measure until there is a price to hang on the
// right. It widens itself the day prices land, with no other change.
const HAS_PRICES = MENU.some((category) =>
  category.items.some((item) => item.price !== null),
)

export default function MenuPage() {
  return (
    <>
      <section className="py-12 md:py-20">
        <Container>
          <h1 className="text-h1 font-extrabold uppercase tracking-tight">Menu</h1>
          <p className="mt-4 max-w-[62ch] text-lg">
            Burgers, baskets, sandwiches and a full bar. The whole list, on one page, no
            download.
          </p>

          <p className="mt-6 max-w-[62ch] rounded border border-hairline bg-surface p-4">
            Prices at the bar while we finish this page.{' '}
            <a href={TEL_HREF} className="font-bold underline underline-offset-4 hover:text-amber-ink">
              Call for today&apos;s specials:{' '}
              <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
            </a>
          </p>
        </Container>
      </section>

      <CategoryNav categories={MENU} />

      <section className="py-12 md:py-20">
        <Container>
          <div
            className={`${HAS_PRICES ? 'max-w-3xl' : 'max-w-[36rem]'} space-y-12 md:space-y-16`}
          >
            {MENU.map((category) => (
              <MenuCategorySection
                key={category.id}
                category={category}
                emptyNote={EMPTY_NOTES[category.id]}
              />
            ))}
          </div>
        </Container>
      </section>

      {/* The one inverted ink band on this page (build/03 §1.4). Statement left,
          action right at lg so the band fills instead of stranding both in the
          left third of a 1200px container. */}
      <Reveal>
        <section className="bg-ink py-16 text-paper md:py-28">
          <Container className="grid gap-8 lg:grid-cols-12 lg:items-center lg:gap-12">
            <h2 className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em] lg:col-span-7">
              Not sure what is on today
            </h2>
            <div className="lg:col-span-5">
              <p className="max-w-[44ch] text-lg leading-relaxed">
                The kitchen runs specials that never make it onto a page this tidy. One
                call gets you the real answer.
              </p>
              <ButtonA href={TEL_HREF} variant="amber" size="lg" className="mt-6">
                <Phone size={18} weight="bold" aria-hidden />
                Call {SITE.phoneDisplay}
              </ButtonA>
            </div>
          </Container>
        </section>
      </Reveal>
    </>
  )
}
