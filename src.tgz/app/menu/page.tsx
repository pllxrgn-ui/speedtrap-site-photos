import type { Metadata } from 'next'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { CategoryNav } from '@/components/menu/category-nav'
import { MenuCategorySection } from '@/components/menu/menu-category'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { menuJsonLd } from '@/lib/jsonld'
import { TEL_HREF } from '@/lib/links'
import { MENU, MENU_PRICES_AS_OF } from '@/lib/menu'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  // "Menu & Prices" restored 2026-09-14, the day lib/menu.ts got real prices
  // (build/04-seo-schema.md wanted exactly this).
  title: 'Menu & Prices',
  description:
    'The full menu with prices for Speed Trap Tap House in Reardan, Washington: burgers, dinners, sandwiches, baskets and a full bar. Specials change daily, so call ahead.',
}

// Real photos only, business-posted, mapped where they honestly belong:
// their cheeseburgers on Burgers, their bar on Drinks & Taps. No category
// gets a stand-in from someone else's kitchen (client direction 2026-09-14;
// provenance in lib/photos.ts).
const CATEGORY_PHOTOS: Record<string, { src: string; alt: string; ratio: '1:1'; category: 'food' | 'bar' }> = {
  burgers: {
    src: '/photos/cheeseburgers-pass.webp',
    alt: 'Six open-faced cheeseburgers lined up on the kitchen pass.',
    ratio: '1:1',
    category: 'food',
  },
  drinks: {
    src: '/photos/bar-full-house.webp',
    alt: 'The long bar on a full night, staff pouring behind it.',
    ratio: '1:1',
    category: 'bar',
  },
}

// With prices live the list runs at the full measure; if the provenance
// regime is ever rolled back (every price null again), the tighter measure
// returns automatically because an empty right-hand column reads as broken.
const HAS_PRICES = MENU.some((category) =>
  category.items.some((item) => item.price !== null),
)

export default function MenuPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(menuJsonLd()) }}
      />
      <section className="py-12 md:py-20">
        <Container>
          <h1 className="text-h1 font-extrabold uppercase tracking-tight">Menu</h1>
          <p className="mt-4 max-w-[62ch] text-lg">
            Burgers, baskets, sandwiches and a full bar. The whole list, on one page, no
            download.
          </p>

          <p className="mt-6 max-w-[62ch] rounded border border-hairline bg-surface p-4">
            {MENU_PRICES_AS_OF ? (
              <>
                Prices as printed on the{' '}
                <span className="font-bold">{MENU_PRICES_AS_OF}</span> menu; if
                one moved since, the board at the bar wins.{' '}
              </>
            ) : (
              <>Prices at the bar while we finish this page. </>
            )}
            <a href={TEL_HREF} className="font-bold underline underline-offset-4 hover:text-amber-ink">
              Call for today&apos;s specials:{' '}
              <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
            </a>
          </p>
        </Container>
      </section>

      <CategoryNav categories={MENU} />

      <section className="py-12 md:py-20">
        <Container>
          <div
            className={`${HAS_PRICES ? 'max-w-3xl' : 'max-w-[36rem]'} space-y-12 md:space-y-16`}
          >
            {MENU.map((category) => (
              <MenuCategorySection
                key={category.id}
                category={category}
                photo={CATEGORY_PHOTOS[category.id]}
              />
            ))}
          </div>
        </Container>
      </section>

      {/* The one inverted ink band on this page (build/03 §1.4). Statement left,
          action right at lg so the band fills instead of stranding both in the
          left third of a 1200px container. */}
      <Reveal>
        <section className="bg-ink py-16 text-paper md:py-28">
          <Container className="grid gap-8 lg:grid-cols-12 lg:items-center lg:gap-12">
            <h2 className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em] lg:col-span-7">
              Not sure what is on today
            </h2>
            <div className="lg:col-span-5">
              <p className="max-w-[44ch] text-lg leading-relaxed">
                The kitchen runs specials that never make it onto a page this tidy. One
                call gets you the real answer.
              </p>
              <ButtonA href={TEL_HREF} variant="amber" size="lg" className="mt-6">
                <Phone size={18} weight="bold" aria-hidden />
                Call {SITE.phoneDisplay}
              </ButtonA>
            </div>
          </Container>
        </section>
      </Reveal>
    </>
  )
}
