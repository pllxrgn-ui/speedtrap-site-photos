import type { Metadata } from 'next'
import { RatingSummary } from '@/components/reviews/rating-summary'
import { ReviewQuote } from '@/components/reviews/review-quote'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { PLATFORM_LINKS, QUOTES } from '@/lib/quotes'

// No Review or AggregateRating schema on this page: policy decision, the
// ratings are third-party and we do not host the reviews (build/04, guardrail 5).
export const metadata: Metadata = {
  title: 'Reviews',
  description:
    'What people actually say about Speed Trap Tap House in Reardan, Washington. Verbatim quotes from Google and Yelp, with links to every review profile.',
}

const PLATFORMS = [
  { label: 'Google', href: PLATFORM_LINKS.google },
  { label: 'Yelp', href: PLATFORM_LINKS.yelp },
  { label: 'TripAdvisor', href: PLATFORM_LINKS.tripadvisor },
]

export default function ReviewsPage() {
  return (
    <>
      <section className="border-b border-hairline bg-paper">
        <Container className="py-12 md:py-20">
          <h1 className="text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em]">
            Reviews
          </h1>
          <p className="mt-6 max-w-[62ch] text-lg leading-relaxed">
            Every quote here is copied word for word from a public review, with
            the name and platform exactly as they appear there. Nothing is
            edited and nothing is written by us.
          </p>
          {/* Reveal is what drives the odometer roll. It is above the fold at
              every viewport, so the early-exit path in reveal.tsx marks it
              visible on mount and the figure rolls on load rather than
              waiting for a scroll that never comes. */}
          <Reveal>
            <RatingSummary />
          </Reveal>
        </Container>
      </section>

      <section className="border-b border-hairline bg-surface">
        <Container className="py-12 md:py-20">
          <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
            In their words
          </h2>
          {/* Group mode: the heading is already there, the quotes arrive in
              sequence behind it (build/03 §1.5). */}
          <Reveal group>
            <div className="stt-stagger mt-8 grid gap-8 md:grid-cols-2">
              {QUOTES.map((quote) => (
                <ReviewQuote key={quote.id} quote={quote} />
              ))}
            </div>
          </Reveal>
        </Container>
      </section>

      <section className="bg-paper">
        <Container className="py-12 md:py-20">
          <Reveal>
            <h2 className="text-h2 font-extrabold uppercase tracking-[-0.02em]">
              Read the rest, or add yours
            </h2>
            <p className="mt-3 max-w-[62ch] text-ink-muted">
              These go straight to the review profiles, unfiltered. If you have
              eaten here, a few lines helps the next person driving through.
            </p>

            <ul className="mt-8 max-w-[62ch]">
              {PLATFORMS.map((platform) => (
                <li key={platform.label} className="border-t border-hairline">
                  <a
                    href={platform.href}
                    target="_blank"
                    rel="noopener"
                    className="tick flex min-h-12 items-center font-bold uppercase tracking-tight underline underline-offset-4 hover:text-amber-ink"
                  >
                    {platform.label}
                  </a>
                </li>
              ))}
            </ul>

            <p className="mt-8">
              <a
                href={PLATFORM_LINKS.google}
                target="_blank"
                rel="noopener"
                className="inline-flex min-h-11 items-center font-bold underline underline-offset-4 hover:text-amber-ink"
              >
                Leave us a review on Google
              </a>
            </p>
          </Reveal>
        </Container>
      </section>
    </>
  )
}
