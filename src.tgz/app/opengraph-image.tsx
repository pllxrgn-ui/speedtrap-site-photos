import { ImageResponse } from 'next/og'
import { SITE } from '@/lib/site'

export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'
export const alt =
  'Speed Trap Tap House, bar and grill on Highway 2 in Reardan, Washington.'

// The one file in the repo allowed to hardcode hex (build/03 §1.7.3): an OG
// card is rasterized once and rendered by other people's software, which has no
// theme and no custom properties. Light-theme literals, no exceptions.
const PAPER = '#F3F4F1'
const SURFACE = '#FFFFFF'
const INK = '#17181A'
const AMBER = '#FFB703'

// Overpass is the brand face, but ImageResponse cannot see next/font, so the
// file has to be fetched as raw bytes. Satori needs truetype: asking Google for
// css2 with no User-Agent returns the ttf source rather than woff2.
//
// Every failure path returns null and the card renders in the built-in face
// instead. An offline build should produce a plainer card, never a broken one.
async function overpass(weight: 400 | 800): Promise<ArrayBuffer | null> {
  try {
    const res = await fetch(
      `https://fonts.googleapis.com/css2?family=Overpass:wght@${weight}`,
    )
    if (!res.ok) return null
    const url = /src: url\((https:\/\/[^)]+)\) format\('truetype'\)/.exec(await res.text())?.[1]
    if (!url) return null
    const font = await fetch(url)
    if (!font.ok) return null
    return await font.arrayBuffer()
  } catch {
    return null
  }
}

export default async function OpengraphImage() {
  const [regular, heavy] = await Promise.all([overpass(400), overpass(800)])
  const fonts = [
    regular ? { name: 'Overpass', data: regular, weight: 400 as const, style: 'normal' as const } : null,
    heavy ? { name: 'Overpass', data: heavy, weight: 800 as const, style: 'normal' as const } : null,
  ].filter((font) => font !== null)

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          background: PAPER,
          color: INK,
          padding: '72px 72px 96px',
          fontFamily: fonts.length > 0 ? 'Overpass' : undefined,
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            gap: 48,
          }}
        >
          <div
            style={{
              display: 'flex',
              width: 660,
              fontSize: 104,
              fontWeight: 800,
              letterSpacing: -3,
              lineHeight: 1.0,
              textTransform: 'uppercase',
            }}
          >
            {SITE.name}
          </div>

          {/* The sign plate, same device as the hero badge. */}
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              background: SURFACE,
              border: `5px solid ${INK}`,
              borderRadius: 10,
              padding: '22px 30px',
              textTransform: 'uppercase',
            }}
          >
            <div style={{ display: 'flex', fontSize: 64, fontWeight: 800, letterSpacing: -2 }}>
              {SITE.rating.value} / 5
            </div>
            <div style={{ display: 'flex', fontSize: 24, fontWeight: 400, letterSpacing: 1 }}>
              {SITE.rating.count} {SITE.rating.source} reviews
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', width: '100%', height: 4, background: INK }} />
          <div style={{ display: 'flex', marginTop: 28, fontSize: 40, fontWeight: 400 }}>
            Bar &amp; Grill on Highway 2, Reardan WA
          </div>
        </div>

        {/* Lane stripe along the bottom edge, the same motif as LaneRule. */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            bottom: 0,
            width: size.width,
            height: 18,
            display: 'flex',
            gap: 32,
          }}
        >
          {Array.from({ length: 12 }, (_, i) => (
            <div key={i} style={{ width: 64, height: 18, background: AMBER }} />
          ))}
        </div>
      </div>
    ),
    { ...size, fonts: fonts.length > 0 ? fonts : undefined },
  )
}
