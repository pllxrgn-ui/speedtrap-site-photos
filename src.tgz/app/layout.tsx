import type { Metadata } from 'next'
import { Anton, Overpass, Overpass_Mono } from 'next/font/google'
import { Footer } from '@/components/site/footer'
import { Header } from '@/components/site/header'
import { StickyCallBar } from '@/components/site/sticky-call-bar'
import { BASE_URL } from '@/lib/base-url'
import { restaurantJsonLd } from '@/lib/jsonld'
import { SITE } from '@/lib/site'
import './globals.css'

const overpass = Overpass({ subsets: ['latin'], variable: '--font-overpass' })
const overpassMono = Overpass_Mono({ subsets: ['latin'], variable: '--font-overpass-mono' })
// The display face (build/03 amendment 2026-09-14d): hero name, section
// heads, lane words, dish names, stat labels. One weight, ~18KB, swap +
// metric-adjusted fallback so the giant name holds CLS 0 through the swap.
// display:'block' is forbidden here (invisible LCP element).
const anton = Anton({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-anton',
  display: 'swap',
  fallback: ['Arial Narrow', 'Haettenschweiler', 'Impact', 'sans-serif'],
})

export const metadata: Metadata = {
  // Required for app/opengraph-image.tsx to emit an absolute og:image URL.
  // Without it Next warns at build and falls back to localhost, which means the
  // card silently fails to render in every share. Same source as sitemap/robots.
  metadataBase: new URL(BASE_URL),
  // ONE PAGE (build/07 §4): /menu's title carried the business's most
  // valuable local query and is now a fragment - fragments do not rank - so
  // the root absorbs menu intent. The description is /menu's already-cleared
  // string, verbatim (reusing a cleared string is not authoring one). Both
  // flagged to Pol as brand-facing copy. No template: one route.
  title: `${SITE.name} | Menu, Burgers & Full Bar in Reardan, WA`,
  description:
    'The full menu with prices for Speed Trap Tap House in Reardan, Washington: burgers, dinners, sandwiches, baskets and a full bar. Specials change daily, so call ahead.',
}

export default function RootLayout({ children }: LayoutProps<'/'>) {
  return (
    <html lang="en" className={`${overpass.variable} ${overpassMono.variable} ${anton.variable}`}>
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(restaurantJsonLd()) }}
        />
        {/* First focusable thing on every page. Hidden until focused, then an
            ink plate top-left, on the same system as every other control. */}
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:inline-flex focus:min-h-11 focus:items-center focus:rounded focus:bg-ink focus:px-4 focus:font-bold focus:uppercase focus:tracking-tight focus:text-paper"
        >
          Skip to content
        </a>
        <Header />
        <main id="main" tabIndex={-1}>
          {children}
        </main>
        <Footer />
        <StickyCallBar />
      </body>
    </html>
  )
}
