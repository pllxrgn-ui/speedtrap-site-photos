import type { Metadata } from 'next'
import { Big_Shoulders, Martian_Mono, Schibsted_Grotesk } from 'next/font/google'
import { BASE_URL } from '@/lib/base-url'
import { SITE } from '@/lib/site'
import './globals.css'

// ROOT: html + the type trio only. The public chrome (header, footer,
// sticky call bar, restaurant JSON-LD, skip link) lives in (site)/layout -
// the back office must not render the customer chrome (build/08 §4), and
// a nested layout cannot remove what a parent added.
//
// The type trio (build/03 amendment 2026-09-15h, client feedback: "less
// common, not AI-adjacent"): Big Shoulders (signage - drawn for Chicago's
// civic wayfinding), Schibsted Grotesk (body, carries real 800s), Martian
// Mono (every numeral, instrument register). All variable, swap + metric
// fallbacks; display:'block' stays forbidden (invisible LCP element).
const sans = Schibsted_Grotesk({ subsets: ['latin'], variable: '--font-sans-src', display: 'swap' })
const mono = Martian_Mono({ subsets: ['latin'], variable: '--font-mono-src', display: 'swap' })
const displayFace = Big_Shoulders({
  subsets: ['latin'],
  variable: '--font-display-src',
  display: 'swap',
  fallback: ['Arial Narrow', 'Haettenschweiler', 'Impact', 'sans-serif'],
})

export const metadata: Metadata = {
  // Required for app/opengraph-image.tsx to emit an absolute og:image URL.
  // Without it Next warns at build and falls back to localhost, which means the
  // card silently fails to render in every share. Same source as sitemap/robots.
  metadataBase: new URL(BASE_URL),
  // ONE PAGE (build/07 §4): /menu's title carried the business's most
  // valuable local query and is now a fragment - fragments do not rank - so
  // the root absorbs menu intent. The description is /menu's already-cleared
  // string, verbatim (reusing a cleared string is not authoring one). Both
  // flagged to Pol as brand-facing copy. No template: one route.
  title: `${SITE.name} | Menu, Burgers & Full Bar in Reardan, WA`,
  description:
    'The full menu with prices for Speed Trap Tap House in Reardan, Washington: burgers, dinners, sandwiches, baskets and a full bar. Specials change daily, so call ahead.',
}

export default function RootLayout({ children }: LayoutProps<'/'>) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable} ${displayFace.variable}`}>
      <body>{children}</body>
    </html>
  )
}
