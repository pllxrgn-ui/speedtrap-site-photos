import type { CSSProperties } from 'react'
import type { Metadata } from 'next'
import { Phone } from '@phosphor-icons/react/dist/ssr'
import { LaneRule } from '@/components/art/lane-rule'
import { Container } from '@/components/site/container'
import { SignPlate } from '@/components/site/sign-plate'
import { ButtonA, ButtonLink } from '@/components/ui/button'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Page not found',
}

// The 404 shipped as Next's default, which is the one page on the site that
// looked like somebody else's. It is built out of the same signage the rest of
// the site is: one sign plate (inside the two-per-page ration, build/03 §1.4),
// the joke told once and straight-faced (§4.1), then the two things a lost
// visitor actually wants, which are the same two things every other page ends
// with: the menu and the phone.
//
// EASTER EGG (motion pass, 2026-09-13). This is the one page allowed the wink
// at the cruiser in the logo, and it is spent in two places:
//
//   1. The plate arrives knocked 2.5deg off true and settles straight on the
//      spring, like a sign somebody clipped.
//   2. A slow amber glow behind it, 3.4s each way, 6.8s per cycle: 0.15 Hz,
//      one hue, no alternation, nothing that could read as a strobe. The
//      photosensitivity rule is absolute and this is two orders of magnitude
//      inside it. No red, no blue, no blink, nothing that looks like a light
//      bar in operation. Just a warm glow way off down the highway.
//
// Both collapse entirely under prefers-reduced-motion. The page is identical
// in content either way.
const step = (index: number) => ({ '--stt-i': index }) as CSSProperties

export default function NotFound() {
  return (
    <section>
      <Container className="py-16 md:py-28">
        <div className="relative inline-block">
          <span
            aria-hidden="true"
            className="stt-beacon pointer-events-none absolute -inset-4 rounded-full bg-amber opacity-0 blur-2xl"
          />
          <SignPlate
            tone="amber"
            className="stt-knock relative inline-block text-h2 leading-none"
          >
            Wrong turn
          </SignPlate>
        </div>

        <h1
          style={step(1)}
          className="stt-rise mt-8 max-w-[16ch] text-h1 font-extrabold uppercase leading-[1.05] tracking-[-0.02em]"
        >
          This page is not on the map
        </h1>
        <p
          style={step(2)}
          className="stt-rise mt-6 max-w-[52ch] text-lg leading-relaxed text-ink-muted"
        >
          The link you followed does not go anywhere. The building is still on
          Highway 2 in Reardan, and the kitchen does not care how you got here.
        </p>

        <LaneRule drift className="mt-10 max-w-md" />

        <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <ButtonLink href="/" variant="ink" size="lg" style={step(3)} className="stt-rise">
            Back to the front
          </ButtonLink>
          <ButtonLink href="/#menu" variant="ghost" size="lg" style={step(4)} className="stt-rise">
            View menu
          </ButtonLink>
          <ButtonA href={TEL_HREF} variant="ghost" size="lg" style={step(5)} className="stt-rise">
            <Phone size={18} weight="bold" aria-hidden />
            Call {SITE.phoneDisplay}
          </ButtonA>
        </div>
      </Container>
    </section>
  )
}
