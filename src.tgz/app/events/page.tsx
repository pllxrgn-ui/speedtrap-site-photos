import type { Metadata } from 'next'
import { RhythmList } from '@/components/events/rhythm-list'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { MULE_DAYS_NOTE, RECURRING } from '@/lib/events'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Events & Weekly Specials',
  description:
    'The weekly rhythm at Speed Trap Tap House in Reardan, Washington. Taco Tuesday, Friday fish and chips, karaoke and live music. Call to confirm what is on tonight.',
}

export default function EventsPage() {
  return (
    <>
      <section className="py-12 md:py-20">
        <Container>
          <h1 className="text-h1 font-extrabold uppercase tracking-tight">
            Events &amp; Weekly Specials
          </h1>
          <p className="mt-4 max-w-[62ch] text-lg">
            The rhythm below is what regulars know.{' '}
            <a href={TEL_HREF} className="font-bold underline underline-offset-4 hover:text-amber-ink">
              Call to confirm what is on tonight:{' '}
              <span className="font-mono tabular-nums">{SITE.phoneDisplay}</span>
            </a>
          </p>

          {/* Section head stays h2, event names are h3 inside the list, so the
              outline runs h1 → h2 → h3 instead of jumping. */}
          <h2 className="mt-10 text-h2 font-extrabold uppercase tracking-tight">
            The week, as it usually runs
          </h2>
          <div className="mt-6 max-w-3xl">
            <RhythmList events={RECURRING} />
          </div>
        </Container>
      </section>

      {/* Plain surface plus hairlines: --surface-warm is scoped to the today
          strip only (build/03 §1.3). The accent is an amber plate at the
          standard radius, because --radius-sign belongs to the hero plate and
          the open-now chip and nothing else (§1.4). */}
      <Reveal>
        <section className="border-y border-hairline bg-surface py-16 md:py-28">
          <Container className="grid gap-6 lg:grid-cols-12 lg:items-center lg:gap-12">
            <h2 className="lg:col-span-5">
              <span className="inline-block rounded bg-amber px-5 py-3 text-h2 font-extrabold uppercase leading-[1.15] tracking-[-0.02em] text-on-amber">
                Mule Days
              </span>
            </h2>
            <p className="max-w-[46ch] text-lg leading-relaxed lg:col-span-7">
              {MULE_DAYS_NOTE}
            </p>
          </Container>
        </section>
      </Reveal>

      <Reveal>
        <section className="py-12 md:py-20">
          <Container>
            <h2 className="text-h2 font-extrabold uppercase tracking-tight">
              Nights get announced before they get printed
            </h2>
            <p className="mt-4 max-w-[62ch] text-lg">
              Karaoke dates and live acts land when they land. Follow along on Facebook, or
              call and someone will tell you straight.
            </p>
            <p className="mt-4">
              <a
                href={SITE.social.facebook}
                target="_blank"
                rel="noopener"
                className="inline-flex min-h-11 items-center font-bold underline underline-offset-4"
              >
                Facebook
              </a>
            </p>
          </Container>
        </section>
      </Reveal>
    </>
  )
}
