import { AdminShell } from '@/components/admin/admin-shell'
import { getDb } from '@/lib/db'
import { menuEventLine } from '@/lib/admin/menu-log'
import { BAR_TIME_ZONE, barDateLabel } from '@/lib/provenance'

// Node runtime (the App Router default - Prisma needs it); the explicit
// segment config is forbidden under experimental.useCache (as-built note).
export const dynamic = 'force-dynamic'

const PAGE_SIZE = 200

// THE LOG (build/09 addendum 4): the MenuEvent ledger, readable. Every
// toast in the editor promises "every change is logged" — this is where
// that promise is kept visible. Read-only by design: the ledger is
// append-only and nothing here can touch it.
export default async function LogPage() {
  const db = getDb()
  const [events, total] = await Promise.all([
    db.menuEvent.findMany({ orderBy: { at: 'desc' }, take: PAGE_SIZE }),
    db.menuEvent.count(),
  ])

  const timeLabel = (at: Date) =>
    at.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', timeZone: BAR_TIME_ZONE })

  // Grouped under day headers, bar clock — the register the plate uses.
  const days: { label: string; rows: typeof events }[] = []
  for (const event of events) {
    const label = barDateLabel(event.at.toISOString())
    const last = days[days.length - 1]
    if (last && last.label === label) days[days.length - 1] = { label, rows: [...last.rows, event] }
    else days.push({ label, rows: [event] })
  }

  return (
    <AdminShell title="The log" active="log">
      <p className="rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
        Every change to the menu, newest first — what the editor promises,
        written down. Nothing here can be edited or deleted.
      </p>

      {events.length === 0 ? (
        <p className="mt-6 text-sm italic text-ink-muted">Nothing yet — the ledger starts with the first change.</p>
      ) : (
        <div className="mt-4 flex flex-col gap-6">
          {days.map((day) => (
            <section key={day.label} aria-label={day.label}>
              <h2 className="border-b-2 border-ink pb-1 font-mono text-xs font-bold uppercase tracking-widest">
                {day.label}
              </h2>
              <ul className="mt-2 flex flex-col">
                {day.rows.map((event) => (
                  <li
                    key={event.id}
                    className="flex items-baseline justify-between gap-4 border-b border-hairline py-2"
                  >
                    <span className="min-w-0 text-sm font-bold">
                      {menuEventLine(event)}
                      {event.actor === 'seed' ? (
                        <span className="ml-2 rounded border border-hairline px-1.5 py-0.5 font-mono text-[0.6875rem] font-bold uppercase tracking-wide text-ink-muted">
                          opening
                        </span>
                      ) : null}
                    </span>
                    <span className="shrink-0 font-mono text-xs uppercase tabular-nums text-ink-muted">
                      {timeLabel(event.at)}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}

      {total > PAGE_SIZE ? (
        <p className="mt-4 text-sm italic text-ink-muted">
          Showing the latest {PAGE_SIZE} of {total} changes — the ledger keeps every one.
        </p>
      ) : null}
    </AdminShell>
  )
}
