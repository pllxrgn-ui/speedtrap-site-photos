import { AdminShell } from '@/components/admin/admin-shell'
import { HoursExceptions, type ExceptionView } from '@/components/admin/hours-exceptions'
import { HoursWeek, type WeekRow } from '@/components/admin/hours-week'
import { getDb } from '@/lib/db'
import { barServiceDay, DAY_ORDER } from '@/lib/hours'
import { hoursProvenance } from '@/lib/provenance'

// Node runtime (the App Router default - Prisma needs it); the explicit
// segment config is forbidden under experimental.useCache (as-built note).
export const dynamic = 'force-dynamic'

// THE HOURS (build/13 section 4). Off the tab rail, entered from a link at
// the TOP of THE BOARD's left rail. Two regimes on one screen, each stated by
// a mono chip where its controls are: the week WAITS FOR PUBLISH, dated rows
// are LIVE AS YOU TYPE.
//
// NO CACHE HERE, ON PURPOSE: the admin shows truth, so it reads both tables
// directly rather than through getHours(). It also shows EVERY dated row,
// including both sides of an overlap - the owner needs to see and remove what
// he typed. Only the public page collapses an overlap to one winner
// (resolveException, section 1.9).
//
// NO PREVIEW ISLAND (section 4.5, cut with its argument written down so it is
// not re-proposed): the menu's preview earns its keep because composition and
// photos are not visible from the editor, but THE WEEK EDITOR IS THE TABLE. A
// preview of seven rows the owner just typed, two inches below in a second
// material, would also render SAVED state beside an IMMEDIATE panel - adding
// a dated row would leave it empty until a reload, which reads as "it did not
// work."
export default async function HoursPage() {
  const db = getDb()
  const [days, exceptions] = await Promise.all([
    db.hoursDay.findMany(),
    db.hoursException.findMany({ orderBy: [{ date: 'asc' }, { createdAt: 'asc' }] }),
  ])

  // ORDER COMES FROM DAY_ORDER, NEVER FROM THE QUERY. HoursDay.day is a
  // String @id, so findMany() hands back fri,mon,sat,sun,thu,tue,wed and
  // nothing in Postgres knows Monday comes first (section 2.3).
  const byDay = new Map(days.map((row) => [row.day, row]))
  const week: WeekRow[] = DAY_ORDER.map((day) => {
    const row = byDay.get(day)
    if (!row) return { day, state: 'unset', open: '', close: '' }
    if (row.closed || row.open === null || row.close === null) {
      return { day, state: 'closed', open: '', close: '' }
    }
    return { day, state: 'open', open: row.open, close: row.close }
  })

  // The stamp is max(updatedAt) across the seven rows - one of the reasons
  // the week is seven rows and not one JSON blob (section 1.1).
  const lastChange = days.reduce<Date | null>(
    (latest, row) => (latest === null || row.updatedAt > latest ? row.updatedAt : latest),
    null,
  )

  const rows: ExceptionView[] = exceptions.map((row) => ({
    id: row.id,
    date: row.date,
    endDate: row.endDate,
    closed: row.closed,
    open: row.open,
    close: row.close,
    label: row.label,
  }))

  // THE SERVICE DAY, computed once on the server and carried down: at 00:20
  // on a Saturday the bar is still working Friday, so Friday's row is not
  // "past" yet (section 0.4). Nothing on this screen reads the browser clock.
  const today = barServiceDay()

  return (
    <AdminShell title="The hours" active="hours">
      {/* PROVENANCE ONLY - the same device as board/page.tsx:105. The regimes
          are the two chips below; an instruction paragraph here is the
          build/11 defect this screen is written against. */}
      <p className="rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
        {hoursProvenance(lastChange?.toISOString() ?? null).adminLine}
      </p>

      <div className="mt-4 flex flex-col gap-6 lg:grid lg:grid-cols-2 lg:items-start">
        <HoursWeek initial={week} />
        <HoursExceptions initial={rows} today={today} />
      </div>
    </AdminShell>
  )
}
