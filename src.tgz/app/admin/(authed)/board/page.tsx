import { AdminShell } from '@/components/admin/admin-shell'
import { BoardNote } from '@/components/admin/board-note'
import { EightySixBoard, type EightySixGroup } from '@/components/admin/eightysix-board'
import { RepublishButton } from '@/components/admin/republish-button'
import { SpecialEditor, type SlotState } from '@/components/admin/special-editor'
import { getDb } from '@/lib/db'
import { MENU } from '@/lib/menu'
import { MENU_KEY_SET, menuKey } from '@/lib/menu-keys'
import { MENU_PRICES_AS_OF } from '@/lib/menu'
import { menuProvenance } from '@/lib/provenance'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

// THE BOARD (build/08 §4): today's note · the 86 board · three specials
// slots. The header copy is non-negotiable — the owner reads WHY this
// screen cannot change a price. requireSession ran in the (authed) layout.
export default async function BoardPage() {
  const db = getDb()
  const [specials, states, note] = await Promise.all([
    db.special.findMany({ orderBy: { id: 'asc' } }),
    db.itemState.findMany(),
    db.siteNote.findUnique({ where: { id: 1 } }),
  ])

  const stateByKey = new Map(states.map((state) => [state.itemKey, state]))
  // Deliberate freshness read in a force-dynamic SERVER component: "is
  // this 86 still live" must be judged against the render's own clock.
  // eslint-disable-next-line react-hooks/purity
  const now = Date.now()
  const groups: EightySixGroup[] = MENU.map((category) => ({
    categoryId: category.id,
    title: category.title,
    items: category.items.map((item) => {
      const key = menuKey(category.id, item.name)
      const state = stateByKey.get(key)
      const live =
        Boolean(state?.soldOut) && (!state?.expiresAt || state.expiresAt.getTime() > now)
      return { itemKey: key, name: item.name, soldOut: live, hold: state?.hold ?? 'tonight' }
    }),
  }))
  const orphans = states
    .filter((state) => state.soldOut && !MENU_KEY_SET.has(state.itemKey))
    .map((state) => state.itemKey)

  const slots: SlotState[] = [1, 2, 3].map((slot) => {
    const row = specials.find((special) => special.id === slot)
    return {
      slot,
      title: row?.title ?? '',
      body: row?.body ?? '',
      priceLabel: row?.priceLabel ?? '',
      published: row?.published ?? false,
      publishedAt: row?.publishedAt?.toISOString() ?? null,
    }
  })
  const anyLive = slots.some((slot) => slot.published)

  return (
    <AdminShell title="The board" active="board">
      <div className="flex flex-col gap-4">
        <p className="rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
          {menuProvenance(MENU_PRICES_AS_OF).adminBoardLine}
        </p>

        <BoardNote initial={{ body: note?.body ?? '', published: note?.published ?? false }} />

        <section aria-label="Specials" className="flex flex-col gap-3">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="font-display text-xl uppercase">Today&apos;s specials</h2>
            {anyLive ? <RepublishButton /> : null}
          </div>
          {slots.map((slot) => (
            <SpecialEditor key={slot.slot} initial={slot} />
          ))}
        </section>

        <EightySixBoard groups={groups} orphans={orphans} />
      </div>
    </AdminShell>
  )
}
