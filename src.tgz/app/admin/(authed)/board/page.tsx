import { AdminShell } from '@/components/admin/admin-shell'
import { BoardNote } from '@/components/admin/board-note'
import { FavoritesEditor, type PickerDish, type SpotState as FavoriteSpot } from '@/components/admin/favorites-editor'
import { MenuPreview, type PreviewGroup } from '@/components/admin/menu-preview'
import { RepublishButton } from '@/components/admin/republish-button'
import { SpecialEditor, type SlotState } from '@/components/admin/special-editor'
import { getDb } from '@/lib/db'
import { menuProvenance } from '@/lib/provenance'

// Node runtime (the App Router default - Prisma needs it); the explicit
// segment config is forbidden under experimental.useCache (as-built note).
export const dynamic = 'force-dynamic'

// THE BOARD (build/08 §4, build/09): today's note, three specials slots,
// and THE MENU EDITOR - the live menu with every word tappable. Wide
// screen: the left rail holds the words, the paper takes the rest.
export default async function BoardPage() {
  const db = getDb()
  const [menuBoards, dishes, specials, states, note, dishPhotos, lastEvent, featureSpots] =
    await Promise.all([
      db.menuBoard.findMany({ orderBy: [{ sortIndex: 'asc' }, { id: 'asc' }] }),
      db.menuDish.findMany({ orderBy: [{ categoryId: 'asc' }, { sortIndex: 'asc' }] }),
      db.special.findMany({ orderBy: { id: 'asc' } }),
      db.itemState.findMany(),
      db.siteNote.findUnique({ where: { id: 1 } }),
      db.dishPhoto.findMany(),
      db.menuEvent.findFirst({ where: { actor: 'owner' }, orderBy: { at: 'desc' } }),
      db.featureSpot.findMany({ orderBy: { slot: 'asc' } }),
    ])

  const stateByKey = new Map(states.map((state) => [state.itemKey, state]))
  const photoByKey = new Map(dishPhotos.map((photo) => [photo.itemKey, photo]))
  const dishIds = new Set(dishes.map((dish) => dish.id))
  // Deliberate freshness read in a force-dynamic SERVER component: "is
  // this 86 still live" must be judged against the render's own clock.
  // eslint-disable-next-line react-hooks/purity
  const now = Date.now()

  // The admin shows EVERY board, including empty ones — an empty board is
  // exactly what the owner needs to see to fill or remove; the public page
  // is the one that hides it (lib/menu-data.ts).
  const groups: PreviewGroup[] = menuBoards.map((board) => ({
    categoryId: board.id,
    title: board.title,
    note: board.note ?? '',
    dishes: dishes
      .filter((dish) => dish.categoryId === board.id)
      .map((dish) => {
        const state = stateByKey.get(dish.id)
        const photo = photoByKey.get(dish.id)
        const live =
          Boolean(state?.soldOut) && (!state?.expiresAt || state.expiresAt.getTime() > now)
        return {
          id: dish.id,
          name: dish.name,
          description: dish.description ?? '',
          price: dish.priceCents === null ? '' : (dish.priceCents / 100).toFixed(2),
          soldOut: live,
          hold: state?.hold ?? 'tonight',
          photo: photo ? { src: photo.url, alt: photo.alt } : null,
        }
      }),
  }))

  const orphans = [
    ...states.filter((state) => state.soldOut && !dishIds.has(state.itemKey)),
    ...dishPhotos.filter((photo) => !dishIds.has(photo.itemKey)),
  ].map((row) => row.itemKey)

  const boardTitleById = new Map(menuBoards.map((board) => [board.id, board.title]))
  const favoriteSpots: FavoriteSpot[] = featureSpots.map((spot) => ({
    slot: spot.slot,
    dishId: spot.dishId,
    blurb: spot.blurb,
  }))
  const pickerDishes: PickerDish[] = dishes.map((dish) => {
    const photo = photoByKey.get(dish.id)
    return {
      id: dish.id,
      name: dish.name,
      boardTitle: boardTitleById.get(dish.categoryId) ?? dish.categoryId,
      price: dish.priceCents === null ? '' : (dish.priceCents / 100).toFixed(2),
      description: dish.description,
      photo: photo ? { src: photo.url, alt: photo.alt } : null,
    }
  })

  const slots: SlotState[] = [1, 2, 3].map((slot) => {
    const row = specials.find((special) => special.id === slot)
    return {
      slot,
      title: row?.title ?? '',
      body: row?.body ?? '',
      priceLabel: row?.priceLabel ?? '',
      published: row?.published ?? false,
      publishedAt: row?.publishedAt?.toISOString() ?? null,
      photo: row?.photoUrl ? { src: row.photoUrl, alt: row.photoAlt ?? row.title } : null,
    }
  })
  const anyLive = slots.some((slot) => slot.published)

  return (
    <AdminShell title="The board" active="board">
      <p className="rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
        {menuProvenance(lastEvent?.at.toISOString() ?? null).adminBoardLine}
      </p>

      <div className="mt-4 flex flex-col gap-6 lg:grid lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)] lg:items-start">
        <div className="flex flex-col gap-4 lg:sticky lg:top-4">
          <BoardNote initial={{ body: note?.body ?? '', published: note?.published ?? false }} />

          <section aria-label="Specials" className="flex flex-col gap-3">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="font-display text-xl uppercase">Today&apos;s specials</h2>
              {anyLive ? <RepublishButton /> : null}
            </div>
            {slots.map((slot) => (
              <SpecialEditor key={slot.slot} initial={slot} />
            ))}
          </section>
        </div>

        {/* Favorites sit ON TOP of the menu (Pol, 2026-09-23) — they are
            the cards above the boards on the site, so the editor mirrors
            that order: storefront first, then the paper. */}
        <div className="flex min-w-0 flex-col gap-6">
          <FavoritesEditor spots={favoriteSpots} dishes={pickerDishes} />
          <MenuPreview groups={groups} orphans={[...new Set(orphans)]} />
        </div>
      </div>
    </AdminShell>
  )
}
