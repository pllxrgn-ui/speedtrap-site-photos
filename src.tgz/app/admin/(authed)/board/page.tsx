import { AdminShell } from '@/components/admin/admin-shell'
import { BoardNote } from '@/components/admin/board-note'
import { MenuPreview, type PreviewGroup } from '@/components/admin/menu-preview'
import { RepublishButton } from '@/components/admin/republish-button'
import { SpecialEditor, type SlotState } from '@/components/admin/special-editor'
import { getDb } from '@/lib/db'
import { MENU, MENU_PRICES_AS_OF } from '@/lib/menu'
import { MENU_KEY_SET, menuKey } from '@/lib/menu-keys'
import { menuProvenance } from '@/lib/provenance'

// Node runtime (the App Router default - Prisma needs it); the explicit
// segment config is forbidden under experimental.useCache (as-built note).
export const dynamic = 'force-dynamic'

// THE BOARD (build/08 §4 + the 2026-09-22 amendment): today's note, three
// specials slots, and THE MENU PREVIEW - the site's own menu with an 86
// switch and a photo slot on every ticket. Wide screen: the left rail
// holds the words, the paper takes the rest. The header copy is
// non-negotiable - the owner reads WHY this screen cannot change a price.
export default async function BoardPage() {
  const db = getDb()
  const [specials, states, note, dishPhotos] = await Promise.all([
    db.special.findMany({ orderBy: { id: 'asc' } }),
    db.itemState.findMany(),
    db.siteNote.findUnique({ where: { id: 1 } }),
    db.dishPhoto.findMany(),
  ])

  const stateByKey = new Map(states.map((state) => [state.itemKey, state]))
  const photoByKey = new Map(dishPhotos.map((photo) => [photo.itemKey, photo]))
  // Deliberate freshness read in a force-dynamic SERVER component: "is
  // this 86 still live" must be judged against the render's own clock.
  // eslint-disable-next-line react-hooks/purity
  const now = Date.now()

  const groups: PreviewGroup[] = MENU.map((category) => ({
    categoryId: category.id,
    title: category.title,
    dishes: category.items.map((item) => {
      const key = menuKey(category.id, item.name)
      const state = stateByKey.get(key)
      const photo = photoByKey.get(key)
      const live =
        Boolean(state?.soldOut) && (!state?.expiresAt || state.expiresAt.getTime() > now)
      return {
        itemKey: key,
        item,
        soldOut: live,
        hold: state?.hold ?? 'tonight',
        photo: photo ? { src: photo.url, alt: photo.alt } : null,
        hasCodePhoto: Boolean(item.photo),
      }
    }),
  }))
  const orphans = [
    ...states.filter((state) => state.soldOut && !MENU_KEY_SET.has(state.itemKey)),
    ...dishPhotos.filter((photo) => !MENU_KEY_SET.has(photo.itemKey)),
  ].map((row) => row.itemKey)

  const slots: SlotState[] = [1, 2, 3].map((slot) => {
    const row = specials.find((special) => special.id === slot)
    return {
      slot,
      title: row?.title ?? '',
      body: row?.body ?? '',
      priceLabel: row?.priceLabel ?? '',
      published: row?.published ?? false,
      publishedAt: row?.publishedAt?.toISOString() ?? null,
    }
  })
  const anyLive = slots.some((slot) => slot.published)

  return (
    <AdminShell title="The board" active="board" wide>
      <p className="rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
        {menuProvenance(MENU_PRICES_AS_OF).adminBoardLine}
      </p>

      <div className="mt-4 flex flex-col gap-6 lg:grid lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)] lg:items-start">
        <div className="flex flex-col gap-4 lg:sticky lg:top-4">
          <BoardNote initial={{ body: note?.body ?? '', published: note?.published ?? false }} />

          <section aria-label="Specials" className="flex flex-col gap-3">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="font-display text-xl uppercase">Today&apos;s specials</h2>
              {anyLive ? <RepublishButton /> : null}
            </div>
            {slots.map((slot) => (
              <SpecialEditor key={slot.slot} initial={slot} />
            ))}
          </section>
        </div>

        <MenuPreview groups={groups} orphans={[...new Set(orphans)]} />
      </div>
    </AdminShell>
  )
}
