import { AdminShell } from '@/components/admin/admin-shell'
import { BoardNote } from '@/components/admin/board-note'
import { FavoritesEditor, type PickerDish, type SpotState as FavoriteSpot } from '@/components/admin/favorites-editor'
import { HoursRailLink } from '@/components/admin/hours-rail-link'
import { MenuPreview, type PreviewGroup } from '@/components/admin/menu-preview'
import { RepublishButton } from '@/components/admin/republish-button'
import { SpecialEditor, type SlotState } from '@/components/admin/special-editor'
import { getDb } from '@/lib/db'
import { barServiceDay, dayStateOf, DAY_ORDER, spanEnd } from '@/lib/hours'
import { menuProvenance } from '@/lib/provenance'

// Node runtime (the App Router default - Prisma needs it); the explicit
// segment config is forbidden under experimental.useCache (as-built note).
export const dynamic = 'force-dynamic'

// THE BOARD (build/08 §4, build/09): today's note, three specials slots,
// and THE MENU EDITOR - the live menu with every word tappable. Wide
// screen: the left rail holds the words, the paper takes the rest.
export default async function BoardPage() {
  const db = getDb()
  const [
    menuBoards,
    dishes,
    specials,
    states,
    note,
    dishPhotos,
    lastEvent,
    featureSpots,
    hoursDays,
    hoursExceptions,
  ] = await Promise.all([
    db.menuBoard.findMany({ orderBy: [{ sortIndex: 'asc' }, { id: 'asc' }] }),
    db.menuDish.findMany({ orderBy: [{ categoryId: 'asc' }, { sortIndex: 'asc' }] }),
    db.special.findMany({ orderBy: { id: 'asc' } }),
    db.itemState.findMany(),
    db.siteNote.findUnique({ where: { id: 1 } }),
    db.dishPhoto.findMany(),
    db.menuEvent.findFirst({ where: { actor: 'owner' }, orderBy: { at: 'desc' } }),
    db.featureSpot.findMany({ orderBy: { slot: 'asc' } }),
    // Two thin reads for THE HOURS link row's amber rule (build/13 section
    // 4.1). Seven rows and tens of dated rows at the outside - this is not
    // the screen's cost centre.
    db.hoursDay.findMany({ select: { day: true, closed: true, open: true, close: true } }),
    db.hoursException.findMany({ select: { date: true, endDate: true } }),
  ])

  const stateByKey = new Map(states.map((state) => [state.itemKey, state]))
  const photoByKey = new Map(dishPhotos.map((photo) => [photo.itemKey, photo]))
  const dishIds = new Set(dishes.map((dish) => dish.id))
  // Deliberate freshness read in a force-dynamic SERVER component: "is
  // this 86 still live" must be judged against the render's own clock.
  // eslint-disable-next-line react-hooks/purity
  const now = Date.now()

  // The admin shows EVERY board, including empty ones — an empty board is
  // exactly what the owner needs to see to fill or remove; the public page
  // is the one that hides it (lib/menu-data.ts).
  const groups: PreviewGroup[] = menuBoards.map((board) => ({
    categoryId: board.id,
    title: board.title,
    note: board.note ?? '',
    dishes: dishes
      .filter((dish) => dish.categoryId === board.id)
      .map((dish) => {
        const state = stateByKey.get(dish.id)
        const photo = photoByKey.get(dish.id)
        const live =
          Boolean(state?.soldOut) && (!state?.expiresAt || state.expiresAt.getTime() > now)
        return {
          id: dish.id,
          name: dish.name,
          description: dish.description ?? '',
          price: dish.priceCents === null ? '' : (dish.priceCents / 100).toFixed(2),
          soldOut: live,
          hold: state?.hold ?? 'tonight',
          photo: photo ? { src: photo.url, alt: photo.alt } : null,
        }
      }),
  }))

  const orphans = [
    ...states.filter((state) => state.soldOut && !dishIds.has(state.itemKey)),
    ...dishPhotos.filter((photo) => !dishIds.has(photo.itemKey)),
  ].map((row) => row.itemKey)

  const boardTitleById = new Map(menuBoards.map((board) => [board.id, board.title]))
  const favoriteSpots: FavoriteSpot[] = featureSpots.map((spot) => ({
    slot: spot.slot,
    dishId: spot.dishId,
    blurb: spot.blurb,
  }))
  const pickerDishes: PickerDish[] = dishes.map((dish) => {
    const photo = photoByKey.get(dish.id)
    return {
      id: dish.id,
      name: dish.name,
      boardTitle: boardTitleById.get(dish.categoryId) ?? dish.categoryId,
      price: dish.priceCents === null ? '' : (dish.priceCents / 100).toFixed(2),
      description: dish.description,
      photo: photo ? { src: photo.url, alt: photo.alt } : null,
    }
  })

  // Amber while any of the seven days is unset, or while a dated row that is
  // already over is still listed. Judged on the SERVICE day, so a row does
  // not read as "past" while the bar is still working that night.
  const hoursByDay = new Map(hoursDays.map((row) => [row.day, row]))
  // Through dayStateOf/DAY_ORDER, not a fourth hand-written copy of "what
  // counts as unset" (review round 1, nit): the editor, the public gate and
  // the ledger all read the tri-state through that one function.
  const unsetDays = DAY_ORDER.filter(
    (day) => dayStateOf(hoursByDay.get(day)).state === 'unset',
  ).length
  const serviceDay = barServiceDay()
  // EVERY past row, not the first ten - and the panel's expander is what
  // keeps that honest (finding 3): an amber the owner cannot clear because
  // the row is off the bottom of a slice is an amber that stops meaning
  // "needs you".
  const pastHoursRows = hoursExceptions.filter((row) => spanEnd(row) < serviceDay).length

  const slots: SlotState[] = [1, 2, 3].map((slot) => {
    const row = specials.find((special) => special.id === slot)
    return {
      slot,
      title: row?.title ?? '',
      body: row?.body ?? '',
      priceLabel: row?.priceLabel ?? '',
      published: row?.published ?? false,
      publishedAt: row?.publishedAt?.toISOString() ?? null,
      photo: row?.photoUrl ? { src: row.photoUrl, alt: row.photoAlt ?? row.title } : null,
    }
  })
  const anyLive = slots.some((slot) => slot.published)

  return (
    <AdminShell title="The board" active="board">
      <p className="rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
        {menuProvenance(lastEvent?.at.toISOString() ?? null).adminBoardLine}
      </p>

      <div className="mt-4 flex flex-col gap-6 lg:grid lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)] lg:items-start">
        {/* D2 (build/11): a pinned rail may not exceed the viewport. This one
            measured 1,285px tall in a 950px window, so it pinned and never
            scrolled — specials SLOT 3 sat below the fold at every scroll
            position, and on a 1366×768 counter laptop slot 2 went with it.
            max-h + its own overflow give the pin somewhere to go.

            overflow-x-clip rides along because `overflow-y: auto` alone
            COERCES overflow-x from visible to auto (measured in Chromium:
            visible/auto -> auto/auto; clip/auto -> hidden/auto), which would
            hang a stray horizontal scrollbar off a rail that never scrolls
            sideways. Either way the box now clips at its padding edge, so
            -mx-1/px-1 buys back the 4px a 2px focus ring at 2px offset needs:
            "Still true — republish" sits flush with the rail's right edge and
            its ring was landing on the cut. The negative margin keeps the
            cards exactly the width they were; the 4px rides in the grid gap. */}
        <div className="flex flex-col gap-4 lg:sticky lg:top-4 lg:-mx-1 lg:max-h-[calc(100vh-2rem)] lg:overflow-y-auto lg:overflow-x-clip lg:px-1">
          {/* THE HOURS lives off the rail, and THIS ROW is how the owner
              finds it on day one (build/13 section 4.1, review finding 7):
              FIRST in the scroller and first on the phone stack, directly
              under the line that already says what the site is showing. A
              ~56px row inside a box that scrolls is a scroll cost, not a
              reachability cost - D2's class is closed by the max-h above. */}
          <HoursRailLink unsetDays={unsetDays} pastRows={pastHoursRows} />
          <BoardNote initial={{ body: note?.body ?? '', published: note?.published ?? false }} />

          <section aria-label="Specials" className="flex flex-col gap-3">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="font-display text-xl uppercase">Today&apos;s specials</h2>
              {anyLive ? <RepublishButton /> : null}
            </div>
            {slots.map((slot) => (
              <SpecialEditor key={slot.slot} initial={slot} />
            ))}
          </section>
        </div>

        {/* Favorites sit ON TOP of the menu (Pol, 2026-09-23) — they are
            the cards above the boards on the site, so the editor mirrors
            that order: storefront first, then the paper. */}
        <div className="flex min-w-0 flex-col gap-6">
          <FavoritesEditor spots={favoriteSpots} dishes={pickerDishes} />
          <MenuPreview groups={groups} orphans={[...new Set(orphans)]} />
        </div>
      </div>
    </AdminShell>
  )
}
