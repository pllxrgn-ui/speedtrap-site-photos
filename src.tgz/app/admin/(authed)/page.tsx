import { AdminShell } from '@/components/admin/admin-shell'
import { FilterPills, type BookFilter } from '@/components/admin/filter-pills'
import { TheBook } from '@/components/admin/the-book'
import type { TicketBooking } from '@/components/admin/booking-ticket'
import type { TimeWindowValue } from '@/lib/booking'
import { getDb } from '@/lib/db'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

// THE BOOK (build/08 §4): the queue, default screen. Filter state rides
// the URL so a refresh behind the bar keeps the view. The layout above
// already ran requireSession; the data read happens here, server-side.

const DAY_MS = 86_400_000

// The bar's own clock, not the server's: "today" behind this bar is the
// Pacific date, whatever region the function runs in.
function reardanToday(): string {
  return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' })
}

function whereFor(filter: BookFilter) {
  const today = new Date(`${reardanToday()}T00:00:00Z`)
  switch (filter) {
    case 'new':
      return { status: 'new' as const }
    case 'today':
      return { requestedOn: today }
    case 'week':
      return { requestedOn: { gte: today, lt: new Date(today.getTime() + 7 * DAY_MS) } }
    default:
      return {}
  }
}

export default async function AdminHome({
  searchParams,
}: {
  searchParams: Promise<{ f?: string }>
}) {
  const { f } = await searchParams
  const filter: BookFilter = f === 'today' || f === 'week' || f === 'all' ? f : 'new'

  const rows = await getDb().booking.findMany({
    where: whereFor(filter),
    orderBy: [{ requestedOn: 'asc' }, { createdAt: 'asc' }],
    take: 200,
  })

  const bookings: TicketBooking[] = rows.map((row) => ({
    id: row.id,
    reference: row.reference,
    name: row.name,
    phone: row.phone,
    phoneDigits: row.phoneDigits,
    partySize: row.partySize,
    date: row.requestedOn.toISOString().slice(0, 10),
    timeWindow: row.timeWindow as TimeWindowValue,
    note: row.note,
    status: row.status,
    createdAt: row.createdAt.toISOString(),
  }))

  return (
    <AdminShell title="The book" active="book">
      <div className="flex flex-col gap-4">
        <FilterPills active={filter} />
        <TheBook key={filter} initial={bookings} />
      </div>
    </AdminShell>
  )
}
