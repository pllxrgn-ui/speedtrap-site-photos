import { AdminShell } from '@/components/admin/admin-shell'
import { FilterPills, type BookFilter } from '@/components/admin/filter-pills'
import { TheBook } from '@/components/admin/the-book'
import type { TicketBooking } from '@/components/admin/booking-ticket'
import type { TimeWindowValue } from '@/lib/booking'
import { getDb } from '@/lib/db'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

// THE BOOK (build/08 §4): the queue, default screen. Filter state rides
// the URL so a refresh behind the bar keeps the view. The layout above
// already ran requireSession; the data read happens here, server-side.

const DAY_MS = 86_400_000

// The bar's own clock, not the server's: "today" behind this bar is the
// Pacific date, whatever region the function runs in.
function reardanToday(): string {
  return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' })
}

function whereFor(filter: BookFilter) {
  const today = new Date(`${reardanToday()}T00:00:00Z`)
  switch (filter) {
    case 'new':
      return { status: 'new' as const }
    case 'today':
      return { requestedOn: today }
    case 'week':
      return { requestedOn: { gte: today, lt: new Date(today.getTime() + 7 * DAY_MS) } }
    default:
      return {}
  }
}

export default async function AdminHome({
  searchParams,
}: {
  searchParams: Promise<{ f?: string }>
}) {
  const { f } = await searchParams
  const filter: BookFilter = f === 'today' || f === 'week' || f === 'all' ? f : 'new'

  const db = getDb()
  const today = new Date(`${reardanToday()}T00:00:00Z`)
  const weekOut = new Date(today.getTime() + 7 * DAY_MS)
  // At-a-glance strip (Smoky Mug integration, 2026-09-23): the counts the
  // owner walks in wanting, before any scrolling.
  const [rows, newCount, todayAgg, upcoming] = await Promise.all([
    db.booking.findMany({
      where: whereFor(filter),
      orderBy: [{ requestedOn: 'asc' }, { createdAt: 'asc' }],
      take: 200,
    }),
    db.booking.count({ where: { status: 'new' } }),
    db.booking.aggregate({
      where: { requestedOn: today, status: { in: ['new', 'confirmed'] } },
      _count: true,
      _sum: { partySize: true },
    }),
    db.booking.count({
      where: { requestedOn: { gt: today, lte: weekOut }, status: { in: ['new', 'confirmed'] } },
    }),
  ])

  const bookings: TicketBooking[] = rows.map((row) => ({
    id: row.id,
    reference: row.reference,
    name: row.name,
    phone: row.phone,
    phoneDigits: row.phoneDigits,
    partySize: row.partySize,
    date: row.requestedOn.toISOString().slice(0, 10),
    timeWindow: row.timeWindow as TimeWindowValue,
    note: row.note,
    status: row.status,
    createdAt: row.createdAt.toISOString(),
  }))

  const glance = [
    { label: 'Need you', value: newCount, amber: newCount > 0 },
    { label: 'Today', value: todayAgg._count, sub: `${todayAgg._sum.partySize ?? 0} covers` },
    { label: 'Next 7 days', value: upcoming },
    { label: 'Online booking', value: process.env.NEXT_PUBLIC_BOOKING_ENABLED === '1' ? 'ON' : 'OFF' },
  ]

  return (
    <AdminShell title="The book" active="book">
      {/* D6 (build/11): the tile that matters most was the only hollow one —
          going amber dropped its surface. Amber is the BORDER (and the
          numeral); every tile keeps the same material underneath. */}
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        {glance.map((tile) => (
          <div
            key={tile.label}
            className={`rounded-lg border bg-surface p-3 ${'amber' in tile && tile.amber ? 'border-amber' : 'border-hairline'}`}
          >
            <p className="font-mono text-[0.6875rem] font-bold uppercase tracking-widest text-ink-muted">
              {tile.label}
            </p>
            <p className={`mt-1 font-mono text-2xl font-bold tabular-nums ${'amber' in tile && tile.amber ? 'text-amber-ink' : ''}`}>
              {tile.value}
            </p>
            {'sub' in tile && tile.sub ? (
              <p className="font-mono text-xs uppercase tracking-wide tabular-nums text-ink-muted">{tile.sub}</p>
            ) : null}
          </div>
        ))}
      </div>
      <div className="flex flex-col gap-4">
        <FilterPills active={filter} />
        <TheBook key={filter} initial={bookings} />
      </div>
    </AdminShell>
  )
}
