import { requireAdminPage } from '@/lib/admin/page-guard'

// THE authorization boundary for every authed admin page (build/08 §2 row
// 9): a real session row, checked server-side, on every render. The
// middleware redirect is convenience; this is the wall. Never cache an
// authed view.
// NOT the only wall (security fix 2026-09-28, Betty's review F1): Next
// renders this layout and its page in parallel, so a redirect here alone
// still streamed the page's server payload (THE BOOK's bookings with name
// and phone) inside the 307 to a forged stt_admin cookie. Every page calls
// requireAdminPage() itself before its first read (lib/admin/page-guard.ts;
// the gate's check-admin-auth fails a page that does not); cache() shares
// one session read between this layout and the page.
// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

export default async function AuthedAdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdminPage()
  return <>{children}</>
}
