import { redirect } from 'next/navigation'
import { requireSession } from '@/lib/auth/session'

// THE authorization boundary for every authed admin page (build/08 §2 row
// 9): a real session row, checked server-side, on every render. The
// middleware redirect is convenience; this is the wall. Never cache an
// authed view.
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export default async function AuthedAdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireSession()
  if (!session) redirect('/admin/login')
  return <>{children}</>
}
