import { AdminShell } from '@/components/admin/admin-shell'
import { PassphraseForm } from '@/components/admin/passphrase-form'
import { requireAdminPage } from '@/lib/admin/page-guard'

export const dynamic = 'force-dynamic'

// THE KEY (build/09 addendum 7): change the admin passphrase without a
// redeploy. Not a tab - reached from the header, next to Sign out.
export default async function PassphrasePage() {
  await requireAdminPage() // the page's own wall, before any read (2026-09-28)
  return (
    <AdminShell title="The key" active="key">
      <p className="max-w-xl rounded border border-hairline bg-surface px-4 py-3 text-sm font-bold">
        One passphrase opens the whole back of house. Change it here; the
        old one stops working everywhere the moment you do.
      </p>
      <div className="mt-5">
        <PassphraseForm />
      </div>
    </AdminShell>
  )
}
