import type { Metadata } from 'next'

// The back office never enters an index (build/08 §2 row 10, three
// layers): robots.ts disallows /admin, next.config sends X-Robots-Tag,
// and this metadata covers any renderer that only reads the page.
export const metadata: Metadata = {
  title: 'Back of house | Speed Trap Tap House',
  robots: { index: false, follow: false },
}

// THE SERVICE STATION (contract §Back of House): same brand, different
// job. scene-station pins the cooler ground in both themes; there is
// deliberately NO .grain here — grain is the film. Auth lives in the
// (authed) group's layout so the login plate can render without a session.
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  // overflow-x-clip (D3, build/11): the scene sits on a DIV, not the body, so
  // any horizontal overflow used to scroll past its right edge and expose a
  // paper-WHITE strip (WCAG 1.4.10). The header that caused it is fixed in
  // admin-shell.tsx; this is the ground's own guarantee that a future wide
  // child cannot reopen the hole. `clip` and not `hidden` on purpose — clip
  // is not a scroll container, so the board rail's sticky pin still resolves
  // against the viewport.
  return <div className="scene-station min-h-screen overflow-x-clip">{children}</div>
}
