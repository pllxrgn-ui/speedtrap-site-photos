import type { Metadata } from 'next'

// The back office never enters an index (build/08 §2 row 10, three
// layers): robots.ts disallows /admin, next.config sends X-Robots-Tag,
// and this metadata covers any renderer that only reads the page.
export const metadata: Metadata = {
  title: 'Back of house | Speed Trap Tap House',
  robots: { index: false, follow: false },
}

// THE SERVICE STATION (contract §Back of House): same brand, different
// job. scene-station pins the cooler ground in both themes; there is
// deliberately NO .grain here — grain is the film. Auth lives in the
// (authed) group's layout so the login plate can render without a session.
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <div className="scene-station min-h-screen">{children}</div>
}
