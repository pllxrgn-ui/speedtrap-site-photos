import { LoginPlate } from '@/components/admin/login-plate'

// THE PLATE, Phase 3 skeleton (build/08 §4): password only — no email, no
// "forgot", no signup. Phase 4 dresses it in .scene-station.
export default function AdminLoginPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-4">
      <LoginPlate />
    </main>
  )
}
