import type { MetadataRoute } from 'next'
import { BASE_URL } from '@/lib/base-url'

// AI-crawler friendly on purpose (build/04): aggregators currently feed
// assistants wrong data about this business; we want the canonical site read.
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/' }],
    sitemap: `${BASE_URL}/sitemap.xml`,
  }
}
