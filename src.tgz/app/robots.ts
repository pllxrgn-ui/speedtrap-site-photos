import type { MetadataRoute } from 'next'
import { BASE_URL } from '@/lib/base-url'

// AI-crawler friendly on purpose (build/04): aggregators currently feed
// assistants wrong data about this business; we want the canonical site read.
// EXCEPT while the site lives on the preview host: a crawlable vercel.app
// twin would compete with the real domain after cutover (audit build/05
// M11), so preview hosts disallow. Setting NEXT_PUBLIC_SITE_URL to the real
// domain flips this open with no code change.
// The back office is disallowed in BOTH modes (build/08 §2 row 10 — layer
// one of three; X-Robots-Tag and the layout metadata are the others).
export default function robots(): MetadataRoute.Robots {
  const preview = new URL(BASE_URL).hostname.endsWith('.vercel.app')
  return {
    rules: [
      preview
        ? { userAgent: '*', disallow: '/' }
        : { userAgent: '*', allow: '/', disallow: ['/admin', '/api/admin'] },
    ],
    sitemap: `${BASE_URL}/sitemap.xml`,
  }
}
