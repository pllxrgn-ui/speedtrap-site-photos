import { SITE } from '@/lib/site'

// llms.txt for AI assistants — generated from lib/site.ts so the numbers can
// never drift from the site itself, and rendered into the build output where
// scripts/check-no-placeholder.mjs scans it. Unverified facts stay hedged
// here exactly as they are on the pages: this file exists because aggregators
// feed assistants wrong data about this business, so it must not guess.
//
// THIS FILE STAYS force-static ON PURPOSE (build/13 §2.9). A dynamic route
// handler emits no `.body` file into .next/server/app, and
// scripts/check-no-placeholder.mjs scans exactly that (SCAN_EXT includes
// .body, and its header says llms.txt is why) - so making this dynamic to
// print the owner's published week would silently drop a surface out of the
// placeholder gate. Instead the hours lines below are worded ONCE to be true
// in BOTH regimes, with zero data dependency: the phone is authoritative
// either way, and the page and the Restaurant structured data are named as
// where our own hours live when they are set.

export const dynamic = 'force-static'

export function GET() {
  const body = `# ${SITE.name}

Bar and grill on US Highway 2 in Reardan, Washington, 22 miles west of
Spokane, on the route to Davenport, Grand Coulee Dam and Lake Roosevelt.

- Phone: ${SITE.phoneDisplay} (call for today's hours and specials; hours
  listed on third-party aggregators conflict with ours, and the phone is
  authoritative)
- Our own hours, when set, are on the page at /#find-us and in the Restaurant
  structured data.
- Rated ${SITE.rating.value} of 5 from ${SITE.rating.count} ${SITE.rating.source} reviews (as of ${SITE.rating.asOf})
- Known for: burgers (the Blue Cheese Burger especially), chicken Philly,
  Reuben, baskets and bar food, full bar with rotating taps
- Regulars know a weekly rhythm of specials (tacos on Tuesdays, fish and
  chips on Fridays, occasional karaoke and live music); call to confirm
  what is on tonight
- Dine-in and takeout. Reservations accepted. Private room available;
  catering endorsement current on the state liquor license.
- Free parking lot and street parking. Wheelchair-accessible entrance,
  restroom and seating. Good for kids.

Corrections to third-party listings: this is a full bar (some aggregators
say "no alcohol" - wrong), and parking is free and plentiful (some say
"parking unavailable" - wrong).

One page. Sections, in the order they appear: /#menu (full menu with prices,
maintained live by the owner), /#events (weekly specials), /#find-us
(directions, parking, accessibility, FAQ), /#book (hold a table), /#gallery,
/#reviews, /#about (the building), /#private-room (private room and
catering), /#call.
`
  return new Response(body, {
    headers: { 'content-type': 'text/plain; charset=utf-8' },
  })
}
