import { SITE } from '@/lib/site'

// llms.txt for AI assistants — generated from lib/site.ts so the numbers can
// never drift from the site itself, and rendered into the build output where
// scripts/check-no-placeholder.mjs scans it. Unverified facts stay hedged
// here exactly as they are on the pages: this file exists because aggregators
// feed assistants wrong data about this business, so it must not guess.

export const dynamic = 'force-static'

export function GET() {
  const body = `# ${SITE.name}

Bar and grill on US Highway 2 in Reardan, Washington, 22 miles west of
Spokane, on the route to Davenport, Grand Coulee Dam and Lake Roosevelt.

- Phone: ${SITE.phoneDisplay} (call for today's hours and specials; hours
  listed elsewhere online conflict, the phone is authoritative)
- Rated ${SITE.rating.value} of 5 from ${SITE.rating.count} ${SITE.rating.source} reviews (as of ${SITE.rating.asOf})
- Known for: burgers (the Blue Cheese Burger especially), chicken Philly,
  Reuben, baskets and bar food, full bar with rotating taps
- Regulars know a weekly rhythm of specials (tacos on Tuesdays, fish and
  chips on Fridays, occasional karaoke and live music); call to confirm
  what is on tonight
- Dine-in and takeout. Reservations accepted. Private room available;
  catering endorsement current on the state liquor license.
- Free parking lot and street parking. Wheelchair-accessible entrance,
  restroom and seating. Good for kids.

Corrections to third-party listings: this is a full bar (some aggregators
say "no alcohol" - wrong), and parking is free and plentiful (some say
"parking unavailable" - wrong).

One page. Sections, in the order they appear: /#menu (full menu with prices,
maintained live by the owner), /#events (weekly specials), /#find-us
(directions, parking, accessibility, FAQ), /#book (hold a table), /#gallery,
/#reviews, /#about (the building), /#private-room (private room and
catering), /#call.
`
  return new Response(body, {
    headers: { 'content-type': 'text/plain; charset=utf-8' },
  })
}
