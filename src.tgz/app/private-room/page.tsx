import type { Metadata } from 'next'
import { Certificate, ForkKnife, Phone, UsersThree } from '@phosphor-icons/react/dist/ssr'
import { InquiryFallback } from '@/components/private-room/inquiry-fallback'
import { InquiryForm } from '@/components/private-room/inquiry-form'
import { Container } from '@/components/site/container'
import { Reveal } from '@/components/site/reveal'
import { ButtonA } from '@/components/ui/button'
import { TEL_HREF } from '@/lib/links'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Private Room & Catering',
  description: `${SITE.name} has a private dining room in Reardan, Washington, and a catering endorsement on its license. Tell us your date and headcount and we will tell you if the room fits.`,
}

// Capacity, minimums and deposits are genuinely unknown (CLIENT-QUESTIONS #7).
// Nothing on this page invents a number. What we can stand behind: the room
// exists (Google business attributes), the license carries a catering
// endorsement active through May 2027 (WSLCB, research/03 §A2), and one
// verbatim review of a catered event (Menupix, September 2023, research/01).
const FACTS = [
  {
    icon: UsersThree,
    title: 'There is a private room',
    body: 'A private dining room, part of the restaurant, and bookable. What it seats is the one thing we are not going to guess at in print.',
  },
  {
    icon: ForkKnife,
    title: 'A full bar comes with it',
    body: 'The full spirits license is current in state records. Beer, wine and cocktails, not just what is on tap.',
  },
  {
    icon: Certificate,
    title: 'Licensed to cater',
    body: 'Our license carries a catering endorsement, active in Washington State records through May 2027. Ask what we can bring and how far it travels.',
  },
] as const

const inquiryEnabled = process.env.NEXT_PUBLIC_INQUIRY_ENABLED === '1'

export default function PrivateRoomPage() {
  return (
    <>
      <section className="border-b border-hairline">
        <Container className="py-12 md:py-20">
          <h1 className="text-h1 leading-[1.05] font-extrabold uppercase tracking-[-0.02em] text-balance">
            The private room
          </h1>
          <p className="mt-6 max-w-[62ch] text-lg leading-relaxed">
            Yes, there is one, and yes you can have it. What we will not do is print a
            seating number we have not measured, because you would plan around it and
            we would both regret it. So here is the deal instead.{' '}
            <strong className="font-bold">
              Tell us your date and headcount and we will tell you if the room fits.
            </strong>
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonA href={TEL_HREF} variant="amber" size="lg">
              <Phone size={20} weight="bold" aria-hidden />
              Call {SITE.phoneDisplay}
            </ButtonA>
            <ButtonA href="#ask" variant="ghost" size="lg">
              Ask about a date
            </ButtonA>
          </div>
        </Container>
      </section>

      <section className="border-b border-hairline bg-surface">
        <Container className="py-12 md:py-20">
          <Reveal>
            <h2 className="text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
              What we can tell you today
            </h2>
            <dl className="mt-10 grid gap-8 md:grid-cols-3">
              {FACTS.map((fact) => (
                <div key={fact.title}>
                  <dt className="text-xl font-bold">
                    <fact.icon size={32} weight="bold" aria-hidden className="block" />
                    <span className="mt-4 block">{fact.title}</span>
                  </dt>
                  <dd className="mt-2 max-w-[48ch] leading-relaxed text-ink-muted">
                    {fact.body}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </Container>
      </section>

      {/* The one inverted ink band on this page (build/03 §1.4). It carries the
          only piece of outside proof we have that the catering is any good.
          Centered and set at h1: a 36ch pull quote on a 1200px band left four
          fifths of it empty, and a prose measure is the wrong tool for a
          statement band. */}
      <section className="bg-ink text-paper">
        <Container className="py-16 md:py-28">
          <Reveal>
            {/* rem, not ch: a ch measure on the figure resolves against the
                figure's own 16px, not the h1-sized quote inside it, which is
                how this band ended up 247px wide on a 1200px container. */}
            <figure className="mx-auto max-w-[40rem] text-center">
              <blockquote>
                <p className="text-h1 leading-[1.05] font-extrabold uppercase tracking-[-0.02em] text-balance">
                  &ldquo;The food was excellent.&rdquo;
                </p>
              </blockquote>
              <figcaption className="mt-6 font-mono text-sm">
                Menupix review of a catered event, September 2023
              </figcaption>
            </figure>
          </Reveal>
        </Container>
      </section>

      <section
        id="ask"
        className="scroll-mt-[calc(var(--header-h)+1rem)] border-b border-hairline"
      >
        <Container className="py-12 md:py-20">
          <Reveal>
            <div className="grid gap-10 lg:grid-cols-12">
              <div className="lg:col-span-4">
                <h2 className="text-h2 leading-[1.15] font-extrabold uppercase tracking-tight text-balance">
                  Ask about a date
                </h2>
                <p className="mt-4 max-w-[48ch] leading-relaxed text-ink-muted">
                  Capacity, deposits and what a booking includes are not published here
                  yet, because we have not pinned them down in writing. Ask and you get
                  the real numbers, not a range somebody typed into a website.
                </p>
              </div>
              <div className="lg:col-span-8">
                {inquiryEnabled ? <InquiryForm /> : <InquiryFallback />}
              </div>
            </div>
          </Reveal>
        </Container>
      </section>
    </>
  )
}
