// One favorites spot (1..4 — the DB CHECK is the real cap; slot 1 is the
// poster). PATCH changes the DISH (by id, verified against the live menu;
// null darkens the spot and its card drops) and/or the LINE under the
// name (empty falls back to the dish's own menu line). Favorites are the
// storefront, not the menu: changes go live immediately — no tray — and
// every change still writes its MenuEvent ledger row.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ slot: string }> }

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

function slotOf(raw: string): number | null {
  const slot = Number(raw)
  return Number.isInteger(slot) && slot >= 1 && slot <= 4 ? slot : null
}

export async function PATCH(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const slot = slotOf((await params).slot)
  if (slot === null) return fail(404, 'Four spots. That is not one of them.')

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const { dishId, blurb } = (body.value ?? {}) as { dishId?: unknown; blurb?: unknown }

  // Same posture as every PATCH back here: a wrong-typed field refuses
  // the WHOLE patch.
  if (
    (dishId !== undefined && dishId !== null && typeof dishId !== 'string') ||
    (blurb !== undefined && typeof blurb !== 'string')
  ) {
    return fail(400, 'Text fields only.')
  }
  if (dishId === undefined && blurb === undefined) return fail(400, 'Nothing to change.')

  let cleanBlurb: string | null | undefined
  if (typeof blurb === 'string') {
    const cleaned = sanitize(blurb)
    if (cleaned.length > 160) return fail(400, 'Keep the line under 160 characters.')
    cleanBlurb = cleaned || null
  }

  try {
    const db = getDb()
    const existing = await db.featureSpot.findUnique({ where: { slot } })
    const oldDish = existing?.dishId
      ? await db.menuDish.findUnique({ where: { id: existing.dishId }, select: { name: true } })
      : null

    let newDishName: string | null = oldDish?.name ?? null
    if (typeof dishId === 'string') {
      const dish = await db.menuDish.findUnique({ where: { id: dishId }, select: { name: true } })
      if (!dish) return fail(400, 'Not a dish on the menu.')
      newDishName = dish.name
    } else if (dishId === null) {
      newDishName = null
    }

    const nextDishId = dishId === undefined ? (existing?.dishId ?? null) : dishId
    const nextBlurb = cleanBlurb === undefined ? (existing?.blurb ?? null) : cleanBlurb

    const spot = await db.$transaction(async (tx) => {
      const row = await tx.featureSpot.upsert({
        where: { slot },
        create: { slot, dishId: nextDishId, blurb: nextBlurb },
        update: { dishId: nextDishId, blurb: nextBlurb },
      })
      if (dishId !== undefined && nextDishId !== (existing?.dishId ?? null)) {
        await tx.menuEvent.create({
          data: {
            actor: 'owner',
            dishId: nextDishId,
            dishName: newDishName ?? oldDish?.name ?? `Favorite spot ${slot}`,
            field: 'featured',
            from: oldDish?.name ?? null,
            to: newDishName,
          },
        })
      }
      if (cleanBlurb !== undefined && nextBlurb !== (existing?.blurb ?? null)) {
        await tx.menuEvent.create({
          data: {
            actor: 'owner',
            dishId: nextDishId,
            dishName: newDishName ?? `Favorite spot ${slot}`,
            field: 'feature-line',
            from: existing?.blurb ?? null,
            to: nextBlurb,
          },
        })
      }
      return row
    })

    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, spot, dishName: newDishName })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
