import { csrfOk } from '@/lib/auth/csrf'
import { clearedAuthCookies, requireSession, revokeSession } from '@/lib/auth/session'
import { isAllowedOrigin } from '@/lib/http/origin'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
// No mutation is ever a GET (build/08 §2 row 7), sign-out included.
export async function POST(request: Request) {
  if (!isAllowedOrigin(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }
  const session = await requireSession()
  if (!session) {
    return Response.json({ ok: false, message: 'Not signed in.' }, { status: 401 })
  }
  if (!csrfOk(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }

  // Server-side delete of the exact row requireSession validated — one
  // read path, not two (see revokeSession).
  await revokeSession(session.tokenHash)

  const headers = new Headers({ 'content-type': 'application/json' })
  for (const cookie of clearedAuthCookies()) headers.append('set-cookie', cookie)
  return new Response(JSON.stringify({ ok: true }), { status: 200, headers })
}
