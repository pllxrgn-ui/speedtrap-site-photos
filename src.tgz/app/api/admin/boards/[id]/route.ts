// Edit, reorder or remove one board (build/09 addendum). Renames touch the
// TITLE only — the id was minted at creation and never changes, so every
// existing #fragment and link keeps working. Reorders swap sortIndex with
// the neighbour. A board deletes only when it is EMPTY: dishes never
// disappear as a side effect of anything.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

export async function PATCH(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const { title, note, move } = (body.value ?? {}) as {
    title?: unknown
    note?: unknown
    move?: unknown
  }

  // Same posture as the dish PATCH: a wrong-typed field refuses the WHOLE
  // patch, and a move never rides along with a text edit — applying one
  // and not the other is a partial success nobody asked for.
  if (
    (title !== undefined && typeof title !== 'string') ||
    (note !== undefined && typeof note !== 'string') ||
    (move !== undefined && move !== 'up' && move !== 'down')
  ) {
    return fail(400, 'Text fields only.')
  }
  if (move !== undefined && (title !== undefined || note !== undefined)) {
    return fail(400, 'One change at a time.')
  }

  try {
    const db = getDb()
    const board = await db.menuBoard.findUnique({ where: { id: (await params).id } })
    if (!board) return fail(404, 'Not a board on the menu.')

    if (move !== undefined) {
      const neighbour = await db.menuBoard.findFirst({
        where: move === 'up' ? { sortIndex: { lt: board.sortIndex } } : { sortIndex: { gt: board.sortIndex } },
        orderBy: { sortIndex: move === 'up' ? 'desc' : 'asc' },
      })
      // Already at the edge: nothing to do, nothing to log.
      if (!neighbour) return Response.json({ ok: true, board })

      const updated = await db.$transaction(async (tx) => {
        const row = await tx.menuBoard.update({
          where: { id: board.id },
          data: { sortIndex: neighbour.sortIndex },
        })
        await tx.menuBoard.update({
          where: { id: neighbour.id },
          data: { sortIndex: board.sortIndex },
        })
        await tx.menuEvent.create({
          data: {
            actor: 'owner',
            dishName: board.title,
            field: 'board-order',
            from: String(board.sortIndex),
            to: String(neighbour.sortIndex),
          },
        })
        return row
      })
      revalidateTag('overlay', 'max')
      return Response.json({ ok: true, board: updated })
    }

    const changes: { field: 'board-renamed' | 'board-note'; from: string | null; to: string | null }[] = []
    const data: { title?: string; note?: string | null } = {}
    if (typeof title === 'string') {
      const cleaned = sanitize(title)
      if (cleaned.length < 1 || cleaned.length > 40) {
        return fail(400, 'A board needs a name, 40 characters or fewer.')
      }
      data.title = cleaned
      if (cleaned !== board.title) changes.push({ field: 'board-renamed', from: board.title, to: cleaned })
    }
    if (typeof note === 'string') {
      const cleaned = sanitize(note)
      if (cleaned.length > 200) return fail(400, 'Keep the note under 200 characters.')
      data.note = cleaned || null
      if ((cleaned || null) !== board.note) changes.push({ field: 'board-note', from: board.note, to: cleaned || null })
    }
    if (data.title === undefined && data.note === undefined) return fail(400, 'Nothing to change.')

    const updated = await db.$transaction(async (tx) => {
      const row = await tx.menuBoard.update({ where: { id: board.id }, data })
      for (const change of changes) {
        await tx.menuEvent.create({
          data: {
            actor: 'owner',
            // A rename is logged under the NEW title, same as a dish rename.
            dishName: change.field === 'board-renamed' ? (change.to ?? board.title) : (data.title ?? board.title),
            field: change.field,
            from: change.from,
            to: change.to,
          },
        })
      }
      return row
    })
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, board: updated })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  try {
    const db = getDb()
    const { id } = await params
    const board = await db.menuBoard.findUnique({ where: { id } })
    if (!board) return fail(404, 'Not a board on the menu.')

    const dishes = await db.menuDish.count({ where: { categoryId: id } })
    if (dishes > 0) return fail(400, 'Take its dishes off first — a board only goes when it is empty.')

    await db.$transaction([
      db.menuBoard.delete({ where: { id } }),
      db.menuEvent.create({
        data: { actor: 'owner', dishName: board.title, field: 'board-deleted', from: board.title },
      }),
    ])
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
