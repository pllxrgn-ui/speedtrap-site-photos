// Add a board (build/09 addendum). The board's id is minted ONCE from its
// first title and is opaque forever after — renames can never break a
// #fragment, a nav pill or a link someone already shared. Ids that would
// collide with a page section (or an existing board) get a random tail
// instead of a fight.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { SECTIONS } from '@/lib/links'
import { sanitize } from '@/lib/sanitize'

export const dynamic = 'force-dynamic'

// Every anchor the one-pager renders that is NOT a menu board. A board id
// landing on one of these would hijack an existing #fragment.
const RESERVED = new Set([
  'top',
  'call',
  'ask',
  ...SECTIONS.map((section) => section.href.slice(1)),
])

function slugOf(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 30)
    .replace(/-+$/g, '')
}

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return Response.json({ ok: false, message: 'Could not read that.' }, { status: 400 })
  const { title } = (body.value ?? {}) as { title?: unknown }
  if (typeof title !== 'string') {
    return Response.json({ ok: false, message: 'Text fields only.' }, { status: 400 })
  }
  const cleaned = sanitize(title)
  if (cleaned.length < 1 || cleaned.length > 40) {
    return Response.json(
      { ok: false, message: 'A board needs a name, 40 characters or fewer.' },
      { status: 400 },
    )
  }

  try {
    const db = getDb()
    const base = slugOf(cleaned)
    let id = base
    if (id.length === 0 || RESERVED.has(id) || (await db.menuBoard.findUnique({ where: { id } }))) {
      // 8 hex chars of tail: unique in practice; the PK catches the rest.
      id = `${base ? base.slice(0, 21) : 'board'}-${crypto.randomUUID().slice(0, 8)}`
    }
    const last = await db.menuBoard.findFirst({
      orderBy: { sortIndex: 'desc' },
      select: { sortIndex: true },
    })
    const board = await db.$transaction(async (tx) => {
      const created = await tx.menuBoard.create({
        data: { id, title: cleaned, sortIndex: (last?.sortIndex ?? -1) + 1 },
      })
      await tx.menuEvent.create({
        data: { actor: 'owner', dishName: created.title, field: 'board-created', to: created.id },
      })
      return created
    })
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, board }, { status: 201 })
  } catch {
    return Response.json(
      { ok: false, message: 'That did not stick. Refresh and retry.' },
      { status: 500 },
    )
  }
}
