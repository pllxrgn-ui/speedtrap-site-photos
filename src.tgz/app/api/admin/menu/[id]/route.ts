// Edit or remove one dish (build/09). PATCH takes any of {name,
// description, price} — price as a STRING the owner typed ("17", "17.50",
// "" for no price), parsed to integer cents here, never a float in the
// database. One MenuEvent per changed field, same transaction. DELETE
// removes the dish AND its 86 mark AND its photo row in one transaction
// (the blob dies best-effort), and the ledger records the dish BY NAME so
// the deletion stays legible after the row is gone.

import { del } from '@vercel/blob'
import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

// "17" | "17.5" | "17.50" | "$17.50" | "" -> cents | null; anything else
// refuses — a price the parser guessed at is worse than a refusal.
function parsePriceInput(raw: string): number | null | 'invalid' {
  const trimmed = raw.trim()
  if (trimmed === '') return null // empty means "no price", on purpose
  const cleaned = trimmed.replace(/^\$/, '')
  if (cleaned === '') return 'invalid' // a lone "$" is a typo, not a wipe
  if (!/^\d{1,4}(\.\d{1,2})?$/.test(cleaned)) return 'invalid'
  return Math.round(Number(cleaned) * 100)
}

export async function PATCH(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const { name, description, price, move } = (body.value ?? {}) as {
    name?: unknown
    description?: unknown
    price?: unknown
    move?: unknown
  }

  // A wrong-typed field refuses the WHOLE patch - silently dropping one
  // change while applying another is a partial success nobody asked for.
  if (
    (name !== undefined && typeof name !== 'string') ||
    (description !== undefined && typeof description !== 'string') ||
    (price !== undefined && typeof price !== 'string') ||
    (move !== undefined && move !== 'up' && move !== 'down')
  ) {
    return fail(400, 'Text fields only.')
  }
  // A move never rides along with a text edit — same one-or-the-other
  // posture as the board PATCH.
  if (move !== undefined && (name !== undefined || description !== undefined || price !== undefined)) {
    return fail(400, 'One change at a time.')
  }

  if (move !== undefined) {
    try {
      const db = getDb()
      const dish = await db.menuDish.findUnique({ where: { id: (await params).id } })
      if (!dish) return fail(404, 'Not on the menu.')
      const neighbour = await db.menuDish.findFirst({
        where: {
          categoryId: dish.categoryId,
          sortIndex: move === 'up' ? { lt: dish.sortIndex } : { gt: dish.sortIndex },
        },
        orderBy: { sortIndex: move === 'up' ? 'desc' : 'asc' },
      })
      // Already at the edge of its board: nothing to do, nothing to log.
      if (!neighbour) return Response.json({ ok: true, dish })

      const updated = await db.$transaction(async (tx) => {
        const row = await tx.menuDish.update({
          where: { id: dish.id },
          data: { sortIndex: neighbour.sortIndex },
        })
        await tx.menuDish.update({
          where: { id: neighbour.id },
          data: { sortIndex: dish.sortIndex },
        })
        await tx.menuEvent.create({
          data: {
            actor: 'owner',
            dishId: dish.id,
            dishName: dish.name,
            field: 'order',
            from: String(dish.sortIndex),
            to: String(neighbour.sortIndex),
          },
        })
        return row
      })
      revalidateTag('overlay', 'max')
      return Response.json({ ok: true, dish: updated })
    } catch {
      return fail(500, 'That did not stick. Refresh and retry.')
    }
  }

  const changes: { field: 'name' | 'description' | 'price'; value: string | number | null }[] = []
  if (typeof name === 'string') {
    const cleaned = sanitize(name)
    if (cleaned.length < 1 || cleaned.length > 60) {
      return fail(400, 'A dish needs a name, 60 characters or fewer.')
    }
    changes.push({ field: 'name', value: cleaned })
  }
  if (typeof description === 'string') {
    const cleaned = sanitize(description)
    if (cleaned.length > 200) return fail(400, 'Keep the description under 200 characters.')
    changes.push({ field: 'description', value: cleaned || null })
  }
  if (typeof price === 'string') {
    const cents = parsePriceInput(price)
    if (cents === 'invalid') return fail(400, 'A price like 17 or 17.50 — or empty for none.')
    if (cents !== null && cents > 999_99) return fail(400, 'That is not a bar price.')
    changes.push({ field: 'price', value: cents })
  }
  if (changes.length === 0) return fail(400, 'Nothing to change.')

  try {
    const db = getDb()
    const dish = await db.menuDish.findUnique({ where: { id: (await params).id } })
    if (!dish) return fail(404, 'Not on the menu.')

    const centsLabel = (cents: number | null) =>
      cents === null ? null : `$${(cents / 100).toFixed(2)}`

    const updated = await db.$transaction(async (tx) => {
      const data: Record<string, string | number | null> = {}
      for (const change of changes) {
        if (change.field === 'name') data.name = change.value as string
        if (change.field === 'description') data.description = change.value as string | null
        if (change.field === 'price') data.priceCents = change.value as number | null
      }
      const row = await tx.menuDish.update({ where: { id: dish.id }, data })
      for (const change of changes) {
        const from =
          change.field === 'name'
            ? dish.name
            : change.field === 'description'
              ? dish.description
              : centsLabel(dish.priceCents)
        const to =
          change.field === 'price' ? centsLabel(change.value as number | null) : (change.value as string | null)
        if (from === to) continue // an edit that changed nothing logs nothing
        await tx.menuEvent.create({
          data: {
            actor: 'owner',
            dishId: dish.id,
            dishName: change.field === 'name' ? (to ?? dish.name) : dish.name,
            field: change.field,
            from,
            to,
          },
        })
      }
      return row
    })

    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, dish: updated })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  try {
    const db = getDb()
    const { id } = await params
    const dish = await db.menuDish.findUnique({ where: { id } })
    if (!dish) return fail(404, 'Not on the menu.')
    const photo = await db.dishPhoto.findUnique({ where: { itemKey: id } })

    await db.$transaction([
      db.itemState.deleteMany({ where: { itemKey: id } }),
      db.dishPhoto.deleteMany({ where: { itemKey: id } }),
      db.menuDish.delete({ where: { id } }),
      db.menuEvent.create({
        data: { actor: 'owner', dishId: id, dishName: dish.name, field: 'deleted', from: dish.name },
      }),
    ])

    if (photo && process.env.BLOB_READ_WRITE_TOKEN) {
      try {
        await del(photo.url)
      } catch {
        /* orphaned blob, nothing else */
      }
    }

    revalidateTag('overlay', 'max')
    return Response.json({ ok: true })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
