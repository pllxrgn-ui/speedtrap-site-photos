// Add a dish (build/09 owner's-word regime). Every menu change writes a
// MenuEvent ledger row IN THE SAME TRANSACTION — the append-only ledger is
// what replaced the drift canaries, so a write without its ledger row is
// the one thing this API must make impossible.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { CATEGORIES } from '@/lib/menu'

export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return Response.json({ ok: false, message: 'Could not read that.' }, { status: 400 })
  const { categoryId } = (body.value ?? {}) as { categoryId?: unknown }
  if (
    typeof categoryId !== 'string' ||
    !CATEGORIES.some((category) => category.id === categoryId)
  ) {
    return Response.json({ ok: false, message: 'Not one of the seven boards.' }, { status: 400 })
  }

  try {
    const db = getDb()
    const last = await db.menuDish.findFirst({
      where: { categoryId },
      orderBy: { sortIndex: 'desc' },
      select: { sortIndex: true },
    })
    const dish = await db.$transaction(async (tx) => {
      const created = await tx.menuDish.create({
        data: {
          // New dishes get an opaque id (cuid); only the seed used menuKeys.
          id: `dish-${crypto.randomUUID()}`,
          categoryId,
          name: 'New dish',
          priceCents: null,
          sortIndex: (last?.sortIndex ?? -1) + 1,
        },
      })
      await tx.menuEvent.create({
        data: { actor: 'owner', dishId: created.id, dishName: created.name, field: 'created' },
      })
      return created
    })
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, dish }, { status: 201 })
  } catch {
    return Response.json({ ok: false, message: 'That did not stick. Refresh and retry.' }, { status: 500 })
  }
}
