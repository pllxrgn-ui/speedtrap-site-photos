// Status changes and hard deletes for one booking (build/08 §4). Every
// mutation: requireSession + double-submit CSRF + origin, transitions
// validated server-side against lib/booking-status.ts, and the
// BookingEvent lands in the SAME transaction as the change — an audit
// trail that can drift from its row is theater.

import { csrfOk } from '@/lib/auth/csrf'
import { requireSession } from '@/lib/auth/session'
import { canTransition, ALLOWED_TRANSITIONS } from '@/lib/booking-status'
import { getDb } from '@/lib/db'
import { isAllowedOrigin } from '@/lib/http/origin'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

function guardFailure(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

async function guards(request: Request): Promise<Response | null> {
  if (!isAllowedOrigin(request)) return guardFailure(403, 'Not allowed.')
  const session = await requireSession()
  if (!session) return guardFailure(401, 'Not signed in.')
  if (!csrfOk(request)) return guardFailure(403, 'Not allowed.')
  return null
}

export async function PATCH(request: Request, { params }: Params) {
  const refused = await guards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) {
    // The cap and a broken body are different problems: an owner pasting a
    // long note deserves "too long", not "your browser broke".
    return body.reason === 'too-large'
      ? guardFailure(413, 'Note is too long. Keep it under 500 characters.')
      : guardFailure(400, 'Could not read that.')
  }
  const { status, note } = (body.value ?? {}) as { status?: unknown; note?: unknown }

  const wantsStatus = typeof status === 'string'
  const wantsNote = typeof note === 'string'
  if (!wantsStatus && !wantsNote) return guardFailure(400, 'Nothing to change.')
  // Object.hasOwn, not `in`: "__proto__" and friends must not walk the
  // prototype chain into an authenticated DB read (review finding 1).
  if (wantsStatus && !Object.hasOwn(ALLOWED_TRANSITIONS, status)) {
    return guardFailure(400, 'Not a status.')
  }
  if (wantsNote && note.length > 500) return guardFailure(400, 'Note is too long.')

  try {
    const db = getDb()
    const booking = await db.booking.findUnique({ where: { id: (await params).id } })
    if (!booking) return guardFailure(404, 'Not in the book.')

    const nextStatus = wantsStatus ? (status as keyof typeof ALLOWED_TRANSITIONS) : undefined
    if (nextStatus && !canTransition(booking.status, nextStatus)) {
      return guardFailure(
        400,
        `Cannot go from ${booking.status} to ${nextStatus}.`,
      )
    }

    const updated = await db.$transaction(async (tx) => {
      const row = await tx.booking.update({
        where: { id: booking.id },
        data: {
          ...(nextStatus ? { status: nextStatus } : {}),
          ...(wantsNote ? { note: note ? sanitize(note) : null } : {}),
        },
      })
      await tx.bookingEvent.create({
        data: {
          bookingId: booking.id,
          actor: 'owner',
          from: nextStatus ? booking.status : null,
          to: nextStatus ?? null,
          // A note edit is recorded even when it rides along with a status
          // change — the audit trail is load-bearing, not decorative
          // (review finding 4).
          note: wantsNote ? 'note edited' : null,
        },
      })
      return row
    })

    return Response.json({ ok: true, booking: updated })
  } catch {
    return guardFailure(500, 'That change did not stick. Refresh and retry.')
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const refused = await guards(request)
  if (refused) return refused

  try {
    const db = getDb()
    const { id } = await params
    const booking = await db.booking.findUnique({ where: { id }, select: { id: true } })
    if (!booking) return guardFailure(404, 'Not in the book.')

    // Hard delete, cascading the audit trail, leaving the PII-free
    // DeletionLog row — deletion stays real, the count survives (§1).
    await db.$transaction([
      db.deletionLog.create({ data: { bookingId: booking.id, reason: 'owner-deleted' } }),
      db.booking.delete({ where: { id: booking.id } }),
    ])
    return Response.json({ ok: true })
  } catch {
    return guardFailure(500, 'That delete did not stick. Refresh and retry.')
  }
}
