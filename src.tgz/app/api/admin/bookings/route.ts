// THE BOOK's data feed, minimal Phase 3 shape (build/08 §4 — the full
// filter set and PATCH/DELETE land with the admin UI in Phase 4). Reading
// PII, so: requireSession in the handler (the gate grep checks), never
// cached, node runtime for Prisma.

import { adminGuards } from '@/lib/admin/guards'
import { requireSession } from '@/lib/auth/session'
import { bookingSchema, phoneDigits, presanitizeBooking, purgeAfterOf } from '@/lib/booking'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { newReference } from '@/lib/reference'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

const STATUSES = ['new', 'confirmed', 'declined', 'cancelled', 'no_show', 'completed'] as const
type Status = (typeof STATUSES)[number]

export async function GET(request: Request) {
  const session = await requireSession()
  if (!session) {
    return Response.json({ ok: false, message: 'Not signed in.' }, { status: 401 })
  }

  const url = new URL(request.url)
  const statusParam = url.searchParams.get('status')
  const status = STATUSES.includes(statusParam as Status) ? (statusParam as Status) : undefined

  try {
    const bookings = await getDb().booking.findMany({
      where: status ? { status } : undefined,
      orderBy: [{ requestedOn: 'asc' }, { createdAt: 'asc' }],
      take: 200,
    })
    return Response.json({ ok: true, bookings })
  } catch {
    // Same posture as every PII route: nothing about the failure leaves
    // the process (veto 16).
    return Response.json({ ok: false, message: 'Could not load the book. Refresh.' }, { status: 500 })
  }
}

// STAFF-ENTERED bookings (Smoky Mug integration, 2026-09-23): the phone
// rings, the owner says yes, and THE BOOK is where it lands - one book of
// record for web AND phone. The call already happened, so the row is born
// CONFIRMED (no call-back loop for a booking taken on the phone), with an
// audit event saying who entered it. Same validation as the public form
// (bookingSchema), same dedup floor - a double entry answers with the
// existing reference instead of a second ticket.
export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 16 * 1024)
  if (!body.ok) return Response.json({ ok: false, message: 'Could not read that.' }, { status: 400 })

  const parsed = bookingSchema.safeParse(presanitizeBooking(body.value))
  if (!parsed.success) {
    const issue = parsed.error.issues[0]
    return Response.json(
      { ok: false, message: issue?.message ?? 'Check the form and try again.' },
      { status: 400 },
    )
  }
  const input = parsed.data
  const digits = phoneDigits(input.phone)

  try {
    const db = getDb()
    const existing = await db.booking.findUnique({
      where: {
        phoneDigits_requestedOn_timeWindow: {
          phoneDigits: digits,
          requestedOn: new Date(`${input.date}T00:00:00Z`),
          timeWindow: input.timeWindow,
        },
      },
    })
    if (existing) {
      return Response.json({ ok: true, duplicate: true, booking: existing })
    }

    const booking = await db.$transaction(async (tx) => {
      const created = await tx.booking.create({
        data: {
          reference: newReference(),
          status: 'confirmed',
          name: input.name,
          phone: input.phone,
          phoneDigits: digits,
          partySize: input.partySize,
          requestedOn: new Date(`${input.date}T00:00:00Z`),
          timeWindow: input.timeWindow,
          note: input.note || null,
          purgeAfter: purgeAfterOf(input.date),
        },
      })
      await tx.bookingEvent.create({
        data: { bookingId: created.id, actor: 'owner', from: null, to: 'confirmed', note: 'entered at the bar' },
      })
      return created
    })
    return Response.json({ ok: true, booking }, { status: 201 })
  } catch {
    return Response.json(
      { ok: false, message: 'That did not stick. Refresh and retry.' },
      { status: 500 },
    )
  }
}
