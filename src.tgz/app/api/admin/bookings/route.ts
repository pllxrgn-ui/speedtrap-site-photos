// THE BOOK's data feed, minimal Phase 3 shape (build/08 §4 — the full
// filter set and PATCH/DELETE land with the admin UI in Phase 4). Reading
// PII, so: requireSession in the handler (the gate grep checks), never
// cached, node runtime for Prisma.

import { requireSession } from '@/lib/auth/session'
import { getDb } from '@/lib/db'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

const STATUSES = ['new', 'confirmed', 'declined', 'cancelled', 'no_show', 'completed'] as const
type Status = (typeof STATUSES)[number]

export async function GET(request: Request) {
  const session = await requireSession()
  if (!session) {
    return Response.json({ ok: false, message: 'Not signed in.' }, { status: 401 })
  }

  const url = new URL(request.url)
  const statusParam = url.searchParams.get('status')
  const status = STATUSES.includes(statusParam as Status) ? (statusParam as Status) : undefined

  try {
    const bookings = await getDb().booking.findMany({
      where: status ? { status } : undefined,
      orderBy: [{ requestedOn: 'asc' }, { createdAt: 'asc' }],
      take: 200,
    })
    return Response.json({ ok: true, bookings })
  } catch {
    // Same posture as every PII route: nothing about the failure leaves
    // the process (veto 16).
    return Response.json({ ok: false, message: 'Could not load the book. Refresh.' }, { status: 500 })
  }
}
