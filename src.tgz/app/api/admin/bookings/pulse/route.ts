// THE WATCHER's heartbeat (build/09 addendum 5). The admin left open on
// the bar's laptop polls this once a minute; a fresh arrival makes the
// browser cling. Deliberately PII-FREE — a count and a timestamp cross
// the wire every minute, never a name or a phone — and read-only, so a
// stolen response tells nobody anything worth stealing.

import { requireSession } from '@/lib/auth/session'
import { getDb } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  const session = await requireSession()
  if (!session) {
    return Response.json({ ok: false, message: 'Sign in first.' }, { status: 401 })
  }

  try {
    const db = getDb()
    const [newCount, latest] = await Promise.all([
      db.booking.count({ where: { status: 'new' } }),
      db.booking.findFirst({
        where: { status: 'new' },
        orderBy: { createdAt: 'desc' },
        select: { createdAt: true },
      }),
    ])
    return Response.json({
      ok: true,
      newCount,
      latestAt: latest?.createdAt.toISOString() ?? null,
    })
  } catch {
    return Response.json({ ok: false, message: 'Could not read the book.' }, { status: 500 })
  }
}
