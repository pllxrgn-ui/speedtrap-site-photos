// Manual republish (build/08 §4): re-stamps every live special's
// publishedAt to NOW — the freshness line on the page goes back to "From
// the kitchen, today." — and busts the overlay cache. Staleness is shown,
// never hidden; this is the owner saying "still true".

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused
  try {
    const stamped = await getDb().special.updateMany({
      where: { published: true },
      data: { publishedAt: new Date() },
    })
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, restamped: stamped.count })
  } catch {
    return Response.json({ ok: false, message: 'That did not stick. Refresh and retry.' }, { status: 500 })
  }
}
