// "Today's note" — one row, 160 characters, expires at the bar's next
// morning on its own so a Tuesday note cannot greet a Thursday customer.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

function nextBarMorning(now: Date): Date {
  const next = new Date(now)
  next.setUTCHours(9, 0, 0, 0)
  if (next.getTime() <= now.getTime()) next.setUTCDate(next.getUTCDate() + 1)
  return next
}

export async function PUT(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return Response.json({ ok: false, message: 'Could not read that.' }, { status: 400 })
  const { body: text, published } = (body.value ?? {}) as { body?: unknown; published?: unknown }

  const note = typeof text === 'string' ? sanitize(text) : ''
  if (note.length > 160) {
    return Response.json({ ok: false, message: 'Keep it under 160 characters.' }, { status: 400 })
  }
  const live = published === true && note.length > 0

  try {
    const now = new Date()
    const data = { body: note || null, published: live, expiresAt: live ? nextBarMorning(now) : null }
    const saved = await getDb().siteNote.upsert({
      where: { id: 1 },
      create: { id: 1, ...data },
      update: data,
    })
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, note: saved })
  } catch {
    return Response.json({ ok: false, message: 'That did not stick. Refresh and retry.' }, { status: 500 })
  }
}
