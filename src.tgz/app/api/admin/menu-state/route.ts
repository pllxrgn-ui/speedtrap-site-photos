// The 86 board (build/08 fork C). Setting a mark REQUIRES a hold and the
// expiry is computed here, automatically — a dish left 86'd forever makes
// the site lie (veto 13; 'cleared' is the deliberate no-expiry exception
// the owner has to pick on purpose). Keys are validated against the code
// menu, so an orphan can only ARISE from a rename (caught by the 50-key
// canary), never be created fresh.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { MENU_KEY_SET } from '@/lib/menu-keys'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

const HOLDS = ['tonight', 'this_week', 'cleared'] as const
type Hold = (typeof HOLDS)[number]

// "Tonight" ends when the bar's day does: the next 09:00 UTC (2am Pacific)
// - the same clock the purge cron runs on.
function nextBarMorning(now: Date): Date {
  const next = new Date(now)
  next.setUTCHours(9, 0, 0, 0)
  if (next.getTime() <= now.getTime()) next.setUTCDate(next.getUTCDate() + 1)
  return next
}

function expiryFor(hold: Hold, now: Date): Date | null {
  if (hold === 'tonight') return nextBarMorning(now)
  if (hold === 'this_week') return new Date(nextBarMorning(now).getTime() + 6 * 86_400_000)
  return null // 'cleared': off until the owner clears it, shown as such
}

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return Response.json({ ok: false, message: 'Could not read that.' }, { status: 400 })
  const { itemKey, soldOut, hold } = (body.value ?? {}) as {
    itemKey?: unknown
    soldOut?: unknown
    hold?: unknown
  }

  if (typeof itemKey !== 'string' || itemKey.length === 0 || itemKey.length > 60) {
    return Response.json({ ok: false, message: 'Not a dish on the printed menu.' }, { status: 400 })
  }
  if (typeof soldOut !== 'boolean') {
    return Response.json({ ok: false, message: 'On or off — nothing else.' }, { status: 400 })
  }
  // A fresh 86 must name a dish on the printed menu; an ORPHAN (its dish
  // was renamed in code) may only be CLEARED — the strip in the admin
  // exists exactly so these rows can die (build/08 §1).
  if (soldOut && !MENU_KEY_SET.has(itemKey)) {
    return Response.json({ ok: false, message: 'Not a dish on the printed menu.' }, { status: 400 })
  }
  const chosenHold: Hold =
    typeof hold === 'string' && (HOLDS as readonly string[]).includes(hold)
      ? (hold as Hold)
      : 'tonight'

  try {
    const now = new Date()
    const db = getDb()
    let state
    if (soldOut) {
      const data = { soldOut: true, hold: chosenHold, expiresAt: expiryFor(chosenHold, now) }
      state = await db.itemState.upsert({
        where: { itemKey },
        create: { itemKey, ...data },
        update: data,
      })
    } else {
      // Clearing never CREATES a row (review: an upsert here was unbounded
      // row creation through the admin API) — clearing a mark that does
      // not exist is a success that writes nothing.
      await db.itemState.updateMany({
        where: { itemKey },
        data: { soldOut: false, hold: 'cleared', expiresAt: null },
      })
      state = { itemKey, soldOut: false, hold: 'cleared', expiresAt: null }
    }
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, state })
  } catch {
    return Response.json({ ok: false, message: 'That did not stick. Refresh and retry.' }, { status: 500 })
  }
}
