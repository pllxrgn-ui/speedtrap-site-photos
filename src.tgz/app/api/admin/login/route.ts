// Admin sign-in (build/08 §2 rows 6-8). Password only — no email, no
// "forgot", no signup. A reset is Pol re-running scripts/hash-password.mjs
// and updating ADMIN_PASSWORD_HASH; lockout is always a 429 with a window,
// never permanent (veto 9 — the owner locked out on a Saturday night is
// worse than a slow brute force against a generated passphrase).

import { verifyPassword, withMinDuration } from '@/lib/auth/password'
import { newCsrfToken } from '@/lib/auth/csrf'
import { createSession, csrfCookie, sessionCookie } from '@/lib/auth/session'
import { getDb } from '@/lib/db'
import { isAllowedOrigin } from '@/lib/http/origin'
import { readJsonCapped } from '@/lib/http/read-capped'
import { clientIpOf, hashIp } from '@/lib/pii'
import { loginWindows, takeRateSlots } from '@/lib/rate-limit'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
const MAX_BODY_BYTES = 4 * 1024
const RESPONSE_FLOOR_MS = 250

export async function POST(request: Request) {
  if (!isAllowedOrigin(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }
  if (!request.headers.get('content-type')?.includes('application/json')) {
    return Response.json({ ok: false, message: 'Send JSON.' }, { status: 415 })
  }

  const body = await readJsonCapped(request, MAX_BODY_BYTES)
  if (!body.ok) {
    return Response.json({ ok: false, message: 'Could not read that.' }, { status: 400 })
  }

  try {
    const db = getDb()
    const ipHash = hashIp(clientIpOf(request))

    // Every attempt counts — right, wrong, malformed, or unconfigured — so
    // no shape of probe is free and unbounded (review: the 503 and the
    // shape-401 used to return before any slot was taken).
    const rate = await takeRateSlots(db, loginWindows(ipHash))
    if (!rate.allowed) {
      return Response.json(
        { ok: false, message: 'Too many tries. Wait a few minutes.' },
        { status: 429, headers: { 'retry-after': String(rate.retryAfterSeconds) } },
      )
    }

    // DELIBERATE: the shape 401 sits inside the rate window but OUTSIDE
    // the floor — its timing reveals only what the sender already knows
    // (their own body was malformed); the floor exists to blur verify.
    const password = (body.value as { password?: unknown } | null)?.password
    if (typeof password !== 'string' || password.length < 1 || password.length > 256) {
      return Response.json({ ok: false, message: 'Wrong password.' }, { status: 401 })
    }

    const stored = process.env.ADMIN_PASSWORD_HASH
    if (!stored) {
      return Response.json({ ok: false, message: 'Sign-in is not configured.' }, { status: 503 })
    }

    // The floor covers verify AND session creation so a success does not
    // return measurably slower than a failure (§2 row 6).
    return await withMinDuration(RESPONSE_FLOOR_MS, async () => {
      const valid = await verifyPassword(password, stored)
      if (!valid) {
        return Response.json({ ok: false, message: 'Wrong password.' }, { status: 401 })
      }
      const token = await createSession(ipHash)
      const headers = new Headers({ 'content-type': 'application/json' })
      headers.append('set-cookie', sessionCookie(token))
      headers.append('set-cookie', csrfCookie(newCsrfToken()))
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers })
    })
  } catch {
    return Response.json({ ok: false, message: 'Sign-in failed. Try again.' }, { status: 500 })
  }
}
