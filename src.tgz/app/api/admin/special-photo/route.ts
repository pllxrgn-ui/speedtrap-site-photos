// Owner-uploaded special photos (build/09 addendum 2). Same Blob store,
// same 4MB cap and multipart posture as dish photos (audit M6), keyed to
// the SLOT (1..3). The photo lives on the Special row itself, so clearing
// a slot's text keeps its photo until the owner removes or replaces it.

import { del, put } from '@vercel/blob'
import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readBodyCapped, readJsonCapped } from '@/lib/http/read-capped'

export const dynamic = 'force-dynamic'

const MAX_PHOTO_BYTES = 4 * 1024 * 1024
const TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
}

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

function slotOf(raw: unknown): number | null {
  const slot = Number(raw)
  return Number.isInteger(slot) && slot >= 1 && slot <= 3 ? slot : null
}

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  if (!process.env.BLOB_READ_WRITE_TOKEN) {
    return fail(503, 'Photo storage is not connected yet.')
  }

  // Byte-counting cap BEFORE formData() — same M6 posture as dish-photo.
  const capped = await readBodyCapped(request, MAX_PHOTO_BYTES + 64 * 1024)
  if (!capped.ok) {
    return capped.reason === 'too-large'
      ? fail(413, 'That photo is over 4MB. Send a smaller one.')
      : fail(400, 'Could not read that upload.')
  }

  let form: FormData
  try {
    form = await new Request(request.url, {
      method: 'POST',
      headers: { 'content-type': request.headers.get('content-type') ?? '' },
      body: new Uint8Array(capped.bytes),
    }).formData()
  } catch {
    return fail(400, 'Could not read that upload.')
  }

  const slot = slotOf(form.get('slot'))
  const file = form.get('file')
  if (slot === null) return fail(400, 'Three slots. That is not one of them.')
  if (!(file instanceof File)) return fail(400, 'No photo in that upload.')
  if (!(file.type in TYPES)) return fail(415, 'JPEG, PNG or WebP only.')
  if (file.size === 0) return fail(400, 'That file is empty.')
  if (file.size > MAX_PHOTO_BYTES) return fail(413, 'That photo is over 4MB. Send a smaller one.')

  try {
    const db = getDb()
    const existing = await db.special.findUnique({ where: { id: slot } })

    const blob = await put(`specials/slot-${slot}.${TYPES[file.type]}`, file, {
      access: 'public',
      addRandomSuffix: true, // a replace gets a NEW url — no stale CDN copy
      contentType: file.type,
    })

    // A photo can land before the slot's text has ever been saved — the
    // upsert creates a dark placeholder row (unpublished, no title), which
    // the editor already renders as an empty slot.
    const alt = existing?.title ? `${existing.title}, as served` : 'Today’s special, as served'
    const special = await db.special.upsert({
      where: { id: slot },
      create: {
        id: slot,
        title: '',
        published: false,
        startsOn: new Date(),
        photoUrl: blob.url,
        photoAlt: alt,
      },
      update: { photoUrl: blob.url, photoAlt: alt },
    })

    // Best-effort cleanup, sync-throw-safe (same accepted cost as dishes).
    if (existing?.photoUrl && existing.photoUrl !== blob.url) {
      try {
        await del(existing.photoUrl)
      } catch {
        /* orphaned blob, nothing else */
      }
    }

    revalidateTag('overlay', 'max')
    return Response.json({
      ok: true,
      photo: { src: special.photoUrl as string, alt: special.photoAlt ?? alt },
    })
  } catch {
    return fail(500, 'That upload did not stick. Try it again.')
  }
}

export async function DELETE(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const slot = slotOf(((body.value ?? {}) as { slot?: unknown }).slot)
  if (slot === null) return fail(400, 'Three slots. That is not one of them.')

  try {
    const db = getDb()
    const existing = await db.special.findUnique({ where: { id: slot } })
    if (existing?.photoUrl) {
      await db.special.update({
        where: { id: slot },
        data: { photoUrl: null, photoAlt: null },
      })
      if (process.env.BLOB_READ_WRITE_TOKEN) {
        try {
          await del(existing.photoUrl)
        } catch {
          /* orphaned blob, nothing else */
        }
      }
    }
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true })
  } catch {
    return fail(500, 'That did not stick. Try it again.')
  }
}
