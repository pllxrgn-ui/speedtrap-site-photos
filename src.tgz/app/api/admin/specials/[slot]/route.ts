// One specials slot (1..3 — the DB CHECK is the real cap). PUT replaces
// the slot; DELETE clears it. priceLabel is a sanitized LABEL and nothing
// here can touch a board price (build/08 veto 4). Every write ends with
// revalidateTag('overlay', 'max') — that is what makes a publish visible on the very
// next request (veto 6, as amended in the as-built notes).

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ slot: string }> }

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

function slotOf(raw: string): number | null {
  const slot = Number(raw)
  return Number.isInteger(slot) && slot >= 1 && slot <= 3 ? slot : null
}

export async function PUT(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const slot = slotOf((await params).slot)
  if (slot === null) return fail(404, 'Three slots. That is not one of them.')

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const raw = (body.value ?? {}) as {
    title?: unknown
    body?: unknown
    priceLabel?: unknown
    published?: unknown
  }

  const title = typeof raw.title === 'string' ? sanitize(raw.title) : ''
  if (title.length < 1 || title.length > 60) {
    return fail(400, 'A special needs a name, 60 characters or fewer.')
  }
  const text = typeof raw.body === 'string' ? sanitize(raw.body) : ''
  if (text.length > 200) return fail(400, 'Keep the description under 200 characters.')
  const priceLabel = typeof raw.priceLabel === 'string' ? sanitize(raw.priceLabel) : ''
  if (priceLabel.length > 16) return fail(400, 'The price label is 16 characters, max.')
  const published = raw.published === true

  try {
    const db = getDb()
    const existing = await db.special.findUnique({ where: { id: slot } })
    const now = new Date()
    const data = {
      title,
      body: text || null,
      priceLabel: priceLabel || null,
      published,
      // publishedAt is THE provenance stamp the page prints: set when a
      // special goes live (or is re-published), kept while it only edits.
      publishedAt: published
        ? existing?.published
          ? (existing.publishedAt ?? now)
          : now
        : existing?.publishedAt ?? null,
      startsOn: existing?.startsOn ?? now,
    }
    const special = await db.special.upsert({
      where: { id: slot },
      create: { id: slot, ...data },
      update: data,
    })
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, special })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const slot = slotOf((await params).slot)
  if (slot === null) return fail(404, 'Three slots. That is not one of them.')

  try {
    const db = getDb()
    // Addendum 2: clearing a slot's TEXT keeps its photo — the photo goes
    // through /api/admin/special-photo explicitly. A slot with a photo
    // clears down to a dark placeholder row instead of deleting.
    const existing = await db.special.findUnique({ where: { id: slot } })
    if (existing?.photoUrl) {
      await db.special.update({
        where: { id: slot },
        data: { title: '', body: null, priceLabel: null, published: false, publishedAt: null },
      })
    } else {
      await db.special.deleteMany({ where: { id: slot } })
    }
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
