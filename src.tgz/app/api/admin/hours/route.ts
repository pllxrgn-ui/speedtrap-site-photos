// THE WEEK (build/13 section 5). ONE declarative PUT carries all seven days,
// each as { state: 'unset' } | { state: 'closed' } | { state: 'open', open,
// close }. There is deliberately no /api/admin/hours/[day]:
//
//   - the publish is ATOMIC, which is the whole regime (section 0.5 - seven
//     half-typed rows must not go live between taps);
//   - the endpoint is idempotent, so a double tap costs nothing;
//   - the id-in-path question never opens for days.
//
// `unset` DELETES the row, because absence of a row is UNSET and UNSET is not
// closed (section 1.1). The editor ships empty and the page has to be able to
// say so.
//
// Every changed day writes one HoursEvent in the SAME transaction (the
// MenuEvent pattern, ported) and a day that did not change writes nothing at
// all - menu/[id]/route.ts:153's rule.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { dayField, sameDay } from '@/lib/admin/hours-writes'
import { getDb } from '@/lib/db'
import { DAY_ORDER, dayLedgerValue, isPublishable, weekSchema, type DayId } from '@/lib/hours'
import { readJsonCapped } from '@/lib/http/read-capped'

// Node runtime (the App Router default for route handlers - Prisma needs it).
// The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08).
export const dynamic = 'force-dynamic'

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

export async function PUT(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')

  // zod rather than hand-rolled typeof checks: this body is seven objects
  // carrying a discriminated union, and the schema lives in lib/hours.ts so
  // the client pre-validates against the identical rules (section 5.1). The
  // refusal the owner reads is the schema's own sentence.
  const parsed = weekSchema.safeParse(body.value)
  if (!parsed.success) {
    return fail(400, parsed.error.issues[0]?.message ?? 'That week did not make sense.')
  }

  const wantedByDay = new Map(parsed.data.days.map((day) => [day.day, day]))

  try {
    const saved = await getDb().$transaction(async (tx) => {
      const before = await tx.hoursDay.findMany()
      const beforeByDay = new Map(before.map((row) => [row.day, row]))

      // OVER DAY_ORDER, never over the parsed body's order and never over
      // findMany()'s: HoursDay.day is a String @id, so Postgres hands back
      // fri,mon,sat,sun,thu,tue,wed and nothing in it knows Monday comes
      // first (section 2.3).
      for (const day of DAY_ORDER) {
        const wanted = wantedByDay.get(day)
        if (!wanted) continue // weekSchema already refused a short week
        const prior = beforeByDay.get(day) ?? null
        if (sameDay(prior, wanted)) continue // no change, no write, no row

        if (wanted.state === 'unset') {
          await tx.hoursDay.delete({ where: { day } })
        } else {
          const data =
            wanted.state === 'closed'
              ? { closed: true, open: null, close: null }
              : { closed: false, open: wanted.open, close: wanted.close }
          await tx.hoursDay.upsert({ where: { day }, create: { day, ...data }, update: data })
        }

        await tx.hoursEvent.create({
          data: {
            actor: 'owner',
            subject: day,
            field: dayField(wanted),
            from: dayLedgerValue(prior),
            to: dayLedgerValue(wanted),
          },
        })
      }

      return tx.hoursDay.findMany()
    })

    revalidateTag('overlay', 'max')

    // Sorted through DAY_ORDER here too: the findMany above is a read of
    // truth, not a source of order, and the client must never learn order
    // from a response.
    const byDay = new Map(saved.map((row) => [row.day as DayId, row]))
    const days = DAY_ORDER.map((day) => byDay.get(day)).filter((row) => row !== undefined)

    return Response.json({ ok: true, days, published: isPublishable(days) })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
