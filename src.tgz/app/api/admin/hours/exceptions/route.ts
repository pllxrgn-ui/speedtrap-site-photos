// CLOSING EARLY, OR CLOSED - adding one dated row (build/13 section 5).
//
// IMMEDIATE regime (section 0.5): "closing at 8 tonight, private party" typed
// during service cannot queue behind an APPLY button. This is the SOLD OUT
// argument verbatim. The week is the deliberate publish; this is not.
//
// The row EXPIRES BY ITS OWN DATE - no expiresAt column, no nextBarMorning,
// no cron (section 1.6). It is filtered against barServiceDay(), never
// barToday() and never new Date(), because the bar's day ends at 4am
// (section 0.4).
//
// Overlap is LEGAL DATA and the database does not refuse it: "closed Dec 24
// to Jan 2" plus "Dec 25 closed - holiday" is the headline use case. The
// response carries section 1.9's warning sentence instead, computed from the
// rows already in the transaction, never a second round trip.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import {
  exceptionSubject,
  exceptionSummary,
  overlapWarning,
} from '@/lib/admin/hours-writes'
import { getDb } from '@/lib/db'
import { barServiceDay, exceptionSchema, liveExceptionsWhere } from '@/lib/hours'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

export const dynamic = 'force-dynamic'

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')

  const parsed = exceptionSchema.safeParse(body.value)
  if (!parsed.success) {
    return fail(400, parsed.error.issues[0]?.message ?? 'That date did not make sense.')
  }

  // The reason is owner-typed free text on a PUBLIC page, so it inherits the
  // booking note's posture: sanitized on the way in, at the boundary, once.
  // Sanitizing AFTER the length check would let the neutering apostrophe push
  // a 60-character reason past the column width.
  const label = parsed.data.label ? sanitize(parsed.data.label) : ''
  if (label.length > 60) return fail(400, 'Keep the reason under 60 characters.')

  const input = parsed.data
  const data = {
    date: input.date,
    endDate: input.endDate ?? null,
    closed: input.closed,
    open: input.closed ? null : (input.open ?? null),
    close: input.closed ? null : (input.close ?? null),
    label: label || null,
  }

  try {
    const today = barServiceDay()
    const saved = await getDb().$transaction(async (tx) => {
      const row = await tx.hoursException.create({ data })
      await tx.hoursEvent.create({
        data: {
          actor: 'owner',
          subject: exceptionSubject(row),
          field: 'exception-added',
          to: exceptionSummary(row),
        },
      })
      // Read the live rows INSIDE the transaction, so the warning and the row
      // can never disagree with what the database holds. The filter object
      // is passed WHOLE - a spread of its one key would silently drop a
      // second key the day it grows one (review round 1, finding 7).
      const live = await tx.hoursException.findMany({ where: liveExceptionsWhere(today) })
      return { row, others: live.filter((other) => other.id !== row.id) }
    })

    revalidateTag('overlay', 'max')

    const warning = overlapWarning(saved.row, saved.others)
    return Response.json({ ok: true, row: saved.row, ...(warning ? { warning } : {}) }, { status: 201 })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
