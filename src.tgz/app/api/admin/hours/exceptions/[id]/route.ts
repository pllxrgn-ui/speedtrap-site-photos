// Edit or remove one dated row (build/13 section 5). IMMEDIATE, like the POST
// beside it: the owner who typed "closing at 8 tonight" at 6pm is the same
// owner who un-types it at 7.
//
// PATCH IS DECLARATIVE - the body is the whole row, the same shape and the
// same schema the POST takes, so the client never has to know which fields it
// is allowed to send.
//
// LEDGER, per changed ASPECT, all inside the transaction:
//
//   - the DATE moved   -> exception-removed (the old row) + exception-added
//     (the new one). A moved date is exactly that: the old dated fact is gone
//     and a new one exists, and saying so uses only section 1.1's closed value
//     set instead of inventing a ninth discriminator for it.
//   - the hours changed -> exception-hours, or exception-closed when the row
//     became a full closure.
//   - the reason changed -> exception-label.
//   - nothing changed -> NOTHING IS LOGGED (menu/[id]/route.ts:153).
//
// DELETE writes exception-removed carrying the row's own summary, so the
// deletion stays legible after the row is gone - the same reason the menu's
// DELETE records the dish BY NAME.
//
// The id rides in the path: encodeURIComponent at the CALL SITE, restated
// from build/09's as-built scar (seed dish ids carry slashes, went unencoded,
// and every edit of a seed dish 404'd). cuid() contains no slash, so this is
// belt and braces.

import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import {
  exceptionHours,
  exceptionSubject,
  exceptionSummary,
  overlapWarning,
} from '@/lib/admin/hours-writes'
import { getDb } from '@/lib/db'
import { barServiceDay, exceptionSchema, liveExceptionsWhere } from '@/lib/hours'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

export const dynamic = 'force-dynamic'

type Params = { params: Promise<{ id: string }> }

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

export async function PATCH(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')

  const parsed = exceptionSchema.safeParse(body.value)
  if (!parsed.success) {
    return fail(400, parsed.error.issues[0]?.message ?? 'That date did not make sense.')
  }

  const label = parsed.data.label ? sanitize(parsed.data.label) : ''
  if (label.length > 60) return fail(400, 'Keep the reason under 60 characters.')

  const input = parsed.data
  const data = {
    date: input.date,
    endDate: input.endDate ?? null,
    closed: input.closed,
    open: input.closed ? null : (input.open ?? null),
    close: input.closed ? null : (input.close ?? null),
    label: label || null,
  }

  try {
    const db = getDb()
    const { id } = await params
    const today = barServiceDay()
    const saved = await db.$transaction(async (tx) => {
      // THE BEFORE-READ IS INSIDE THE TRANSACTION (review round 1, finding
      // 2). Read outside it, the ledger's `from` could describe a row a
      // concurrent write had already changed - a log that quietly misstates
      // what it replaced is worse than no log. Null here means the row is
      // gone; nothing has been written, so returning is a clean rollback.
      const before = await tx.hoursException.findUnique({ where: { id } })
      if (!before) return null

      const row = await tx.hoursException.update({ where: { id }, data })

      const movedDate = exceptionSubject(before) !== exceptionSubject(row)
      if (movedDate) {
        await tx.hoursEvent.create({
          data: {
            actor: 'owner',
            subject: exceptionSubject(before),
            field: 'exception-removed',
            from: exceptionSummary(before),
          },
        })
        await tx.hoursEvent.create({
          data: {
            actor: 'owner',
            subject: exceptionSubject(row),
            field: 'exception-added',
            to: exceptionSummary(row),
          },
        })
      } else {
        if (exceptionHours(before) !== exceptionHours(row)) {
          await tx.hoursEvent.create({
            data: {
              actor: 'owner',
              subject: exceptionSubject(row),
              field: row.closed ? 'exception-closed' : 'exception-hours',
              from: exceptionHours(before),
              to: exceptionHours(row),
            },
          })
        }
        if ((before.label ?? null) !== (row.label ?? null)) {
          await tx.hoursEvent.create({
            data: {
              actor: 'owner',
              subject: exceptionSubject(row),
              field: 'exception-label',
              from: before.label,
              to: row.label,
            },
          })
        }
      }

      // The object whole, like every other caller (finding 7).
      const live = await tx.hoursException.findMany({ where: liveExceptionsWhere(today) })
      return { row, others: live.filter((other) => other.id !== row.id) }
    })

    if (!saved) return fail(404, 'That date is not on the list.')

    revalidateTag('overlay', 'max')

    const warning = overlapWarning(saved.row, saved.others)
    return Response.json({ ok: true, row: saved.row, ...(warning ? { warning } : {}) })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}

export async function DELETE(request: Request, { params }: Params) {
  const refused = await adminGuards(request)
  if (refused) return refused

  try {
    const db = getDb()
    const { id } = await params
    // The read that the ledger row is built from happens INSIDE the
    // transaction (finding 2), which is also why this is the callback form
    // and not the array form: the array form cannot read first.
    const removed = await db.$transaction(async (tx) => {
      const row = await tx.hoursException.findUnique({ where: { id } })
      if (!row) return null
      await tx.hoursException.delete({ where: { id } })
      await tx.hoursEvent.create({
        data: {
          actor: 'owner',
          subject: exceptionSubject(row),
          field: 'exception-removed',
          from: exceptionSummary(row),
        },
      })
      return row
    })

    if (!removed) return fail(404, 'That date is not on the list.')

    revalidateTag('overlay', 'max')
    return Response.json({ ok: true })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
