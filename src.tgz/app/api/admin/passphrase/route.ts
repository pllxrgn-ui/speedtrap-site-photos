// Change the admin passphrase from inside the admin (build/09 addendum 7).
// The current passphrase must be typed again (a stolen open session must
// not be enough to lock the owner out), the new one keeps the generator's
// twelve-character floor, and every OTHER session dies with the change —
// whoever knows the new passphrase is the only one still signed in.
// Wrong-current attempts ride the LOGIN rate buckets: this is a guessing
// surface exactly like the sign-in form, and it pays the same 250ms floor.

import { activeAdminHash } from '@/lib/auth/credential'
import { hashPassword, verifyPassword, withMinDuration } from '@/lib/auth/password'
import { adminGuards } from '@/lib/admin/guards'
import { requireSession } from '@/lib/auth/session'
import { getDb } from '@/lib/db'
import { readJsonCapped } from '@/lib/http/read-capped'
import { clientIpOf, hashIp } from '@/lib/pii'
import { loginWindows, takeRateSlots } from '@/lib/rate-limit'

export const dynamic = 'force-dynamic'

const RESPONSE_FLOOR_MS = 250
const MIN_LENGTH = 12 // scripts/hash-password.mjs refuses shorter, so do we
const MAX_LENGTH = 256

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused
  const session = await requireSession()
  if (!session) return fail(401, 'Sign in first.')

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const { current, next } = (body.value ?? {}) as { current?: unknown; next?: unknown }
  if (typeof current !== 'string' || typeof next !== 'string') {
    return fail(400, 'Text fields only.')
  }
  if (next.length < MIN_LENGTH) {
    return fail(400, 'Twelve characters at least. Longer beats clever.')
  }
  if (next.length > MAX_LENGTH) return fail(400, 'That is too long to type twice.')
  if (next === current) return fail(400, 'That is the passphrase you already have.')

  try {
    const db = getDb()
    const ipHash = hashIp(clientIpOf(request))

    // Same buckets as sign-in: a wrong "current" here is the same guess it
    // would be at the door, and it costs a slot either way.
    const rate = await takeRateSlots(db, loginWindows(ipHash))
    if (!rate.allowed) {
      return Response.json(
        { ok: false, message: 'Too many tries. Wait a few minutes.' },
        { status: 429, headers: { 'retry-after': String(rate.retryAfterSeconds) } },
      )
    }

    return await withMinDuration(RESPONSE_FLOOR_MS, async () => {
      const stored = await activeAdminHash(db)
      if (!stored) return fail(503, 'Sign-in is not configured.')
      const valid = await verifyPassword(current, stored)
      if (!valid) return fail(401, 'That is not the current passphrase.')

      const hash = await hashPassword(next)
      // ONE transaction: the new hash and the death of every OTHER session
      // land together or not at all. Split writes could change the
      // passphrase while claiming failure - and leave old devices signed
      // in through a rotation that promised to end them (review wart,
      // fixed same day).
      await db.$transaction(async (tx) => {
        await tx.adminCredential.upsert({
          where: { id: 1 },
          create: { id: 1, hash },
          update: { hash },
        })
        await tx.session.deleteMany({ where: { tokenHash: { not: session.tokenHash } } })
      })
      return Response.json({ ok: true })
    })
  } catch {
    return fail(500, 'That did not stick. Refresh and retry.')
  }
}
