// Owner-uploaded dish photos (contract §Back of House amendment). The
// photo is the OWNER'S OWN media — permission inherent, which is stronger
// provenance than anything scraped — and it can never carry a name or a
// price: alt text is generated from the dish name, the row stores only a
// URL, and the overlay boundary (veto 4) is untouched.

import { del, put } from '@vercel/blob'
import { revalidateTag } from 'next/cache'
import { adminGuards } from '@/lib/admin/guards'
import { getDb } from '@/lib/db'
import { readBodyCapped, readJsonCapped } from '@/lib/http/read-capped'
import { MENU, type MenuCategory } from '@/lib/menu'
import { MENU_KEY_SET, menuKey } from '@/lib/menu-keys'

export const dynamic = 'force-dynamic'

const MAX_PHOTO_BYTES = 4 * 1024 * 1024
const TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
}

function fail(status: number, message: string): Response {
  return Response.json({ ok: false, message }, { status })
}

function dishNameFor(itemKey: string): string | null {
  for (const category of MENU as readonly MenuCategory[]) {
    for (const item of category.items) {
      if (menuKey(category.id, item.name) === itemKey) return item.name
    }
  }
  return null
}

export async function POST(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  if (!process.env.BLOB_READ_WRITE_TOKEN) {
    return fail(503, 'Photo storage is not connected yet.')
  }

  // The multipart body goes through the SAME byte-counting cap as every
  // JSON body — calling formData() on the raw request would buffer a
  // chunked upload unbounded, re-opening audit M6 on this path (review
  // 2026-09-22, HIGH). 64KB of overhead covers boundaries + fields.
  const capped = await readBodyCapped(request, MAX_PHOTO_BYTES + 64 * 1024)
  if (!capped.ok) {
    return capped.reason === 'too-large'
      ? fail(413, 'That photo is over 4MB. Send a smaller one.')
      : fail(400, 'Could not read that upload.')
  }

  let form: FormData
  try {
    form = await new Request(request.url, {
      method: 'POST',
      headers: { 'content-type': request.headers.get('content-type') ?? '' },
      body: new Uint8Array(capped.bytes),
    }).formData()
  } catch {
    return fail(400, 'Could not read that upload.')
  }

  const itemKey = form.get('itemKey')
  const file = form.get('file')
  if (typeof itemKey !== 'string' || !MENU_KEY_SET.has(itemKey)) {
    return fail(400, 'Not a dish on the printed menu.')
  }
  const dishName = dishNameFor(itemKey)
  if (!dishName) return fail(400, 'Not a dish on the printed menu.')
  if (!(file instanceof File)) return fail(400, 'No photo in that upload.')
  if (!(file.type in TYPES)) return fail(415, 'JPEG, PNG or WebP only.')
  if (file.size === 0) return fail(400, 'That file is empty.')
  if (file.size > MAX_PHOTO_BYTES) return fail(413, 'That photo is over 4MB. Send a smaller one.')

  try {
    const db = getDb()
    const previous = await db.dishPhoto.findUnique({ where: { itemKey } })

    const blob = await put(`dishes/${itemKey}.${TYPES[file.type]}`, file, {
      access: 'public',
      addRandomSuffix: true, // a replace gets a NEW url — no stale CDN copy
      contentType: file.type,
    })

    const photo = await db.dishPhoto.upsert({
      where: { itemKey },
      create: { itemKey, url: blob.url, alt: `${dishName}, as served` },
      update: { url: blob.url, alt: `${dishName}, as served` },
    })

    // Best-effort: the old blob is garbage once the row points elsewhere.
    // Sync-throw-safe on purpose — a failed cleanup must never turn a
    // SAVED photo into a 500 with a stale page (review finding 2). If it
    // fails, the orphaned blob is the accepted cost (finding 3).
    if (previous && previous.url !== blob.url) {
      try {
        await del(previous.url)
      } catch {
        /* orphaned blob, nothing else */
      }
    }

    revalidateTag('overlay', 'max')
    return Response.json({ ok: true, photo: { src: photo.url, alt: photo.alt } })
  } catch {
    return fail(500, 'That upload did not stick. Try it again.')
  }
}

export async function DELETE(request: Request) {
  const refused = await adminGuards(request)
  if (refused) return refused

  const body = await readJsonCapped(request, 4 * 1024)
  if (!body.ok) return fail(400, 'Could not read that.')
  const { itemKey } = (body.value ?? {}) as { itemKey?: unknown }
  // Unknown keys are allowed here ON PURPOSE: this is also how an orphaned
  // photo row (dish renamed in code) gets cleaned up.
  if (typeof itemKey !== 'string' || itemKey.length === 0 || itemKey.length > 60) {
    return fail(400, 'Not a dish key.')
  }

  try {
    const db = getDb()
    const existing = await db.dishPhoto.findUnique({ where: { itemKey } })
    if (existing) {
      await db.dishPhoto.delete({ where: { itemKey } })
      if (process.env.BLOB_READ_WRITE_TOKEN) {
        try {
          await del(existing.url)
        } catch {
          /* orphaned blob, nothing else (finding 3, accepted) */
        }
      }
    }
    revalidateTag('overlay', 'max')
    return Response.json({ ok: true })
  } catch {
    return fail(500, 'That did not stick. Try it again.')
  }
}
