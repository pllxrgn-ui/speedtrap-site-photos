import { NextResponse } from 'next/server'
import { getDb } from '@/lib/db'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
export const dynamic = 'force-dynamic'

// Born as the Phase 1 transport proof (build/08 §5). Kept since 2026-09-26
// as the "is it running" database probe the Gemfield panel reads - it reads
// `ok` and nothing else. The body is ONLY { ok } on purpose: this route is
// public and unauthenticated, so no count, no reason, no error text crosses
// the wire (the booking count it used to return is business data). The
// query still touches the Booking table so a missing schema reads as down.
export async function GET() {
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ ok: false }, { status: 503 })
  }
  try {
    await getDb().booking.count()
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('db health check failed:', error)
    return NextResponse.json({ ok: false }, { status: 503 })
  }
}
