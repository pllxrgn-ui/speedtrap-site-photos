import { NextResponse } from 'next/server'
import { getDb } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// Phase 1 transport proof ONLY (build/08 §5): proves `prisma generate` and
// the engine binary survive the SHA-pinned tarball transport, and that the
// pooled Neon URL answers from a Vercel function. Returns no data beyond a
// row count. DELETE this route before Phase 3 ships — the §5 gate says so.
export async function GET() {
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ ok: false, reason: 'DATABASE_URL not set' }, { status: 503 })
  }
  try {
    const count = await getDb().booking.count()
    return NextResponse.json({ ok: true, count })
  } catch (error) {
    console.error('db health check failed:', error)
    return NextResponse.json({ ok: false, reason: 'query failed' }, { status: 503 })
  }
}
