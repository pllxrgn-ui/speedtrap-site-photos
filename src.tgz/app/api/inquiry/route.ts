// Private-room inquiry endpoint.
//
// DELIVERY IS NOT WIRED UP. The owner has not chosen a domain or an inbox yet
// (CLIENT-QUESTIONS #12), so there is nowhere for an inquiry to land. Until
// INQUIRY_WEBHOOK_URL is configured this route answers 503 and tells the caller
// to phone instead. It never returns a success it cannot back up: a form that
// says "we got it" into a void loses real bookings. Guarded by
// app/api/inquiry/route.test.ts.
//
// To turn it on: set INQUIRY_WEBHOOK_URL (an email relay or form endpoint the
// owner controls) and NEXT_PUBLIC_INQUIRY_ENABLED=1 so the page mounts the form.
// The build-time check below refuses a build where only the public flag is set.
//
// TODO: add Cloudflare Turnstile verification here once the owner has an
// account and we have a real site key and secret. The honeypot below is the
// only bot gate today.
// Rate limiting: lib/rate-limit.ts exists now (Postgres-backed). Wire it in
// here when this route is enabled, or retire this route into /api/booking
// first (build/08 Phase 6) — whichever comes sooner.

import { SITE } from '@/lib/site'
import { inquirySchema } from '@/lib/inquiry'
import { isHoneypotHit } from '@/lib/http/honeypot'
import { isAllowedOrigin } from '@/lib/http/origin'
import { readJsonCapped } from '@/lib/http/read-capped'
import { sanitize } from '@/lib/sanitize'

// The two env vars must flip together. Failing the build beats failing the
// customer at the last step of a filled-in form.
if (process.env.NEXT_PUBLIC_INQUIRY_ENABLED === '1' && !process.env.INQUIRY_WEBHOOK_URL) {
  throw new Error(
    'NEXT_PUBLIC_INQUIRY_ENABLED=1 but INQUIRY_WEBHOOK_URL is not set. ' +
      'Set both or neither: see apps/web/.env.example.',
  )
}

const NOT_WIRED_UP = `We cannot take this online yet. Call ${SITE.phoneDisplay} and we will sort it out in two minutes.`
const DELIVERY_FAILED = `That message did not get through. Call ${SITE.phoneDisplay} and we will sort it out in two minutes.`

const MAX_BODY_BYTES = 16 * 1024

export async function POST(request: Request) {
  // Browsers always send Origin on a fetch POST; a mismatched one is another
  // site submitting on a visitor's behalf. Allow-set (closes audit M5) and
  // the deliberate absent-Origin pass live in lib/http/origin.ts.
  if (!isAllowedOrigin(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }

  if (!request.headers.get('content-type')?.includes('application/json')) {
    return Response.json({ ok: false, message: 'Send JSON.' }, { status: 415 })
  }

  // Counts actual bytes off the wire (closes audit M6: a chunked body with
  // no Content-Length used to buffer unbounded here).
  const body = await readJsonCapped(request, MAX_BODY_BYTES)
  if (!body.ok) {
    if (body.reason === 'too-large') {
      return Response.json({ ok: false, message: 'That is too much text.' }, { status: 413 })
    }
    return Response.json(
      { ok: false, message: 'We could not read that request. Please try again.' },
      { status: 400 },
    )
  }
  const payload: unknown = body.value

  // Honeypot: answer 200 so a bot learns nothing from the status, but never
  // claim success. If a real person somehow lands here (aggressive autofill),
  // they see an honest "call us" instead of a fabricated confirmation.
  if (isHoneypotHit(payload)) {
    return Response.json({ ok: false, message: NOT_WIRED_UP })
  }

  const parsed = inquirySchema.safeParse(payload)
  if (!parsed.success) {
    return Response.json(
      {
        ok: false,
        message: 'Some of those answers did not go through. Check the form and try again.',
        issues: parsed.error.issues.map((issue) => ({
          field: issue.path.join('.'),
          message: issue.message,
        })),
      },
      { status: 400 },
    )
  }

  const webhookUrl = process.env.INQUIRY_WEBHOOK_URL
  if (!webhookUrl) {
    return Response.json({ ok: false, message: NOT_WIRED_UP }, { status: 503 })
  }

  // Listed field by field so the honeypot value never leaves this process.
  const { name, phone, date, headcount, occasion, message } = parsed.data

  try {
    const delivered = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      signal: AbortSignal.timeout(8000),
      body: JSON.stringify({
        source: 'private-room-inquiry',
        name: sanitize(name),
        phone: sanitize(phone),
        date,
        headcount,
        occasion,
        message: message ? sanitize(message) : undefined,
      }),
    })
    if (!delivered.ok) {
      return Response.json({ ok: false, message: DELIVERY_FAILED }, { status: 502 })
    }
  } catch {
    return Response.json({ ok: false, message: DELIVERY_FAILED }, { status: 502 })
  }

  return Response.json({ ok: true })
}
