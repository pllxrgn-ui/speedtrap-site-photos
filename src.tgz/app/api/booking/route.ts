// Table-booking request endpoint (build/08 §2-§3). A REQUEST QUEUE, not a
// reservation system: nothing here holds a table, and no response may say
// Booked or Confirmed (veto 10). The row lands in THE BOOK (/admin, Phase
// 4) and the owner calls back.
//
// Check order is cheapest-first (§2 row 3): headers before body, body
// before validation, validation before the database, the database before
// the webhook.

import { getDb } from '@/lib/db'
import { SITE } from '@/lib/site'
import { bookingSchema, phoneDigits, presanitizeBooking, purgeAfterOf } from '@/lib/booking'
import { isHoneypotHit } from '@/lib/http/honeypot'
import { isAllowedOrigin } from '@/lib/http/origin'
import { readJsonCapped } from '@/lib/http/read-capped'
import { notifyBooking } from '@/lib/notify'
import { clientIpOf, hashIp } from '@/lib/pii'
import { newReference } from '@/lib/reference'
import { bookingWindows, takeRateSlots } from '@/lib/rate-limit'

// Node runtime (the App Router default for route handlers - Prisma needs
// it). The explicit `runtime` segment config is FORBIDDEN once
// experimental.useCache is on (as-built note, build/08): the default is
// the declaration now.
// PII with nowhere to go is collection without purpose (§2 row 11, veto
// 14): the public flag cannot ship without the store, the hash pepper AND
// the cron bearer — without CRON_SECRET the purge route 404s on every
// scheduled run and the 90-day deletion promise silently never executes
// (review finding 3). Failing the build beats failing the customer — the
// same tested idiom as the inquiry route.
//
// Amended when booking went live (Pol's call, 2026-09-22): the notify
// WEBHOOK is no longer in the mandatory set. It was always "a ping, not
// the record" (lib/notify.ts) — THE BOOK in /admin is where requests
// land, the page promises a call-back rather than a held table, and #B1
// (the real ping target) stays open. Until it is answered, nobody is
// pinged: the owner must open THE BOOK. That trade is stated in
// CLIENT-QUESTIONS.md, not hidden here.
if (
  process.env.NEXT_PUBLIC_BOOKING_ENABLED === '1' &&
  (!process.env.DATABASE_URL || !process.env.PII_HASH_PEPPER || !process.env.CRON_SECRET)
) {
  throw new Error(
    'NEXT_PUBLIC_BOOKING_ENABLED=1 but DATABASE_URL, PII_HASH_PEPPER or ' +
      'CRON_SECRET is not set. Set all of them or none: see apps/web/.env.example.',
  )
}

const NOT_WIRED_UP = `We cannot hold tables online yet. Call ${SITE.phoneDisplay} and we will sort it out in two minutes.`
const TRY_THE_PHONE = `That did not go through. Call ${SITE.phoneDisplay} and we will take it down the old way.`

const MAX_BODY_BYTES = 16 * 1024
const REFERENCE_ATTEMPTS = 3

// Duck-typed on purpose: route tests mock the db module, and an instanceof
// check against Prisma's error class would never match a test double.
function uniqueViolationOn(error: unknown, field: string): boolean {
  if (typeof error !== 'object' || error === null) return false
  const known = error as { code?: unknown; meta?: { target?: unknown } }
  if (known.code !== 'P2002') return false
  const target = known.meta?.target
  return Array.isArray(target) && target.some((t) => typeof t === 'string' && t.includes(field))
}

export async function POST(request: Request) {
  if (!isAllowedOrigin(request)) {
    return Response.json({ ok: false, message: 'Not allowed.' }, { status: 403 })
  }

  if (!request.headers.get('content-type')?.includes('application/json')) {
    return Response.json({ ok: false, message: 'Send JSON.' }, { status: 415 })
  }

  const body = await readJsonCapped(request, MAX_BODY_BYTES)
  if (!body.ok) {
    if (body.reason === 'too-large') {
      return Response.json({ ok: false, message: 'That is too much text.' }, { status: 413 })
    }
    return Response.json(
      { ok: false, message: 'We could not read that request. Please try again.' },
      { status: 400 },
    )
  }

  // Honeypot: 200 so a bot learns nothing from the status, ok:false so no
  // human is lied to. The database is never touched. The copy must stay
  // true in BOTH flag states — "we cannot do this online" would be a lie
  // once booking is live, so it says the request failed (which it did).
  if (isHoneypotHit(body.value)) {
    return Response.json({ ok: false, message: TRY_THE_PHONE })
  }

  // Sanitize-then-validate lives in the shared contract (lib/booking.ts)
  // so the Phase 4 form runs the identical transform (review findings 4+7,
  // follow-up 3).
  const parsed = bookingSchema.safeParse(presanitizeBooking(body.value))
  if (!parsed.success) {
    return Response.json(
      {
        ok: false,
        message: 'Some of those answers did not go through. Check the form and try again.',
        issues: parsed.error.issues.map((issue) => ({
          field: issue.path.join('.'),
          message: issue.message,
        })),
      },
      { status: 400 },
    )
  }

  // Not wired up yet (flag off): an honest 503 and the phone number, never
  // a success into a void (§2 row 11). The DATABASE_URL clause is belt and
  // braces only — the module guard above makes it unreachable in a healthy
  // boot, since flag=1 without a database refuses to build at all.
  if (process.env.NEXT_PUBLIC_BOOKING_ENABLED !== '1' || !process.env.DATABASE_URL) {
    return Response.json({ ok: false, message: NOT_WIRED_UP }, { status: 503 })
  }

  const input = parsed.data
  const digits = phoneDigits(input.phone)
  const requestedOn = new Date(`${input.date}T00:00:00Z`)
  const note = input.note || null

  // Everything that can touch the database lives inside ONE try: the very
  // first query of a request is the one most likely to hit a cold Neon
  // compute, and even that failure owes the caller the ok:false body with
  // the phone number, never a bare framework 500 (review finding 5).
  try {
    const db = getDb()
    const ipHash = hashIp(clientIpOf(request))

    const rate = await takeRateSlots(db, bookingWindows(ipHash))
    if (!rate.allowed) {
      return Response.json(
        { ok: false, message: `That is a lot of requests at once. Call ${SITE.phoneDisplay} instead.` },
        { status: 429, headers: { 'retry-after': String(rate.retryAfterSeconds) } },
      )
    }

    for (let attempt = 0; attempt < REFERENCE_ATTEMPTS; attempt += 1) {
      const reference = newReference()
      try {
        const booking = await db.$transaction(async (tx) => {
          const created = await tx.booking.create({
            data: {
              reference,
              kind: 'table',
              name: input.name,
              phone: input.phone,
              phoneDigits: digits,
              partySize: input.partySize,
              requestedOn,
              timeWindow: input.timeWindow,
              note,
              ipHash,
              purgeAfter: purgeAfterOf(input.date),
            },
          })
          await tx.bookingEvent.create({
            data: { bookingId: created.id, actor: 'system', to: 'new' },
          })
          return created
        })

        // The ping fires AFTER the commit: a broken webhook still commits
        // the booking, and THE BOOK stays the source of truth.
        await notifyBooking({
          reference: booking.reference,
          name: input.name,
          phone: input.phone,
          date: input.date,
          timeWindow: input.timeWindow,
          partySize: input.partySize,
          note: note ?? undefined,
        })

        return Response.json({ ok: true, reference: booking.reference }, { status: 201 })
      } catch (error) {
        // Rare reference collision: draw again.
        if (uniqueViolationOn(error, 'reference')) continue

        // Same phone, same day, same window: the same friendly success
        // with the SAME reference, never an error (§2 row 5). But a
        // re-submit that CHANGES the ask is a correction, not a
        // double-tap — record it, update the row and ping the owner, or
        // THE BOOK lies about the party (review finding 6).
        if (uniqueViolationOn(error, 'phoneDigits')) {
          const existing = await db.booking.findUnique({
            where: {
              phoneDigits_requestedOn_timeWindow: {
                phoneDigits: digits,
                requestedOn,
                timeWindow: input.timeWindow,
              },
            },
          })
          if (existing) {
            // The detector must cover every field the update below writes,
            // or a name-spelling correction silently changes nothing
            // (review follow-up 2).
            const changes: string[] = []
            if (existing.partySize !== input.partySize) {
              changes.push(`party ${existing.partySize} -> ${input.partySize}`)
            }
            if ((existing.note ?? null) !== note) changes.push('note updated')
            if (existing.name !== input.name) changes.push('name updated')
            if (existing.phone !== input.phone) changes.push('phone format updated')

            if (changes.length > 0) {
              await db.$transaction(async (tx) => {
                await tx.booking.update({
                  where: { id: existing.id },
                  data: { name: input.name, phone: input.phone, partySize: input.partySize, note },
                })
                await tx.bookingEvent.create({
                  data: {
                    bookingId: existing.id,
                    actor: 'system',
                    note: `amended request: ${changes.join(', ')}`,
                  },
                })
              })
              await notifyBooking({
                reference: existing.reference,
                name: input.name,
                phone: input.phone,
                date: input.date,
                timeWindow: input.timeWindow,
                partySize: input.partySize,
                note: note ?? undefined,
              })
            }
            return Response.json({ ok: true, reference: existing.reference })
          }
        }
        throw error
      }
    }
    throw new Error('reference collisions exhausted retries')
  } catch {
    // No detail out (it could describe the schema) and none logged — a
    // failure here may carry the customer's name and number (veto 16).
    return Response.json({ ok: false, message: TRY_THE_PHONE }, { status: 500 })
  }
}
