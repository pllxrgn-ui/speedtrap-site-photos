// Daily retention sweep (build/08 §1). A deletion promise made to
// customers must not be lazily evaluated on the owner's next login — this
// runs on the vercel.json cron whether or not anyone signs in.

import { timingSafeEqual } from 'node:crypto'
import { getDb } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// Day-window rate buckets need to outlive their own day; 25h covers DST.
const RATE_WINDOW_SLACK_MS = 25 * 60 * 60 * 1000

// 404 on any mismatch so the route does not advertise itself (§2 row 15).
// No secret configured means NO caller is valid, not everyone.
function bearerMatches(request: Request): boolean {
  const secret = process.env.CRON_SECRET
  if (!secret) return false
  const presented = Buffer.from(request.headers.get('authorization') ?? '')
  const expected = Buffer.from(`Bearer ${secret}`)
  return presented.length === expected.length && timingSafeEqual(presented, expected)
}

export async function GET(request: Request) {
  if (!bearerMatches(request)) {
    return new Response(null, { status: 404 })
  }
  if (!process.env.DATABASE_URL) {
    return Response.json({ ok: false, reason: 'DATABASE_URL not set' }, { status: 503 })
  }

  const db = getDb()
  const now = new Date()

  // Hard-delete due bookings (events cascade) and leave PII-free
  // DeletionLog rows in the same transaction: deletion stays real, the
  // count survives.
  const due = await db.booking.findMany({
    where: { purgeAfter: { lt: now } },
    select: { id: true },
  })
  if (due.length > 0) {
    await db.$transaction([
      db.deletionLog.createMany({
        data: due.map((booking) => ({ bookingId: booking.id, reason: 'retention-purge' })),
      }),
      db.booking.deleteMany({ where: { id: { in: due.map((booking) => booking.id) } } }),
    ])
  }

  const sessions = await db.session.deleteMany({
    where: { OR: [{ expiresAt: { lt: now } }, { absoluteEnd: { lt: now } }] },
  })
  const rateWindows = await db.rateHit.deleteMany({
    where: { windowStart: { lt: new Date(now.getTime() - RATE_WINDOW_SLACK_MS) } },
  })

  return Response.json({
    ok: true,
    purged: due.length,
    sessions: sessions.count,
    rateWindows: rateWindows.count,
  })
}
