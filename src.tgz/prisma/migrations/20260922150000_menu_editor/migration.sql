-- THE MENU EDITOR (build/09). Seeded 1:1 from the July 2026 printed-menu
-- transcription (research/05) - this file IS the frozen evidence the old
-- drift canaries pinned. Dish ids are the pre-existing menuKeys, so the
-- ItemState and DishPhoto rows already in production keep working with
-- zero remapping.
CREATE TABLE "MenuDish" (
    "id" VARCHAR(60) NOT NULL,
    "categoryId" VARCHAR(30) NOT NULL,
    "name" VARCHAR(60) NOT NULL,
    "description" VARCHAR(200),
    "priceCents" INTEGER,
    "gf" BOOLEAN NOT NULL DEFAULT false,
    "v" BOOLEAN NOT NULL DEFAULT false,
    "houseMade" BOOLEAN NOT NULL DEFAULT false,
    "sortIndex" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "MenuDish_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MenuDish_categoryId_sortIndex_idx" ON "MenuDish"("categoryId", "sortIndex");
CREATE TABLE "MenuEvent" (
    "id" TEXT NOT NULL,
    "at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actor" VARCHAR(20) NOT NULL,
    "dishId" VARCHAR(60),
    "dishName" VARCHAR(60) NOT NULL,
    "field" VARCHAR(20) NOT NULL,
    "from" VARCHAR(200),
    "to" VARCHAR(200),
    CONSTRAINT "MenuEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "MenuEvent_at_idx" ON "MenuEvent"("at");
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/speed-trap-burger','burgers','Speed Trap Burger','Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.',2000,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/blue-cheese-burger','burgers','Blue Cheese Burger','Blue cheese, grilled onions, bacon. The one people drive out for.',1700,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/jail-house-burger','burgers','Jail House Burger','Jalapeño and cheddar.',1500,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/hawaiian-burger','burgers','Hawaiian Burger','Teriyaki, pineapple, bacon, Swiss.',1700,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/farmers-burger','burgers','Farmers Burger','Bacon, egg and cheddar.',1700,false,false,false,4,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/mushroom-burger','burgers','Mushroom Burger','Grilled mushrooms, Swiss.',1500,false,false,false,5,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/bacon-cheeseburger','burgers','Bacon Cheeseburger',NULL,1600,false,false,false,6,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/classic-cheeseburger','burgers','Classic Cheeseburger',NULL,1400,false,false,false,7,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('burgers/classic-hamburger','burgers','Classic Hamburger',NULL,1300,false,false,false,8,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('dinners/hamburger-steak-dinner','dinners','Hamburger Steak Dinner','Grilled mushrooms and onions, smothered in gravy.',1900,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('dinners/open-faced-sandwich','dinners','Open Faced Sandwich','Prime rib or turkey under brown gravy.',1800,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('dinners/country-fried-steak','dinners','Country Fried Steak','Smothered in cream gravy.',1800,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('dinners/pork-rib-tips-dinner','dinners','Pork Rib Tips Dinner','Slathered in barbecue sauce.',1900,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/philly-cheesesteak','sandwiches','Philly Cheesesteak','Prime rib, jalapeño, onion, Swiss. The marinated chicken version runs $16.',1800,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/classic-french-dip','sandwiches','Classic French Dip','House prime rib, Swiss, jus for dunking.',1600,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/the-chicken-sandwich','sandwiches','The Chicken Sandwich','Grilled, with mayo, lettuce and tomato. Crispy version runs $14.',1600,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/john-s-pork-chop-sandwich','sandwiches','John''s Pork Chop Sandwich','Fried patty, mustard, pickles, onions.',1400,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/patty-melt','sandwiches','Patty Melt','1000 island, Swiss and grilled onions on rye.',1500,false,false,false,4,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/club-sandwich','sandwiches','Club Sandwich','Turkey, ham, bacon, tomato, lettuce and cheese.',2000,false,false,false,5,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/classic-blt','sandwiches','Classic BLT',NULL,1400,false,false,false,6,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('sandwiches/grilled-ham-and-cheese','sandwiches','Grilled Ham & Cheese',NULL,1500,false,false,false,7,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/chicken-gizzards','appetizers','Chicken Gizzards',NULL,1200,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/cordon-blue-balls','appetizers','Cordon Blue Balls','Yes, that is the real name.',1100,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/breaded-chicken-wings','appetizers','Breaded Chicken Wings',NULL,1300,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/mozzarella-sticks','appetizers','Mozzarella Sticks',NULL,1200,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/jalape-o-poppers','appetizers','Jalapeño Poppers',NULL,1000,false,false,false,4,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/fried-mushrooms','appetizers','Fried Mushrooms',NULL,1000,false,false,false,5,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/macaroni-gouda-bites','appetizers','Macaroni Gouda Bites',NULL,1200,false,false,false,6,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/basket-of-fries-or-tater-tots','appetizers','Basket of Fries or Tater Tots',NULL,700,false,false,false,7,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('appetizers/basket-of-onion-rings-or-sweet-potato-fries','appetizers','Basket of Onion Rings or Sweet Potato Fries',NULL,1000,false,false,false,8,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('baskets/fish-and-chips','baskets','Fish & Chips',NULL,1500,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('baskets/chicken-strips','baskets','Chicken Strips',NULL,1400,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('baskets/steak-fingers','baskets','Steak Fingers',NULL,1400,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('baskets/breaded-shrimp','baskets','Breaded Shrimp',NULL,1400,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('baskets/gizzards-and-side','baskets','Gizzards & Side',NULL,1400,false,false,false,4,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('baskets/two-taco-basket','baskets','Two Taco Basket',NULL,1000,false,false,false,5,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/chief-salad','salads-sides','Chief Salad','Easily feeds two.',1600,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/taco-salad','salads-sides','Taco Salad',NULL,1500,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/grilled-chicken-salad','salads-sides','Grilled Chicken Salad',NULL,1400,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/chicken-blt-salad','salads-sides','Chicken BLT Salad',NULL,1500,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/patty-melt-salad','salads-sides','Patty Melt Salad',NULL,1400,false,false,false,4,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/side-house-salad','salads-sides','Side House Salad',NULL,400,false,false,false,5,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/cup-of-mac-salad-or-soup','salads-sides','Cup of Mac Salad or Soup',NULL,400,false,false,false,6,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/bowl-of-mac-salad-or-soup','salads-sides','Bowl of Mac Salad or Soup',NULL,600,false,false,false,7,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('salads-sides/chips-and-salsa','salads-sides','Chips & Salsa',NULL,500,false,false,false,8,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('drinks/fountain-soda','drinks','Fountain Soda',NULL,300,false,false,false,0,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('drinks/can-of-soda','drinks','Can of Soda',NULL,150,false,false,false,1,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('drinks/brewed-iced-tea','drinks','Brewed Iced Tea',NULL,300,false,false,false,2,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('drinks/hot-coffee-or-tea','drinks','Hot Coffee or Tea',NULL,300,false,false,false,3,CURRENT_TIMESTAMP);
INSERT INTO "MenuDish" ("id","categoryId","name","description","priceCents","gf","v","houseMade","sortIndex","updatedAt") VALUES ('drinks/juice','drinks','Juice','Cranberry, pineapple or orange.',300,false,false,false,4,CURRENT_TIMESTAMP);
INSERT INTO "MenuEvent" ("id","actor","dishName","field","from","to") VALUES ('menu-seed-2026-09-22','seed','the whole menu','created',NULL,'seeded 1:1 from the July 2026 printed-menu transcription (research/05)');
