-- Owner-uploaded dish photos (contract §Back of House amendment 2026-09-22).
-- Hand-written because Neon was unreachable at authoring time; shape matches
-- prisma/schema.prisma model DishPhoto exactly.
CREATE TABLE "DishPhoto" (
    "itemKey" VARCHAR(60) NOT NULL,
    "url" VARCHAR(500) NOT NULL,
    "alt" VARCHAR(120) NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DishPhoto_pkey" PRIMARY KEY ("itemKey")
);
