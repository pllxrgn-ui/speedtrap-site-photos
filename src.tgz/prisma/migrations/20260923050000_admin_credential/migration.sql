-- Rotatable admin passphrase (build/09 addendum 7). No seed: an empty
-- table means the ADMIN_PASSWORD_HASH env var is the active credential.
CREATE TABLE "AdminCredential" (
    "id" INTEGER NOT NULL DEFAULT 1,
    "hash" VARCHAR(200) NOT NULL,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdminCredential_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "AdminCredential" ADD CONSTRAINT "AdminCredential_id_check" CHECK ("id" = 1);
