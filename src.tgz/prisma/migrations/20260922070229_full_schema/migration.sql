-- CreateEnum
CREATE TYPE "HoldUntil" AS ENUM ('tonight', 'this_week', 'cleared');

-- CreateTable
CREATE TABLE "BookingEvent" (
    "id" TEXT NOT NULL,
    "bookingId" TEXT NOT NULL,
    "at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actor" VARCHAR(40) NOT NULL,
    "from" "BookingStatus",
    "to" "BookingStatus",
    "note" VARCHAR(280),

    CONSTRAINT "BookingEvent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DeletionLog" (
    "id" TEXT NOT NULL,
    "bookingId" TEXT NOT NULL,
    "at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reason" VARCHAR(40) NOT NULL,

    CONSTRAINT "DeletionLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Session" (
    "id" TEXT NOT NULL,
    "tokenHash" CHAR(64) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "absoluteEnd" TIMESTAMP(3) NOT NULL,
    "ipHash" CHAR(64),

    CONSTRAINT "Session_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RateHit" (
    "bucket" VARCHAR(80) NOT NULL,
    "windowStart" TIMESTAMP(3) NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "RateHit_pkey" PRIMARY KEY ("bucket","windowStart")
);

-- CreateTable
CREATE TABLE "Special" (
    "id" INTEGER NOT NULL,
    "title" VARCHAR(60) NOT NULL,
    "body" VARCHAR(200),
    "priceLabel" VARCHAR(16),
    "startsOn" DATE NOT NULL,
    "endsOn" DATE,
    "published" BOOLEAN NOT NULL DEFAULT false,
    "publishedAt" TIMESTAMP(3),
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Special_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ItemState" (
    "itemKey" VARCHAR(60) NOT NULL,
    "soldOut" BOOLEAN NOT NULL DEFAULT false,
    "hold" "HoldUntil" NOT NULL DEFAULT 'tonight',
    "expiresAt" TIMESTAMP(3),
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ItemState_pkey" PRIMARY KEY ("itemKey")
);

-- CreateTable
CREATE TABLE "SiteNote" (
    "id" INTEGER NOT NULL DEFAULT 1,
    "body" VARCHAR(160),
    "published" BOOLEAN NOT NULL DEFAULT false,
    "expiresAt" TIMESTAMP(3),
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SiteNote_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "BookingEvent_bookingId_at_idx" ON "BookingEvent"("bookingId", "at");

-- CreateIndex
CREATE UNIQUE INDEX "Session_tokenHash_key" ON "Session"("tokenHash");

-- CreateIndex
CREATE INDEX "Session_expiresAt_idx" ON "Session"("expiresAt");

-- CreateIndex
CREATE INDEX "RateHit_windowStart_idx" ON "RateHit"("windowStart");

-- CreateIndex
CREATE INDEX "Special_published_startsOn_endsOn_idx" ON "Special"("published", "startsOn", "endsOn");

-- AddForeignKey
ALTER TABLE "BookingEvent" ADD CONSTRAINT "BookingEvent_bookingId_fkey" FOREIGN KEY ("bookingId") REFERENCES "Booking"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Hand-added (build/08 §1): caps live in the database so no UI bug can
-- violate them. Three specials max; party size 1..40.
ALTER TABLE "Special" ADD CONSTRAINT "Special_id_range" CHECK ("id" BETWEEN 1 AND 3);
ALTER TABLE "Booking" ADD CONSTRAINT "Booking_partySize_range" CHECK ("partySize" BETWEEN 1 AND 40);
