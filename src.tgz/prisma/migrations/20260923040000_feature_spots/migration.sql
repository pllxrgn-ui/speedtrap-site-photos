-- THE FAVORITES (build/09 addendum 6). Seeded by NAME lookup so the
-- migration works on any branch regardless of dish-id spelling; a name
-- that is missing simply leaves its spot dark (the page soft-drops it).
CREATE TABLE "FeatureSpot" (
    "slot" INTEGER NOT NULL,
    "dishId" VARCHAR(60),
    "blurb" VARCHAR(160),
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FeatureSpot_pkey" PRIMARY KEY ("slot")
);

ALTER TABLE "FeatureSpot" ADD CONSTRAINT "FeatureSpot_slot_check" CHECK ("slot" BETWEEN 1 AND 4);

-- The four cards as shipped in code (blurbs verbatim from dishes.tsx).
INSERT INTO "FeatureSpot" ("slot", "dishId", "blurb", "updatedAt")
SELECT 1, id, 'The one people drive out for.', CURRENT_TIMESTAMP FROM "MenuDish" WHERE name = 'Blue Cheese Burger';
INSERT INTO "FeatureSpot" ("slot", "dishId", "blurb", "updatedAt")
SELECT 2, id, 'Double patty, grilled ham, 1000 island, grilled onions, cheese and bacon. Ask before you commit.', CURRENT_TIMESTAMP FROM "MenuDish" WHERE name = 'Speed Trap Burger';
INSERT INTO "FeatureSpot" ("slot", "dishId", "blurb", "updatedAt")
SELECT 3, id, 'Prime rib, done the Philly way.', CURRENT_TIMESTAMP FROM "MenuDish" WHERE name = 'Philly Cheesesteak';
INSERT INTO "FeatureSpot" ("slot", "dishId", "blurb", "updatedAt")
SELECT 4, id, 'The Friday tradition.', CURRENT_TIMESTAMP FROM "MenuDish" WHERE name = 'Fish & Chips';
