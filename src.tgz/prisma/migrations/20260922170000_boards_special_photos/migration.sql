-- Editable boards + special photos (build/09 addendum).
--
-- MenuBoard is seeded from the seven CODE categories with their ids
-- FROZEN, so every existing #fragment, nav pill and redirect keeps
-- working. A board created later mints its id from its first title and
-- that id is opaque forever - renames can never break a link.
--
-- Special grows photoUrl/photoAlt: same Blob pipeline as dish photos,
-- keyed to the slot.

CREATE TABLE "MenuBoard" (
    "id" VARCHAR(30) NOT NULL,
    "title" VARCHAR(40) NOT NULL,
    "note" VARCHAR(200),
    "sortIndex" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MenuBoard_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "MenuBoard_sortIndex_idx" ON "MenuBoard"("sortIndex");

-- The seven boards, exactly as the July 2026 seed prints them.
INSERT INTO "MenuBoard" ("id", "title", "note", "sortIndex", "updatedAt") VALUES
  ('burgers', 'Burgers', 'The reason most people pull over. Mayo, lettuce, tomato, pickles and onions on every one, fries on the side.', 0, CURRENT_TIMESTAMP),
  ('dinners', 'Dinners', 'With your choice of potato, plus soup or salad.', 1, CURRENT_TIMESTAMP),
  ('sandwiches', 'Sandwiches', 'Served with fries.', 2, CURRENT_TIMESTAMP),
  ('appetizers', 'Appetizers', NULL, 3, CURRENT_TIMESTAMP),
  ('baskets', 'Baskets', 'With fries.', 4, CURRENT_TIMESTAMP),
  ('salads-sides', 'Salads & Sides', NULL, 5, CURRENT_TIMESTAMP),
  ('drinks', 'Drinks & Taps', 'Full bar: rotating drafts, can and bottle beer, wine, cocktails.', 6, CURRENT_TIMESTAMP);

-- The board ledger reads better with the seed on it, same as the dishes.
INSERT INTO "MenuEvent" ("id", "actor", "dishName", "field", "to")
VALUES ('board-seed-2026-09-22', 'seed', 'The seven boards', 'board-created', 'burgers, dinners, sandwiches, appetizers, baskets, salads-sides, drinks');

-- Special photos.
ALTER TABLE "Special" ADD COLUMN "photoUrl" VARCHAR(500);
ALTER TABLE "Special" ADD COLUMN "photoAlt" VARCHAR(120);
