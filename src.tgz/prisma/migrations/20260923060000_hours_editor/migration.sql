-- THE HOURS (build/13). Three tables, seven CHECK constraints, two indexes.
--
-- THIS MIGRATION SEEDS NOTHING. NOT ONE ROW. "No guessed hours in UI or
-- schema" (CLAUDE.md release gate) is the one copy rule build/09 did not
-- supersede: build/09 crossed veto 4 for PRICES because the July
-- transcription was frozen evidence and the regime change was written down.
-- No equivalent ruling exists for hours. The Yelp door-sign photo is an
-- undated upload for the OWNER to check his typing against, never seed
-- data. Contrast 20260923040000_feature_spots, which legally seeds four
-- rows from shipped code. scripts/check-no-seeded-hours.mjs fails the gate
-- if a row ever appears here.
--
-- The editor ships EMPTY. Absence of a HoursDay row is "UNSET", which is
-- not "closed", and the public page keeps saying "call for today's hours"
-- until the owner types his week.
--
-- ASCII ONLY, and the time regexes are written [0-9] rather than \d --
-- DEPLOY.md:104-115's console-paste trap turned every non-ASCII byte in
-- the menu seed into box-drawing characters in both branches.

-- CreateTable
CREATE TABLE "HoursDay" (
    "day" VARCHAR(3) NOT NULL,
    "closed" BOOLEAN NOT NULL DEFAULT false,
    "open" VARCHAR(5),
    "close" VARCHAR(5),
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "HoursDay_pkey" PRIMARY KEY ("day")
);

-- CreateTable
CREATE TABLE "HoursException" (
    "id" TEXT NOT NULL,
    "date" VARCHAR(10) NOT NULL,
    "endDate" VARCHAR(10),
    "closed" BOOLEAN NOT NULL DEFAULT false,
    "open" VARCHAR(5),
    "close" VARCHAR(5),
    "label" VARCHAR(60),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "HoursException_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HoursEvent" (
    "id" TEXT NOT NULL,
    "at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actor" VARCHAR(20) NOT NULL,
    "subject" VARCHAR(60) NOT NULL,
    "field" VARCHAR(24) NOT NULL,
    "from" VARCHAR(120),
    "to" VARCHAR(120),

    CONSTRAINT "HoursEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "HoursException_date_idx" ON "HoursException"("date");

-- CreateIndex
CREATE INDEX "HoursEvent_at_idx" ON "HoursEvent"("at");

-- CHECK constraints (build/13 section 1.4) -- Prisma cannot express these,
-- so they live here, the way Special's 1..3 and Booking's partySize do.

ALTER TABLE "HoursDay" ADD CONSTRAINT "HoursDay_day_check"
  CHECK ("day" IN ('mon','tue','wed','thu','fri','sat','sun'));

-- The tri-state made structural: a row is EITHER closed with no times,
-- OR open with BOTH times. No UI bug can write a half-day.
ALTER TABLE "HoursDay" ADD CONSTRAINT "HoursDay_shape_check"
  CHECK (("closed" AND "open" IS NULL AND "close" IS NULL)
      OR (NOT "closed" AND "open" IS NOT NULL AND "close" IS NOT NULL));

ALTER TABLE "HoursDay" ADD CONSTRAINT "HoursDay_time_check"
  CHECK (("open"  IS NULL OR "open"  ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$')
     AND ("close" IS NULL OR "close" ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'));

ALTER TABLE "HoursException" ADD CONSTRAINT "HoursException_date_check"
  CHECK ("date" ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
     AND ("endDate" IS NULL OR "endDate" ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'));

ALTER TABLE "HoursException" ADD CONSTRAINT "HoursException_range_check"
  CHECK ("endDate" IS NULL OR "endDate" >= "date");

ALTER TABLE "HoursException" ADD CONSTRAINT "HoursException_shape_check"
  CHECK (("closed" AND "open" IS NULL AND "close" IS NULL)
      OR (NOT "closed" AND "open" IS NOT NULL AND "close" IS NOT NULL));

ALTER TABLE "HoursException" ADD CONSTRAINT "HoursException_time_check"
  CHECK (("open"  IS NULL OR "open"  ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$')
     AND ("close" IS NULL OR "close" ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'));

-- NO uniqueness and NO exclusion constraint on "HoursException", on
-- purpose. Ranges make one wrong: UNIQUE("date") would reject the legal
-- second row, and an exclusion constraint that understood ranges would
-- have to encode the precedence rule in SQL, where it cannot be unit
-- tested. Overlap is legal data with a defined winner --
-- resolveException() in lib/hours.ts (build/13 section 1.9).
--
-- NO CHECK on "HoursEvent"."field" either. The ledger is append-only and
-- must accept a value a future wave adds without a migration.
