-- CreateEnum
CREATE TYPE "BookingKind" AS ENUM ('table', 'private_room');

-- CreateEnum
CREATE TYPE "BookingStatus" AS ENUM ('new', 'confirmed', 'declined', 'cancelled', 'no_show', 'completed');

-- CreateEnum
CREATE TYPE "TimeWindow" AS ENUM ('lunch', 'afternoon', 'evening', 'late');

-- CreateTable
CREATE TABLE "Booking" (
    "id" TEXT NOT NULL,
    "reference" VARCHAR(10) NOT NULL,
    "kind" "BookingKind" NOT NULL DEFAULT 'table',
    "status" "BookingStatus" NOT NULL DEFAULT 'new',
    "name" VARCHAR(80) NOT NULL,
    "phone" VARCHAR(30) NOT NULL,
    "phoneDigits" VARCHAR(15) NOT NULL,
    "partySize" SMALLINT NOT NULL,
    "requestedOn" DATE NOT NULL,
    "timeWindow" "TimeWindow" NOT NULL,
    "note" VARCHAR(500),
    "ipHash" CHAR(64),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "purgeAfter" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Booking_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Booking_reference_key" ON "Booking"("reference");

-- CreateIndex
CREATE INDEX "Booking_status_requestedOn_idx" ON "Booking"("status", "requestedOn");

-- CreateIndex
CREATE INDEX "Booking_purgeAfter_idx" ON "Booking"("purgeAfter");

-- CreateIndex
CREATE UNIQUE INDEX "Booking_phoneDigits_requestedOn_timeWindow_key" ON "Booking"("phoneDigits", "requestedOn", "timeWindow");
